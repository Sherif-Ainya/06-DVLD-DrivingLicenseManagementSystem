﻿using System;
using System.Data;
using System.Data.SqlClient;

namespace DVLD_DataAccess
{
	public class clsDataAccessTestAppointments
	{
		public static bool HasOpenAppointment(int LDLA_ID, int TestTypeID)
		{
			bool IsFound = false;

			SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);
			string query = "Select IsLocked From TestAppointments Where LocalDrivingLicenseApplicationID = @LDLA_ID AND TestTypeID = @TestTypeID Order By TestAppointmentID desc;";

			SqlCommand command = new SqlCommand(query, connection);
			command.Parameters.AddWithValue("@LDLA_ID", LDLA_ID);
			command.Parameters.AddWithValue("@TestTypeID", TestTypeID);

			try
			{
				connection.Open();
				object result = command.ExecuteScalar();  // It return Single Value.

				if (result != null)
				{
					IsFound = !Convert.ToBoolean(result);
				}
				connection.Close();
			}
			catch (Exception ex)
			{
				Console.WriteLine("Error: " + ex.Message);
			}
			return IsFound;
		}
		public static bool PassedThisTest(int LDLA_ID, int TestTypeID)
		{
			bool IsFound = false;

			SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);
			string query = @"Select TestResult From Tests JOIN TestAppointments On Tests.TestAppointmentID = TestAppointments.TestAppointmentID
				Where LocalDrivingLicenseApplicationID = @LDLA_ID AND TestTypeID = @TestTypeID Order By TestID desc;";

			SqlCommand command = new SqlCommand(query, connection);
			command.Parameters.AddWithValue("@LDLA_ID", LDLA_ID);
			command.Parameters.AddWithValue("@TestTypeID", TestTypeID);

			try
			{
				connection.Open();
				object result = command.ExecuteScalar();  // It return Single Value.

				if (result != null)
				{
					IsFound = Convert.ToBoolean(result);
				}
				connection.Close();
			}
			catch (Exception ex)
			{
				Console.WriteLine("Error: " + ex.Message);
			}
			return IsFound;
		}

		//

		public static bool GetTestAppointment(int TestAppointmentID, ref int TestTypeID, ref int LDLA_ID, ref DateTime AppointmentDate,
			ref decimal PaidFees, ref int CreatedByUserID, ref bool IsLocked)
		{
			bool isFound = false;

			SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);
			string query = @"SELECT * FROM TestAppointments Where TestAppointmentID = @TestAppointmentID;";

			SqlCommand cmd = new SqlCommand(query, connection);
			cmd.Parameters.AddWithValue("@TestAppointmentID", TestAppointmentID);

			try
			{
				connection.Open();
				SqlDataReader reader = cmd.ExecuteReader();

				if (reader.Read())
				{
					isFound = true;

					//TestAppointmentID = (int)reader[0];
					TestTypeID = (int)reader[1];
					LDLA_ID = (int)reader[2];
					AppointmentDate = (DateTime)reader[3];
					PaidFees = (decimal)reader[4];
					CreatedByUserID = (int)reader[5];
					IsLocked = (bool)reader[6];

					reader.Close();
				}
			}
			//catch (Exception ex)
			//{
			//}
			finally
			{
				connection.Close();
			}
			return isFound;
		}

		public static int AddNewAppointment(int TestTypeID, int LDLA_ID, DateTime AppointmentDate,
		 decimal PaidFees, int CreatedByUserID, bool IsLocked)
		{
			int AppointmentID = -1;
			SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);
			string query = @"INSERT INTO TestAppointments
        VALUES (@TestTypeID, @@LDLA_ID, @AppointmentDate, @PaidFees, @CreatedByUserID, @IsLocked, @RetakeTestApplicationID);
        SELECT SCOPE_IDENTITY();";

			SqlCommand command = new SqlCommand(query, connection);
			command.Parameters.AddWithValue("@TestTypeID", TestTypeID);
			command.Parameters.AddWithValue("@@LDLA_ID", LDLA_ID);
			command.Parameters.AddWithValue("@AppointmentDate", AppointmentDate);
			command.Parameters.AddWithValue("@PaidFees", PaidFees);
			command.Parameters.AddWithValue("@CreatedByUserID", CreatedByUserID);
			command.Parameters.AddWithValue("@IsLocked", IsLocked);
            command.Parameters.AddWithValue("@RetakeTestApplicationID", DBNull.Value);
            try
			{
				connection.Open();
				object result = command.ExecuteScalar();

				if (result != null && int.TryParse(result.ToString(), out int insertedID))
				{
					AppointmentID = insertedID;
				}
			}
			//catch (Exception ex)
			//{
			//}
			finally
			{
				connection.Close();
			}
			return AppointmentID;
		}

		public static bool UpdateAppointment(int TestAppointmentID, int TestTypeID, int LDLA_ID, DateTime AppointmentDate,
			decimal PaidFees, int CreatedByUserID, bool IsLocked)
		{
			int rowsAffected = 0;
			SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

			string query =
                @"Update TestAppointments
					SET TestTypeID = @TestTypeID, LocalDrivingLicenseApplicationID = @LDLA_ID, AppointmentDate = @AppointmentDate,
						PaidFees = @PaidFees, CreatedByUserID = @CreatedByUserID, IsLocked = @IsLocked, RetakeTestApplicationID = @RetakeTestApplicationID
					Where TestAppointmentID = @TestAppointmentID;";

			SqlCommand command = new SqlCommand(query, connection);
			command.Parameters.AddWithValue("@TestAppointmentID", TestAppointmentID);
			command.Parameters.AddWithValue("@TestTypeID", TestTypeID);
			command.Parameters.AddWithValue("@LDLA_ID", LDLA_ID);
			command.Parameters.AddWithValue("@AppointmentDate", AppointmentDate);
			command.Parameters.AddWithValue("@PaidFees", PaidFees);
			command.Parameters.AddWithValue("@CreatedByUserID", CreatedByUserID);
			command.Parameters.AddWithValue("@IsLocked", IsLocked);
            command.Parameters.AddWithValue("@RetakeTestApplicationID", DBNull.Value);

            try
			{
				connection.Open();
				rowsAffected = command.ExecuteNonQuery();
			}
			//catch (Exception ex)
			//{
			//}
			finally
			{
				connection.Close();
			}
			return (rowsAffected > 0);
		}

		public static bool DeleteAppointment(int TestAppointmentID)
		{
			int rowsAffected = 0;
			SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);
			string query = @"Delete TestAppointments WHERE TestAppointmentID = @TestAppointmentID";

			SqlCommand command = new SqlCommand(query, connection);
			command.Parameters.AddWithValue("@TestAppointmentID", TestAppointmentID);

			try
			{
				connection.Open();
				rowsAffected = command.ExecuteNonQuery();
			}
			//catch (Exception ex)
			//{
			//}
			finally
			{
				connection.Close();
			}
			return (rowsAffected > 0);
		}

		public static DataTable GetAllAppointmentsOfLocalApp_TestType(int LDLA_ID, int TestTypeID)
		{
			DataTable dt = new DataTable();
			SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

			string query = @"SELECT * FROM TestAppointments Where LocalDrivingLicenseApplicationID = @LDLA_ID AND TestTypeID = @TestTypeID Order By TestAppointmentID desc;";

			SqlCommand command = new SqlCommand(query, connection);
			command.Parameters.AddWithValue("@LDLA_ID", LDLA_ID);
			command.Parameters.AddWithValue("@TestTypeID", TestTypeID);

			try
			{
				connection.Open();
				SqlDataReader reader = command.ExecuteReader();

				if (reader.HasRows)
				{
					dt.Load(reader);
				}
				reader.Close();
			}
			//catch (Exception ex)
			//{
			//}
			finally
			{
				connection.Close();
			}
			return dt;
		}
	}
}
