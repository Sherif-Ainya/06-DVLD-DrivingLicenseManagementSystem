﻿using System;
using System.Data;
using System.Data.SqlClient;

namespace DVLD_DataAccess
{
	public class clsDataAccessDetainedLicenses
	{
		public static bool IsThisLicenseDetained(int licenseID)
		{
			bool isDetained = false;

			SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);
			//string query = "SELECT IsReleased FROM DetainedLicenses Where LicenseID = @licenseID;";
			string query = "SELECT Case WHEN IsReleased = 0 Then 1 ELSE 0 End AS IsDetained FROM DetainedLicenses Where LicenseID = @licenseID Order By IsReleased desc;";

			SqlCommand command = new SqlCommand(query, connection);
			command.Parameters.AddWithValue("@licenseID", licenseID);

			try
			{
				connection.Open();
				object result = command.ExecuteScalar();

				if (result != null)
				{
					isDetained = Convert.ToBoolean(result);
				}

				//connection.Open();
				//SqlDataReader reader = command.ExecuteReader();

				//isDetained = reader.HasRows;

				//reader.Close();
			}
			//catch (Exception ex)
			//{
			//}
			finally
			{
				connection.Close();
			}
			return isDetained;
		}

		//

		public static bool GetDetainedLicenseByLicenseID(ref int DetainID, int LicenseID, ref DateTime DetainDate, ref decimal FineFees, ref int CreatedByUserID,
			ref bool IsReleased, ref DateTime ReleaseDate, ref int ReleasedByUserID, ref int ReleaseApplicationID)
		{
			bool isFound = false;

			SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);
			string query = @"SELECT * FROM DetainedLicenses Where LicenseID = @LicenseID Order by IsReleased;";

			SqlCommand cmd = new SqlCommand(query, connection);
			cmd.Parameters.AddWithValue("@LicenseID", LicenseID);

			try
			{
				connection.Open();
				SqlDataReader reader = cmd.ExecuteReader();

				if (reader.Read())
				{
					isFound = true;
					DetainID = (int)reader[0];
					//LicenseID = (int)reader[1];
					DetainDate = (DateTime)reader[2];
					FineFees = (decimal)reader[3];
					CreatedByUserID = (int)reader[4];
					IsReleased = (bool)reader[5];

					if (reader[6] != System.DBNull.Value)
						ReleaseDate = (DateTime)reader[6];
					else
						ReleaseDate = DateTime.MinValue;

					if (reader[7] != System.DBNull.Value)
						ReleasedByUserID = (int)reader[7];
					else
						ReleasedByUserID = -1;

					if (reader[8] != System.DBNull.Value)
						ReleaseApplicationID = (int)reader[8];
					else
						ReleaseApplicationID = -1;

					reader.Close();
				}
			}
			//catch (Exception ex)
			//{
			//}
			finally
			{
				connection.Close();
			}
			return isFound;
		}

		public static bool GetDetainedLicenseByDetainID(int DetainID, ref int LicenseID, ref DateTime DetainDate, ref decimal FineFees, ref int CreatedByUserID,
			ref bool IsReleased, ref DateTime ReleaseDate, ref int ReleasedByUserID, ref int ReleaseApplicationID)
		{
			bool isFound = false;

			SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);
			string query = @"SELECT * FROM DetainedLicenses Where DetainID = @DetainID;";

			SqlCommand cmd = new SqlCommand(query, connection);
			cmd.Parameters.AddWithValue("@DetainID", DetainID);

			try
			{
				connection.Open();
				SqlDataReader reader = cmd.ExecuteReader();

				if (reader.Read())
				{
					isFound = true;
					//DetainID = (int)reader[0];
					LicenseID = (int)reader[1];
					DetainDate = (DateTime)reader[2];
					FineFees = (decimal)reader[3];
					CreatedByUserID = (int)reader[4];
					IsReleased = (bool)reader[5];

					if (reader[6] != System.DBNull.Value)
						ReleaseDate = (DateTime)reader[6];
					else
						ReleaseDate = DateTime.MinValue;

					if (reader[7] != System.DBNull.Value)
						ReleasedByUserID = (int)reader[7];
					else
						ReleasedByUserID = -1;

					if (reader[8] != System.DBNull.Value)
						ReleaseApplicationID = (int)reader[8];
					else
						ReleaseApplicationID = -1;

					reader.Close();
				}
			}
			//catch (Exception ex)
			//{
			//}
			finally
			{
				connection.Close();
			}
			return isFound;
		}

		public static int AddNewDetainedLicense(int LicenseID, DateTime DetainDate, decimal FineFees, int CreatedByUserID)
		{
			int DetainID = -1;
			SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);
			string query = @"INSERT INTO DetainedLicenses
        VALUES (@LicenseID, @DetainDate, @FineFees, @CreatedByUserID, 0, null, null, null);
        SELECT SCOPE_IDENTITY();";

			SqlCommand command = new SqlCommand(query, connection);
			command.Parameters.AddWithValue("@LicenseID", LicenseID);
			command.Parameters.AddWithValue("@DetainDate", DetainDate);
			command.Parameters.AddWithValue("@FineFees", FineFees);
			command.Parameters.AddWithValue("@CreatedByUserID", CreatedByUserID);

			try
			{
				connection.Open();
				object result = command.ExecuteScalar();

				if (result != null && int.TryParse(result.ToString(), out int insertedID))
				{
					DetainID = insertedID;
				}
			}
			//catch (Exception ex)
			//{
			//}
			finally
			{
				connection.Close();
			}
			return DetainID;
		}

		public static bool UpdateLicense(int DetainID, bool isReleased, DateTime ReleaseDate, int ReleasedByUserID, int ReleaseApplicationID)
		{
			int rowsAffected = 0;
			SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

			string query =
				@"Update DetainedLicenses
					SET IsReleased = @isReleased, ReleaseDate = @ReleaseDate, ReleasedByUserID = @ReleasedByUserID, ReleaseApplicationID = @ReleaseApplicationID
					Where DetainID = @DetainID;";

			SqlCommand command = new SqlCommand(query, connection);
			command.Parameters.AddWithValue("@DetainID", DetainID);
			command.Parameters.AddWithValue("@isReleased", isReleased);
			command.Parameters.AddWithValue("@ReleaseDate", ReleaseDate);
			command.Parameters.AddWithValue("@ReleasedByUserID", ReleasedByUserID);
			command.Parameters.AddWithValue("@ReleaseApplicationID", ReleaseApplicationID);

			try
			{
				connection.Open();
				rowsAffected = command.ExecuteNonQuery();
			}
			//catch (Exception ex)
			//{
			//}
			finally
			{
				connection.Close();
			}
			return (rowsAffected > 0);
		}

		//

		public static DataTable GetAllDetainedLicenses()
		{
			DataTable dt = new DataTable();
			SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

			string query = @"Select DetainID, DetainedLicenses.LicenseID, DetainDate, IsReleased, FineFees, ReleaseDate, People.NationalNo, FirstName + ' ' + LastName AS FullName, ReleaseApplicationID
				From DetainedLicenses JOIN Licenses ON DetainedLicenses.LicenseID = Licenses.LicenseID
				JOIN Drivers ON Licenses.DriverID = DRIVERS.DriverID JOIN People ON Drivers.PersonID = People.PersonID Order By IsReleased;";
			SqlCommand command = new SqlCommand(query, connection);

			try
			{
				connection.Open();
				SqlDataReader reader = command.ExecuteReader();

				if (reader.HasRows)
				{
					dt.Load(reader);
				}
				reader.Close();
			}
			//catch (Exception ex)
			//{
			//}
			finally
			{
				connection.Close();
			}
			return dt;
		}
	}
}
