﻿using System;
using System.Data;
using System.Data.SqlClient;

namespace DVLD_DataAccess
{
	public class clsDataAccessDrivers
	{
		public static int IsPersonDriver(int PersonID)
		{
			int driverID = -1;

			SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);
			string query = "Select DriverID From Drivers Join People ON Drivers.PersonID = People.PersonID AND People.PersonID = @PersonID;";

			SqlCommand command = new SqlCommand(query, connection);
			command.Parameters.AddWithValue("@PersonID", PersonID);

			try
			{
				connection.Open();

				object result = command.ExecuteScalar();
				if (result != null)
				{
					int.TryParse(result.ToString(), out driverID);
				}

				connection.Close();
			}
			//catch (Exception ex)
			//{
			//}
			finally
			{
				connection.Close();
			}
			return driverID;
		}
		public static int IsPersonDriver(string NationalNo)
		{
			int driverID = -1;

			SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);
			string query = "Select DriverID From Drivers Join People ON Drivers.PersonID = People.PersonID AND People.NationalNo = @NationalNo;";

			SqlCommand command = new SqlCommand(query, connection);
			command.Parameters.AddWithValue("@NationalNo", NationalNo);

			try
			{
				connection.Open();

				object result = command.ExecuteScalar();
				if (result != null)
				{
					int.TryParse(result.ToString(), out driverID);
				}

				connection.Close();
			}
			//catch (Exception ex)
			//{
			//}
			finally
			{
				connection.Close();
			}
			return driverID;
		}

		//
		public static int AddNewDriver(int PersonID, int CreatedByUser, DateTime CreatedDate)
		{
			int DriverID = -1;
			SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);
			string query = @"INSERT INTO Drivers
        VALUES (@PersonID, @CreatedByUser, @CreatedDate);
        SELECT SCOPE_IDENTITY();";

			SqlCommand command = new SqlCommand(query, connection);
			command.Parameters.AddWithValue("@PersonID", PersonID);
			command.Parameters.AddWithValue("@CreatedByUser", CreatedByUser);
			command.Parameters.AddWithValue("@CreatedDate", CreatedDate);

			try
			{
				connection.Open();
				object result = command.ExecuteScalar();

				if (result != null && int.TryParse(result.ToString(), out int insertedID))
				{
					DriverID = insertedID;
				}
			}
			//catch (Exception ex)
			//{
			//}
			finally
			{
				connection.Close();
			}
			return DriverID;
		}
		public static bool GetDriver(int DriverID, ref int PersonID, ref int CreatedByUser, ref DateTime CreatedDate)
		{
			bool isFound = false;

			SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);
			string query = @"SELECT * FROM Drivers Where DriverID = @DriverID;";

			SqlCommand cmd = new SqlCommand(query, connection);
			cmd.Parameters.AddWithValue("@DriverID", DriverID);

			try
			{
				connection.Open();
				SqlDataReader reader = cmd.ExecuteReader();

				if (reader.Read())
				{
					isFound = true;
					//DriverID = (int)reader[0];
					PersonID = (int)reader[1];
					CreatedByUser = (int)reader[2];
					CreatedDate = (DateTime)reader[3];

					reader.Close();
				}
			}
			//catch (Exception ex)
			//{
			//}
			finally
			{
				connection.Close();
			}
			return isFound;
		}
		public static DataTable GetAllDrivers()
		{
			DataTable dt = new DataTable();
			SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

			string query = "SELECT * FROM Drivers_View;";
			SqlCommand command = new SqlCommand(query, connection);

			try
			{
				connection.Open();
				SqlDataReader reader = command.ExecuteReader();

				if (reader.HasRows)
				{
					dt.Load(reader);
				}
				reader.Close();
			}
			//catch (Exception ex)
			//{
			//}
			finally
			{
				connection.Close();
			}
			return dt;
		}
	}
}
