﻿using System.Data;
using System.Data.SqlClient;

namespace DVLD_DataAccess
{
	public class clsDataAccessUsers
	{
		public static bool GetUser(int UserID, ref int PersonID, ref string UserName, ref string Password, ref bool Active)
		{
			bool isFound = false;

			SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);
			string query = @"SELECT * FROM Users Where UserID = @UserID;";

			SqlCommand cmd = new SqlCommand(query, connection);
			cmd.Parameters.AddWithValue("@UserID", UserID);

			try
			{
				connection.Open();
				SqlDataReader reader = cmd.ExecuteReader();

				if (reader.Read())
				{
					isFound = true;
					//UserID = (int)reader[0];
					PersonID = (int)reader[1];
					UserName = (string)reader[2];
					Password = (string)reader[3];
					Active = (bool)reader[4];

					reader.Close();
				}
			}
			//catch (Exception ex)
			//{
			//}
			finally
			{
				connection.Close();
			}
			return isFound;
		}
		public static bool GetUser(ref int UserID, ref int PersonID, string UserName, ref string Password, ref bool Active)
		{
			bool isFound = false;

			SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);
			string query = @"SELECT * FROM Users Where UserName = @UserName;";

			SqlCommand cmd = new SqlCommand(query, connection);
			cmd.Parameters.AddWithValue("@UserName", UserName);

			try
			{
				connection.Open();
				SqlDataReader reader = cmd.ExecuteReader();

				if (reader.Read())
				{
					isFound = true;
					UserID = (int)reader[0];
					PersonID = (int)reader[1];
					//UserName = (string)reader[2];
					Password = (string)reader[3];
					Active = (bool)reader[4];

					reader.Close();
				}
			}
			//catch (Exception ex)
			//{
			//}
			finally
			{
				connection.Close();
			}
			return isFound;
		}
		public static bool GetUser(ref int UserID, ref int PersonID, string UserName, string Password, ref bool Active)
		{
			bool isFound = false;

			SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);
			string query = @"SELECT * FROM Users Where UserName = @UserName AND Password = @Password;";

			SqlCommand cmd = new SqlCommand(query, connection);
			cmd.Parameters.AddWithValue("@UserName", UserName);
			cmd.Parameters.AddWithValue("@Password", Password);

			try
			{
				connection.Open();
				SqlDataReader reader = cmd.ExecuteReader();

				if (reader.Read())
				{
					isFound = true;
					UserID = (int)reader[0];
					PersonID = (int)reader[1];
					//UserName = (string)reader[2];
					//Password = (string)reader[3];
					Active = (bool)reader[4];

					reader.Close();
				}
			}
			//catch (Exception ex)
			//{
			//}
			finally
			{
				connection.Close();
			}
			return isFound;
		}

		public static int AddNewUser(int PersonID, string UserName, string Password, bool Active)
		{
			int UserID = -1;
			SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);
			string query = @"INSERT INTO Users
        VALUES (@PersonID, @UserName, @Password, @IsActive);
        SELECT SCOPE_IDENTITY();";

			SqlCommand command = new SqlCommand(query, connection);
			command.Parameters.AddWithValue("@PersonID", PersonID);
			command.Parameters.AddWithValue("@UserName", UserName);
			command.Parameters.AddWithValue("@Password", Password);
			command.Parameters.AddWithValue("@IsActive", Active);

			try
			{
				connection.Open();
				object result = command.ExecuteScalar();

				if (result != null && int.TryParse(result.ToString(), out int insertedID))
				{
					UserID = insertedID;
				}
			}
			//catch (Exception ex)
			//{
			//}
			finally
			{
				connection.Close();
			}
			return UserID;
		}
		public static bool UpdateUser(int UserID, string UserName, string Password, bool Active)
		{
			int rowsAffected = 0;
			SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

			string query =
				@"Update Users
					SET UserName = @UserName, Password = @Password, IsActive = @IsActive
					Where UserID = @UserID;";

			SqlCommand command = new SqlCommand(query, connection);
			command.Parameters.AddWithValue("@UserID", UserID);
			command.Parameters.AddWithValue("@UserName", UserName);
			command.Parameters.AddWithValue("@Password", Password);
			command.Parameters.AddWithValue("@IsActive", Active);

			try
			{
				connection.Open();
				rowsAffected = command.ExecuteNonQuery();
			}
			//catch (Exception ex)
			//{
			//}
			finally
			{
				connection.Close();
			}
			return (rowsAffected > 0);
		}

		public static bool DeleteUser(int UserID)
		{
			int rowsAffected = 0;
			SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);
			string query = @"Delete Users WHERE UserID = @UserID";

			SqlCommand command = new SqlCommand(query, connection);
			command.Parameters.AddWithValue("@UserID", UserID);

			try
			{
				connection.Open();
				rowsAffected = command.ExecuteNonQuery();
			}
			//catch (Exception ex)
			//{
			//}
			finally
			{
				connection.Close();
			}
			return (rowsAffected > 0);
		}
		public static bool DeleteUser(string UserName, string Password)
		{
			int rowsAffected = 0;
			SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);
			string query = @"Delete Users WHERE UserName = @UserName, Password = @Password;";

			SqlCommand command = new SqlCommand(query, connection);
			command.Parameters.AddWithValue("@UserName", UserName);
			command.Parameters.AddWithValue("@Password", Password);

			try
			{
				connection.Open();
				rowsAffected = command.ExecuteNonQuery();
			}
			//catch (Exception ex)
			//{
			//}
			finally
			{
				connection.Close();
			}
			return (rowsAffected > 0);
		}

		public static bool IsUserExist(int UserID)
		{
			bool isFound = false;

			SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);
			string query = "SELECT Found = 1 FROM Users WHERE UserID = @UserID";

			SqlCommand command = new SqlCommand(query, connection);
			command.Parameters.AddWithValue("@UserID", UserID);

			try
			{
				connection.Open();
				SqlDataReader reader = command.ExecuteReader();

				isFound = reader.HasRows;

				reader.Close();
			}
			//catch (Exception ex)
			//{
			//}
			finally
			{
				connection.Close();
			}
			return isFound;
		}
		public static bool IsUserExist(string userName)
		{
			bool isFound = false;

			SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);
			string query = "SELECT Found = 1 FROM Users WHERE userName = @userName";

			SqlCommand command = new SqlCommand(query, connection);
			command.Parameters.AddWithValue("@userName", userName);

			try
			{
				connection.Open();
				SqlDataReader reader = command.ExecuteReader();

				isFound = reader.HasRows;

				reader.Close();
			}
			//catch (Exception ex)
			//{
			//}
			finally
			{
				connection.Close();
			}
			return isFound;
		}
		public static bool IsUserExist(string userName, string password)
		{
			bool isFound = false;

			SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);
			string query = "SELECT Found = 1 FROM Users WHERE UserName = @userName, Password = @Password";

			SqlCommand command = new SqlCommand(query, connection);
			command.Parameters.AddWithValue("@userName", userName);
			command.Parameters.AddWithValue("@Password", password);

			try
			{
				connection.Open();
				SqlDataReader reader = command.ExecuteReader();

				isFound = reader.HasRows;

				reader.Close();
			}
			//catch (Exception ex)
			//{
			//}
			finally
			{
				connection.Close();
			}
			return isFound;
		}

		public static DataTable GetAllUsers()
		{
			DataTable dt = new DataTable();
			SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

			//string query = "SELECT * FROM Users INNER JOIN People ON Users.PersonID = People.PersonID;";
			string query = @"SELECT UserID, Users.PersonID,
				Case
					WHEN ThirdName is Null Then FirstName + ' ' + SecondName + ' ' + LastName ELSE FirstName + ' ' + ThirdName + ' ' + SecondName + ' ' + LastName End AS FullName,
				UserName, Password, IsActive
				FROM Users INNER JOIN People ON Users.PersonID = People.PersonID;";
			SqlCommand command = new SqlCommand(query, connection);

			try
			{
				connection.Open();
				SqlDataReader reader = command.ExecuteReader();

				if (reader.HasRows)
				{
					dt.Load(reader);
				}
				reader.Close();
			}
			//catch (Exception ex)
			//{
			//}
			finally
			{
				connection.Close();
			}
			return dt;
		}
	}
}
