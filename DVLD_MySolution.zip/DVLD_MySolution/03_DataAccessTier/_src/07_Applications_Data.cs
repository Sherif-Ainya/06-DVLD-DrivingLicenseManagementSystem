﻿using System;
using System.Data;
using System.Data.SqlClient;

namespace DVLD_DataAccess
{
	public class clsDataAccessApplications
	{
		public static bool GetApplication(int ApplicationID, ref int ApplicationPersonID, ref DateTime ApplicationDateTime, ref int ApplicationTypeID,
			ref byte ApplicationStatus, ref DateTime LastStatusDate, ref decimal PaidFees, ref int CreatedByUserID)
		{
			bool isFound = false;

			SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);
			string query = @"SELECT * FROM Applications Where ApplicationID = @ApplicationID;";

			SqlCommand cmd = new SqlCommand(query, connection);
			cmd.Parameters.AddWithValue("@ApplicationID", ApplicationID);

			try
			{
				connection.Open();
				SqlDataReader reader = cmd.ExecuteReader();

				if (reader.Read())
				{
					isFound = true;
					//ApplicationID = (int)reader[0];
					ApplicationPersonID = (int)reader[1];
					ApplicationDateTime = (DateTime)reader[2];
					ApplicationTypeID = (int)reader[3];
					ApplicationStatus = (byte)reader[4];
					LastStatusDate = (DateTime)reader[5];
					PaidFees = (decimal)reader[6];
					CreatedByUserID = (int)reader[7];

					reader.Close();
				}
			}
			//catch (Exception ex)
			//{
			//}
			finally
			{
				connection.Close();
			}
			return isFound;
		}

		public static int AddNewApplication(int ApplicationPersonID, DateTime ApplicationDateTime, int ApplicationTypeID,
			byte ApplicationStatus, DateTime LastStatusDate, decimal PaidFees, int CreatedByUserID)
		{
			int ApplicationID = -1;
			SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);
			string query = @"INSERT INTO Applications
        VALUES (@ApplicationPersonID, @ApplicationDateTime, @ApplicationTypeID, @ApplicationStatus, @LastStatusDate, @PaidFees, @CreatedByUserID);
        SELECT SCOPE_IDENTITY();";

			SqlCommand command = new SqlCommand(query, connection);
			command.Parameters.AddWithValue("@ApplicationPersonID", ApplicationPersonID);
			command.Parameters.AddWithValue("@ApplicationDateTime", ApplicationDateTime);
			command.Parameters.AddWithValue("@ApplicationTypeID", ApplicationTypeID);
			command.Parameters.AddWithValue("@ApplicationStatus", ApplicationStatus);
			command.Parameters.AddWithValue("@LastStatusDate", LastStatusDate);
			command.Parameters.AddWithValue("@PaidFees", PaidFees);
			command.Parameters.AddWithValue("@CreatedByUserID", CreatedByUserID);

			try
			{
				connection.Open();
				object result = command.ExecuteScalar();

				if (result != null && int.TryParse(result.ToString(), out int insertedID))
				{
					ApplicationID = insertedID;
				}
			}
			//catch (Exception ex)
			//{
			//}
			finally
			{
				connection.Close();
			}
			return ApplicationID;
		}

		public static bool UpdateApplication(int ApplicationID, int ApplicationPersonID, DateTime ApplicationDateTime, int ApplicationTypeID,
			byte ApplicationStatus, DateTime LastStatusDate, decimal PaidFees, int CreatedByUserID)
		{
			int rowsAffected = 0;
			SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

			string query =
				@"Update Applications
					SET ApplicationPersonID = @ApplicationPersonID, ApplicationDateTime = @ApplicationDateTime, ApplicationTypeID = @ApplicationTypeID,
						ApplicationStatus = @ApplicationStatus, LastStatusDate = @LastStatusDate, PaidFees = @PaidFees, CreatedByUserID = @CreatedByUserID
					Where ApplicationID = @ApplicationID;";

			SqlCommand command = new SqlCommand(query, connection);
			command.Parameters.AddWithValue("@ApplicationID", ApplicationID);
			command.Parameters.AddWithValue("@ApplicationPersonID", ApplicationPersonID);
			command.Parameters.AddWithValue("@ApplicationDateTime", ApplicationDateTime);
			command.Parameters.AddWithValue("@ApplicationTypeID", ApplicationTypeID);
			command.Parameters.AddWithValue("@ApplicationStatus", ApplicationStatus);
			command.Parameters.AddWithValue("@LastStatusDate", LastStatusDate);
			command.Parameters.AddWithValue("@PaidFees", PaidFees);
			command.Parameters.AddWithValue("@CreatedByUserID", CreatedByUserID);

			try
			{
				connection.Open();
				rowsAffected = command.ExecuteNonQuery();
			}
			//catch (Exception ex)
			//{
			//}
			finally
			{
				connection.Close();
			}
			return (rowsAffected > 0);
		}

		public static bool DeleteApplicatoin(int ApplicationID)
		{
			int rowsAffected = 0;
			SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);
			string query = @"Delete Applications WHERE ApplicationID = @ApplicationID";

			SqlCommand command = new SqlCommand(query, connection);
			command.Parameters.AddWithValue("@ApplicationID", ApplicationID);

			try
			{
				connection.Open();
				rowsAffected = command.ExecuteNonQuery();
			}
			//catch (Exception ex)
			//{
			//}
			finally
			{
				connection.Close();
			}
			return (rowsAffected > 0);
		}

		public static DataTable GetAllApplications()
		{
			DataTable dt = new DataTable();
			SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

			string query = @"SELECT * FROM Applications;";

			SqlCommand command = new SqlCommand(query, connection);

			try
			{
				connection.Open();
				SqlDataReader reader = command.ExecuteReader();

				if (reader.HasRows)
				{
					dt.Load(reader);
				}
				reader.Close();
			}
			//catch (Exception ex)
			//{
			//}
			finally
			{
				connection.Close();
			}
			return dt;
		}
	}
}
