﻿using System;
using System.Data;
using System.Data.SqlClient;

namespace DVLD_DataAccess
{
	public class clsDataAccessInternationDL
	{
		public static int IsThisLocalDLHasInternationalDL(int LocalDL_ID)
		{
			int intDL_ID = -1;

			SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);
			string query = @"Select InternationalLicenseID From InternationalLicenses Join Licenses
				ON InternationalLicenses.IssuedUsingLocalLicenseID = Licenses.LicenseID AND Licenses.LicenseID = @LocalDL_ID;";

			SqlCommand command = new SqlCommand(query, connection);
			command.Parameters.AddWithValue("@LocalDL_ID", LocalDL_ID);

			try
			{
				connection.Open();

				object result = command.ExecuteScalar();
				if (result != null)
				{
					int.TryParse(result.ToString(), out intDL_ID);
				}

				connection.Close();
			}
			//catch (Exception ex)
			//{
			//}
			finally
			{
				connection.Close();
			}
			return intDL_ID;
		}

		//

		public static bool GetIntL_ID(int InternationalLicenseID, ref int ApplicationID, ref int DriverID, ref int IssuedUsingLocalLicenseID,
			ref DateTime IssueDate, ref DateTime ExpirationDate, ref bool IsActive, ref int CreatedByUserID)
		{
			bool isFound = false;

			SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);
			string query = @"SELECT * FROM InternationalLicenses Where InternationalLicenseID = @InternationalLicenseID;";

			SqlCommand cmd = new SqlCommand(query, connection);
			cmd.Parameters.AddWithValue("@InternationalLicenseID", InternationalLicenseID);

			try
			{
				connection.Open();
				SqlDataReader reader = cmd.ExecuteReader();

				if (reader.Read())
				{
					isFound = true;
					//InternationalLicenseID = (int)reader[0];
					ApplicationID = (int)reader[1];
					DriverID = (int)reader[2];
					IssuedUsingLocalLicenseID = (int)reader[3];
					IssueDate = (DateTime)reader[4];
					ExpirationDate = (DateTime)reader[5];
					IsActive = (bool)reader[6];
					CreatedByUserID = (int)reader[7];

					reader.Close();
				}
			}
			//catch (Exception ex)
			//{
			//}
			finally
			{
				connection.Close();
			}
			return isFound;
		}

		public static int AddNewIntL(int ApplicationID, int DriverID, int IssuedUsingLocalLicenseID,
			DateTime IssueDate, DateTime ExpirationDate, bool IsActive, int CreatedByUserID)
		{
			int Inter_LID = -1;
			SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);
			string query = @"INSERT INTO InternationalLicenses
        VALUES (@ApplicationID, @DriverID, @IssuedUsingLocalLicenseID, @IssueDate, @ExpirationDate, @IsActive, @CreatedByUserID);
        SELECT SCOPE_IDENTITY();";

			SqlCommand command = new SqlCommand(query, connection);
			command.Parameters.AddWithValue("@ApplicationID", ApplicationID);
			command.Parameters.AddWithValue("@DriverID", DriverID);
			command.Parameters.AddWithValue("@IssuedUsingLocalLicenseID", IssuedUsingLocalLicenseID);
			command.Parameters.AddWithValue("@IssueDate", IssueDate);
			command.Parameters.AddWithValue("@ExpirationDate", ExpirationDate);
			command.Parameters.AddWithValue("@IsActive", IsActive);
			command.Parameters.AddWithValue("@CreatedByUserID", CreatedByUserID);

			try
			{
				connection.Open();
				object result = command.ExecuteScalar();

				if (result != null && int.TryParse(result.ToString(), out int insertedID))
				{
					Inter_LID = insertedID;
				}
			}
			//catch (Exception ex)
			//{
			//}
			finally
			{
				connection.Close();
			}
			return Inter_LID;
		}

		public static bool UpdateIntL(int IntL_ID, bool Active)
		{
			int rowsAffected = 0;
			SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

			string query =
				@"Update InternationalLicenses
					SET IsActive = @IsActive
					Where InternationalLicenseID = @IntL_ID;";

			SqlCommand command = new SqlCommand(query, connection);
			command.Parameters.AddWithValue("@IntL_ID", IntL_ID);
			command.Parameters.AddWithValue("@IsActive", Active);

			try
			{
				connection.Open();
				rowsAffected = command.ExecuteNonQuery();
			}
			//catch (Exception ex)
			//{
			//}
			finally
			{
				connection.Close();
			}
			return (rowsAffected > 0);
		}

		//
		public static DataTable GetAll_InDL()
		{
			DataTable dt = new DataTable();
			SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

			string query = @"SELECT * FROM InternationalLicenses;";

			SqlCommand command = new SqlCommand(query, connection);

			try
			{
				connection.Open();
				SqlDataReader reader = command.ExecuteReader();

				if (reader.HasRows)
				{
					dt.Load(reader);
				}
				reader.Close();
			}
			//catch (Exception ex)
			//{
			//}
			finally
			{
				connection.Close();
			}
			return dt;
		}
		public static DataTable GetAll_IntLicensesForPerson(int personID)
		{
			DataTable dt = new DataTable();
			SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

			string query = @"Select InternationalLicenseID, ApplicationID, IssuedUsingLocalLicenseID, IssueDate, ExpirationDate, IsActive
				From InternationalLicenses JOIN Drivers On InternationalLicenses.DriverID = Drivers.DriverID
				Where Drivers.PersonID = (Select PersonID From People Where PersonID = @personID) Order By IsActive desc;";
			SqlCommand command = new SqlCommand(query, connection);
			command.Parameters.AddWithValue("@personID", personID);

			try
			{
				connection.Open();
				SqlDataReader reader = command.ExecuteReader();

				if (reader.HasRows)
				{
					dt.Load(reader);
				}
				reader.Close();
			}
			//catch (Exception ex)
			//{
			//}
			finally
			{
				connection.Close();
			}
			return dt;
		}
		public static DataTable GetAll_IntLicensesForPerson(string nationalNo)
		{
			DataTable dt = new DataTable();
			SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

			string query = @"Select InternationalLicenseID, ApplicationID, IssuedUsingLocalLicenseID, IssueDate, ExpirationDate, IsActive
				From InternationalLicenses JOIN Drivers On InternationalLicenses.DriverID = Drivers.DriverID
				Where Drivers.PersonID = (Select PersonID From People Where NationalNo = @nationalNo) Order By IsActive desc;";
			SqlCommand command = new SqlCommand(query, connection);
			command.Parameters.AddWithValue("@nationalNo", nationalNo);

			try
			{
				connection.Open();
				SqlDataReader reader = command.ExecuteReader();

				if (reader.HasRows)
				{
					dt.Load(reader);
				}
				reader.Close();
			}
			//catch (Exception ex)
			//{
			//}
			finally
			{
				connection.Close();
			}
			return dt;
		}
	}
}
