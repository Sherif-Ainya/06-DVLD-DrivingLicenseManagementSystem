﻿using System;
using System.Data;
using System.Data.SqlClient;

namespace DVLD_DataAccess
{
	public class clsDataAccessLicenseClasses
	{
		public static bool GetLicenseClass(int LicenseClassID, ref string ClassName, ref string ClassDescription,
			ref byte MinimumAllowedAge, ref byte DefaultValidittyLength, ref decimal ClassFees)
		{
			bool isFound = false;

			SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);
			string query = @"SELECT * FROM LicenseClasses Where LicenseClassID = @LicenseClassID;";

			SqlCommand cmd = new SqlCommand(query, connection);
			cmd.Parameters.AddWithValue("@LicenseClassID", LicenseClassID);

			try
			{
				connection.Open();
				SqlDataReader reader = cmd.ExecuteReader();

				if (reader.Read())
				{
					isFound = true;
					//LicenseClassID = (int)reader[0];
					ClassName = (string)reader[1];
					ClassDescription = (string)reader[2];
					MinimumAllowedAge = (byte)reader[3];
					DefaultValidittyLength = (byte)reader[4];
					ClassFees = (decimal)reader[5];

					reader.Close();
				}
			}
			//catch (Exception ex)
			//{
			//	connection.Close();
			//	isFound = false;
			//}
			finally
			{
				connection.Close();
			}
			return isFound;
		}
		public static bool UpdateLicenseClass(int LicenseClassID, string ClassName, string ClassDescription,
			 byte MinimumAllowedAge, byte DefaultValidittyLength, decimal ClassFees)
		{
			int rowsAffected = 0;
			SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

			string query =
				@"Update LicenseClasses
					SET ClassName = @ClassName, ClassDescription = @ClassDescription, MinimumAllowedAge = @MinimumAllowedAge,
						DefaultValidityLength = @DefaultValidityLength, ClassFees = @ClassFees
					Where LicenseClassID = @LicenseClassID;";

			SqlCommand command = new SqlCommand(query, connection);
			command.Parameters.AddWithValue("@LicenseClassID", LicenseClassID);
			command.Parameters.AddWithValue("@ClassName", ClassName);
			command.Parameters.AddWithValue("@ClassDescription", ClassDescription);
			command.Parameters.AddWithValue("@MinimumAllowedAge", MinimumAllowedAge);
			command.Parameters.AddWithValue("@DefaultValidityLength", DefaultValidittyLength);
			command.Parameters.AddWithValue("@ClassFees", ClassFees);

			try
			{
				connection.Open();
				rowsAffected = command.ExecuteNonQuery();
			}
			catch (Exception ex)
			{
				connection.Close();
				return false;
			}
			finally
			{
				connection.Close();
			}
			return (rowsAffected > 0);
		}
		public static DataTable GetAllLicenseClasses()
		{
			DataTable dt = new DataTable();
			SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

			string query = @"SELECT * FROM LicenseClasses;";
			SqlCommand command = new SqlCommand(query, connection);

			try
			{
				connection.Open();
				SqlDataReader reader = command.ExecuteReader();

				if (reader.HasRows)
				{
					dt.Load(reader);
				}
				reader.Close();
			}
			//catch (Exception ex)
			//{
			//}
			finally
			{
				connection.Close();
			}
			return dt;
		}
	}
}
