﻿using System;
using System.Data;
using System.Data.SqlClient;

namespace DVLD_DataAccess
{
	public class clsDataAccessApplicationTypes
	{
		public static bool GetApplicationType(int applicationTypeID, ref string applicationTypeTitle, ref decimal applicationTypeFees)
		{
			bool isFound = false;

			SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);
			string query = @"SELECT * FROM ApplicationTypes Where ApplicationTypeID = @ApplicationTypeID;";

			SqlCommand cmd = new SqlCommand(query, connection);
			cmd.Parameters.AddWithValue("@ApplicationTypeID", applicationTypeID);

			try
			{
				connection.Open();
				SqlDataReader reader = cmd.ExecuteReader();

				if (reader.Read())
				{
					isFound = true;
					//applicationTypeID = (int)reader[0];
					applicationTypeTitle = (string)reader[1];
					applicationTypeFees = (decimal)reader[2];

					reader.Close();
				}
			}
			//catch (Exception ex)
			//{
			//	connection.Close();
			//	isFound = false;
			//}
			finally
			{
				connection.Close();
			}
			return isFound;
		}
		public static bool UpdateApplicationType(int applicationTypeID, string applicationTypeTitle, decimal applicationTypeFees)
		{
			int rowsAffected = 0;
			SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

			string query =
				@"Update ApplicationTypes
					SET ApplicationTypeTitle = @ApplicationTypeTitle, ApplicationFees = @ApplicationFees
					Where ApplicationTypeID = @ApplicationTypeID;";

			SqlCommand command = new SqlCommand(query, connection);
			command.Parameters.AddWithValue("@ApplicationTypeID", applicationTypeID);
			command.Parameters.AddWithValue("@ApplicationTypeTitle", applicationTypeTitle);
			command.Parameters.AddWithValue("@ApplicationFees", applicationTypeFees);

			try
			{
				connection.Open();
				rowsAffected = command.ExecuteNonQuery();
			}
			catch (Exception ex)
			{
				connection.Close();
				return false;
			}
			finally
			{
				connection.Close();
			}
			return (rowsAffected > 0);
		}
		public static DataTable GetAllApplicationTypes()
		{
			DataTable dt = new DataTable();
			SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

			string query = @"SELECT * FROM ApplicationTypes;";
			SqlCommand command = new SqlCommand(query, connection);

			try
			{
				connection.Open();
				SqlDataReader reader = command.ExecuteReader();

				if (reader.HasRows)
				{
					dt.Load(reader);
				}
				reader.Close();
			}
			//catch (Exception ex)
			//{
			//}
			finally
			{
				connection.Close();
			}
			return dt;
		}
	}
}
