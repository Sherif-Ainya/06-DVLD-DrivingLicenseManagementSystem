﻿using System;
using System.Data;
using System.Data.SqlClient;

namespace DVLD_DataAccess
{
	public class clsDataAccessTestTypes
	{
		public static bool GetTestType(int TestTypeID, ref string TestTypeTitle, ref string TestTypeDescription, ref decimal TestTypeFees)
		{
			bool isFound = false;

			SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);
			string query = @"SELECT * FROM TestTypes Where TestTypeID = @TestTypeID;";

			SqlCommand cmd = new SqlCommand(query, connection);
			cmd.Parameters.AddWithValue("@TestTypeID", TestTypeID);

			try
			{
				connection.Open();
				SqlDataReader reader = cmd.ExecuteReader();

				if (reader.Read())
				{
					isFound = true;
					//TestTypeID = (int)reader[0];
					TestTypeTitle = (string)reader[1];
					TestTypeDescription = (string)reader[2];
					TestTypeFees = (decimal)reader[3];

					reader.Close();
				}
			}
			//catch (Exception ex)
			//{
			//	connection.Close();
			//	isFound = false;
			//}
			finally
			{
				connection.Close();
			}
			return isFound;
		}
		public static bool UpdateTestType(int TestTypeID, string TestTypeTitle, string TestTypeDescription, decimal TestTypeFees)
		{
			int rowsAffected = 0;
			SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

			string query =
				@"Update TestTypes
					SET TestTypeTitle = @TestTypeTitle, TestTypeDescription = @TestTypeDescription, TestTypeFees = @TestTypeFees
					Where TestTypeID = @TestTypeID;";

			SqlCommand command = new SqlCommand(query, connection);
			command.Parameters.AddWithValue("@TestTypeID", TestTypeID);
			command.Parameters.AddWithValue("@TestTypeTitle", TestTypeTitle);
			command.Parameters.AddWithValue("@TestTypeDescription", TestTypeDescription);
			command.Parameters.AddWithValue("@TestTypeFees", TestTypeFees);

			try
			{
				connection.Open();
				rowsAffected = command.ExecuteNonQuery();
			}
			catch (Exception ex)
			{
				connection.Close();
				return false;
			}
			finally
			{
				connection.Close();
			}
			return (rowsAffected > 0);
		}
		public static DataTable GetAllTestTypes()
		{
			DataTable dt = new DataTable();
			SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

			string query = @"SELECT * FROM TestTypes;";
			SqlCommand command = new SqlCommand(query, connection);

			try
			{
				connection.Open();
				SqlDataReader reader = command.ExecuteReader();

				if (reader.HasRows)
				{
					dt.Load(reader);
				}
				reader.Close();
			}
			//catch (Exception ex)
			//{
			//}
			finally
			{
				connection.Close();
			}
			return dt;
		}
	}
}
