﻿using System;
using System.Data;
using System.Data.SqlClient;

namespace DVLD_DataAccess
{
	public class clsDataAccessLicenses
	{
		public static bool GetLicenseByLDLA_ID(int LDLA_ID, ref int LicenseID, ref int ApplicationID, ref int DriverID, ref int LicenseClass,
			ref DateTime IssueDate, ref DateTime ExpirationDate, ref string Notes, ref decimal PaidFees, ref bool IsActive, ref byte IssueReason, ref int CreatedByUserID)
		{
			bool isFound = false;

			SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);
			string query = @"Select Licenses.* From Licenses Join Applications On Licenses.ApplicationID = Applications.ApplicationID
				Where Licenses.ApplicationID = (Select ApplicationID From LocalDrivingLicenseApplications Where LocalDrivingLicenseApplicationID = @LDLA_ID);";

			SqlCommand cmd = new SqlCommand(query, connection);
			cmd.Parameters.AddWithValue("@LDLA_ID", LDLA_ID);

			try
			{
				connection.Open();
				SqlDataReader reader = cmd.ExecuteReader();

				if (reader.Read())
				{
					isFound = true;
					LicenseID = (int)reader[0];
					ApplicationID = (int)reader[1];
					DriverID = (int)reader[2];
					LicenseClass = (int)reader[3];
					IssueDate = (DateTime)reader[4];
					ExpirationDate = (DateTime)reader[5];

					if (reader[6] != System.DBNull.Value)
						Notes = (string)reader[6];
					else
						Notes = "";

					PaidFees = (decimal)reader[7];
					IsActive = (bool)reader[8];
					IssueReason = (byte)reader[9];
					CreatedByUserID = (int)reader[10];

					reader.Close();
				}
			}
			//catch (Exception ex)
			//{
			//}
			finally
			{
				connection.Close();
			}
			return isFound;
		}
		public static bool GetLicenseByLicenseID(int LicenseID, ref int ApplicationID, ref int DriverID, ref int LicenseClass,
			ref DateTime IssueDate, ref DateTime ExpirationDate, ref string Notes, ref decimal PaidFees, ref bool IsActive, ref byte IssueReason, ref int CreatedByUserID)
		{
			bool isFound = false;

			SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);
			string query = @"SELECT * FROM Licenses Where LicenseID = @LicenseID;";

			SqlCommand cmd = new SqlCommand(query, connection);
			cmd.Parameters.AddWithValue("@LicenseID", LicenseID);

			try
			{
				connection.Open();
				SqlDataReader reader = cmd.ExecuteReader();

				if (reader.Read())
				{
					isFound = true;
					//LicenseID = (int)reader[0];
					ApplicationID = (int)reader[1];
					DriverID = (int)reader[2];
					LicenseClass = (int)reader[3];
					IssueDate = (DateTime)reader[4];
					ExpirationDate = (DateTime)reader[5];

					if (reader[6] != System.DBNull.Value)
						Notes = (string)reader[6];
					else
						Notes = "";

					PaidFees = (decimal)reader[7];
					IsActive = (bool)reader[8];
					IssueReason = (byte)reader[9];
					CreatedByUserID = (int)reader[10];

					reader.Close();
				}
			}
			//catch (Exception ex)
			//{
			//}
			finally
			{
				connection.Close();
			}
			return isFound;
		}

		//

		public static int AddNewLicense(int ApplicationID, int DriverID, int LicenseClass,
			DateTime IssueDate, DateTime ExpirationDate, string Notes, decimal PaidFees, bool IsActive, byte IssueReason, int CreatedByUserID)
		{
			int LicenseID = -1;
			SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);
			string query = @"INSERT INTO Licenses
        VALUES (@ApplicationID, @DriverID, @LicenseClass, @IssueDate, @ExpirationDate, @Notes, @PaidFees, @IsActive, @IssueReason, @CreatedByUserID);
        SELECT SCOPE_IDENTITY();";

			SqlCommand command = new SqlCommand(query, connection);
			command.Parameters.AddWithValue("@ApplicationID", ApplicationID);
			command.Parameters.AddWithValue("@DriverID", DriverID);
			command.Parameters.AddWithValue("@LicenseClass", LicenseClass);
			command.Parameters.AddWithValue("@IssueDate", IssueDate);
			command.Parameters.AddWithValue("@ExpirationDate", ExpirationDate);
			command.Parameters.AddWithValue("@Notes", Notes);
			command.Parameters.AddWithValue("@PaidFees", PaidFees);
			command.Parameters.AddWithValue("@IsActive", IsActive);
			command.Parameters.AddWithValue("@IssueReason", IssueReason);
			command.Parameters.AddWithValue("@CreatedByUserID", CreatedByUserID);

			try
			{
				connection.Open();
				object result = command.ExecuteScalar();

				if (result != null && int.TryParse(result.ToString(), out int insertedID))
				{
					LicenseID = insertedID;
				}
			}
			//catch (Exception ex)
			//{
			//}
			finally
			{
				connection.Close();
			}
			return LicenseID;
		}

		public static bool UpdateLicense(int LicenseID, bool Active)
		{
			int rowsAffected = 0;
			SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

			string query =
				@"Update Licenses
					SET IsActive = @IsActive
					Where LicenseID = @LicenseID;";

			SqlCommand command = new SqlCommand(query, connection);
			command.Parameters.AddWithValue("@LicenseID", LicenseID);
			command.Parameters.AddWithValue("@IsActive", Active);

			try
			{
				connection.Open();
				rowsAffected = command.ExecuteNonQuery();
			}
			//catch (Exception ex)
			//{
			//}
			finally
			{
				connection.Close();
			}
			return (rowsAffected > 0);
		}

		//
		public static DataTable GetAllLocalLicensesForPerson(int personID)
		{
			DataTable dt = new DataTable();
			SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

			string query = @"Select LicenseID, ApplicationID, ClassName, IssueDate, ExpirationDate, IsActive
				From Licenses JOIN Drivers On Licenses.DriverID = Drivers.DriverID JOIN LicenseClasses On Licenses.LicenseClass = LicenseClasses.LicenseClassID
				Where Drivers.PersonID = (Select PersonID From People Where PersonID = @personID) Order By IsActive desc";
			SqlCommand command = new SqlCommand(query, connection);
			command.Parameters.AddWithValue("@personID", personID);

			try
			{
				connection.Open();
				SqlDataReader reader = command.ExecuteReader();

				if (reader.HasRows)
				{
					dt.Load(reader);
				}
				reader.Close();
			}
			//catch (Exception ex)
			//{
			//}
			finally
			{
				connection.Close();
			}
			return dt;
		}
		public static DataTable GetAllLocalLicensesForPerson(string nationalNo)
		{
			DataTable dt = new DataTable();
			SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

			string query = @"Select LicenseID, ApplicationID, ClassName, IssueDate, ExpirationDate, IsActive
				From Licenses JOIN Drivers On Licenses.DriverID = Drivers.DriverID JOIN LicenseClasses On Licenses.LicenseClass = LicenseClasses.LicenseClassID
				Where Drivers.PersonID = (Select PersonID From People Where NationalNo = @nationalNo) Order By IsActive desc";
			SqlCommand command = new SqlCommand(query, connection);
			command.Parameters.AddWithValue("@nationalNo", nationalNo);

			try
			{
				connection.Open();
				SqlDataReader reader = command.ExecuteReader();

				if (reader.HasRows)
				{
					dt.Load(reader);
				}
				reader.Close();
			}
			//catch (Exception ex)
			//{
			//}
			finally
			{
				connection.Close();
			}
			return dt;
		}
	}
}
