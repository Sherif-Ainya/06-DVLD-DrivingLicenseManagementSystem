﻿using System.Data;
using System.Data.SqlClient;

namespace DVLD_DataAccess
{
	public class clsDataAccessTests
	{
		public static bool GetTest(int TestID, ref int TestAppointmentID, ref bool TestResult, ref string Notes, ref int CreatedByUserID)
		{
			bool isFound = false;

			SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);
			string query = @"SELECT * FROM Tests Where TestID = @TestID;";

			SqlCommand cmd = new SqlCommand(query, connection);
			cmd.Parameters.AddWithValue("@TestID", TestID);

			try
			{
				connection.Open();
				SqlDataReader reader = cmd.ExecuteReader();

				if (reader.Read())
				{
					isFound = true;

					TestID = (int)reader[0];
					TestAppointmentID = (int)reader[1];
					TestResult = (bool)reader[2];
					Notes = (string)reader[3];
					CreatedByUserID = (int)reader[4];

					reader.Close();
				}
			}
			//catch (Exception ex)
			//{
			//}
			finally
			{
				connection.Close();
			}
			return isFound;
		}

		public static int AddNewTest(int TestAppointmentID, bool TestResult, string Notes, int CreatedByUserID)
		{
			int TestID = -1;
			SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);
			string query = @"INSERT INTO Tests
					VALUES (@TestAppointmentID, @TestResult, @Notes, @CreatedByUserID);
        SELECT SCOPE_IDENTITY();";

			SqlCommand command = new SqlCommand(query, connection);
			command.Parameters.AddWithValue("@TestAppointmentID", TestAppointmentID);
			command.Parameters.AddWithValue("@TestResult", TestResult);
			command.Parameters.AddWithValue("@Notes", Notes);
			command.Parameters.AddWithValue("@CreatedByUserID", CreatedByUserID);

			try
			{
				connection.Open();
				object result = command.ExecuteScalar();

				if (result != null && int.TryParse(result.ToString(), out int insertedID))
				{
					TestID = insertedID;
				}
			}
			//catch (Exception ex)
			//{
			//}
			finally
			{
				connection.Close();
			}
			return TestID;
		}

		public static bool UpdateTest(int TestID, int TestAppointmentID, bool TestResult, string Notes, int CreatedByUserID)
		{
			int rowsAffected = 0;
			SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

			string query =
				@"Update Tests
					SET TestAppointmentID = @TestAppointmentID, TestResult = @TestResult, Notes = @Notes, CreatedByUserID = @CreatedByUserID
					Where TestID = @TestID;";

			SqlCommand command = new SqlCommand(query, connection);
			command.Parameters.AddWithValue("@TestID", TestID);
			command.Parameters.AddWithValue("@TestAppointmentID", TestAppointmentID);
			command.Parameters.AddWithValue("@TestResult", TestResult);
			command.Parameters.AddWithValue("@Notes", Notes);
			command.Parameters.AddWithValue("@CreatedByUserID", CreatedByUserID);

			try
			{
				connection.Open();
				rowsAffected = command.ExecuteNonQuery();
			}
			//catch (Exception ex)
			//{
			//}
			finally
			{
				connection.Close();
			}
			return (rowsAffected > 0);
		}

		public static bool DeleteTest(int TestID)
		{
			int rowsAffected = 0;
			SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);
			string query = @"Delete Tests WHERE TestID = @TestID";

			SqlCommand command = new SqlCommand(query, connection);
			command.Parameters.AddWithValue("@TestID", TestID);

			try
			{
				connection.Open();
				rowsAffected = command.ExecuteNonQuery();
			}
			//catch (Exception ex)
			//{
			//}
			finally
			{
				connection.Close();
			}
			return (rowsAffected > 0);
		}

		public static DataTable GetAllTests()
		{
			DataTable dt = new DataTable();
			SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

			string query = @"SELECT * FROM Tests;";

			SqlCommand command = new SqlCommand(query, connection);

			try
			{
				connection.Open();
				SqlDataReader reader = command.ExecuteReader();

				if (reader.HasRows)
				{
					dt.Load(reader);
				}
				reader.Close();
			}
			//catch (Exception ex)
			//{
			//}
			finally
			{
				connection.Close();
			}
			return dt;
		}
	}
}
