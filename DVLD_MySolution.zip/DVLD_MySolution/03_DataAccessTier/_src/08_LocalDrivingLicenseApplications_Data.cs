﻿using System;
using System.Data;
using System.Data.SqlClient;

namespace DVLD_DataAccess
{
	public class clsDataAccess_LDLA
	{
		public struct stStatus_ApplicationID
		{
			public bool Found { get; set; }
			public byte status { get; set; }
			public int applicationID { get; set; }
		}
		public static stStatus_ApplicationID LastPerson_LDLA_Status_ApplicationID(int personID, int LicencesClassID)
		{
			stStatus_ApplicationID status_ApplicationID = new stStatus_ApplicationID();
			SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);
			string query = @" SELECT Applications.ApplicationID, Applications.ApplicationStatus FROM Applications
				JOIN LocalDrivingLicenseApplications ON Applications.ApplicationID = LocalDrivingLicenseApplications.ApplicationID
				JOIN LicenseClasses ON LocalDrivingLicenseApplications.LicenseClassID = LicenseClasses.LicenseClassID
				Where ApplicantPersonID = @personID AND LicenseClasses.LicenseClassID = @LicencesClassID Order By ApplicationID desc;";  // Cancelled Record Goes Down.

			SqlCommand command = new SqlCommand(query, connection);
			command.Parameters.AddWithValue("@personID", personID);
			command.Parameters.AddWithValue("@LicencesClassID", LicencesClassID);

			try
			{
				connection.Open();
				SqlDataReader reader = command.ExecuteReader();

				if (reader.Read())
				{
					status_ApplicationID.Found = true;
					status_ApplicationID.applicationID = (int)reader[0];
					status_ApplicationID.status = (byte)reader[1];
				}
				else
				{
					status_ApplicationID.Found = false;
				}
				reader.Close();
			}
			//catch (Exception ex)
			//{
			//}
			finally
			{
				connection.Close();
			}
			return status_ApplicationID;
		}


		public static bool ChangeAppStatusByLDLA_ID(int LDLA_ID, int appStatus)
		//public static bool Cancel_LDLA(int LDLA_ID)
		{
			int rowsAffected = 0;
			SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);
			// 2 = cancelled, 3 = completed.

			string query = @"Update Applications Set ApplicationStatus = @appStatus, LastStatusDate = @Now
				Where ApplicationID = (Select ApplicationID From LocalDrivingLicenseApplications Where LocalDrivingLicenseApplicationID = @LDLA_ID);";

			SqlCommand command = new SqlCommand(query, connection);
			command.Parameters.AddWithValue("@LDLA_ID", LDLA_ID);
			command.Parameters.AddWithValue("@appStatus", appStatus);
			command.Parameters.AddWithValue("@Now", DateTime.Now);

			try
			{
				connection.Open();
				rowsAffected = command.ExecuteNonQuery();
			}
			//catch (Exception ex)
			//{
			//}
			finally
			{
				connection.Close();
			}
			return (rowsAffected > 0);
		}


		private static bool _DeleteRelatedTests(int LDLA)
		{
			int rowsAffected = 0;
			SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

			string query = @"Delete Tests WHERE TestID IN 
				(Select TestID From Tests JOIN TestAppointments On Tests.TestAppointmentID = TestAppointments.TestAppointmentID AND TestAppointments.LocalDrivingLicenseApplicationID = @LDLA)";

			SqlCommand command = new SqlCommand(query, connection);
			command.Parameters.AddWithValue("@LDLA", LDLA);

			try
			{
				connection.Open();
				rowsAffected = command.ExecuteNonQuery();
			}
			//catch (Exception ex)
			//{
			//}
			finally
			{
				connection.Close();
			}
			return (rowsAffected > 0);
		}
		private static bool _DeleteRelatedTestAppointments(int LDLA)
		{
			int rowsAffected = 0;
			SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

			string query = @"Delete TestAppointments WHERE LocalDrivingLicenseApplicationID = @LDLA";

			SqlCommand command = new SqlCommand(query, connection);
			command.Parameters.AddWithValue("@LDLA", LDLA);

			try
			{
				connection.Open();
				rowsAffected = command.ExecuteNonQuery();
			}
			//catch (Exception ex)
			//{
			//}
			finally
			{
				connection.Close();
			}
			return (rowsAffected > 0);
		}
		private static bool _DeleteLDLA(int LDLA)
		{
			int rowsAffected = 0;
			SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

			string query = @"Delete LocalDrivingLicenseApplications WHERE LocalDrivingLicenseApplicationID = @LDLA";

			SqlCommand command = new SqlCommand(query, connection);
			command.Parameters.AddWithValue("@LDLA", LDLA);

			try
			{
				connection.Open();
				rowsAffected = command.ExecuteNonQuery();
			}
			//catch (Exception ex)
			//{
			//}
			finally
			{
				connection.Close();
			}
			return (rowsAffected > 0);
		}
		public static bool Delete_LDLA(int LDLA)
		{
			int relatedApp = -1, licnenseClassID = -1;
			Get_LDLA(LDLA, ref relatedApp, ref licnenseClassID);

			if (!_DeleteRelatedTests(LDLA))
				return false;

			if (!_DeleteRelatedTestAppointments(LDLA))
				return false;

			if (!_DeleteLDLA(LDLA))
				return false;

			int rowsAffected = 0;
			SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);


			string query = @"Delete Applications Where ApplicationID = @ApplicationID";

			SqlCommand command = new SqlCommand(query, connection);
			command.Parameters.AddWithValue("@ApplicationID", relatedApp);

			try
			{
				connection.Open();
				rowsAffected = command.ExecuteNonQuery();
			}
			//catch (Exception ex)
			//{
			//}
			finally
			{
				connection.Close();
			}
			return (rowsAffected > 0);
		}


		public static bool Get_LDLA(int LocalDrivingLicenseApplicationID, ref int ApplicationID, ref int LicenseClassID)
		{
			bool isFound = false;

			SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);
			string query = @"SELECT * FROM LocalDrivingLicenseApplications Where LocalDrivingLicenseApplicationID = @LocalDrivingLicenseApplicationID;";

			SqlCommand cmd = new SqlCommand(query, connection);
			cmd.Parameters.AddWithValue("@LocalDrivingLicenseApplicationID", LocalDrivingLicenseApplicationID);

			try
			{
				connection.Open();
				SqlDataReader reader = cmd.ExecuteReader();

				if (reader.Read())
				{
					isFound = true;
					//LocalDrivingLicenseApplicationID = (int)reader[0];
					ApplicationID = (int)reader[1];
					LicenseClassID = (int)reader[2];

					reader.Close();
				}
			}
			//catch (Exception ex)
			//{
			//}
			finally
			{
				connection.Close();
			}
			return isFound;
		}
		public static int AddNew_LDLA(int ApplicationID, int LicenseClassID)
		{
			int LocalDrivingLicenseApplicationID = -1;
			SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);
			string query = @"INSERT INTO LocalDrivingLicenseApplications
        VALUES (@ApplicationID, @LicenseClassID);
        SELECT SCOPE_IDENTITY();";

			SqlCommand command = new SqlCommand(query, connection);
			command.Parameters.AddWithValue("@ApplicationID", ApplicationID);
			command.Parameters.AddWithValue("@LicenseClassID", LicenseClassID);

			try
			{
				connection.Open();
				object result = command.ExecuteScalar();

				if (result != null && int.TryParse(result.ToString(), out int insertedID))
				{
					LocalDrivingLicenseApplicationID = insertedID;
				}
			}
			//catch (Exception ex)
			//{
			//}
			finally
			{
				connection.Close();
			}
			return LocalDrivingLicenseApplicationID;
		}
		public static bool Update_LDLA(int LocalDrivingLicenseApplicationID, int ApplicationID, int LicenseClassID)
		{
			int rowsAffected = 0;
			SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

			string query =
				@"Update LocalDrivingLicenseApplications
					SET ApplicationID = @ApplicationID, LicenseClassID = @LicenseClassID
					Where LocalDrivingLicenseApplicationID = @LocalDrivingLicenseApplicationID;";

			SqlCommand command = new SqlCommand(query, connection);
			command.Parameters.AddWithValue("@LocalDrivingLicenseApplicationID", LocalDrivingLicenseApplicationID);
			command.Parameters.AddWithValue("@ApplicationID", ApplicationID);
			command.Parameters.AddWithValue("@LicenseClassID", LicenseClassID);


			try
			{
				connection.Open();
				rowsAffected = command.ExecuteNonQuery();
			}
			//catch (Exception ex)
			//{
			//}
			finally
			{
				connection.Close();
			}
			return (rowsAffected > 0);
		}
		public static DataTable GetAll_LDLA()
		{
			DataTable dt = new DataTable();
			SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

			string query = @"SELECT * FROM LocalDrivingLicenseApplications;";

			SqlCommand command = new SqlCommand(query, connection);

			try
			{
				connection.Open();
				SqlDataReader reader = command.ExecuteReader();

				if (reader.HasRows)
				{
					dt.Load(reader);
				}
				reader.Close();
			}
			//catch (Exception ex)
			//{
			//}
			finally
			{
				connection.Close();
			}
			return dt;
		}
	}
}
