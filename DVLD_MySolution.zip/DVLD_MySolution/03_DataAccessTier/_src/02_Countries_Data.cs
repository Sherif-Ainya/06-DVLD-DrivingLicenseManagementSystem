﻿using System.Data;
using System.Data.SqlClient;
using DVLD_DataAccess;

namespace _03_DataAccessTier.src
{
	public class clsDataAccessCountries
	{
		public static bool GetCountryInfoByID(int countryID, ref string countryName)
		{
			bool isFound = false;
			SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);
			string query = @"Select * from Countries Where CountryID = @CountryID;";

			SqlCommand command = new SqlCommand(query, connection);
			command.Parameters.AddWithValue("CountryID", countryID);

			try
			{
				connection.Open();
				SqlDataReader reader = command.ExecuteReader();

				if (reader.Read())
				{
					isFound = true;
					countryName = (string)reader["CountryName"];
				}
				reader.Close();
			}
			//catch (Exception ex)
			//{
			//}
			finally
			{
				connection.Close();
			}
			return isFound;
		}

		public static bool GetCountryInfoByName(ref int countryID, string countryname)
		{
			bool isFound = false;
			SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);
			string query = @"Select * from Countries Where CountryName = @CountryName;";

			SqlCommand command = new SqlCommand(query, connection);
			command.Parameters.AddWithValue("CountryName", countryname);

			try
			{
				connection.Open();
				SqlDataReader reader = command.ExecuteReader();

				if (reader.Read())
				{
					isFound = true;
					countryID = (int)reader["CountryID"];
				}

				reader.Close();
			}
			//catch (Exception ex)
			//{
			//}
			finally
			{
				connection.Close();
			}
			return isFound;
		}

		public static DataTable GetAllCountries()
		{
			DataTable dt = new DataTable();
			SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

			string query = "SELECT * FROM Countries Order By CountryName";
			SqlCommand command = new SqlCommand(query, connection);

			try
			{
				connection.Open();
				SqlDataReader reader = command.ExecuteReader();

				if (reader.HasRows)
				{
					dt.Load(reader);
				}
				reader.Close();
			}
			//catch (Exception ex)
			//{
			//}
			finally
			{
				connection.Close();
			}
			return dt;
		}
	}
}
