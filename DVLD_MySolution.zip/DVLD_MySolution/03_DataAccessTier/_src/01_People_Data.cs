﻿using System;
using System.Data;
using System.Data.SqlClient;

namespace DVLD_DataAccess
{
	public class clsDataAccessPeople
	{
		public static bool GetPerson(int personID, ref string nationalNo, ref string firstName, ref string secondName, ref string thirdName, ref string lastName,
			 ref DateTime dateOfBirth, ref short gender, ref string address, ref string phone, ref string email, ref int countryID, ref string imagePath)
		{
			bool isFound = false;
			SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);
			string query = @"SELECT * FROM People Where PersonID = @Person_ID";

			SqlCommand cmd = new SqlCommand(query, connection);
			cmd.Parameters.AddWithValue("@Person_ID", personID);

			try
			{
				connection.Open();
				SqlDataReader reader = cmd.ExecuteReader();

				if (reader.Read())
				{
					isFound = true;
					nationalNo = (string)reader[1];
					firstName = (string)reader[2];
					secondName = (string)reader[3];

					if (reader[4] != System.DBNull.Value)
						thirdName = (string)reader[4];
					else
						thirdName = "";

					lastName = (string)reader[5];
					dateOfBirth = (DateTime)reader[6];
					//gender = Convert.ToInt16((byte)reader[7]);
					gender = (byte)reader[7];
					address = (string)reader[8];
					phone = (string)reader[9];

					if (reader[10] != System.DBNull.Value)
						email = (string)reader[10];
					else
						email = "";

					countryID = (int)reader[11];

					if (reader[12] != System.DBNull.Value)
						imagePath = (string)reader[12];
					else
						imagePath = "";
				}
				else
				{
					isFound = false;
				}
				reader.Close();
			}
			//catch (Exception ex)
			//{
			//}
			finally
			{
				connection.Close();
			}
			return isFound;
		}

		public static bool GetPerson(ref int personID, string nationalNo, ref string firstName, ref string secondName, ref string thirdName, ref string lastName,
			 ref DateTime dateOfBirth, ref short gender, ref string address, ref string phone, ref string email, ref int countryID, ref string imagePath)
		{
			bool isFound = false;
			SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);
			string query = @"SELECT * FROM People Where NationalNo = @NationalNo";

			SqlCommand cmd = new SqlCommand(query, connection);
			cmd.Parameters.AddWithValue("@NationalNo", nationalNo);

			try
			{
				connection.Open();
				SqlDataReader reader = cmd.ExecuteReader();

				if (reader.Read())
				{
					isFound = true;
					personID = (int)reader[0];
					nationalNo = (string)reader[1];
					firstName = (string)reader[2];
					secondName = (string)reader[3];

					if (reader[4] != System.DBNull.Value)
						thirdName = (string)reader[4];
					else
						thirdName = "";

					lastName = (string)reader[5];
					dateOfBirth = (DateTime)reader[6];
					gender = Convert.ToInt16((byte)reader[7]);
					address = (string)reader[8];
					phone = (string)reader[9];

					if (reader[10] != System.DBNull.Value)
						email = (string)reader[10];
					else
						email = "";

					countryID = (int)reader[11];

					if (reader[12] != System.DBNull.Value)
						imagePath = (string)reader[12];
					else
						imagePath = "";
				}
				else
				{
					isFound = false;
				}
				reader.Close();
			}
			//catch (Exception ex)
			//{
			//}
			finally
			{
				connection.Close();
			}
			return isFound;
		}

		public static int AddNewPerson(string nationalNo, string firstName, string secondName, string thirdName, string lastName,
			DateTime dateOfBirth, short gender, string address, string phone, string email, int countryID, string imagePath)
		{
			int Person_ID = -1;

			SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);
			string query = @"INSERT INTO People
        VALUES (@NationalNo, @FirstName, @SecondName, @ThirdName, @LastName, @DateOfBirth, @Gendor, @Address, @Phone, @Email, @NationalityCountryID, @ImagePath);
        SELECT SCOPE_IDENTITY();";

			SqlCommand command = new SqlCommand(query, connection);
			command.Parameters.AddWithValue("@NationalNo", nationalNo);
			command.Parameters.AddWithValue("@FirstName", firstName);
			command.Parameters.AddWithValue("@SecondName", secondName);

			if (thirdName != "" && thirdName != null)
				command.Parameters.AddWithValue("@ThirdName", thirdName);
			else
				command.Parameters.AddWithValue("@ThirdName", System.DBNull.Value);

			command.Parameters.AddWithValue("@LastName", lastName);
			command.Parameters.AddWithValue("@DateOfBirth", dateOfBirth);
			//command.Parameters.AddWithValue("@Gendor", Convert.ToByte(gender));
			command.Parameters.AddWithValue("@Gendor", gender);
			command.Parameters.AddWithValue("@Address", address);
			command.Parameters.AddWithValue("@Phone", phone);

			if (email != "")
				command.Parameters.AddWithValue("@Email", email);
			else
				command.Parameters.AddWithValue("@Email", System.DBNull.Value);

			command.Parameters.AddWithValue("@NationalityCountryID", countryID);

			if (imagePath != "")
				command.Parameters.AddWithValue("@ImagePath", imagePath);
			else
				command.Parameters.AddWithValue("@ImagePath", System.DBNull.Value);

			try
			{
				connection.Open();
				object result = command.ExecuteScalar();

				if (result != null && int.TryParse(result.ToString(), out int insertedID))
				{
					Person_ID = insertedID;
				}
			}
			//catch (Exception ex)
			//{
			//}
			finally
			{
				connection.Close();
			}
			return Person_ID;
		}

		public static bool UpdatePerson(int personID, string nationalNo, string firstName, string secondName, string thirdName, string lastName,
			DateTime dateOfBirth, short gender, string address, string phone, string email, int countryID, string imagePath)
		{
			int rowsAffected = 0;
			SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

			string query = @"UPDATE People
				SET NationalNo = @NationalNo, FirstName = @FirstName, @SecondName = SecondName, ThirdName = @ThirdName, LastName = @LastName,
					DateOfBirth = @DateOfBirth, Gendor = @Gendor, Address = @Address, Phone = @Phone, Email = @Email, NationalityCountryID = @NationalityCountryID, ImagePath = @ImagePath
				WHERE PersonID = @PersonID";

			SqlCommand command = new SqlCommand(query, connection);
			command.Parameters.AddWithValue("@PersonID", personID);
			command.Parameters.AddWithValue("@NationalNo", nationalNo);
			command.Parameters.AddWithValue("@FirstName", firstName);
			command.Parameters.AddWithValue("@SecondName", secondName);

			if (thirdName != "" && thirdName != null)
				command.Parameters.AddWithValue("@ThirdName", thirdName);
			else
				command.Parameters.AddWithValue("@ThirdName", System.DBNull.Value);

			command.Parameters.AddWithValue("@LastName", lastName);
			command.Parameters.AddWithValue("@DateOfBirth", dateOfBirth);
			command.Parameters.AddWithValue("@Gendor", Convert.ToByte(gender));
			command.Parameters.AddWithValue("@Address", address);
			command.Parameters.AddWithValue("@Phone", phone);

			if (email != "")
				command.Parameters.AddWithValue("@Email", email);
			else
				command.Parameters.AddWithValue("@Email", System.DBNull.Value);

			command.Parameters.AddWithValue("@NationalityCountryID", countryID);

			if (imagePath != "")
				command.Parameters.AddWithValue("@ImagePath", imagePath);
			else
				command.Parameters.AddWithValue("@ImagePath", System.DBNull.Value);

			try
			{
				connection.Open();
				rowsAffected = command.ExecuteNonQuery();
			}
			//catch (Exception ex)
			//{
			//}
			finally
			{
				connection.Close();
			}
			return (rowsAffected > 0);
		}

		public static bool DeletePerson(int personID)
		{
			int rowsAffected = 0;
			SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);
			string query = @"Delete People WHERE PersonID = @personID";

			SqlCommand command = new SqlCommand(query, connection);
			command.Parameters.AddWithValue("@personID", personID);

			try
			{
				connection.Open();
				rowsAffected = command.ExecuteNonQuery();
			}
			//catch (Exception ex)
			//{
			//}
			finally
			{
				connection.Close();
			}
			return (rowsAffected > 0);
		}

		public static bool IsPersonExist(int personID)
		{
			bool isFound = false;
			SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);
			string query = "SELECT Found = 1 FROM People WHERE PersonID = @personID";

			SqlCommand command = new SqlCommand(query, connection);
			command.Parameters.AddWithValue("@personID", personID);

			try
			{
				connection.Open();
				SqlDataReader reader = command.ExecuteReader();

				isFound = reader.HasRows;

				reader.Close();
			}
			//catch (Exception ex)
			//{
			//}
			finally
			{
				connection.Close();
			}
			return isFound;
		}
		public static bool IsPersonExist(string nationalNo)
		{
			bool isFound = false;

			SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);
			string query = "SELECT Found = 1 FROM People WHERE NationalNo = @nationalNo";

			SqlCommand command = new SqlCommand(query, connection);
			command.Parameters.AddWithValue("@nationalNo", nationalNo);

			try
			{
				connection.Open();
				SqlDataReader reader = command.ExecuteReader();

				isFound = reader.HasRows;

				reader.Close();
			}
			//catch (Exception ex)
			//{
			//}
			finally
			{
				connection.Close();
			}
			return isFound;
		}

		public static bool IsThisPersonUser(int personID)
		{
			bool isFound = false;

			SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);
			string query = "SELECT Found = 1 FROM Users WHERE PersonID = @personID";

			SqlCommand command = new SqlCommand(query, connection);
			command.Parameters.AddWithValue("@personID", personID);

			try
			{
				connection.Open();
				SqlDataReader reader = command.ExecuteReader();

				isFound = reader.HasRows;

				reader.Close();
			}
			//catch (Exception ex)
			//{
			//}
			finally
			{
				connection.Close();
			}
			return isFound;
		}

		public static DataTable GetAllPeople()
		{
			DataTable dt = new DataTable();
			SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

			string query = "SELECT * FROM People;";
			SqlCommand command = new SqlCommand(query, connection);

			try
			{
				connection.Open();
				SqlDataReader reader = command.ExecuteReader();

				if (reader.HasRows)
				{
					dt.Load(reader);
				}
				reader.Close();
			}
			//catch (Exception ex)
			//{
			//}
			finally
			{
				connection.Close();
			}
			return dt;
		}
	}
}
