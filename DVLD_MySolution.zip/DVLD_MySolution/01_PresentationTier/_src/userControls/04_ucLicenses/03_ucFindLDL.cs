﻿using System;
using System.Windows.Forms;
using DVLD_Business;

namespace _02_DVLD_Mine._src.userControls._04_ucLicenses
{
	public partial class _03_ucFindLDL : UserControl
	{
		public event Action<int> OnFound_ReturnLDL_ID;
		protected virtual void Found(int LocalDL_ID)
		{
			Action<int> handler = OnFound_ReturnLDL_ID;
			if (handler != null)
			{
				handler(LocalDL_ID);
			}
		}
		public event Action<clsBusinessLicenses> OnFound_ReturnObject;
		protected virtual void Found1(ref clsBusinessLicenses LocalDL)
		{
			Action<clsBusinessLicenses> handler = OnFound_ReturnObject;
			if (handler != null)
			{
				handler(LocalDL);
			}
		}


		public _03_ucFindLDL()
		{
			InitializeComponent();
			mtxbFindLDL.Focus();
		}


		public enum enFindMode { eInternational, eRenew, eReplacment, eDetain, eRelease };
		private enFindMode _Mode = enFindMode.eInternational;
		private clsBusinessLicenses _LocalDL;

		public void FindFor(enFindMode findFor)
		{
			_Mode = findFor;
		}

		private void ClearFindPerson_Focus()
		{
			mtxbFindLDL.Clear();
			mtxbFindLDL.Focus();
		}
		private bool InternationalConditions()
		{
			if (_LocalDL.LicenseClass != 3)
			{
				MessageBox.Show("The Type Of The Selected Local Driving Lisince Dose not Match, It must be [Class 3 - Ordinary driving license].", "Type Donsn't Match!", MessageBoxButtons.OK, MessageBoxIcon.Error);
				ClearFindPerson_Focus();
				return false;
			}

			int relatedIntDL_ID = clsBusinessInternationDL.IsThisLocalDLHasInternationalDL(_LocalDL.LicenseID);
			if (relatedIntDL_ID != -1)
			{
				MessageBox.Show("This Local Driving Licence Already Has A Realated International Driving License With ID [ " + relatedIntDL_ID + "].!", "Already Has One!", MessageBoxButtons.OK, MessageBoxIcon.Error);
				ClearFindPerson_Focus();
				return false;
			}
			return true;
		}
		private bool RenewConditions()
		{
			if (DateTime.Now < _LocalDL.ExpirationDate)
			{
				MessageBox.Show("This Local Driving Licence Is Not Expired Yet!, It Will Expire In [" + _LocalDL.ExpirationDate.ToString() + "].", "Not Expired!", MessageBoxButtons.OK, MessageBoxIcon.Error);
				ClearFindPerson_Focus();
				return false;
			}

			return true;
		}
		private bool DetainConditions()
		{
			if (clsBusinessDetainedLicenses.IsThisLicenseDetained(_LocalDL.LicenseID))
			{
				MessageBox.Show("This Local Driving Licence Already Detained!", "Detained!", MessageBoxButtons.OK, MessageBoxIcon.Error);
				ClearFindPerson_Focus();
				return false;
			}

			return true;
		}
		private bool ReleaseConditions()
		{
			if (!clsBusinessDetainedLicenses.IsThisLicenseDetained(_LocalDL.LicenseID))
			{
				MessageBox.Show("This Local Driving Licence Is Not Detained!", "Not Detained!", MessageBoxButtons.OK, MessageBoxIcon.Error);
				ClearFindPerson_Focus();
				return false;
			}

			return true;
		}
		private void btnFind_Click(object sender, EventArgs e)
		{
			if (string.IsNullOrEmpty(mtxbFindLDL.Text))
			{
				mtxbFindLDL.Focus();
				return;
			}

			int LocalDL_ID = Convert.ToInt32(mtxbFindLDL.Text);
			clsBusinessLicenses LocalDL = clsBusinessLicenses.FindByLicenseID(LocalDL_ID);
			if (LocalDL == null)
			{
				MessageBox.Show("The Selected Local Driving Lisence Is Not Found!", "Local DL Was Not Found!", MessageBoxButtons.OK, MessageBoxIcon.Error);
				return;
			}

			if (!LocalDL.IsActive)
			{
				MessageBox.Show("The Selected Local Driving Lisince Is not Active.", "Local DL Not Active!", MessageBoxButtons.OK, MessageBoxIcon.Error);
				ClearFindPerson_Focus();
				return;
			}


			if (_Mode != enFindMode.eReplacment)
			{
				_LocalDL = LocalDL;
				if (_Mode == enFindMode.eInternational && !InternationalConditions())
					return;

				if (_Mode == enFindMode.eRenew && !RenewConditions())
					return;

				if (_Mode == enFindMode.eDetain && !DetainConditions())
					return;

				if (_Mode == enFindMode.eRelease && !ReleaseConditions())
					return;
			}


			if (OnFound_ReturnLDL_ID != null)
				Found(LocalDL_ID);

			if (OnFound_ReturnObject != null)
				Found1(ref LocalDL);
		}
	}
}
