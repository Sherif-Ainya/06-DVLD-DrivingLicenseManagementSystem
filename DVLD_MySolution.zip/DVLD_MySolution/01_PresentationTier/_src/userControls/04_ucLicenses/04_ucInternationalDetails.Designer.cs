﻿namespace _02_DVLD_Mine._src.userControls._04_ucLicenses
{
	partial class _04_ucInternationalDetails
	{
		/// <summary> 
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary> 
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Component Designer generated code

		/// <summary> 
		/// Required method for Designer support - do not modify 
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.gbPersonDetails = new System.Windows.Forms.GroupBox();
			this.lblApplicationID = new System.Windows.Forms.Label();
			this._lblApplicationID = new System.Windows.Forms.Label();
			this.lblDriverID = new System.Windows.Forms.Label();
			this._lblDriverID = new System.Windows.Forms.Label();
			this.lblIsActive = new System.Windows.Forms.Label();
			this._lblIsActive = new System.Windows.Forms.Label();
			this.lblExpirationDate = new System.Windows.Forms.Label();
			this._lblExpirationDate = new System.Windows.Forms.Label();
			this.btnEdit = new System.Windows.Forms.Button();
			this.lblDateOfBirth = new System.Windows.Forms.Label();
			this.lblGender = new System.Windows.Forms.Label();
			this.lblNationalNo = new System.Windows.Forms.Label();
			this.lblIssueDate = new System.Windows.Forms.Label();
			this.lblName = new System.Windows.Forms.Label();
			this.lblLicenseID = new System.Windows.Forms.Label();
			this.pbPersonImage = new System.Windows.Forms.PictureBox();
			this._lblNationalNo = new System.Windows.Forms.Label();
			this._lblGender = new System.Windows.Forms.Label();
			this._lblDateOfBirth = new System.Windows.Forms.Label();
			this._lblIssueDate = new System.Windows.Forms.Label();
			this._lblName = new System.Windows.Forms.Label();
			this._lblLicenseID = new System.Windows.Forms.Label();
			this.gbPersonDetails.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.pbPersonImage)).BeginInit();
			this.SuspendLayout();
			// 
			// gbPersonDetails
			// 
			this.gbPersonDetails.BackColor = System.Drawing.Color.PaleTurquoise;
			this.gbPersonDetails.Controls.Add(this.lblApplicationID);
			this.gbPersonDetails.Controls.Add(this._lblApplicationID);
			this.gbPersonDetails.Controls.Add(this.lblDriverID);
			this.gbPersonDetails.Controls.Add(this._lblDriverID);
			this.gbPersonDetails.Controls.Add(this.lblIsActive);
			this.gbPersonDetails.Controls.Add(this._lblIsActive);
			this.gbPersonDetails.Controls.Add(this.lblExpirationDate);
			this.gbPersonDetails.Controls.Add(this._lblExpirationDate);
			this.gbPersonDetails.Controls.Add(this.btnEdit);
			this.gbPersonDetails.Controls.Add(this.lblDateOfBirth);
			this.gbPersonDetails.Controls.Add(this.lblGender);
			this.gbPersonDetails.Controls.Add(this.lblNationalNo);
			this.gbPersonDetails.Controls.Add(this.lblIssueDate);
			this.gbPersonDetails.Controls.Add(this.lblName);
			this.gbPersonDetails.Controls.Add(this.lblLicenseID);
			this.gbPersonDetails.Controls.Add(this.pbPersonImage);
			this.gbPersonDetails.Controls.Add(this._lblNationalNo);
			this.gbPersonDetails.Controls.Add(this._lblGender);
			this.gbPersonDetails.Controls.Add(this._lblDateOfBirth);
			this.gbPersonDetails.Controls.Add(this._lblIssueDate);
			this.gbPersonDetails.Controls.Add(this._lblName);
			this.gbPersonDetails.Controls.Add(this._lblLicenseID);
			this.gbPersonDetails.Dock = System.Windows.Forms.DockStyle.Fill;
			this.gbPersonDetails.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.gbPersonDetails.Location = new System.Drawing.Point(0, 0);
			this.gbPersonDetails.Name = "gbPersonDetails";
			this.gbPersonDetails.Size = new System.Drawing.Size(847, 462);
			this.gbPersonDetails.TabIndex = 3;
			this.gbPersonDetails.TabStop = false;
			this.gbPersonDetails.Text = "Driver International License Information  :";
			// 
			// lblApplicationID
			// 
			this.lblApplicationID.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
			this.lblApplicationID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.lblApplicationID.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblApplicationID.ForeColor = System.Drawing.Color.Black;
			this.lblApplicationID.Location = new System.Drawing.Point(723, 78);
			this.lblApplicationID.Name = "lblApplicationID";
			this.lblApplicationID.Size = new System.Drawing.Size(73, 41);
			this.lblApplicationID.TabIndex = 28;
			this.lblApplicationID.Text = "???";
			this.lblApplicationID.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// _lblApplicationID
			// 
			this._lblApplicationID.AutoSize = true;
			this._lblApplicationID.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this._lblApplicationID.Location = new System.Drawing.Point(562, 85);
			this._lblApplicationID.Name = "_lblApplicationID";
			this._lblApplicationID.Size = new System.Drawing.Size(145, 26);
			this._lblApplicationID.TabIndex = 27;
			this._lblApplicationID.Text = "Applicaiton ID :";
			// 
			// lblDriverID
			// 
			this.lblDriverID.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
			this.lblDriverID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.lblDriverID.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblDriverID.ForeColor = System.Drawing.Color.Black;
			this.lblDriverID.Location = new System.Drawing.Point(747, 124);
			this.lblDriverID.Name = "lblDriverID";
			this.lblDriverID.Size = new System.Drawing.Size(73, 41);
			this.lblDriverID.TabIndex = 26;
			this.lblDriverID.Text = "???";
			this.lblDriverID.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// _lblDriverID
			// 
			this._lblDriverID.AutoSize = true;
			this._lblDriverID.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this._lblDriverID.Location = new System.Drawing.Point(613, 131);
			this._lblDriverID.Name = "_lblDriverID";
			this._lblDriverID.Size = new System.Drawing.Size(108, 26);
			this._lblDriverID.TabIndex = 25;
			this._lblDriverID.Text = " Driver ID :";
			// 
			// lblIsActive
			// 
			this.lblIsActive.BackColor = System.Drawing.Color.AntiqueWhite;
			this.lblIsActive.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.lblIsActive.Font = new System.Drawing.Font("Palatino Linotype", 13.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblIsActive.Location = new System.Drawing.Point(302, 410);
			this.lblIsActive.Name = "lblIsActive";
			this.lblIsActive.Size = new System.Drawing.Size(105, 35);
			this.lblIsActive.TabIndex = 22;
			this.lblIsActive.Text = "!?";
			this.lblIsActive.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// _lblIsActive
			// 
			this._lblIsActive.AutoSize = true;
			this._lblIsActive.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this._lblIsActive.Location = new System.Drawing.Point(44, 414);
			this._lblIsActive.Name = "_lblIsActive";
			this._lblIsActive.Size = new System.Drawing.Size(93, 26);
			this._lblIsActive.TabIndex = 21;
			this._lblIsActive.Text = "Is Active?";
			// 
			// lblExpirationDate
			// 
			this.lblExpirationDate.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
			this.lblExpirationDate.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.lblExpirationDate.Font = new System.Drawing.Font("Palatino Linotype", 13.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblExpirationDate.Location = new System.Drawing.Point(205, 350);
			this.lblExpirationDate.Name = "lblExpirationDate";
			this.lblExpirationDate.Size = new System.Drawing.Size(291, 35);
			this.lblExpirationDate.TabIndex = 20;
			this.lblExpirationDate.Text = "????";
			this.lblExpirationDate.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// _lblExpirationDate
			// 
			this._lblExpirationDate.AutoSize = true;
			this._lblExpirationDate.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this._lblExpirationDate.Location = new System.Drawing.Point(25, 350);
			this._lblExpirationDate.Name = "_lblExpirationDate";
			this._lblExpirationDate.Size = new System.Drawing.Size(152, 26);
			this._lblExpirationDate.TabIndex = 19;
			this._lblExpirationDate.Text = "Expiration Date :";
			// 
			// btnEdit
			// 
			this.btnEdit.BackColor = System.Drawing.SystemColors.ScrollBar;
			this.btnEdit.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
			this.btnEdit.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
			this.btnEdit.FlatAppearance.BorderSize = 2;
			this.btnEdit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnEdit.Font = new System.Drawing.Font("Palatino Linotype", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnEdit.ForeColor = System.Drawing.Color.Red;
			this.btnEdit.Image = global::_02_DVLD_Mine.Properties.Resources.highlighter_pen;
			this.btnEdit.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btnEdit.Location = new System.Drawing.Point(596, 410);
			this.btnEdit.Name = "btnEdit";
			this.btnEdit.Size = new System.Drawing.Size(159, 36);
			this.btnEdit.TabIndex = 0;
			this.btnEdit.Text = "Edit Person Info";
			this.btnEdit.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.btnEdit.UseVisualStyleBackColor = false;
			this.btnEdit.Visible = false;
			this.btnEdit.Click += new System.EventHandler(this.btnEditPerson_Click);
			// 
			// lblDateOfBirth
			// 
			this.lblDateOfBirth.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
			this.lblDateOfBirth.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.lblDateOfBirth.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblDateOfBirth.Location = new System.Drawing.Point(204, 224);
			this.lblDateOfBirth.Name = "lblDateOfBirth";
			this.lblDateOfBirth.Size = new System.Drawing.Size(291, 35);
			this.lblDateOfBirth.TabIndex = 18;
			this.lblDateOfBirth.Text = "????";
			this.lblDateOfBirth.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// lblGender
			// 
			this.lblGender.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
			this.lblGender.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.lblGender.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblGender.Location = new System.Drawing.Point(267, 175);
			this.lblGender.Name = "lblGender";
			this.lblGender.Size = new System.Drawing.Size(163, 35);
			this.lblGender.TabIndex = 17;
			this.lblGender.Text = "????";
			this.lblGender.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// lblNationalNo
			// 
			this.lblNationalNo.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
			this.lblNationalNo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.lblNationalNo.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblNationalNo.Location = new System.Drawing.Point(267, 127);
			this.lblNationalNo.Name = "lblNationalNo";
			this.lblNationalNo.Size = new System.Drawing.Size(163, 35);
			this.lblNationalNo.TabIndex = 16;
			this.lblNationalNo.Text = "????";
			this.lblNationalNo.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// lblIssueDate
			// 
			this.lblIssueDate.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
			this.lblIssueDate.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.lblIssueDate.Font = new System.Drawing.Font("Palatino Linotype", 13.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblIssueDate.Location = new System.Drawing.Point(204, 303);
			this.lblIssueDate.Name = "lblIssueDate";
			this.lblIssueDate.Size = new System.Drawing.Size(291, 35);
			this.lblIssueDate.TabIndex = 14;
			this.lblIssueDate.Text = "????";
			this.lblIssueDate.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// lblName
			// 
			this.lblName.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
			this.lblName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.lblName.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblName.Location = new System.Drawing.Point(185, 50);
			this.lblName.Name = "lblName";
			this.lblName.Size = new System.Drawing.Size(326, 35);
			this.lblName.TabIndex = 11;
			this.lblName.Text = "????";
			this.lblName.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// lblLicenseID
			// 
			this.lblLicenseID.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
			this.lblLicenseID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.lblLicenseID.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblLicenseID.ForeColor = System.Drawing.Color.Red;
			this.lblLicenseID.Location = new System.Drawing.Point(677, 17);
			this.lblLicenseID.Name = "lblLicenseID";
			this.lblLicenseID.Size = new System.Drawing.Size(73, 41);
			this.lblLicenseID.TabIndex = 10;
			this.lblLicenseID.Text = "???";
			this.lblLicenseID.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// pbPersonImage
			// 
			this.pbPersonImage.BackColor = System.Drawing.Color.LavenderBlush;
			this.pbPersonImage.Image = global::_02_DVLD_Mine.Properties.Resources.find;
			this.pbPersonImage.Location = new System.Drawing.Point(567, 179);
			this.pbPersonImage.Name = "pbPersonImage";
			this.pbPersonImage.Size = new System.Drawing.Size(229, 225);
			this.pbPersonImage.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
			this.pbPersonImage.TabIndex = 9;
			this.pbPersonImage.TabStop = false;
			// 
			// _lblNationalNo
			// 
			this._lblNationalNo.AutoSize = true;
			this._lblNationalNo.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this._lblNationalNo.Location = new System.Drawing.Point(39, 131);
			this._lblNationalNo.Name = "_lblNationalNo";
			this._lblNationalNo.Size = new System.Drawing.Size(124, 26);
			this._lblNationalNo.TabIndex = 8;
			this._lblNationalNo.Text = "National No :";
			// 
			// _lblGender
			// 
			this._lblGender.AutoSize = true;
			this._lblGender.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this._lblGender.Location = new System.Drawing.Point(54, 179);
			this._lblGender.Name = "_lblGender";
			this._lblGender.Size = new System.Drawing.Size(83, 26);
			this._lblGender.TabIndex = 7;
			this._lblGender.Text = "Gender :";
			// 
			// _lblDateOfBirth
			// 
			this._lblDateOfBirth.AutoSize = true;
			this._lblDateOfBirth.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this._lblDateOfBirth.Location = new System.Drawing.Point(35, 224);
			this._lblDateOfBirth.Name = "_lblDateOfBirth";
			this._lblDateOfBirth.Size = new System.Drawing.Size(133, 26);
			this._lblDateOfBirth.TabIndex = 6;
			this._lblDateOfBirth.Text = "Date Of Birth :";
			// 
			// _lblIssueDate
			// 
			this._lblIssueDate.AutoSize = true;
			this._lblIssueDate.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this._lblIssueDate.Location = new System.Drawing.Point(39, 307);
			this._lblIssueDate.Name = "_lblIssueDate";
			this._lblIssueDate.Size = new System.Drawing.Size(109, 26);
			this._lblIssueDate.TabIndex = 4;
			this._lblIssueDate.Text = "Issue Date :";
			// 
			// _lblName
			// 
			this._lblName.AutoSize = true;
			this._lblName.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this._lblName.Location = new System.Drawing.Point(54, 54);
			this._lblName.Name = "_lblName";
			this._lblName.Size = new System.Drawing.Size(73, 26);
			this._lblName.TabIndex = 1;
			this._lblName.Text = "Name :";
			// 
			// _lblLicenseID
			// 
			this._lblLicenseID.AutoSize = true;
			this._lblLicenseID.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this._lblLicenseID.Location = new System.Drawing.Point(540, 24);
			this._lblLicenseID.Name = "_lblLicenseID";
			this._lblLicenseID.Size = new System.Drawing.Size(111, 26);
			this._lblLicenseID.TabIndex = 0;
			this._lblLicenseID.Text = "License ID :";
			// 
			// _04_ucInternationalDetails
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.Controls.Add(this.gbPersonDetails);
			this.Name = "_04_ucInternationalDetails";
			this.Size = new System.Drawing.Size(847, 462);
			this.gbPersonDetails.ResumeLayout(false);
			this.gbPersonDetails.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.pbPersonImage)).EndInit();
			this.ResumeLayout(false);

		}

		#endregion

		private System.Windows.Forms.GroupBox gbPersonDetails;
		private System.Windows.Forms.Label lblDriverID;
		private System.Windows.Forms.Label _lblDriverID;
		private System.Windows.Forms.Label lblIsActive;
		private System.Windows.Forms.Label _lblIsActive;
		private System.Windows.Forms.Label lblExpirationDate;
		private System.Windows.Forms.Label _lblExpirationDate;
		private System.Windows.Forms.Button btnEdit;
		private System.Windows.Forms.Label lblDateOfBirth;
		private System.Windows.Forms.Label lblGender;
		private System.Windows.Forms.Label lblNationalNo;
		private System.Windows.Forms.Label lblIssueDate;
		private System.Windows.Forms.Label lblName;
		private System.Windows.Forms.Label lblLicenseID;
		private System.Windows.Forms.PictureBox pbPersonImage;
		private System.Windows.Forms.Label _lblNationalNo;
		private System.Windows.Forms.Label _lblGender;
		private System.Windows.Forms.Label _lblDateOfBirth;
		private System.Windows.Forms.Label _lblIssueDate;
		private System.Windows.Forms.Label _lblName;
		private System.Windows.Forms.Label _lblLicenseID;
		private System.Windows.Forms.Label lblApplicationID;
		private System.Windows.Forms.Label _lblApplicationID;
	}
}
