﻿namespace _02_DVLD_Mine._src.userControls._04_ucLicenses
{
	partial class _02_ucLicenseHistory
	{
		/// <summary> 
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary> 
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Component Designer generated code

		/// <summary> 
		/// Required method for Designer support - do not modify 
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
			this.gbDriverLicenses = new System.Windows.Forms.GroupBox();
			this.tabControl1 = new System.Windows.Forms.TabControl();
			this.tpLocal = new System.Windows.Forms.TabPage();
			this.lable0 = new System.Windows.Forms.Label();
			this.dgvLocal = new System.Windows.Forms.DataGridView();
			this.cmsShowDetails = new System.Windows.Forms.ContextMenuStrip(this.components);
			this.tsmiShowDetails = new System.Windows.Forms.ToolStripMenuItem();
			this.lblLocal = new System.Windows.Forms.Label();
			this.tpInternational = new System.Windows.Forms.TabPage();
			this.label1 = new System.Windows.Forms.Label();
			this.dgvInternational = new System.Windows.Forms.DataGridView();
			this.lblInternational = new System.Windows.Forms.Label();
			this.gbDriverLicenses.SuspendLayout();
			this.tabControl1.SuspendLayout();
			this.tpLocal.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.dgvLocal)).BeginInit();
			this.cmsShowDetails.SuspendLayout();
			this.tpInternational.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.dgvInternational)).BeginInit();
			this.SuspendLayout();
			// 
			// gbDriverLicenses
			// 
			this.gbDriverLicenses.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
			this.gbDriverLicenses.Controls.Add(this.tabControl1);
			this.gbDriverLicenses.Dock = System.Windows.Forms.DockStyle.Fill;
			this.gbDriverLicenses.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.gbDriverLicenses.Location = new System.Drawing.Point(0, 0);
			this.gbDriverLicenses.Name = "gbDriverLicenses";
			this.gbDriverLicenses.Size = new System.Drawing.Size(1001, 392);
			this.gbDriverLicenses.TabIndex = 2;
			this.gbDriverLicenses.TabStop = false;
			this.gbDriverLicenses.Text = "Driver Licenses :";
			// 
			// tabControl1
			// 
			this.tabControl1.Alignment = System.Windows.Forms.TabAlignment.Bottom;
			this.tabControl1.Controls.Add(this.tpLocal);
			this.tabControl1.Controls.Add(this.tpInternational);
			this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
			this.tabControl1.Font = new System.Drawing.Font("Monotype Corsiva", 18F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.tabControl1.Location = new System.Drawing.Point(3, 24);
			this.tabControl1.Name = "tabControl1";
			this.tabControl1.SelectedIndex = 0;
			this.tabControl1.Size = new System.Drawing.Size(995, 365);
			this.tabControl1.TabIndex = 80;
			// 
			// tpLocal
			// 
			this.tpLocal.Controls.Add(this.lable0);
			this.tpLocal.Controls.Add(this.dgvLocal);
			this.tpLocal.Controls.Add(this.lblLocal);
			this.tpLocal.Location = new System.Drawing.Point(4, 4);
			this.tpLocal.Name = "tpLocal";
			this.tpLocal.Padding = new System.Windows.Forms.Padding(3);
			this.tpLocal.Size = new System.Drawing.Size(987, 324);
			this.tpLocal.TabIndex = 0;
			this.tpLocal.Text = "Local";
			this.tpLocal.UseVisualStyleBackColor = true;
			// 
			// lable0
			// 
			this.lable0.AutoSize = true;
			this.lable0.Font = new System.Drawing.Font("Palatino Linotype", 22F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lable0.ForeColor = System.Drawing.Color.Purple;
			this.lable0.Location = new System.Drawing.Point(314, 3);
			this.lable0.Name = "lable0";
			this.lable0.Size = new System.Drawing.Size(325, 40);
			this.lable0.TabIndex = 79;
			this.lable0.Text = "Local Licenses History";
			// 
			// dgvLocal
			// 
			this.dgvLocal.AllowUserToAddRows = false;
			this.dgvLocal.AllowUserToDeleteRows = false;
			this.dgvLocal.AllowUserToOrderColumns = true;
			this.dgvLocal.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
			this.dgvLocal.BackgroundColor = System.Drawing.SystemColors.GradientInactiveCaption;
			dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
			dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
			dataGridViewCellStyle1.Font = new System.Drawing.Font("Monotype Corsiva", 18F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
			dataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.Aqua;
			dataGridViewCellStyle1.SelectionForeColor = System.Drawing.Color.Violet;
			dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
			this.dgvLocal.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
			this.dgvLocal.ColumnHeadersHeight = 50;
			this.dgvLocal.ContextMenuStrip = this.cmsShowDetails;
			dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
			dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
			dataGridViewCellStyle2.Font = new System.Drawing.Font("Monotype Corsiva", 18F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
			dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.MistyRose;
			dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.ControlText;
			dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
			this.dgvLocal.DefaultCellStyle = dataGridViewCellStyle2;
			this.dgvLocal.Location = new System.Drawing.Point(8, 45);
			this.dgvLocal.Name = "dgvLocal";
			this.dgvLocal.ReadOnly = true;
			this.dgvLocal.RowHeadersWidth = 35;
			this.dgvLocal.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
			this.dgvLocal.Size = new System.Drawing.Size(971, 245);
			this.dgvLocal.TabIndex = 0;
			this.dgvLocal.TabStop = false;
			this.dgvLocal.CellFormatting += new System.Windows.Forms.DataGridViewCellFormattingEventHandler(this.dgvLocal_CellFormatting);
			// 
			// cmsShowDetails
			// 
			this.cmsShowDetails.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsmiShowDetails});
			this.cmsShowDetails.Name = "cmsPeople";
			this.cmsShowDetails.Size = new System.Drawing.Size(160, 44);
			// 
			// tsmiShowDetails
			// 
			this.tsmiShowDetails.Font = new System.Drawing.Font("Aldhabi", 17F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.tsmiShowDetails.Image = global::_02_DVLD_Mine.Properties.Resources.wrap;
			this.tsmiShowDetails.Name = "tsmiShowDetails";
			this.tsmiShowDetails.Size = new System.Drawing.Size(159, 40);
			this.tsmiShowDetails.Text = "Show Details";
			this.tsmiShowDetails.TextDirection = System.Windows.Forms.ToolStripTextDirection.Horizontal;
			this.tsmiShowDetails.Click += new System.EventHandler(this.tsmiShowDetails_Click);
			// 
			// lblLocal
			// 
			this.lblLocal.AutoSize = true;
			this.lblLocal.Font = new System.Drawing.Font("Mongolian Baiti", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblLocal.Location = new System.Drawing.Point(786, 294);
			this.lblLocal.Name = "lblLocal";
			this.lblLocal.Size = new System.Drawing.Size(170, 25);
			this.lblLocal.TabIndex = 78;
			this.lblLocal.Text = "#Records [ 0 ].";
			// 
			// tpInternational
			// 
			this.tpInternational.Controls.Add(this.label1);
			this.tpInternational.Controls.Add(this.dgvInternational);
			this.tpInternational.Controls.Add(this.lblInternational);
			this.tpInternational.Location = new System.Drawing.Point(4, 4);
			this.tpInternational.Name = "tpInternational";
			this.tpInternational.Padding = new System.Windows.Forms.Padding(3);
			this.tpInternational.Size = new System.Drawing.Size(987, 324);
			this.tpInternational.TabIndex = 1;
			this.tpInternational.Text = "International";
			this.tpInternational.UseVisualStyleBackColor = true;
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Font = new System.Drawing.Font("Palatino Linotype", 22F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label1.ForeColor = System.Drawing.Color.Purple;
			this.label1.Location = new System.Drawing.Point(252, 3);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(441, 40);
			this.label1.TabIndex = 82;
			this.label1.Text = " International Licenses History";
			// 
			// dgvInternational
			// 
			this.dgvInternational.AllowUserToAddRows = false;
			this.dgvInternational.AllowUserToDeleteRows = false;
			this.dgvInternational.AllowUserToOrderColumns = true;
			this.dgvInternational.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
			this.dgvInternational.BackgroundColor = System.Drawing.SystemColors.GradientInactiveCaption;
			dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
			dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control;
			dataGridViewCellStyle3.Font = new System.Drawing.Font("Monotype Corsiva", 18F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText;
			dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.Aqua;
			dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.Violet;
			dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
			this.dgvInternational.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle3;
			this.dgvInternational.ColumnHeadersHeight = 50;
			this.dgvInternational.ContextMenuStrip = this.cmsShowDetails;
			dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
			dataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Window;
			dataGridViewCellStyle4.Font = new System.Drawing.Font("Monotype Corsiva", 18F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			dataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.ControlText;
			dataGridViewCellStyle4.SelectionBackColor = System.Drawing.Color.MistyRose;
			dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.ControlText;
			dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
			this.dgvInternational.DefaultCellStyle = dataGridViewCellStyle4;
			this.dgvInternational.Location = new System.Drawing.Point(8, 45);
			this.dgvInternational.Name = "dgvInternational";
			this.dgvInternational.ReadOnly = true;
			this.dgvInternational.RowHeadersWidth = 35;
			this.dgvInternational.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
			this.dgvInternational.Size = new System.Drawing.Size(971, 245);
			this.dgvInternational.TabIndex = 0;
			this.dgvInternational.TabStop = false;
			this.dgvInternational.CellFormatting += new System.Windows.Forms.DataGridViewCellFormattingEventHandler(this.dgvInternational_CellFormatting);
			// 
			// lblInternational
			// 
			this.lblInternational.AutoSize = true;
			this.lblInternational.Font = new System.Drawing.Font("Mongolian Baiti", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblInternational.Location = new System.Drawing.Point(786, 294);
			this.lblInternational.Name = "lblInternational";
			this.lblInternational.Size = new System.Drawing.Size(170, 25);
			this.lblInternational.TabIndex = 81;
			this.lblInternational.Text = "#Records [ 0 ].";
			// 
			// _02_ucLicenseHistory
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
			this.Controls.Add(this.gbDriverLicenses);
			this.Name = "_02_ucLicenseHistory";
			this.Size = new System.Drawing.Size(1001, 392);
			this.gbDriverLicenses.ResumeLayout(false);
			this.tabControl1.ResumeLayout(false);
			this.tpLocal.ResumeLayout(false);
			this.tpLocal.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.dgvLocal)).EndInit();
			this.cmsShowDetails.ResumeLayout(false);
			this.tpInternational.ResumeLayout(false);
			this.tpInternational.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.dgvInternational)).EndInit();
			this.ResumeLayout(false);

		}

		#endregion

		private System.Windows.Forms.GroupBox gbDriverLicenses;
		private System.Windows.Forms.TabControl tabControl1;
		private System.Windows.Forms.TabPage tpLocal;
		private System.Windows.Forms.TabPage tpInternational;
		private System.Windows.Forms.Label lable0;
		private System.Windows.Forms.Label lblLocal;
		private System.Windows.Forms.DataGridView dgvLocal;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.DataGridView dgvInternational;
		private System.Windows.Forms.Label lblInternational;
		private System.Windows.Forms.ContextMenuStrip cmsShowDetails;
		private System.Windows.Forms.ToolStripMenuItem tsmiShowDetails;
	}
}
