﻿namespace _02_DVLD_Mine._src.userControls._04_ucLicenses
{
	partial class _01_ucLicenseDetails
	{
		/// <summary> 
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary> 
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Component Designer generated code

		/// <summary> 
		/// Required method for Designer support - do not modify 
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.gbPersonDetails = new System.Windows.Forms.GroupBox();
			this.lblDriverID = new System.Windows.Forms.Label();
			this._lblDriverID = new System.Windows.Forms.Label();
			this.lblIsDetained = new System.Windows.Forms.Label();
			this._lblIsDetained = new System.Windows.Forms.Label();
			this.lblIsActive = new System.Windows.Forms.Label();
			this._lblIsActive = new System.Windows.Forms.Label();
			this.lblExpirationDate = new System.Windows.Forms.Label();
			this._lblExpirationDate = new System.Windows.Forms.Label();
			this.btnEdit = new System.Windows.Forms.Button();
			this.lblDateOfBirth = new System.Windows.Forms.Label();
			this.lblGender = new System.Windows.Forms.Label();
			this.lblNationalNo = new System.Windows.Forms.Label();
			this.lblNotes = new System.Windows.Forms.Label();
			this.lblIssueDate = new System.Windows.Forms.Label();
			this.lblClassName = new System.Windows.Forms.Label();
			this.lblName = new System.Windows.Forms.Label();
			this.lblLicenseID = new System.Windows.Forms.Label();
			this.pbPersonImage = new System.Windows.Forms.PictureBox();
			this._lblNationalNo = new System.Windows.Forms.Label();
			this._lblGender = new System.Windows.Forms.Label();
			this._lblDateOfBirth = new System.Windows.Forms.Label();
			this._lblNotes = new System.Windows.Forms.Label();
			this._lblIssueDate = new System.Windows.Forms.Label();
			this._lblClassName = new System.Windows.Forms.Label();
			this._lblName = new System.Windows.Forms.Label();
			this._lblLicenseID = new System.Windows.Forms.Label();
			this.lblIssueReason = new System.Windows.Forms.Label();
			this._lblIssueReason = new System.Windows.Forms.Label();
			this.gbPersonDetails.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.pbPersonImage)).BeginInit();
			this.SuspendLayout();
			// 
			// gbPersonDetails
			// 
			this.gbPersonDetails.BackColor = System.Drawing.Color.PaleTurquoise;
			this.gbPersonDetails.Controls.Add(this.lblIssueReason);
			this.gbPersonDetails.Controls.Add(this._lblIssueReason);
			this.gbPersonDetails.Controls.Add(this.lblDriverID);
			this.gbPersonDetails.Controls.Add(this._lblDriverID);
			this.gbPersonDetails.Controls.Add(this.lblIsDetained);
			this.gbPersonDetails.Controls.Add(this._lblIsDetained);
			this.gbPersonDetails.Controls.Add(this.lblIsActive);
			this.gbPersonDetails.Controls.Add(this._lblIsActive);
			this.gbPersonDetails.Controls.Add(this.lblExpirationDate);
			this.gbPersonDetails.Controls.Add(this._lblExpirationDate);
			this.gbPersonDetails.Controls.Add(this.btnEdit);
			this.gbPersonDetails.Controls.Add(this.lblDateOfBirth);
			this.gbPersonDetails.Controls.Add(this.lblGender);
			this.gbPersonDetails.Controls.Add(this.lblNationalNo);
			this.gbPersonDetails.Controls.Add(this.lblNotes);
			this.gbPersonDetails.Controls.Add(this.lblIssueDate);
			this.gbPersonDetails.Controls.Add(this.lblClassName);
			this.gbPersonDetails.Controls.Add(this.lblName);
			this.gbPersonDetails.Controls.Add(this.lblLicenseID);
			this.gbPersonDetails.Controls.Add(this.pbPersonImage);
			this.gbPersonDetails.Controls.Add(this._lblNationalNo);
			this.gbPersonDetails.Controls.Add(this._lblGender);
			this.gbPersonDetails.Controls.Add(this._lblDateOfBirth);
			this.gbPersonDetails.Controls.Add(this._lblNotes);
			this.gbPersonDetails.Controls.Add(this._lblIssueDate);
			this.gbPersonDetails.Controls.Add(this._lblClassName);
			this.gbPersonDetails.Controls.Add(this._lblName);
			this.gbPersonDetails.Controls.Add(this._lblLicenseID);
			this.gbPersonDetails.Dock = System.Windows.Forms.DockStyle.Fill;
			this.gbPersonDetails.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.gbPersonDetails.Location = new System.Drawing.Point(0, 0);
			this.gbPersonDetails.Name = "gbPersonDetails";
			this.gbPersonDetails.Size = new System.Drawing.Size(908, 570);
			this.gbPersonDetails.TabIndex = 2;
			this.gbPersonDetails.TabStop = false;
			this.gbPersonDetails.Text = "Driver License Information  :";
			// 
			// lblDriverID
			// 
			this.lblDriverID.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
			this.lblDriverID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.lblDriverID.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblDriverID.ForeColor = System.Drawing.Color.Black;
			this.lblDriverID.Location = new System.Drawing.Point(782, 91);
			this.lblDriverID.Name = "lblDriverID";
			this.lblDriverID.Size = new System.Drawing.Size(73, 41);
			this.lblDriverID.TabIndex = 26;
			this.lblDriverID.Text = "???";
			this.lblDriverID.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// _lblDriverID
			// 
			this._lblDriverID.AutoSize = true;
			this._lblDriverID.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this._lblDriverID.Location = new System.Drawing.Point(593, 98);
			this._lblDriverID.Name = "_lblDriverID";
			this._lblDriverID.Size = new System.Drawing.Size(108, 26);
			this._lblDriverID.TabIndex = 25;
			this._lblDriverID.Text = " Driver ID :";
			// 
			// lblIsDetained
			// 
			this.lblIsDetained.BackColor = System.Drawing.Color.AntiqueWhite;
			this.lblIsDetained.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.lblIsDetained.Font = new System.Drawing.Font("Palatino Linotype", 13.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblIsDetained.Location = new System.Drawing.Point(750, 510);
			this.lblIsDetained.Name = "lblIsDetained";
			this.lblIsDetained.Size = new System.Drawing.Size(105, 35);
			this.lblIsDetained.TabIndex = 24;
			this.lblIsDetained.Text = "!?";
			this.lblIsDetained.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// _lblIsDetained
			// 
			this._lblIsDetained.AutoSize = true;
			this._lblIsDetained.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this._lblIsDetained.Location = new System.Drawing.Point(593, 514);
			this._lblIsDetained.Name = "_lblIsDetained";
			this._lblIsDetained.Size = new System.Drawing.Size(115, 26);
			this._lblIsDetained.TabIndex = 23;
			this._lblIsDetained.Text = "Is Detained?";
			// 
			// lblIsActive
			// 
			this.lblIsActive.BackColor = System.Drawing.Color.AntiqueWhite;
			this.lblIsActive.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.lblIsActive.Font = new System.Drawing.Font("Palatino Linotype", 13.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblIsActive.Location = new System.Drawing.Point(750, 460);
			this.lblIsActive.Name = "lblIsActive";
			this.lblIsActive.Size = new System.Drawing.Size(105, 35);
			this.lblIsActive.TabIndex = 22;
			this.lblIsActive.Text = "!?";
			this.lblIsActive.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// _lblIsActive
			// 
			this._lblIsActive.AutoSize = true;
			this._lblIsActive.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this._lblIsActive.Location = new System.Drawing.Point(605, 464);
			this._lblIsActive.Name = "_lblIsActive";
			this._lblIsActive.Size = new System.Drawing.Size(93, 26);
			this._lblIsActive.TabIndex = 21;
			this._lblIsActive.Text = "Is Active?";
			// 
			// lblExpirationDate
			// 
			this.lblExpirationDate.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
			this.lblExpirationDate.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.lblExpirationDate.Font = new System.Drawing.Font("Palatino Linotype", 13.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblExpirationDate.Location = new System.Drawing.Point(189, 355);
			this.lblExpirationDate.Name = "lblExpirationDate";
			this.lblExpirationDate.Size = new System.Drawing.Size(291, 35);
			this.lblExpirationDate.TabIndex = 20;
			this.lblExpirationDate.Text = "????";
			this.lblExpirationDate.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// _lblExpirationDate
			// 
			this._lblExpirationDate.AutoSize = true;
			this._lblExpirationDate.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this._lblExpirationDate.Location = new System.Drawing.Point(9, 355);
			this._lblExpirationDate.Name = "_lblExpirationDate";
			this._lblExpirationDate.Size = new System.Drawing.Size(152, 26);
			this._lblExpirationDate.TabIndex = 19;
			this._lblExpirationDate.Text = "Expiration Date :";
			// 
			// btnEdit
			// 
			this.btnEdit.BackColor = System.Drawing.SystemColors.ScrollBar;
			this.btnEdit.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
			this.btnEdit.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
			this.btnEdit.FlatAppearance.BorderSize = 2;
			this.btnEdit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnEdit.Font = new System.Drawing.Font("Palatino Linotype", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnEdit.ForeColor = System.Drawing.Color.Red;
			this.btnEdit.Image = global::_02_DVLD_Mine.Properties.Resources.highlighter_pen;
			this.btnEdit.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btnEdit.Location = new System.Drawing.Point(645, 384);
			this.btnEdit.Name = "btnEdit";
			this.btnEdit.Size = new System.Drawing.Size(159, 36);
			this.btnEdit.TabIndex = 0;
			this.btnEdit.Text = "Edit Person Info";
			this.btnEdit.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.btnEdit.UseVisualStyleBackColor = false;
			this.btnEdit.Visible = false;
			this.btnEdit.Click += new System.EventHandler(this.btnEditPerson_Click);
			// 
			// lblDateOfBirth
			// 
			this.lblDateOfBirth.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
			this.lblDateOfBirth.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.lblDateOfBirth.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblDateOfBirth.Location = new System.Drawing.Point(188, 246);
			this.lblDateOfBirth.Name = "lblDateOfBirth";
			this.lblDateOfBirth.Size = new System.Drawing.Size(291, 35);
			this.lblDateOfBirth.TabIndex = 18;
			this.lblDateOfBirth.Text = "????";
			this.lblDateOfBirth.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// lblGender
			// 
			this.lblGender.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
			this.lblGender.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.lblGender.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblGender.Location = new System.Drawing.Point(246, 197);
			this.lblGender.Name = "lblGender";
			this.lblGender.Size = new System.Drawing.Size(163, 35);
			this.lblGender.TabIndex = 17;
			this.lblGender.Text = "????";
			this.lblGender.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// lblNationalNo
			// 
			this.lblNationalNo.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
			this.lblNationalNo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.lblNationalNo.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblNationalNo.Location = new System.Drawing.Point(246, 149);
			this.lblNationalNo.Name = "lblNationalNo";
			this.lblNationalNo.Size = new System.Drawing.Size(163, 35);
			this.lblNationalNo.TabIndex = 16;
			this.lblNationalNo.Text = "????";
			this.lblNationalNo.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// lblNotes
			// 
			this.lblNotes.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
			this.lblNotes.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.lblNotes.Font = new System.Drawing.Font("Palatino Linotype", 11F, System.Drawing.FontStyle.Bold);
			this.lblNotes.Location = new System.Drawing.Point(143, 469);
			this.lblNotes.Name = "lblNotes";
			this.lblNotes.Size = new System.Drawing.Size(356, 83);
			this.lblNotes.TabIndex = 15;
			this.lblNotes.Text = "????";
			// 
			// lblIssueDate
			// 
			this.lblIssueDate.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
			this.lblIssueDate.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.lblIssueDate.Font = new System.Drawing.Font("Palatino Linotype", 13.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblIssueDate.Location = new System.Drawing.Point(188, 308);
			this.lblIssueDate.Name = "lblIssueDate";
			this.lblIssueDate.Size = new System.Drawing.Size(291, 35);
			this.lblIssueDate.TabIndex = 14;
			this.lblIssueDate.Text = "????";
			this.lblIssueDate.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// lblClassName
			// 
			this.lblClassName.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
			this.lblClassName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.lblClassName.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblClassName.Location = new System.Drawing.Point(166, 39);
			this.lblClassName.Name = "lblClassName";
			this.lblClassName.Size = new System.Drawing.Size(326, 35);
			this.lblClassName.TabIndex = 12;
			this.lblClassName.Text = "????";
			this.lblClassName.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// lblName
			// 
			this.lblName.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
			this.lblName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.lblName.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblName.Location = new System.Drawing.Point(166, 90);
			this.lblName.Name = "lblName";
			this.lblName.Size = new System.Drawing.Size(326, 35);
			this.lblName.TabIndex = 11;
			this.lblName.Text = "????";
			this.lblName.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// lblLicenseID
			// 
			this.lblLicenseID.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
			this.lblLicenseID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.lblLicenseID.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblLicenseID.ForeColor = System.Drawing.Color.Red;
			this.lblLicenseID.Location = new System.Drawing.Point(731, 39);
			this.lblLicenseID.Name = "lblLicenseID";
			this.lblLicenseID.Size = new System.Drawing.Size(73, 41);
			this.lblLicenseID.TabIndex = 10;
			this.lblLicenseID.Text = "???";
			this.lblLicenseID.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// pbPersonImage
			// 
			this.pbPersonImage.BackColor = System.Drawing.Color.LavenderBlush;
			this.pbPersonImage.Image = global::_02_DVLD_Mine.Properties.Resources.find;
			this.pbPersonImage.Location = new System.Drawing.Point(616, 153);
			this.pbPersonImage.Name = "pbPersonImage";
			this.pbPersonImage.Size = new System.Drawing.Size(229, 225);
			this.pbPersonImage.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
			this.pbPersonImage.TabIndex = 9;
			this.pbPersonImage.TabStop = false;
			// 
			// _lblNationalNo
			// 
			this._lblNationalNo.AutoSize = true;
			this._lblNationalNo.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this._lblNationalNo.Location = new System.Drawing.Point(23, 153);
			this._lblNationalNo.Name = "_lblNationalNo";
			this._lblNationalNo.Size = new System.Drawing.Size(124, 26);
			this._lblNationalNo.TabIndex = 8;
			this._lblNationalNo.Text = "National No :";
			// 
			// _lblGender
			// 
			this._lblGender.AutoSize = true;
			this._lblGender.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this._lblGender.Location = new System.Drawing.Point(38, 201);
			this._lblGender.Name = "_lblGender";
			this._lblGender.Size = new System.Drawing.Size(83, 26);
			this._lblGender.TabIndex = 7;
			this._lblGender.Text = "Gender :";
			// 
			// _lblDateOfBirth
			// 
			this._lblDateOfBirth.AutoSize = true;
			this._lblDateOfBirth.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this._lblDateOfBirth.Location = new System.Drawing.Point(19, 246);
			this._lblDateOfBirth.Name = "_lblDateOfBirth";
			this._lblDateOfBirth.Size = new System.Drawing.Size(133, 26);
			this._lblDateOfBirth.TabIndex = 6;
			this._lblDateOfBirth.Text = "Date Of Birth :";
			// 
			// _lblNotes
			// 
			this._lblNotes.AutoSize = true;
			this._lblNotes.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this._lblNotes.Location = new System.Drawing.Point(46, 495);
			this._lblNotes.Name = "_lblNotes";
			this._lblNotes.Size = new System.Drawing.Size(71, 26);
			this._lblNotes.TabIndex = 5;
			this._lblNotes.Text = "Notes :";
			// 
			// _lblIssueDate
			// 
			this._lblIssueDate.AutoSize = true;
			this._lblIssueDate.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this._lblIssueDate.Location = new System.Drawing.Point(23, 312);
			this._lblIssueDate.Name = "_lblIssueDate";
			this._lblIssueDate.Size = new System.Drawing.Size(109, 26);
			this._lblIssueDate.TabIndex = 4;
			this._lblIssueDate.Text = "Issue Date :";
			// 
			// _lblClassName
			// 
			this._lblClassName.AutoSize = true;
			this._lblClassName.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this._lblClassName.Location = new System.Drawing.Point(46, 46);
			this._lblClassName.Name = "_lblClassName";
			this._lblClassName.Size = new System.Drawing.Size(64, 26);
			this._lblClassName.TabIndex = 2;
			this._lblClassName.Text = "Class :";
			// 
			// _lblName
			// 
			this._lblName.AutoSize = true;
			this._lblName.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this._lblName.Location = new System.Drawing.Point(46, 94);
			this._lblName.Name = "_lblName";
			this._lblName.Size = new System.Drawing.Size(73, 26);
			this._lblName.TabIndex = 1;
			this._lblName.Text = "Name :";
			// 
			// _lblLicenseID
			// 
			this._lblLicenseID.AutoSize = true;
			this._lblLicenseID.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this._lblLicenseID.Location = new System.Drawing.Point(570, 46);
			this._lblLicenseID.Name = "_lblLicenseID";
			this._lblLicenseID.Size = new System.Drawing.Size(111, 26);
			this._lblLicenseID.TabIndex = 0;
			this._lblLicenseID.Text = "License ID :";
			// 
			// lblIssueReason
			// 
			this.lblIssueReason.BackColor = System.Drawing.Color.LavenderBlush;
			this.lblIssueReason.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.lblIssueReason.Font = new System.Drawing.Font("Palatino Linotype", 13F, System.Drawing.FontStyle.Bold);
			this.lblIssueReason.ForeColor = System.Drawing.Color.Red;
			this.lblIssueReason.Location = new System.Drawing.Point(202, 416);
			this.lblIssueReason.Name = "lblIssueReason";
			this.lblIssueReason.Size = new System.Drawing.Size(263, 35);
			this.lblIssueReason.TabIndex = 28;
			this.lblIssueReason.Text = "Replacement for Damaged";
			this.lblIssueReason.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// _lblIssueReason
			// 
			this._lblIssueReason.AutoSize = true;
			this._lblIssueReason.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this._lblIssueReason.Location = new System.Drawing.Point(19, 420);
			this._lblIssueReason.Name = "_lblIssueReason";
			this._lblIssueReason.Size = new System.Drawing.Size(130, 26);
			this._lblIssueReason.TabIndex = 27;
			this._lblIssueReason.Text = "Issue Reason :";
			// 
			// _01_ucLicenseDetails
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.Controls.Add(this.gbPersonDetails);
			this.Name = "_01_ucLicenseDetails";
			this.Size = new System.Drawing.Size(908, 570);
			this.gbPersonDetails.ResumeLayout(false);
			this.gbPersonDetails.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.pbPersonImage)).EndInit();
			this.ResumeLayout(false);

		}

		#endregion

		private System.Windows.Forms.GroupBox gbPersonDetails;
		private System.Windows.Forms.Button btnEdit;
		private System.Windows.Forms.Label lblDateOfBirth;
		private System.Windows.Forms.Label lblGender;
		private System.Windows.Forms.Label lblNationalNo;
		private System.Windows.Forms.Label lblNotes;
		private System.Windows.Forms.Label lblIssueDate;
		private System.Windows.Forms.Label lblClassName;
		private System.Windows.Forms.Label lblName;
		private System.Windows.Forms.Label lblLicenseID;
		private System.Windows.Forms.PictureBox pbPersonImage;
		private System.Windows.Forms.Label _lblNationalNo;
		private System.Windows.Forms.Label _lblGender;
		private System.Windows.Forms.Label _lblDateOfBirth;
		private System.Windows.Forms.Label _lblNotes;
		private System.Windows.Forms.Label _lblIssueDate;
		private System.Windows.Forms.Label _lblClassName;
		private System.Windows.Forms.Label _lblName;
		private System.Windows.Forms.Label _lblLicenseID;
		private System.Windows.Forms.Label _lblExpirationDate;
		private System.Windows.Forms.Label lblExpirationDate;
		private System.Windows.Forms.Label lblIsActive;
		private System.Windows.Forms.Label _lblIsActive;
		private System.Windows.Forms.Label lblIsDetained;
		private System.Windows.Forms.Label _lblIsDetained;
		private System.Windows.Forms.Label lblDriverID;
		private System.Windows.Forms.Label _lblDriverID;
		private System.Windows.Forms.Label lblIssueReason;
		private System.Windows.Forms.Label _lblIssueReason;
	}
}
