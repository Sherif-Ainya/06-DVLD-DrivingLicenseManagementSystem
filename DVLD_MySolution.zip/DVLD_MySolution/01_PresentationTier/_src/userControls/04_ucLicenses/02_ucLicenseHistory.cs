﻿using System.Windows.Forms;
using _02_DVLD_Mine._src.Forms._09_Licenses;
using DVLD_Business;

namespace _02_DVLD_Mine._src.userControls._04_ucLicenses
{
	public partial class _02_ucLicenseHistory : UserControl
	{
		public _02_ucLicenseHistory()
		{
			InitializeComponent();
		}

		private void dgvLocal_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
		{
			dgvLocal.ColumnHeadersHeight = 60;
			dgvLocal.RowTemplate.Height = 25;

			dgvLocal.Columns[0].Width = 110;
			dgvLocal.Columns[1].Width = 110;
			dgvLocal.Columns[5].Width = 120;

			dgvLocal.Columns[0].HeaderText = "Lic ID";
			dgvLocal.Columns[1].HeaderText = "App ID";
			dgvLocal.Columns[2].HeaderText = "Class Name";
			dgvLocal.Columns[3].HeaderText = "Issue Date";
			dgvLocal.Columns[4].HeaderText = "Expiration Date";
			dgvLocal.Columns[5].HeaderText = "Is Active?";
		}
		private void dgvInternational_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
		{
			dgvInternational.ColumnHeadersHeight = 60;
			//dgvInternational.RowTemplate.Height = 37;

			dgvInternational.Columns[0].Width = 110;
			dgvInternational.Columns[1].Width = 110;
			dgvInternational.Columns[5].Width = 120;

			dgvInternational.Columns[0].HeaderText = "Lic ID";
			dgvInternational.Columns[1].HeaderText = "App ID";
			dgvInternational.Columns[2].HeaderText = "Class Name";
			dgvInternational.Columns[3].HeaderText = "Issue Date";
			dgvInternational.Columns[4].HeaderText = "Expiration Date";
			dgvInternational.Columns[5].HeaderText = "Is Active?";
		}

		public void LoadPersonData(int personID)
		{
			dgvLocal.SuspendLayout();
			dgvLocal.DataSource = clsBusinessLicenses.GetAllLocalLicensesForPerson(personID);
			dgvLocal.ResumeLayout();
			lblLocal.Text = "# Records [" + dgvLocal.RowCount.ToString() + "].";

			dgvLocal.SuspendLayout();
			dgvInternational.DataSource = clsBusinessInternationDL.GetAll_IntLicensesForPerson(personID);
			lblInternational.Text = "# Records [" + dgvInternational.RowCount.ToString() + "].";
			dgvLocal.ResumeLayout();
		}
		public void LoadPersonData(string nationalNo)
		{
			dgvLocal.SuspendLayout();
			dgvLocal.DataSource = clsBusinessLicenses.GetAllLocalLicensesForPerson(nationalNo);
			dgvLocal.ResumeLayout();
			lblLocal.Text = "# Records [" + dgvLocal.RowCount.ToString() + "].";

			dgvLocal.SuspendLayout();
			dgvInternational.DataSource = clsBusinessInternationDL.GetAll_IntLicensesForPerson(nationalNo);
			lblInternational.Text = "# Records [" + dgvInternational.RowCount.ToString() + "].";
			dgvLocal.ResumeLayout();
		}

		private void tsmiShowDetails_Click(object sender, System.EventArgs e)
		{
			Form frm = new frmLicenseDetails((int)dgvLocal.CurrentRow.Cells[0].Value, frmLicenseDetails.enFindBy.eLicenseID);
			frm.ShowDialog();
		}
	}
}
