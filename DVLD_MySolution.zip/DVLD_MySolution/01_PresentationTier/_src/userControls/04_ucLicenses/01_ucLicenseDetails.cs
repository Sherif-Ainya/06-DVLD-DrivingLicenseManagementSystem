﻿using System.IO;
using System.Windows.Forms;
using _02_DVLD_Mine._src.Forms._02_People;
using _02_DVLD_Mine.Properties;
using DVLD_Business;

namespace _02_DVLD_Mine._src.userControls._04_ucLicenses
{
	public partial class _01_ucLicenseDetails : UserControl
	{
		public _01_ucLicenseDetails()
		{
			InitializeComponent();
		}


		clsBusinessLicenses _currentLicense;
		clsBusinessPeople _currentPerson;


		private void _LoadData()
		{
			_currentPerson = clsBusinessPeople.Find(clsBusinessDrivers.Find(_currentLicense.DriverID).PersonID);

			lblName.Text = _currentPerson.FullName;
			lblNationalNo.Text = _currentPerson.nationalNo;
			lblGender.Text = (_currentPerson.gender == 0) ? "Male." : "Female";
			lblDateOfBirth.Text = _currentPerson.dateOfBirth.ToString("d");

			lblLicenseID.Text = _currentLicense.LicenseID.ToString();
			lblDriverID.Text = _currentLicense.DriverID.ToString();
			lblClassName.Text = clsBusinessLicenseClasses.Find(_currentLicense.LicenseClass).ClassName;
			lblIssueDate.Text = _currentLicense.IssueDate.ToString("d");
			lblExpirationDate.Text = _currentLicense.ExpirationDate.ToString("d");
			lblIssueReason.Text = (_currentLicense.IssueReason == 1) ? "First Time." : (_currentLicense.IssueReason == 2) ? "Renew." : (_currentLicense.IssueReason == 3) ? "Replacement For Damaged." : "Replacement For Lose.";
			lblNotes.Text = _currentLicense.Notes;
			lblIsActive.Text = (_currentLicense.IsActive) ? "Yes." : "No.";
			lblIsDetained.Text = (clsBusinessDetainedLicenses.IsThisLicenseDetained(_currentLicense.LicenseID)) ? "Yes." : "No.";


			if (!string.IsNullOrEmpty(_currentPerson.imagePath) && File.Exists(_currentPerson.imagePath))
			{
				pbPersonImage.Load(_currentPerson.imagePath);
				pbPersonImage.SizeMode = PictureBoxSizeMode.Zoom;
				return;
			}
			if (_currentPerson.gender == 0)
				pbPersonImage.Image = Resources.Male;
			else
				pbPersonImage.Image = Resources.Female;
		}
		public void LoadLicenseDataByLDLA_ID(int LDLA_ID)
		{
			_currentLicense = clsBusinessLicenses.FindByLDLA_ID(LDLA_ID);

			if (_currentLicense != null)
			{
				btnEdit.Visible = true;
				_LoadData();
			}
		}
		public void LoadLicenseDataByLicenseID(int licenseID)
		{
			_currentLicense = clsBusinessLicenses.FindByLicenseID(licenseID);

			if (_currentLicense != null)
			{
				btnEdit.Visible = true;
				_LoadData();
			}
		}


		private void _UpdatePersonInfo()
		{
			lblName.Text = _currentPerson.FullName;
			lblNationalNo.Text = _currentPerson.nationalNo;
			lblGender.Text = (_currentPerson.gender == 0) ? "Male." : "Female";
			lblDateOfBirth.Text = _currentPerson.dateOfBirth.ToString("d");

			if (!string.IsNullOrEmpty(_currentPerson.imagePath) && File.Exists(_currentPerson.imagePath))
			{
				pbPersonImage.Load(_currentPerson.imagePath);
				pbPersonImage.SizeMode = PictureBoxSizeMode.Zoom;
				return;
			}
			if (_currentPerson.gender == 0)
				pbPersonImage.Image = Resources.Male;
			else
				pbPersonImage.Image = Resources.Female;
		}
		private void btnEditPerson_Click(object sender, System.EventArgs e)
		{
			Form update = new frmAdd_UpdatePersonN(_currentPerson.personID);
			update.ShowDialog();

			_currentPerson = clsBusinessPeople.Find(_currentPerson.personID);

			_UpdatePersonInfo();
		}
	}
}
