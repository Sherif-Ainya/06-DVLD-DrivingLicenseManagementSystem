﻿namespace _02_DVLD_Mine._src.userControls._04_ucLicenses
{
	partial class _03_ucFindLDL
	{
		/// <summary> 
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary> 
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Component Designer generated code

		/// <summary> 
		/// Required method for Designer support - do not modify 
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.mtxbFindLDL = new System.Windows.Forms.MaskedTextBox();
			this.lblFiind = new System.Windows.Forms.Label();
			this.btnFind = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// mtxbFindLDL
			// 
			this.mtxbFindLDL.AsciiOnly = true;
			this.mtxbFindLDL.Font = new System.Drawing.Font("Microsoft Sans Serif", 17F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.mtxbFindLDL.Location = new System.Drawing.Point(331, 63);
			this.mtxbFindLDL.Name = "mtxbFindLDL";
			this.mtxbFindLDL.Size = new System.Drawing.Size(248, 33);
			this.mtxbFindLDL.TabIndex = 0;
			this.mtxbFindLDL.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			// 
			// lblFiind
			// 
			this.lblFiind.AutoSize = true;
			this.lblFiind.Font = new System.Drawing.Font("Microsoft Uighur", 22F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblFiind.Location = new System.Drawing.Point(106, 63);
			this.lblFiind.Name = "lblFiind";
			this.lblFiind.Size = new System.Drawing.Size(193, 37);
			this.lblFiind.TabIndex = 55;
			this.lblFiind.Text = "Find By License ID :";
			// 
			// btnFind
			// 
			this.btnFind.BackColor = System.Drawing.Color.HotPink;
			this.btnFind.FlatAppearance.BorderColor = System.Drawing.Color.Black;
			this.btnFind.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
			this.btnFind.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
			this.btnFind.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnFind.Font = new System.Drawing.Font("Microsoft YaHei UI", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnFind.ForeColor = System.Drawing.Color.Red;
			this.btnFind.Image = global::_02_DVLD_Mine.Properties.Resources.find;
			this.btnFind.Location = new System.Drawing.Point(597, 54);
			this.btnFind.Name = "btnFind";
			this.btnFind.Size = new System.Drawing.Size(64, 50);
			this.btnFind.TabIndex = 1;
			this.btnFind.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.btnFind.UseVisualStyleBackColor = false;
			this.btnFind.Click += new System.EventHandler(this.btnFind_Click);
			// 
			// _03_ucFindLDL
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
			this.Controls.Add(this.btnFind);
			this.Controls.Add(this.lblFiind);
			this.Controls.Add(this.mtxbFindLDL);
			this.Name = "_03_ucFindLDL";
			this.Size = new System.Drawing.Size(809, 163);
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion
		private System.Windows.Forms.MaskedTextBox mtxbFindLDL;
		private System.Windows.Forms.Label lblFiind;
		private System.Windows.Forms.Button btnFind;
	}
}
