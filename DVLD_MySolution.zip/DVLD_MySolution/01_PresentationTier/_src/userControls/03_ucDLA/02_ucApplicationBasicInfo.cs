﻿using System.Windows.Forms;
using _02_DVLD_Mine._src.Forms._02_People;
using DVLD_Business;

namespace _02_DVLD_Mine._src.userControls._03_ucDLA
{
	public partial class ucDLABasicInfo : UserControl
	{
		public ucDLABasicInfo()
		{
			InitializeComponent();
		}


		int _currentA_ID, _personID;
		clsBusinessApplications _currentApp;

		private void _Reload()
		{
			_currentApp = clsBusinessApplications.Find(_currentA_ID);

			if (_currentApp == null)
				return;

			lblAppID.Text = _currentApp.ApplicationID.ToString();

			switch (_currentApp.ApplicationStatus)
			{
				case 1:
					lblStatus.Text = "New";
					break;
				case 2:
					lblStatus.Text = "Cancelled";
					break;
				case 3:
					lblStatus.Text = "Completed";
					break;
			}
			lblFees.Text = _currentApp.PaidFees.ToString();
			lblDate.Text = _currentApp.ApplicationDateTime.ToString();
			lblStatusDate.Text = _currentApp.LastStatusDate.ToString();
			lblType.Text = clsBusinessApplicationTypes.Find(_currentApp.ApplicationTypeID).applicationTypeTitle;
			lblApplicant.Text = clsBusinessPeople.Find(_currentApp.ApplicationPersonID).FullName;
			_personID = _currentApp.ApplicationPersonID;
			lblCreatedBy.Text = clsBusinessUsers.Find(_currentApp.CreatedByUserID).userName;
		}
		public void LoadAppBasicData(int AppID)
		{
			_currentA_ID = AppID;
			_Reload();
		}

		private void btnEdit_Click(object sender, System.EventArgs e)
		{
			Form personDetails = new frmPersonDetailsN(_personID);
			personDetails.ShowDialog();
		}
	}
}
