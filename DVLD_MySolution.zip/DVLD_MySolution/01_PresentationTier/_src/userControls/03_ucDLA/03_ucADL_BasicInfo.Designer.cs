﻿namespace _02_DVLD_Mine._src.userControls._03_ucDLA
{
	partial class ucADL_BasicInfo
	{
		/// <summary> 
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary> 
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Component Designer generated code

		/// <summary> 
		/// Required method for Designer support - do not modify 
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.uc_DL_Info1 = new _02_DVLD_Mine._src.userControls._03_ucDLA.uc_DL_Info();
			this.ucDLABasicInfo1 = new _02_DVLD_Mine._src.userControls._03_ucDLA.ucDLABasicInfo();
			this.SuspendLayout();
			// 
			// uc_DL_Info1
			// 
			this.uc_DL_Info1.Dock = System.Windows.Forms.DockStyle.Top;
			this.uc_DL_Info1.Location = new System.Drawing.Point(0, 0);
			this.uc_DL_Info1.Name = "uc_DL_Info1";
			this.uc_DL_Info1.Size = new System.Drawing.Size(809, 142);
			this.uc_DL_Info1.TabIndex = 0;
			// 
			// ucDLABasicInfo1
			// 
			this.ucDLABasicInfo1.Dock = System.Windows.Forms.DockStyle.Bottom;
			this.ucDLABasicInfo1.Location = new System.Drawing.Point(0, 158);
			this.ucDLABasicInfo1.Name = "ucDLABasicInfo1";
			this.ucDLABasicInfo1.Size = new System.Drawing.Size(809, 285);
			this.ucDLABasicInfo1.TabIndex = 1;
			// 
			// ucADL_BasicInfo
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
			this.Controls.Add(this.ucDLABasicInfo1);
			this.Controls.Add(this.uc_DL_Info1);
			this.Name = "ucADL_BasicInfo";
			this.Size = new System.Drawing.Size(809, 443);
			this.ResumeLayout(false);

		}

		#endregion

		private uc_DL_Info uc_DL_Info1;
		private ucDLABasicInfo ucDLABasicInfo1;
	}
}
