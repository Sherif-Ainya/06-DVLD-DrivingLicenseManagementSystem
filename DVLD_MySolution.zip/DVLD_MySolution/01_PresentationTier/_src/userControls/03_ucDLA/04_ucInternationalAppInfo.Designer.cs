﻿namespace _02_DVLD_Mine._src.userControls._03_ucDLA
{
	partial class ucInternationalAppInfo
	{
		/// <summary> 
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary> 
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Component Designer generated code

		/// <summary> 
		/// Required method for Designer support - do not modify 
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.lbl_ILAppID = new System.Windows.Forms.Label();
			this._lbl_ILAppID = new System.Windows.Forms.Label();
			this._lblFees = new System.Windows.Forms.Label();
			this.lblFees = new System.Windows.Forms.Label();
			this._lblAppDate = new System.Windows.Forms.Label();
			this._lblIssueDate = new System.Windows.Forms.Label();
			this._lblCreatedBy = new System.Windows.Forms.Label();
			this.lblCreatedBy = new System.Windows.Forms.Label();
			this.lblIssueDate = new System.Windows.Forms.Label();
			this.lblAppDate = new System.Windows.Forms.Label();
			this._lbl_ILID = new System.Windows.Forms.Label();
			this._lbl_LLID = new System.Windows.Forms.Label();
			this._lblExpirationDate = new System.Windows.Forms.Label();
			this.lblExpirationDate = new System.Windows.Forms.Label();
			this.gbABasicInfo = new System.Windows.Forms.GroupBox();
			this.lbl_LLID = new System.Windows.Forms.Label();
			this.lbl_ILID = new System.Windows.Forms.Label();
			this.gbABasicInfo.SuspendLayout();
			this.SuspendLayout();
			// 
			// lbl_ILAppID
			// 
			this.lbl_ILAppID.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
			this.lbl_ILAppID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.lbl_ILAppID.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Bold);
			this.lbl_ILAppID.ForeColor = System.Drawing.Color.Black;
			this.lbl_ILAppID.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.lbl_ILAppID.Location = new System.Drawing.Point(656, 33);
			this.lbl_ILAppID.Name = "lbl_ILAppID";
			this.lbl_ILAppID.Size = new System.Drawing.Size(65, 35);
			this.lbl_ILAppID.TabIndex = 10;
			this.lbl_ILAppID.Text = "???";
			this.lbl_ILAppID.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// _lbl_ILAppID
			// 
			this._lbl_ILAppID.AutoSize = true;
			this._lbl_ILAppID.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold);
			this._lbl_ILAppID.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this._lbl_ILAppID.Location = new System.Drawing.Point(432, 37);
			this._lbl_ILAppID.Name = "_lbl_ILAppID";
			this._lbl_ILAppID.Size = new System.Drawing.Size(189, 25);
			this._lbl_ILAppID.TabIndex = 12;
			this._lbl_ILAppID.Text = "I L Application ID :";
			// 
			// _lblFees
			// 
			this._lblFees.AutoSize = true;
			this._lblFees.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold);
			this._lblFees.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this._lblFees.Location = new System.Drawing.Point(459, 166);
			this._lblFees.Name = "_lblFees";
			this._lblFees.Size = new System.Drawing.Size(73, 25);
			this._lblFees.TabIndex = 14;
			this._lblFees.Text = "Fees :";
			// 
			// lblFees
			// 
			this.lblFees.BackColor = System.Drawing.Color.MistyRose;
			this.lblFees.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.lblFees.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Bold);
			this.lblFees.ForeColor = System.Drawing.Color.Red;
			this.lblFees.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.lblFees.Location = new System.Drawing.Point(558, 162);
			this.lblFees.Name = "lblFees";
			this.lblFees.Size = new System.Drawing.Size(118, 35);
			this.lblFees.TabIndex = 15;
			this.lblFees.Text = "????";
			this.lblFees.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// _lblAppDate
			// 
			this._lblAppDate.AutoSize = true;
			this._lblAppDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold);
			this._lblAppDate.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this._lblAppDate.Location = new System.Drawing.Point(409, 87);
			this._lblAppDate.Name = "_lblAppDate";
			this._lblAppDate.Size = new System.Drawing.Size(183, 25);
			this._lblAppDate.TabIndex = 20;
			this._lblAppDate.Text = "Application Date :";
			// 
			// _lblIssueDate
			// 
			this._lblIssueDate.AutoSize = true;
			this._lblIssueDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold);
			this._lblIssueDate.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this._lblIssueDate.Location = new System.Drawing.Point(50, 164);
			this._lblIssueDate.Name = "_lblIssueDate";
			this._lblIssueDate.Size = new System.Drawing.Size(128, 25);
			this._lblIssueDate.TabIndex = 22;
			this._lblIssueDate.Text = "Issue Date :";
			// 
			// _lblCreatedBy
			// 
			this._lblCreatedBy.AutoSize = true;
			this._lblCreatedBy.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold);
			this._lblCreatedBy.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this._lblCreatedBy.Location = new System.Drawing.Point(459, 223);
			this._lblCreatedBy.Name = "_lblCreatedBy";
			this._lblCreatedBy.Size = new System.Drawing.Size(133, 25);
			this._lblCreatedBy.TabIndex = 24;
			this._lblCreatedBy.Text = "Created By :";
			// 
			// lblCreatedBy
			// 
			this.lblCreatedBy.BackColor = System.Drawing.Color.Beige;
			this.lblCreatedBy.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.lblCreatedBy.Font = new System.Drawing.Font("Script MT Bold", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblCreatedBy.ForeColor = System.Drawing.Color.Blue;
			this.lblCreatedBy.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.lblCreatedBy.Location = new System.Drawing.Point(612, 218);
			this.lblCreatedBy.Name = "lblCreatedBy";
			this.lblCreatedBy.Size = new System.Drawing.Size(160, 35);
			this.lblCreatedBy.TabIndex = 25;
			this.lblCreatedBy.Text = "????";
			this.lblCreatedBy.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// lblIssueDate
			// 
			this.lblIssueDate.BackColor = System.Drawing.SystemColors.ControlDarkDark;
			this.lblIssueDate.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.lblIssueDate.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Bold);
			this.lblIssueDate.ForeColor = System.Drawing.Color.White;
			this.lblIssueDate.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.lblIssueDate.Location = new System.Drawing.Point(221, 160);
			this.lblIssueDate.Name = "lblIssueDate";
			this.lblIssueDate.Size = new System.Drawing.Size(169, 35);
			this.lblIssueDate.TabIndex = 27;
			this.lblIssueDate.Text = "????";
			this.lblIssueDate.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// lblAppDate
			// 
			this.lblAppDate.BackColor = System.Drawing.SystemColors.ControlDarkDark;
			this.lblAppDate.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.lblAppDate.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Bold);
			this.lblAppDate.ForeColor = System.Drawing.Color.White;
			this.lblAppDate.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.lblAppDate.Location = new System.Drawing.Point(612, 83);
			this.lblAppDate.Name = "lblAppDate";
			this.lblAppDate.Size = new System.Drawing.Size(169, 35);
			this.lblAppDate.TabIndex = 28;
			this.lblAppDate.Text = "????";
			this.lblAppDate.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// _lbl_ILID
			// 
			this._lbl_ILID.AutoSize = true;
			this._lbl_ILID.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold);
			this._lbl_ILID.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this._lbl_ILID.Location = new System.Drawing.Point(7, 43);
			this._lbl_ILID.Name = "_lbl_ILID";
			this._lbl_ILID.Size = new System.Drawing.Size(252, 25);
			this._lbl_ILID.TabIndex = 29;
			this._lbl_ILID.Text = "International License ID :";
			// 
			// _lbl_LLID
			// 
			this._lbl_LLID.AutoSize = true;
			this._lbl_LLID.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold);
			this._lbl_LLID.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this._lbl_LLID.Location = new System.Drawing.Point(39, 89);
			this._lbl_LLID.Name = "_lbl_LLID";
			this._lbl_LLID.Size = new System.Drawing.Size(185, 25);
			this._lbl_LLID.TabIndex = 31;
			this._lbl_LLID.Text = "Local License ID :";
			// 
			// _lblExpirationDate
			// 
			this._lblExpirationDate.AutoSize = true;
			this._lblExpirationDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold);
			this._lblExpirationDate.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this._lblExpirationDate.Location = new System.Drawing.Point(28, 217);
			this._lblExpirationDate.Name = "_lblExpirationDate";
			this._lblExpirationDate.Size = new System.Drawing.Size(172, 25);
			this._lblExpirationDate.TabIndex = 33;
			this._lblExpirationDate.Text = "Expiration Date :";
			// 
			// lblExpirationDate
			// 
			this.lblExpirationDate.BackColor = System.Drawing.SystemColors.ControlDarkDark;
			this.lblExpirationDate.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.lblExpirationDate.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Bold);
			this.lblExpirationDate.ForeColor = System.Drawing.Color.White;
			this.lblExpirationDate.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.lblExpirationDate.Location = new System.Drawing.Point(220, 213);
			this.lblExpirationDate.Name = "lblExpirationDate";
			this.lblExpirationDate.Size = new System.Drawing.Size(169, 35);
			this.lblExpirationDate.TabIndex = 34;
			this.lblExpirationDate.Text = "????";
			this.lblExpirationDate.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// gbABasicInfo
			// 
			this.gbABasicInfo.BackColor = System.Drawing.Color.LavenderBlush;
			this.gbABasicInfo.Controls.Add(this.lbl_LLID);
			this.gbABasicInfo.Controls.Add(this.lbl_ILID);
			this.gbABasicInfo.Controls.Add(this.lblExpirationDate);
			this.gbABasicInfo.Controls.Add(this._lblExpirationDate);
			this.gbABasicInfo.Controls.Add(this._lbl_LLID);
			this.gbABasicInfo.Controls.Add(this._lbl_ILID);
			this.gbABasicInfo.Controls.Add(this.lblAppDate);
			this.gbABasicInfo.Controls.Add(this.lblIssueDate);
			this.gbABasicInfo.Controls.Add(this.lblCreatedBy);
			this.gbABasicInfo.Controls.Add(this._lblCreatedBy);
			this.gbABasicInfo.Controls.Add(this._lblIssueDate);
			this.gbABasicInfo.Controls.Add(this._lblAppDate);
			this.gbABasicInfo.Controls.Add(this.lblFees);
			this.gbABasicInfo.Controls.Add(this._lblFees);
			this.gbABasicInfo.Controls.Add(this._lbl_ILAppID);
			this.gbABasicInfo.Controls.Add(this.lbl_ILAppID);
			this.gbABasicInfo.Dock = System.Windows.Forms.DockStyle.Fill;
			this.gbABasicInfo.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold);
			this.gbABasicInfo.Location = new System.Drawing.Point(0, 0);
			this.gbABasicInfo.Name = "gbABasicInfo";
			this.gbABasicInfo.Size = new System.Drawing.Size(809, 273);
			this.gbABasicInfo.TabIndex = 5;
			this.gbABasicInfo.TabStop = false;
			this.gbABasicInfo.Text = "International Application Info :";
			// 
			// lbl_LLID
			// 
			this.lbl_LLID.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
			this.lbl_LLID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.lbl_LLID.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Bold);
			this.lbl_LLID.ForeColor = System.Drawing.Color.Black;
			this.lbl_LLID.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.lbl_LLID.Location = new System.Drawing.Point(259, 85);
			this.lbl_LLID.Name = "lbl_LLID";
			this.lbl_LLID.Size = new System.Drawing.Size(65, 35);
			this.lbl_LLID.TabIndex = 36;
			this.lbl_LLID.Text = "???";
			this.lbl_LLID.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// lbl_ILID
			// 
			this.lbl_ILID.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
			this.lbl_ILID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.lbl_ILID.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Bold);
			this.lbl_ILID.ForeColor = System.Drawing.Color.Red;
			this.lbl_ILID.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.lbl_ILID.Location = new System.Drawing.Point(293, 39);
			this.lbl_ILID.Name = "lbl_ILID";
			this.lbl_ILID.Size = new System.Drawing.Size(65, 35);
			this.lbl_ILID.TabIndex = 35;
			this.lbl_ILID.Text = "-1";
			this.lbl_ILID.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// ucInternationalAppInfo
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.Controls.Add(this.gbABasicInfo);
			this.Name = "ucInternationalAppInfo";
			this.Size = new System.Drawing.Size(809, 273);
			this.gbABasicInfo.ResumeLayout(false);
			this.gbABasicInfo.PerformLayout();
			this.ResumeLayout(false);

		}

		#endregion

		private System.Windows.Forms.Label lbl_ILAppID;
		private System.Windows.Forms.Label _lbl_ILAppID;
		private System.Windows.Forms.Label _lblFees;
		private System.Windows.Forms.Label lblFees;
		private System.Windows.Forms.Label _lblAppDate;
		private System.Windows.Forms.Label _lblIssueDate;
		private System.Windows.Forms.Label _lblCreatedBy;
		private System.Windows.Forms.Label lblCreatedBy;
		private System.Windows.Forms.Label lblIssueDate;
		private System.Windows.Forms.Label lblAppDate;
		private System.Windows.Forms.Label _lbl_ILID;
		private System.Windows.Forms.Label _lbl_LLID;
		private System.Windows.Forms.Label _lblExpirationDate;
		private System.Windows.Forms.Label lblExpirationDate;
		private System.Windows.Forms.GroupBox gbABasicInfo;
		private System.Windows.Forms.Label lbl_LLID;
		private System.Windows.Forms.Label lbl_ILID;
	}
}
