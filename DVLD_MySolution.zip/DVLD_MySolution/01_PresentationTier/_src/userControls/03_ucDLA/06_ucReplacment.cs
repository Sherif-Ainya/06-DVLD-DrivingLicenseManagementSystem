﻿using System.Windows.Forms;
using DVLD_Business;

namespace _02_DVLD_Mine._src.userControls._03_ucDLA
{
	public partial class _06_ucReplacment : UserControl
	{
		public _06_ucReplacment()
		{
			InitializeComponent();
		}


		public void LoadMainInfo(int oldLicenseID, int appTypeID)
		{
			lblCreatedBy.Text = clsGlobal.currentUser.userName;
			lblOldLicenseID.Text = oldLicenseID.ToString();
			lblAppFees.Text = clsBusinessApplicationTypes.Find(appTypeID).applicationTypeFees.ToString();
		}


		public void LoadLicenseData(int newLicenseID)
		{
			clsBusinessLicenses _currentLicense = clsBusinessLicenses.FindByLicenseID(newLicenseID);

			if (_currentLicense == null)
				return;


			lblReplacmentLicenseID.Text = newLicenseID.ToString();
			//lblReplacmentLicenseID.Text = _currentLicense.LicenseID.ToString();

			lblIssueDate.Text = _currentLicense.IssueDate.ToString();
			lblExpirationDate.Text = _currentLicense.ExpirationDate.ToString();
			lblNotes.Text = _currentLicense.Notes;

			clsBusinessApplications relatedApp = clsBusinessApplications.Find(_currentLicense.ApplicationID);

			lblReplacmentAppID.Text = relatedApp.ApplicationID.ToString();
			lblAppDate.Text = relatedApp.ApplicationDateTime.ToString();
			lblAppFees.Text = relatedApp.PaidFees.ToString();

			lblCreatedBy.Text = clsBusinessUsers.Find(_currentLicense.CreatedByUserID).userName;
		}
	}
}
