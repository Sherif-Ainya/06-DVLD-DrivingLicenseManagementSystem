﻿using System;
using System.Windows.Forms;
using DVLD_Business;

namespace _02_DVLD_Mine._src.userControls._03_ucDLA
{
	public partial class ucInternationalAppInfo : UserControl
	{
		public void LoadMainInfo()
		{
			lblAppDate.Text = DateTime.Now.ToString("d");
			lblIssueDate.Text = DateTime.Now.ToString("d");
			lblExpirationDate.Text = DateTime.Now.ToString("d");
			lblCreatedBy.Text = clsGlobal.currentUser.userName;
			lblFees.Text = clsBusinessApplicationTypes.Find(6).applicationTypeFees.ToString();
		}


		public ucInternationalAppInfo()
		{
			InitializeComponent();
		}


		private int _currentIntLicense_ID;
		private clsBusinessInternationDL _currentIntLicense;

		private void _Reload()
		{
			_currentIntLicense = clsBusinessInternationDL.Find(_currentIntLicense_ID);

			if (_currentIntLicense == null)
				return;


			lbl_ILID.Text = _currentIntLicense_ID.ToString();
			lbl_LLID.Text = _currentIntLicense.IssuedUsingLocalLicenseID.ToString();
			lblIssueDate.Text = _currentIntLicense.IssueDate.ToString();
			lblExpirationDate.Text = _currentIntLicense.ExpirationDate.ToString();

			clsBusinessApplications relatedApp = clsBusinessApplications.Find(_currentIntLicense.ApplicationID);

			lbl_ILAppID.Text = relatedApp.ApplicationID.ToString();
			lblAppDate.Text = relatedApp.ApplicationDateTime.ToString();
			lblFees.Text = relatedApp.PaidFees.ToString();
			lblCreatedBy.Text = clsBusinessUsers.Find(_currentIntLicense.CreatedByUserID).userName;
		}
		public void LoadAppBasicData(int IntLicense_ID)
		{
			_currentIntLicense_ID = IntLicense_ID;
			_Reload();
		}
	}
}
