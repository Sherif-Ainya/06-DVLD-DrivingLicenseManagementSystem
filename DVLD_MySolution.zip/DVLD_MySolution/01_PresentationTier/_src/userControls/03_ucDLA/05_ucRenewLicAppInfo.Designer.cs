﻿namespace _02_DVLD_Mine._src.userControls._03_ucDLA
{
	partial class _05_ucRenewLicAppInfo
	{
		/// <summary> 
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary> 
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Component Designer generated code

		/// <summary> 
		/// Required method for Designer support - do not modify 
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.gbABasicInfo = new System.Windows.Forms.GroupBox();
			this.lblOldLicenseID = new System.Windows.Forms.Label();
			this.lblRenewAppID = new System.Windows.Forms.Label();
			this.lblExpirationDate = new System.Windows.Forms.Label();
			this._lblExpirationDate = new System.Windows.Forms.Label();
			this._lblOldLicenseID = new System.Windows.Forms.Label();
			this._lblRenewAppID = new System.Windows.Forms.Label();
			this.lblAppDate = new System.Windows.Forms.Label();
			this.lblIssueDate = new System.Windows.Forms.Label();
			this.lblCreatedBy = new System.Windows.Forms.Label();
			this._lblCreatedBy = new System.Windows.Forms.Label();
			this._lblIssueDate = new System.Windows.Forms.Label();
			this._lblAppDate = new System.Windows.Forms.Label();
			this.lblAppFees = new System.Windows.Forms.Label();
			this._lblAppFees = new System.Windows.Forms.Label();
			this._lblRenewLicenseID = new System.Windows.Forms.Label();
			this.lblRenewLicenseID = new System.Windows.Forms.Label();
			this.lblLicenseFees = new System.Windows.Forms.Label();
			this._lblLicenseFees = new System.Windows.Forms.Label();
			this.lblTotalFees = new System.Windows.Forms.Label();
			this._lblTotalFees = new System.Windows.Forms.Label();
			this._lblNotes = new System.Windows.Forms.Label();
			this.lblNotes = new System.Windows.Forms.Label();
			this.gbABasicInfo.SuspendLayout();
			this.SuspendLayout();
			// 
			// gbABasicInfo
			// 
			this.gbABasicInfo.BackColor = System.Drawing.Color.LavenderBlush;
			this.gbABasicInfo.Controls.Add(this.lblNotes);
			this.gbABasicInfo.Controls.Add(this._lblNotes);
			this.gbABasicInfo.Controls.Add(this.lblTotalFees);
			this.gbABasicInfo.Controls.Add(this._lblTotalFees);
			this.gbABasicInfo.Controls.Add(this.lblLicenseFees);
			this.gbABasicInfo.Controls.Add(this._lblLicenseFees);
			this.gbABasicInfo.Controls.Add(this.lblOldLicenseID);
			this.gbABasicInfo.Controls.Add(this.lblRenewAppID);
			this.gbABasicInfo.Controls.Add(this.lblExpirationDate);
			this.gbABasicInfo.Controls.Add(this._lblExpirationDate);
			this.gbABasicInfo.Controls.Add(this._lblOldLicenseID);
			this.gbABasicInfo.Controls.Add(this._lblRenewAppID);
			this.gbABasicInfo.Controls.Add(this.lblAppDate);
			this.gbABasicInfo.Controls.Add(this.lblIssueDate);
			this.gbABasicInfo.Controls.Add(this.lblCreatedBy);
			this.gbABasicInfo.Controls.Add(this._lblCreatedBy);
			this.gbABasicInfo.Controls.Add(this._lblIssueDate);
			this.gbABasicInfo.Controls.Add(this._lblAppDate);
			this.gbABasicInfo.Controls.Add(this.lblAppFees);
			this.gbABasicInfo.Controls.Add(this._lblAppFees);
			this.gbABasicInfo.Controls.Add(this._lblRenewLicenseID);
			this.gbABasicInfo.Controls.Add(this.lblRenewLicenseID);
			this.gbABasicInfo.Dock = System.Windows.Forms.DockStyle.Fill;
			this.gbABasicInfo.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold);
			this.gbABasicInfo.Location = new System.Drawing.Point(0, 0);
			this.gbABasicInfo.Name = "gbABasicInfo";
			this.gbABasicInfo.Size = new System.Drawing.Size(809, 428);
			this.gbABasicInfo.TabIndex = 6;
			this.gbABasicInfo.TabStop = false;
			this.gbABasicInfo.Text = "Renew License Info :";
			// 
			// lblOldLicenseID
			// 
			this.lblOldLicenseID.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
			this.lblOldLicenseID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.lblOldLicenseID.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Bold);
			this.lblOldLicenseID.ForeColor = System.Drawing.Color.Black;
			this.lblOldLicenseID.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.lblOldLicenseID.Location = new System.Drawing.Point(710, 80);
			this.lblOldLicenseID.Name = "lblOldLicenseID";
			this.lblOldLicenseID.Size = new System.Drawing.Size(65, 35);
			this.lblOldLicenseID.TabIndex = 36;
			this.lblOldLicenseID.Text = "???";
			this.lblOldLicenseID.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// lblRenewAppID
			// 
			this.lblRenewAppID.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
			this.lblRenewAppID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.lblRenewAppID.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Bold);
			this.lblRenewAppID.ForeColor = System.Drawing.Color.Red;
			this.lblRenewAppID.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.lblRenewAppID.Location = new System.Drawing.Point(273, 36);
			this.lblRenewAppID.Name = "lblRenewAppID";
			this.lblRenewAppID.Size = new System.Drawing.Size(65, 35);
			this.lblRenewAppID.TabIndex = 35;
			this.lblRenewAppID.Text = "-1";
			this.lblRenewAppID.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// lblExpirationDate
			// 
			this.lblExpirationDate.BackColor = System.Drawing.SystemColors.ControlDarkDark;
			this.lblExpirationDate.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.lblExpirationDate.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Bold);
			this.lblExpirationDate.ForeColor = System.Drawing.Color.White;
			this.lblExpirationDate.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.lblExpirationDate.Location = new System.Drawing.Point(220, 198);
			this.lblExpirationDate.Name = "lblExpirationDate";
			this.lblExpirationDate.Size = new System.Drawing.Size(169, 35);
			this.lblExpirationDate.TabIndex = 34;
			this.lblExpirationDate.Text = "????";
			this.lblExpirationDate.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// _lblExpirationDate
			// 
			this._lblExpirationDate.AutoSize = true;
			this._lblExpirationDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold);
			this._lblExpirationDate.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this._lblExpirationDate.Location = new System.Drawing.Point(28, 202);
			this._lblExpirationDate.Name = "_lblExpirationDate";
			this._lblExpirationDate.Size = new System.Drawing.Size(172, 25);
			this._lblExpirationDate.TabIndex = 33;
			this._lblExpirationDate.Text = "Expiration Date :";
			// 
			// _lblOldLicenseID
			// 
			this._lblOldLicenseID.AutoSize = true;
			this._lblOldLicenseID.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold);
			this._lblOldLicenseID.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this._lblOldLicenseID.Location = new System.Drawing.Point(476, 84);
			this._lblOldLicenseID.Name = "_lblOldLicenseID";
			this._lblOldLicenseID.Size = new System.Drawing.Size(167, 25);
			this._lblOldLicenseID.TabIndex = 31;
			this._lblOldLicenseID.Text = "Old License ID :";
			// 
			// _lblRenewAppID
			// 
			this._lblRenewAppID.AutoSize = true;
			this._lblRenewAppID.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold);
			this._lblRenewAppID.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this._lblRenewAppID.Location = new System.Drawing.Point(6, 40);
			this._lblRenewAppID.Name = "_lblRenewAppID";
			this._lblRenewAppID.Size = new System.Drawing.Size(243, 25);
			this._lblRenewAppID.TabIndex = 29;
			this._lblRenewAppID.Text = "Renew License App ID :";
			// 
			// lblAppDate
			// 
			this.lblAppDate.BackColor = System.Drawing.SystemColors.ControlDarkDark;
			this.lblAppDate.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.lblAppDate.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Bold);
			this.lblAppDate.ForeColor = System.Drawing.Color.White;
			this.lblAppDate.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.lblAppDate.Location = new System.Drawing.Point(220, 80);
			this.lblAppDate.Name = "lblAppDate";
			this.lblAppDate.Size = new System.Drawing.Size(169, 35);
			this.lblAppDate.TabIndex = 28;
			this.lblAppDate.Text = "????";
			this.lblAppDate.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// lblIssueDate
			// 
			this.lblIssueDate.BackColor = System.Drawing.SystemColors.ControlDarkDark;
			this.lblIssueDate.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.lblIssueDate.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Bold);
			this.lblIssueDate.ForeColor = System.Drawing.Color.White;
			this.lblIssueDate.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.lblIssueDate.Location = new System.Drawing.Point(221, 151);
			this.lblIssueDate.Name = "lblIssueDate";
			this.lblIssueDate.Size = new System.Drawing.Size(169, 35);
			this.lblIssueDate.TabIndex = 27;
			this.lblIssueDate.Text = "????";
			this.lblIssueDate.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// lblCreatedBy
			// 
			this.lblCreatedBy.BackColor = System.Drawing.Color.Beige;
			this.lblCreatedBy.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.lblCreatedBy.Font = new System.Drawing.Font("Script MT Bold", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblCreatedBy.ForeColor = System.Drawing.Color.Blue;
			this.lblCreatedBy.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.lblCreatedBy.Location = new System.Drawing.Point(224, 261);
			this.lblCreatedBy.Name = "lblCreatedBy";
			this.lblCreatedBy.Size = new System.Drawing.Size(160, 35);
			this.lblCreatedBy.TabIndex = 25;
			this.lblCreatedBy.Text = "????";
			this.lblCreatedBy.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// _lblCreatedBy
			// 
			this._lblCreatedBy.AutoSize = true;
			this._lblCreatedBy.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold);
			this._lblCreatedBy.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this._lblCreatedBy.Location = new System.Drawing.Point(45, 267);
			this._lblCreatedBy.Name = "_lblCreatedBy";
			this._lblCreatedBy.Size = new System.Drawing.Size(133, 25);
			this._lblCreatedBy.TabIndex = 24;
			this._lblCreatedBy.Text = "Created By :";
			// 
			// _lblIssueDate
			// 
			this._lblIssueDate.AutoSize = true;
			this._lblIssueDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold);
			this._lblIssueDate.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this._lblIssueDate.Location = new System.Drawing.Point(50, 155);
			this._lblIssueDate.Name = "_lblIssueDate";
			this._lblIssueDate.Size = new System.Drawing.Size(128, 25);
			this._lblIssueDate.TabIndex = 22;
			this._lblIssueDate.Text = "Issue Date :";
			// 
			// _lblAppDate
			// 
			this._lblAppDate.AutoSize = true;
			this._lblAppDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold);
			this._lblAppDate.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this._lblAppDate.Location = new System.Drawing.Point(17, 84);
			this._lblAppDate.Name = "_lblAppDate";
			this._lblAppDate.Size = new System.Drawing.Size(183, 25);
			this._lblAppDate.TabIndex = 20;
			this._lblAppDate.Text = "Application Date :";
			// 
			// lblAppFees
			// 
			this.lblAppFees.BackColor = System.Drawing.Color.MistyRose;
			this.lblAppFees.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.lblAppFees.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Bold);
			this.lblAppFees.ForeColor = System.Drawing.Color.Red;
			this.lblAppFees.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.lblAppFees.Location = new System.Drawing.Point(647, 151);
			this.lblAppFees.Name = "lblAppFees";
			this.lblAppFees.Size = new System.Drawing.Size(118, 35);
			this.lblAppFees.TabIndex = 15;
			this.lblAppFees.Text = "????";
			this.lblAppFees.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// _lblAppFees
			// 
			this._lblAppFees.AutoSize = true;
			this._lblAppFees.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold);
			this._lblAppFees.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this._lblAppFees.Location = new System.Drawing.Point(439, 151);
			this._lblAppFees.Name = "_lblAppFees";
			this._lblAppFees.Size = new System.Drawing.Size(186, 25);
			this._lblAppFees.TabIndex = 14;
			this._lblAppFees.Text = "Applicaiton Fees :";
			// 
			// _lblRenewLicenseID
			// 
			this._lblRenewLicenseID.AutoSize = true;
			this._lblRenewLicenseID.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold);
			this._lblRenewLicenseID.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this._lblRenewLicenseID.Location = new System.Drawing.Point(421, 40);
			this._lblRenewLicenseID.Name = "_lblRenewLicenseID";
			this._lblRenewLicenseID.Size = new System.Drawing.Size(222, 25);
			this._lblRenewLicenseID.TabIndex = 12;
			this._lblRenewLicenseID.Text = "Renewed License ID :";
			// 
			// lblRenewLicenseID
			// 
			this.lblRenewLicenseID.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
			this.lblRenewLicenseID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.lblRenewLicenseID.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Bold);
			this.lblRenewLicenseID.ForeColor = System.Drawing.Color.Black;
			this.lblRenewLicenseID.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.lblRenewLicenseID.Location = new System.Drawing.Point(663, 36);
			this.lblRenewLicenseID.Name = "lblRenewLicenseID";
			this.lblRenewLicenseID.Size = new System.Drawing.Size(65, 35);
			this.lblRenewLicenseID.TabIndex = 10;
			this.lblRenewLicenseID.Text = "???";
			this.lblRenewLicenseID.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// lblLicenseFees
			// 
			this.lblLicenseFees.BackColor = System.Drawing.Color.MistyRose;
			this.lblLicenseFees.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.lblLicenseFees.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Bold);
			this.lblLicenseFees.ForeColor = System.Drawing.Color.Red;
			this.lblLicenseFees.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.lblLicenseFees.Location = new System.Drawing.Point(647, 198);
			this.lblLicenseFees.Name = "lblLicenseFees";
			this.lblLicenseFees.Size = new System.Drawing.Size(118, 35);
			this.lblLicenseFees.TabIndex = 38;
			this.lblLicenseFees.Text = "????";
			this.lblLicenseFees.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// _lblLicenseFees
			// 
			this._lblLicenseFees.AutoSize = true;
			this._lblLicenseFees.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold);
			this._lblLicenseFees.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this._lblLicenseFees.Location = new System.Drawing.Point(455, 202);
			this._lblLicenseFees.Name = "_lblLicenseFees";
			this._lblLicenseFees.Size = new System.Drawing.Size(154, 25);
			this._lblLicenseFees.TabIndex = 37;
			this._lblLicenseFees.Text = "License Fees :";
			// 
			// lblTotalFees
			// 
			this.lblTotalFees.BackColor = System.Drawing.Color.PeachPuff;
			this.lblTotalFees.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.lblTotalFees.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Bold);
			this.lblTotalFees.ForeColor = System.Drawing.Color.Purple;
			this.lblTotalFees.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.lblTotalFees.Location = new System.Drawing.Point(630, 261);
			this.lblTotalFees.Name = "lblTotalFees";
			this.lblTotalFees.Size = new System.Drawing.Size(154, 35);
			this.lblTotalFees.TabIndex = 40;
			this.lblTotalFees.Text = "????";
			this.lblTotalFees.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// _lblTotalFees
			// 
			this._lblTotalFees.AutoSize = true;
			this._lblTotalFees.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold);
			this._lblTotalFees.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this._lblTotalFees.Location = new System.Drawing.Point(468, 266);
			this._lblTotalFees.Name = "_lblTotalFees";
			this._lblTotalFees.Size = new System.Drawing.Size(128, 25);
			this._lblTotalFees.TabIndex = 39;
			this._lblTotalFees.Text = "Total Fees :";
			// 
			// _lblNotes
			// 
			this._lblNotes.AutoSize = true;
			this._lblNotes.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold);
			this._lblNotes.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this._lblNotes.Location = new System.Drawing.Point(59, 351);
			this._lblNotes.Name = "_lblNotes";
			this._lblNotes.Size = new System.Drawing.Size(81, 25);
			this._lblNotes.TabIndex = 41;
			this._lblNotes.Text = "Notes :";
			// 
			// lblNotes
			// 
			this.lblNotes.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
			this.lblNotes.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.lblNotes.Font = new System.Drawing.Font("Palatino Linotype", 11F, System.Drawing.FontStyle.Bold);
			this.lblNotes.Location = new System.Drawing.Point(179, 324);
			this.lblNotes.Name = "lblNotes";
			this.lblNotes.Size = new System.Drawing.Size(534, 83);
			this.lblNotes.TabIndex = 42;
			this.lblNotes.Text = "????";
			// 
			// _05_ucRenewLicAppInfo
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.Controls.Add(this.gbABasicInfo);
			this.Name = "_05_ucRenewLicAppInfo";
			this.Size = new System.Drawing.Size(809, 428);
			this.gbABasicInfo.ResumeLayout(false);
			this.gbABasicInfo.PerformLayout();
			this.ResumeLayout(false);

		}

		#endregion

		private System.Windows.Forms.GroupBox gbABasicInfo;
		private System.Windows.Forms.Label lblOldLicenseID;
		private System.Windows.Forms.Label lblRenewAppID;
		private System.Windows.Forms.Label lblExpirationDate;
		private System.Windows.Forms.Label _lblExpirationDate;
		private System.Windows.Forms.Label _lblOldLicenseID;
		private System.Windows.Forms.Label _lblRenewAppID;
		private System.Windows.Forms.Label lblAppDate;
		private System.Windows.Forms.Label lblIssueDate;
		private System.Windows.Forms.Label lblCreatedBy;
		private System.Windows.Forms.Label _lblCreatedBy;
		private System.Windows.Forms.Label _lblIssueDate;
		private System.Windows.Forms.Label _lblAppDate;
		private System.Windows.Forms.Label lblAppFees;
		private System.Windows.Forms.Label _lblAppFees;
		private System.Windows.Forms.Label _lblRenewLicenseID;
		private System.Windows.Forms.Label lblRenewLicenseID;
		private System.Windows.Forms.Label lblTotalFees;
		private System.Windows.Forms.Label _lblTotalFees;
		private System.Windows.Forms.Label lblLicenseFees;
		private System.Windows.Forms.Label _lblLicenseFees;
		private System.Windows.Forms.Label _lblNotes;
		private System.Windows.Forms.Label lblNotes;
	}
}
