﻿namespace _02_DVLD_Mine._src.userControls._03_ucDLA
{
	partial class uc_DL_Info
	{
		/// <summary> 
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary> 
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Component Designer generated code

		/// <summary> 
		/// Required method for Designer support - do not modify 
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(uc_DL_Info));
			this.gbDLDetails = new System.Windows.Forms.GroupBox();
			this.lblDLA_PassedTest = new System.Windows.Forms.Label();
			this._lblDLA_PassedTest = new System.Windows.Forms.Label();
			this.lblDLA_ClassName = new System.Windows.Forms.Label();
			this.lblDLA_ID = new System.Windows.Forms.Label();
			this._lblDLA_ClassName = new System.Windows.Forms.Label();
			this._lblDLA_ID = new System.Windows.Forms.Label();
			this.gbDLDetails.SuspendLayout();
			this.SuspendLayout();
			// 
			// gbDLDetails
			// 
			this.gbDLDetails.BackColor = System.Drawing.Color.LavenderBlush;
			this.gbDLDetails.Controls.Add(this.lblDLA_PassedTest);
			this.gbDLDetails.Controls.Add(this._lblDLA_PassedTest);
			this.gbDLDetails.Controls.Add(this.lblDLA_ClassName);
			this.gbDLDetails.Controls.Add(this.lblDLA_ID);
			this.gbDLDetails.Controls.Add(this._lblDLA_ClassName);
			this.gbDLDetails.Controls.Add(this._lblDLA_ID);
			resources.ApplyResources(this.gbDLDetails, "gbDLDetails");
			this.gbDLDetails.Name = "gbDLDetails";
			this.gbDLDetails.TabStop = false;
			// 
			// lblDLA_PassedTest
			// 
			this.lblDLA_PassedTest.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
			this.lblDLA_PassedTest.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			resources.ApplyResources(this.lblDLA_PassedTest, "lblDLA_PassedTest");
			this.lblDLA_PassedTest.ForeColor = System.Drawing.Color.Red;
			this.lblDLA_PassedTest.Name = "lblDLA_PassedTest";
			// 
			// _lblDLA_PassedTest
			// 
			resources.ApplyResources(this._lblDLA_PassedTest, "_lblDLA_PassedTest");
			this._lblDLA_PassedTest.Name = "_lblDLA_PassedTest";
			// 
			// lblDLA_ClassName
			// 
			this.lblDLA_ClassName.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
			this.lblDLA_ClassName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			resources.ApplyResources(this.lblDLA_ClassName, "lblDLA_ClassName");
			this.lblDLA_ClassName.Name = "lblDLA_ClassName";
			// 
			// lblDLA_ID
			// 
			this.lblDLA_ID.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
			this.lblDLA_ID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			resources.ApplyResources(this.lblDLA_ID, "lblDLA_ID");
			this.lblDLA_ID.ForeColor = System.Drawing.Color.Red;
			this.lblDLA_ID.Name = "lblDLA_ID";
			// 
			// _lblDLA_ClassName
			// 
			resources.ApplyResources(this._lblDLA_ClassName, "_lblDLA_ClassName");
			this._lblDLA_ClassName.Name = "_lblDLA_ClassName";
			// 
			// _lblDLA_ID
			// 
			resources.ApplyResources(this._lblDLA_ID, "_lblDLA_ID");
			this._lblDLA_ID.Name = "_lblDLA_ID";
			// 
			// uc_DL_Info
			// 
			resources.ApplyResources(this, "$this");
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.Controls.Add(this.gbDLDetails);
			this.Name = "uc_DL_Info";
			this.gbDLDetails.ResumeLayout(false);
			this.gbDLDetails.PerformLayout();
			this.ResumeLayout(false);

		}

		#endregion

		private System.Windows.Forms.GroupBox gbDLDetails;
		private System.Windows.Forms.Label lblDLA_ClassName;
		private System.Windows.Forms.Label lblDLA_ID;
		private System.Windows.Forms.Label _lblDLA_ClassName;
		private System.Windows.Forms.Label _lblDLA_ID;
		private System.Windows.Forms.Label lblDLA_PassedTest;
		private System.Windows.Forms.Label _lblDLA_PassedTest;
	}
}
