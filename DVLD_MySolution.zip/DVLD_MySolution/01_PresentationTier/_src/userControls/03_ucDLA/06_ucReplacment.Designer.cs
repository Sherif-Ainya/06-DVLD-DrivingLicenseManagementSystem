﻿namespace _02_DVLD_Mine._src.userControls._03_ucDLA
{
	partial class _06_ucReplacment
	{
		/// <summary> 
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary> 
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Component Designer generated code

		/// <summary> 
		/// Required method for Designer support - do not modify 
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.gbABasicInfo = new System.Windows.Forms.GroupBox();
			this.lblOldLicenseID = new System.Windows.Forms.Label();
			this.lblReplacmentAppID = new System.Windows.Forms.Label();
			this.lblExpirationDate = new System.Windows.Forms.Label();
			this._lblExpirationDate = new System.Windows.Forms.Label();
			this._lblOldLicenseID = new System.Windows.Forms.Label();
			this._lblReplacmentAppID = new System.Windows.Forms.Label();
			this.lblAppDate = new System.Windows.Forms.Label();
			this.lblIssueDate = new System.Windows.Forms.Label();
			this.lblCreatedBy = new System.Windows.Forms.Label();
			this._lblCreatedBy = new System.Windows.Forms.Label();
			this._lblIssueDate = new System.Windows.Forms.Label();
			this._lblAppDate = new System.Windows.Forms.Label();
			this.lblAppFees = new System.Windows.Forms.Label();
			this._lblAppFees = new System.Windows.Forms.Label();
			this._lblReplacedLicenseID = new System.Windows.Forms.Label();
			this.lblReplacmentLicenseID = new System.Windows.Forms.Label();
			this.lblNotes = new System.Windows.Forms.Label();
			this._lblNotes = new System.Windows.Forms.Label();
			this.gbABasicInfo.SuspendLayout();
			this.SuspendLayout();
			// 
			// gbABasicInfo
			// 
			this.gbABasicInfo.BackColor = System.Drawing.Color.LavenderBlush;
			this.gbABasicInfo.Controls.Add(this.lblNotes);
			this.gbABasicInfo.Controls.Add(this._lblNotes);
			this.gbABasicInfo.Controls.Add(this.lblOldLicenseID);
			this.gbABasicInfo.Controls.Add(this.lblReplacmentAppID);
			this.gbABasicInfo.Controls.Add(this.lblExpirationDate);
			this.gbABasicInfo.Controls.Add(this._lblExpirationDate);
			this.gbABasicInfo.Controls.Add(this._lblOldLicenseID);
			this.gbABasicInfo.Controls.Add(this._lblReplacmentAppID);
			this.gbABasicInfo.Controls.Add(this.lblAppDate);
			this.gbABasicInfo.Controls.Add(this.lblIssueDate);
			this.gbABasicInfo.Controls.Add(this.lblCreatedBy);
			this.gbABasicInfo.Controls.Add(this._lblCreatedBy);
			this.gbABasicInfo.Controls.Add(this._lblIssueDate);
			this.gbABasicInfo.Controls.Add(this._lblAppDate);
			this.gbABasicInfo.Controls.Add(this.lblAppFees);
			this.gbABasicInfo.Controls.Add(this._lblAppFees);
			this.gbABasicInfo.Controls.Add(this._lblReplacedLicenseID);
			this.gbABasicInfo.Controls.Add(this.lblReplacmentLicenseID);
			this.gbABasicInfo.Dock = System.Windows.Forms.DockStyle.Fill;
			this.gbABasicInfo.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold);
			this.gbABasicInfo.Location = new System.Drawing.Point(0, 0);
			this.gbABasicInfo.Name = "gbABasicInfo";
			this.gbABasicInfo.Size = new System.Drawing.Size(809, 351);
			this.gbABasicInfo.TabIndex = 7;
			this.gbABasicInfo.TabStop = false;
			this.gbABasicInfo.Text = "Replaced License Info :";
			// 
			// lblOldLicenseID
			// 
			this.lblOldLicenseID.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
			this.lblOldLicenseID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.lblOldLicenseID.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Bold);
			this.lblOldLicenseID.ForeColor = System.Drawing.Color.Black;
			this.lblOldLicenseID.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.lblOldLicenseID.Location = new System.Drawing.Point(710, 80);
			this.lblOldLicenseID.Name = "lblOldLicenseID";
			this.lblOldLicenseID.Size = new System.Drawing.Size(65, 35);
			this.lblOldLicenseID.TabIndex = 36;
			this.lblOldLicenseID.Text = "???";
			this.lblOldLicenseID.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// lblReplacmentAppID
			// 
			this.lblReplacmentAppID.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
			this.lblReplacmentAppID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.lblReplacmentAppID.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Bold);
			this.lblReplacmentAppID.ForeColor = System.Drawing.Color.Red;
			this.lblReplacmentAppID.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.lblReplacmentAppID.Location = new System.Drawing.Point(273, 36);
			this.lblReplacmentAppID.Name = "lblReplacmentAppID";
			this.lblReplacmentAppID.Size = new System.Drawing.Size(65, 35);
			this.lblReplacmentAppID.TabIndex = 35;
			this.lblReplacmentAppID.Text = "-1";
			this.lblReplacmentAppID.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// lblExpirationDate
			// 
			this.lblExpirationDate.BackColor = System.Drawing.SystemColors.ControlDarkDark;
			this.lblExpirationDate.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.lblExpirationDate.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Bold);
			this.lblExpirationDate.ForeColor = System.Drawing.Color.White;
			this.lblExpirationDate.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.lblExpirationDate.Location = new System.Drawing.Point(220, 198);
			this.lblExpirationDate.Name = "lblExpirationDate";
			this.lblExpirationDate.Size = new System.Drawing.Size(169, 35);
			this.lblExpirationDate.TabIndex = 34;
			this.lblExpirationDate.Text = "????";
			this.lblExpirationDate.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// _lblExpirationDate
			// 
			this._lblExpirationDate.AutoSize = true;
			this._lblExpirationDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold);
			this._lblExpirationDate.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this._lblExpirationDate.Location = new System.Drawing.Point(28, 202);
			this._lblExpirationDate.Name = "_lblExpirationDate";
			this._lblExpirationDate.Size = new System.Drawing.Size(172, 25);
			this._lblExpirationDate.TabIndex = 33;
			this._lblExpirationDate.Text = "Expiration Date :";
			// 
			// _lblOldLicenseID
			// 
			this._lblOldLicenseID.AutoSize = true;
			this._lblOldLicenseID.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold);
			this._lblOldLicenseID.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this._lblOldLicenseID.Location = new System.Drawing.Point(476, 84);
			this._lblOldLicenseID.Name = "_lblOldLicenseID";
			this._lblOldLicenseID.Size = new System.Drawing.Size(167, 25);
			this._lblOldLicenseID.TabIndex = 31;
			this._lblOldLicenseID.Text = "Old License ID :";
			// 
			// _lblReplacmentAppID
			// 
			this._lblReplacmentAppID.AutoSize = true;
			this._lblReplacmentAppID.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold);
			this._lblReplacmentAppID.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this._lblReplacmentAppID.Location = new System.Drawing.Point(6, 40);
			this._lblReplacmentAppID.Name = "_lblReplacmentAppID";
			this._lblReplacmentAppID.Size = new System.Drawing.Size(210, 25);
			this._lblReplacmentAppID.TabIndex = 29;
			this._lblReplacmentAppID.Text = "Replacment App ID :";
			// 
			// lblAppDate
			// 
			this.lblAppDate.BackColor = System.Drawing.SystemColors.ControlDarkDark;
			this.lblAppDate.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.lblAppDate.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Bold);
			this.lblAppDate.ForeColor = System.Drawing.Color.White;
			this.lblAppDate.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.lblAppDate.Location = new System.Drawing.Point(220, 80);
			this.lblAppDate.Name = "lblAppDate";
			this.lblAppDate.Size = new System.Drawing.Size(169, 35);
			this.lblAppDate.TabIndex = 28;
			this.lblAppDate.Text = "????";
			this.lblAppDate.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// lblIssueDate
			// 
			this.lblIssueDate.BackColor = System.Drawing.SystemColors.ControlDarkDark;
			this.lblIssueDate.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.lblIssueDate.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Bold);
			this.lblIssueDate.ForeColor = System.Drawing.Color.White;
			this.lblIssueDate.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.lblIssueDate.Location = new System.Drawing.Point(221, 151);
			this.lblIssueDate.Name = "lblIssueDate";
			this.lblIssueDate.Size = new System.Drawing.Size(169, 35);
			this.lblIssueDate.TabIndex = 27;
			this.lblIssueDate.Text = "????";
			this.lblIssueDate.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// lblCreatedBy
			// 
			this.lblCreatedBy.BackColor = System.Drawing.Color.Beige;
			this.lblCreatedBy.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.lblCreatedBy.Font = new System.Drawing.Font("Script MT Bold", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblCreatedBy.ForeColor = System.Drawing.Color.Blue;
			this.lblCreatedBy.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.lblCreatedBy.Location = new System.Drawing.Point(625, 198);
			this.lblCreatedBy.Name = "lblCreatedBy";
			this.lblCreatedBy.Size = new System.Drawing.Size(160, 35);
			this.lblCreatedBy.TabIndex = 25;
			this.lblCreatedBy.Text = "????";
			this.lblCreatedBy.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// _lblCreatedBy
			// 
			this._lblCreatedBy.AutoSize = true;
			this._lblCreatedBy.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold);
			this._lblCreatedBy.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this._lblCreatedBy.Location = new System.Drawing.Point(456, 202);
			this._lblCreatedBy.Name = "_lblCreatedBy";
			this._lblCreatedBy.Size = new System.Drawing.Size(133, 25);
			this._lblCreatedBy.TabIndex = 24;
			this._lblCreatedBy.Text = "Created By :";
			// 
			// _lblIssueDate
			// 
			this._lblIssueDate.AutoSize = true;
			this._lblIssueDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold);
			this._lblIssueDate.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this._lblIssueDate.Location = new System.Drawing.Point(50, 155);
			this._lblIssueDate.Name = "_lblIssueDate";
			this._lblIssueDate.Size = new System.Drawing.Size(128, 25);
			this._lblIssueDate.TabIndex = 22;
			this._lblIssueDate.Text = "Issue Date :";
			// 
			// _lblAppDate
			// 
			this._lblAppDate.AutoSize = true;
			this._lblAppDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold);
			this._lblAppDate.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this._lblAppDate.Location = new System.Drawing.Point(17, 84);
			this._lblAppDate.Name = "_lblAppDate";
			this._lblAppDate.Size = new System.Drawing.Size(183, 25);
			this._lblAppDate.TabIndex = 20;
			this._lblAppDate.Text = "Application Date :";
			// 
			// lblAppFees
			// 
			this.lblAppFees.BackColor = System.Drawing.Color.MistyRose;
			this.lblAppFees.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.lblAppFees.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Bold);
			this.lblAppFees.ForeColor = System.Drawing.Color.Red;
			this.lblAppFees.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.lblAppFees.Location = new System.Drawing.Point(647, 145);
			this.lblAppFees.Name = "lblAppFees";
			this.lblAppFees.Size = new System.Drawing.Size(118, 35);
			this.lblAppFees.TabIndex = 15;
			this.lblAppFees.Text = "????";
			this.lblAppFees.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// _lblAppFees
			// 
			this._lblAppFees.AutoSize = true;
			this._lblAppFees.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold);
			this._lblAppFees.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this._lblAppFees.Location = new System.Drawing.Point(431, 151);
			this._lblAppFees.Name = "_lblAppFees";
			this._lblAppFees.Size = new System.Drawing.Size(186, 25);
			this._lblAppFees.TabIndex = 14;
			this._lblAppFees.Text = "Applicaiton Fees :";
			// 
			// _lblReplacedLicenseID
			// 
			this._lblReplacedLicenseID.AutoSize = true;
			this._lblReplacedLicenseID.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold);
			this._lblReplacedLicenseID.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this._lblReplacedLicenseID.Location = new System.Drawing.Point(421, 40);
			this._lblReplacedLicenseID.Name = "_lblReplacedLicenseID";
			this._lblReplacedLicenseID.Size = new System.Drawing.Size(223, 25);
			this._lblReplacedLicenseID.TabIndex = 12;
			this._lblReplacedLicenseID.Text = "Replaced License ID :";
			// 
			// lblReplacmentLicenseID
			// 
			this.lblReplacmentLicenseID.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
			this.lblReplacmentLicenseID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.lblReplacmentLicenseID.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Bold);
			this.lblReplacmentLicenseID.ForeColor = System.Drawing.Color.Black;
			this.lblReplacmentLicenseID.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.lblReplacmentLicenseID.Location = new System.Drawing.Point(663, 36);
			this.lblReplacmentLicenseID.Name = "lblReplacmentLicenseID";
			this.lblReplacmentLicenseID.Size = new System.Drawing.Size(65, 35);
			this.lblReplacmentLicenseID.TabIndex = 10;
			this.lblReplacmentLicenseID.Text = "???";
			this.lblReplacmentLicenseID.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// lblNotes
			// 
			this.lblNotes.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
			this.lblNotes.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.lblNotes.Font = new System.Drawing.Font("Palatino Linotype", 11F, System.Drawing.FontStyle.Bold);
			this.lblNotes.Location = new System.Drawing.Point(184, 255);
			this.lblNotes.Name = "lblNotes";
			this.lblNotes.Size = new System.Drawing.Size(534, 83);
			this.lblNotes.TabIndex = 44;
			this.lblNotes.Text = "????";
			// 
			// _lblNotes
			// 
			this._lblNotes.AutoSize = true;
			this._lblNotes.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold);
			this._lblNotes.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this._lblNotes.Location = new System.Drawing.Point(64, 282);
			this._lblNotes.Name = "_lblNotes";
			this._lblNotes.Size = new System.Drawing.Size(81, 25);
			this._lblNotes.TabIndex = 43;
			this._lblNotes.Text = "Notes :";
			// 
			// _06_ucReplacment
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.Controls.Add(this.gbABasicInfo);
			this.Name = "_06_ucReplacment";
			this.Size = new System.Drawing.Size(809, 351);
			this.gbABasicInfo.ResumeLayout(false);
			this.gbABasicInfo.PerformLayout();
			this.ResumeLayout(false);

		}

		#endregion

		private System.Windows.Forms.GroupBox gbABasicInfo;
		private System.Windows.Forms.Label lblOldLicenseID;
		private System.Windows.Forms.Label lblReplacmentAppID;
		private System.Windows.Forms.Label lblExpirationDate;
		private System.Windows.Forms.Label _lblExpirationDate;
		private System.Windows.Forms.Label _lblOldLicenseID;
		private System.Windows.Forms.Label _lblReplacmentAppID;
		private System.Windows.Forms.Label lblAppDate;
		private System.Windows.Forms.Label lblIssueDate;
		private System.Windows.Forms.Label lblCreatedBy;
		private System.Windows.Forms.Label _lblCreatedBy;
		private System.Windows.Forms.Label _lblIssueDate;
		private System.Windows.Forms.Label _lblAppDate;
		private System.Windows.Forms.Label lblAppFees;
		private System.Windows.Forms.Label _lblAppFees;
		private System.Windows.Forms.Label _lblReplacedLicenseID;
		private System.Windows.Forms.Label lblReplacmentLicenseID;
		private System.Windows.Forms.Label lblNotes;
		private System.Windows.Forms.Label _lblNotes;
	}
}
