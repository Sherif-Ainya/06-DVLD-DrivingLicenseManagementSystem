﻿namespace _02_DVLD_Mine._src.userControls._03_ucDLA
{
	partial class ucDLABasicInfo
	{
		/// <summary> 
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary> 
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Component Designer generated code

		/// <summary> 
		/// Required method for Designer support - do not modify 
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.gbABasicInfo = new System.Windows.Forms.GroupBox();
			this.lblDate = new System.Windows.Forms.Label();
			this.lblStatusDate = new System.Windows.Forms.Label();
			this.btnEdit = new System.Windows.Forms.Button();
			this.lblCreatedBy = new System.Windows.Forms.Label();
			this._lblCreatedBy = new System.Windows.Forms.Label();
			this._lblStatusDate = new System.Windows.Forms.Label();
			this._lblDate = new System.Windows.Forms.Label();
			this.lblApplicant = new System.Windows.Forms.Label();
			this._lblApplicant = new System.Windows.Forms.Label();
			this.lblType = new System.Windows.Forms.Label();
			this._lblType = new System.Windows.Forms.Label();
			this.lblFees = new System.Windows.Forms.Label();
			this._lblFees = new System.Windows.Forms.Label();
			this.lblStatus = new System.Windows.Forms.Label();
			this._lblStatus = new System.Windows.Forms.Label();
			this.lblAppID = new System.Windows.Forms.Label();
			this._lblAppID = new System.Windows.Forms.Label();
			this.gbABasicInfo.SuspendLayout();
			this.SuspendLayout();
			// 
			// gbABasicInfo
			// 
			this.gbABasicInfo.BackColor = System.Drawing.Color.LavenderBlush;
			this.gbABasicInfo.Controls.Add(this.lblDate);
			this.gbABasicInfo.Controls.Add(this.lblStatusDate);
			this.gbABasicInfo.Controls.Add(this.btnEdit);
			this.gbABasicInfo.Controls.Add(this.lblCreatedBy);
			this.gbABasicInfo.Controls.Add(this._lblCreatedBy);
			this.gbABasicInfo.Controls.Add(this._lblStatusDate);
			this.gbABasicInfo.Controls.Add(this._lblDate);
			this.gbABasicInfo.Controls.Add(this.lblApplicant);
			this.gbABasicInfo.Controls.Add(this._lblApplicant);
			this.gbABasicInfo.Controls.Add(this.lblType);
			this.gbABasicInfo.Controls.Add(this._lblType);
			this.gbABasicInfo.Controls.Add(this.lblFees);
			this.gbABasicInfo.Controls.Add(this._lblFees);
			this.gbABasicInfo.Controls.Add(this.lblStatus);
			this.gbABasicInfo.Controls.Add(this._lblStatus);
			this.gbABasicInfo.Controls.Add(this.lblAppID);
			this.gbABasicInfo.Controls.Add(this._lblAppID);
			this.gbABasicInfo.Dock = System.Windows.Forms.DockStyle.Fill;
			this.gbABasicInfo.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold);
			this.gbABasicInfo.Location = new System.Drawing.Point(0, 0);
			this.gbABasicInfo.Name = "gbABasicInfo";
			this.gbABasicInfo.Size = new System.Drawing.Size(809, 285);
			this.gbABasicInfo.TabIndex = 4;
			this.gbABasicInfo.TabStop = false;
			this.gbABasicInfo.Text = "Application Basic Info :";
			// 
			// lblDate
			// 
			this.lblDate.BackColor = System.Drawing.SystemColors.ControlDarkDark;
			this.lblDate.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.lblDate.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Bold);
			this.lblDate.ForeColor = System.Drawing.Color.White;
			this.lblDate.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.lblDate.Location = new System.Drawing.Point(130, 176);
			this.lblDate.Name = "lblDate";
			this.lblDate.Size = new System.Drawing.Size(156, 35);
			this.lblDate.TabIndex = 28;
			this.lblDate.Text = "????";
			this.lblDate.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// lblStatusDate
			// 
			this.lblStatusDate.BackColor = System.Drawing.SystemColors.ControlDarkDark;
			this.lblStatusDate.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.lblStatusDate.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Bold);
			this.lblStatusDate.ForeColor = System.Drawing.Color.White;
			this.lblStatusDate.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.lblStatusDate.Location = new System.Drawing.Point(173, 232);
			this.lblStatusDate.Name = "lblStatusDate";
			this.lblStatusDate.Size = new System.Drawing.Size(156, 35);
			this.lblStatusDate.TabIndex = 27;
			this.lblStatusDate.Text = "????";
			this.lblStatusDate.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// btnEdit
			// 
			this.btnEdit.BackColor = System.Drawing.SystemColors.ScrollBar;
			this.btnEdit.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
			this.btnEdit.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
			this.btnEdit.FlatAppearance.BorderSize = 2;
			this.btnEdit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnEdit.Font = new System.Drawing.Font("Microsoft YaHei UI", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnEdit.ForeColor = System.Drawing.Color.Red;
			this.btnEdit.Image = global::_02_DVLD_Mine.Properties.Resources.highlighter_pen;
			this.btnEdit.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btnEdit.Location = new System.Drawing.Point(631, 180);
			this.btnEdit.Name = "btnEdit";
			this.btnEdit.Size = new System.Drawing.Size(157, 29);
			this.btnEdit.TabIndex = 26;
			this.btnEdit.Text = "View Preson Info";
			this.btnEdit.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.btnEdit.UseVisualStyleBackColor = false;
			this.btnEdit.Click += new System.EventHandler(this.btnEdit_Click);
			// 
			// lblCreatedBy
			// 
			this.lblCreatedBy.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
			this.lblCreatedBy.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.lblCreatedBy.Font = new System.Drawing.Font("Script MT Bold", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblCreatedBy.ForeColor = System.Drawing.Color.Blue;
			this.lblCreatedBy.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.lblCreatedBy.Location = new System.Drawing.Point(554, 232);
			this.lblCreatedBy.Name = "lblCreatedBy";
			this.lblCreatedBy.Size = new System.Drawing.Size(120, 35);
			this.lblCreatedBy.TabIndex = 25;
			this.lblCreatedBy.Text = "????";
			this.lblCreatedBy.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// _lblCreatedBy
			// 
			this._lblCreatedBy.AutoSize = true;
			this._lblCreatedBy.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold);
			this._lblCreatedBy.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this._lblCreatedBy.Location = new System.Drawing.Point(398, 236);
			this._lblCreatedBy.Name = "_lblCreatedBy";
			this._lblCreatedBy.Size = new System.Drawing.Size(133, 25);
			this._lblCreatedBy.TabIndex = 24;
			this._lblCreatedBy.Text = "Created By :";
			// 
			// _lblStatusDate
			// 
			this._lblStatusDate.AutoSize = true;
			this._lblStatusDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold);
			this._lblStatusDate.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this._lblStatusDate.Location = new System.Drawing.Point(20, 236);
			this._lblStatusDate.Name = "_lblStatusDate";
			this._lblStatusDate.Size = new System.Drawing.Size(138, 25);
			this._lblStatusDate.TabIndex = 22;
			this._lblStatusDate.Text = "Status Date :";
			// 
			// _lblDate
			// 
			this._lblDate.AutoSize = true;
			this._lblDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold);
			this._lblDate.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this._lblDate.Location = new System.Drawing.Point(24, 180);
			this._lblDate.Name = "_lblDate";
			this._lblDate.Size = new System.Drawing.Size(70, 25);
			this._lblDate.TabIndex = 20;
			this._lblDate.Text = "Date :";
			// 
			// lblApplicant
			// 
			this.lblApplicant.BackColor = System.Drawing.SystemColors.ControlDarkDark;
			this.lblApplicant.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.lblApplicant.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Bold);
			this.lblApplicant.ForeColor = System.Drawing.Color.White;
			this.lblApplicant.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.lblApplicant.Location = new System.Drawing.Point(429, 137);
			this.lblApplicant.Name = "lblApplicant";
			this.lblApplicant.Size = new System.Drawing.Size(359, 35);
			this.lblApplicant.TabIndex = 19;
			this.lblApplicant.Text = "????";
			this.lblApplicant.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// _lblApplicant
			// 
			this._lblApplicant.AutoSize = true;
			this._lblApplicant.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold);
			this._lblApplicant.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this._lblApplicant.Location = new System.Drawing.Point(298, 141);
			this._lblApplicant.Name = "_lblApplicant";
			this._lblApplicant.Size = new System.Drawing.Size(115, 25);
			this._lblApplicant.TabIndex = 18;
			this._lblApplicant.Text = "Applicant :";
			// 
			// lblType
			// 
			this.lblType.BackColor = System.Drawing.SystemColors.ControlDarkDark;
			this.lblType.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.lblType.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Bold);
			this.lblType.ForeColor = System.Drawing.Color.White;
			this.lblType.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.lblType.Location = new System.Drawing.Point(429, 78);
			this.lblType.Name = "lblType";
			this.lblType.Size = new System.Drawing.Size(359, 35);
			this.lblType.TabIndex = 17;
			this.lblType.Text = "????";
			this.lblType.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// _lblType
			// 
			this._lblType.AutoSize = true;
			this._lblType.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold);
			this._lblType.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this._lblType.Location = new System.Drawing.Point(314, 82);
			this._lblType.Name = "_lblType";
			this._lblType.Size = new System.Drawing.Size(74, 25);
			this._lblType.TabIndex = 16;
			this._lblType.Text = "Type :";
			// 
			// lblFees
			// 
			this.lblFees.BackColor = System.Drawing.SystemColors.ControlDarkDark;
			this.lblFees.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.lblFees.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Bold);
			this.lblFees.ForeColor = System.Drawing.Color.White;
			this.lblFees.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.lblFees.Location = new System.Drawing.Point(131, 111);
			this.lblFees.Name = "lblFees";
			this.lblFees.Size = new System.Drawing.Size(108, 35);
			this.lblFees.TabIndex = 15;
			this.lblFees.Text = "????";
			this.lblFees.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// _lblFees
			// 
			this._lblFees.AutoSize = true;
			this._lblFees.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold);
			this._lblFees.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this._lblFees.Location = new System.Drawing.Point(28, 115);
			this._lblFees.Name = "_lblFees";
			this._lblFees.Size = new System.Drawing.Size(73, 25);
			this._lblFees.TabIndex = 14;
			this._lblFees.Text = "Fees :";
			// 
			// lblStatus
			// 
			this.lblStatus.BackColor = System.Drawing.SystemColors.ControlDarkDark;
			this.lblStatus.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.lblStatus.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Bold);
			this.lblStatus.ForeColor = System.Drawing.Color.White;
			this.lblStatus.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.lblStatus.Location = new System.Drawing.Point(134, 52);
			this.lblStatus.Name = "lblStatus";
			this.lblStatus.Size = new System.Drawing.Size(120, 35);
			this.lblStatus.TabIndex = 13;
			this.lblStatus.Text = "????";
			this.lblStatus.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// _lblStatus
			// 
			this._lblStatus.AutoSize = true;
			this._lblStatus.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold);
			this._lblStatus.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this._lblStatus.Location = new System.Drawing.Point(24, 58);
			this._lblStatus.Name = "_lblStatus";
			this._lblStatus.Size = new System.Drawing.Size(87, 25);
			this._lblStatus.TabIndex = 12;
			this._lblStatus.Text = "Status :";
			// 
			// lblAppID
			// 
			this.lblAppID.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
			this.lblAppID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.lblAppID.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Bold);
			this.lblAppID.ForeColor = System.Drawing.Color.Red;
			this.lblAppID.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.lblAppID.Location = new System.Drawing.Point(523, 19);
			this.lblAppID.Name = "lblAppID";
			this.lblAppID.Size = new System.Drawing.Size(65, 35);
			this.lblAppID.TabIndex = 10;
			this.lblAppID.Text = "-1";
			this.lblAppID.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// _lblAppID
			// 
			this._lblAppID.AutoSize = true;
			this._lblAppID.Font = new System.Drawing.Font("Algerian", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this._lblAppID.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this._lblAppID.Location = new System.Drawing.Point(315, 24);
			this._lblAppID.Name = "_lblAppID";
			this._lblAppID.Size = new System.Drawing.Size(177, 24);
			this._lblAppID.TabIndex = 0;
			this._lblAppID.Text = "Application ID";
			// 
			// ucDLABasicInfo
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.Controls.Add(this.gbABasicInfo);
			this.Name = "ucDLABasicInfo";
			this.Size = new System.Drawing.Size(809, 285);
			this.gbABasicInfo.ResumeLayout(false);
			this.gbABasicInfo.PerformLayout();
			this.ResumeLayout(false);

		}

		#endregion

		private System.Windows.Forms.GroupBox gbABasicInfo;
		private System.Windows.Forms.Label _lblStatus;
		private System.Windows.Forms.Label lblAppID;
		private System.Windows.Forms.Label _lblAppID;
		private System.Windows.Forms.Label lblStatus;
		private System.Windows.Forms.Label lblFees;
		private System.Windows.Forms.Label _lblFees;
		private System.Windows.Forms.Label lblType;
		private System.Windows.Forms.Label _lblType;
		private System.Windows.Forms.Label lblApplicant;
		private System.Windows.Forms.Label _lblApplicant;
		private System.Windows.Forms.Label lblCreatedBy;
		private System.Windows.Forms.Label _lblCreatedBy;
		private System.Windows.Forms.Label _lblStatusDate;
		private System.Windows.Forms.Label _lblDate;
		private System.Windows.Forms.Button btnEdit;
		private System.Windows.Forms.Label lblDate;
		private System.Windows.Forms.Label lblStatusDate;
	}
}
