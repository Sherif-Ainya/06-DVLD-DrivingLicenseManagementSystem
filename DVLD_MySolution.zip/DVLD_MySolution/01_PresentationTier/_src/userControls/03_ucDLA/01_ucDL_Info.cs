﻿using System.Windows.Forms;
using DVLD_Business;

namespace _02_DVLD_Mine._src.userControls._03_ucDLA
{
	public partial class uc_DL_Info : UserControl
	{
		public uc_DL_Info()
		{
			InitializeComponent();
		}

		int _currentLDLA_ID;

		private void _Reload()
		{
			string className = "";
			int passedTests = 0;
			if (!clsBusinessLocalDrivingLicenseapplications_View.GetLDLA_ShortInfo(_currentLDLA_ID, ref className, ref passedTests))
				return;

			lblDLA_ID.Text = _currentLDLA_ID.ToString();
			lblDLA_ClassName.Text = className;
			lblDLA_PassedTest.Text = passedTests.ToString() + " / 3";
		}
		public void LoadLDLAShortData(int LDLA_ID)
		{
			_currentLDLA_ID = LDLA_ID;
			_Reload();
		}
	}
}
