﻿using System.Windows.Forms;
using DVLD_Business;

namespace _02_DVLD_Mine._src.userControls._03_ucDLA
{
	public partial class ucADL_BasicInfo : UserControl
	{
		public ucADL_BasicInfo()
		{
			InitializeComponent();
		}

		int _currentLDLA_ID;

		private void _Reload()
		{
			uc_DL_Info1.LoadLDLAShortData(_currentLDLA_ID);
			ucDLABasicInfo1.LoadAppBasicData(clsBusiness_LDLA.Find(_currentLDLA_ID).ApplicationID);
		}
		public void LoadData(int DLA_ID)
		{
			_currentLDLA_ID = DLA_ID;
			_Reload();
		}
	}
}
