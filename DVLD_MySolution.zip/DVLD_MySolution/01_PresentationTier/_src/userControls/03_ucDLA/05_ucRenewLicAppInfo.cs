﻿using System.Windows.Forms;
using DVLD_Business;

namespace _02_DVLD_Mine._src.userControls._03_ucDLA
{
	public partial class _05_ucRenewLicAppInfo : UserControl
	{
		public void LoadMainInfo(int licenseID, int licenseClass)
		{
			//lblAppDate.Text = DateTime.Now.ToString("d");
			//lblIssueDate.Text = DateTime.Now.ToString("d");
			//lblExpirationDate.Text = DateTime.Now.ToString("d");
			lblCreatedBy.Text = clsGlobal.currentUser.userName;

			lblOldLicenseID.Text = licenseID.ToString();

			decimal relatedApp = clsBusinessApplicationTypes.Find(2).applicationTypeFees;
			lblAppFees.Text = relatedApp.ToString();
			decimal licenseFees = clsBusinessLicenseClasses.Find(licenseClass).ClassFees;
			lblLicenseFees.Text = licenseFees.ToString();
			lblTotalFees.Text = (licenseFees + relatedApp).ToString();
		}


		public _05_ucRenewLicAppInfo()
		{
			InitializeComponent();
		}


		private int _currentLicenseID;
		private int _OldLicenseID;
		private clsBusinessLicenses _currentLicense;

		private void _Reload()
		{
			_currentLicense = clsBusinessLicenses.FindByLicenseID(_currentLicenseID);

			if (_currentLicense == null)
				return;


			lblRenewLicenseID.Text = _currentLicenseID.ToString();
			lblOldLicenseID.Text = _OldLicenseID.ToString();

			lblRenewLicenseID.Text = _currentLicense.LicenseID.ToString();
			lblIssueDate.Text = _currentLicense.IssueDate.ToString();
			lblExpirationDate.Text = _currentLicense.ExpirationDate.ToString();

			clsBusinessApplications relatedApp = clsBusinessApplications.Find(_currentLicense.ApplicationID);

			lblRenewAppID.Text = relatedApp.ApplicationID.ToString();
			lblAppDate.Text = relatedApp.ApplicationDateTime.ToString();
			lblAppFees.Text = relatedApp.PaidFees.ToString();

			decimal licenseFees = clsBusinessLicenseClasses.Find(_currentLicense.LicenseClass).ClassFees;
			lblLicenseFees.Text = licenseFees.ToString();

			lblTotalFees.Text = (licenseFees + relatedApp.PaidFees).ToString();

			lblNotes.Text = _currentLicense.Notes;

			lblCreatedBy.Text = clsBusinessUsers.Find(_currentLicense.CreatedByUserID).userName;
		}
		public void LoadLicenseData(int newLicenseID, int oldLicenseID)
		{
			_currentLicenseID = newLicenseID;
			_OldLicenseID = oldLicenseID;
			_Reload();
		}
	}
}
