﻿using System.IO;
using System.Windows.Forms;
using _02_DVLD_Mine._src.Main.People;
using _02_DVLD_Mine.Properties;
using _03_DataAccessTier.src;
using DVLD_Business;

namespace _02_DVLD_Mine._src.userControls.People
{
	public partial class uc1_PersonDetails : UserControl
	{
		private int _currentPersonID;
		clsBusinessPeople _currentPerson;
		private void _LoadData()
		{
			_currentPerson = clsBusinessPeople.Find(_currentPersonID);
			lblPersonID.Text = _currentPersonID.ToString();
			lblName.Text = _currentPerson.FullName;
			lblNationalNo.Text = _currentPerson.nationalNo;

			lblDateOfBirth.Text = _currentPerson.dateOfBirth.ToString();
			lblCountry.Text = clsBusinessCountries.Find(_currentPerson.nationalityCountryID).countryName;
			lblAddress.Text = _currentPerson.address;
			lblPhone.Text = _currentPerson.phone;
			lblEmail.Text = _currentPerson.email;

			if (!string.IsNullOrEmpty(_currentPerson.imagePath) && File.Exists(_currentPerson.imagePath))
			{
				pbPersonImage.Load(_currentPerson.imagePath);
				pbPersonImage.SizeMode = PictureBoxSizeMode.Zoom;
				return;
			}

			if (_currentPerson.gender == 0)
				pbPersonImage.Image = Resources.Male;
			else
				pbPersonImage.Image = Resources.Female;
		}


		public uc1_PersonDetails(int PersonID)
		{
			InitializeComponent();
			_currentPersonID = PersonID;
			_LoadData();
		}


		private void btnEditPerson_Click(object sender, System.EventArgs e)
		{
			Form update = new frmAdd_UpdatePerson(_currentPersonID);
			update.ShowDialog();
			_LoadData();
		}
	}
}
