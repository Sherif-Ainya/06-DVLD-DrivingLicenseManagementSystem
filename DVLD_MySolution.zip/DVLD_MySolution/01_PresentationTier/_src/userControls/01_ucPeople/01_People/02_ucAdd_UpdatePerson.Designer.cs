﻿namespace _02_DVLD_Mine._src.userControls.People
{
	partial class uc1_Add_UpdatePerson
	{
		/// <summary> 
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary> 
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Component Designer generated code

		/// <summary> 
		/// Required method for Designer support - do not modify 
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			this._lblCountry = new System.Windows.Forms.Label();
			this._lblPhone = new System.Windows.Forms.Label();
			this._lblDateOfBirth = new System.Windows.Forms.Label();
			this._lblAddress = new System.Windows.Forms.Label();
			this._lblEmail = new System.Windows.Forms.Label();
			this._lblGender = new System.Windows.Forms.Label();
			this._lblNationalNo = new System.Windows.Forms.Label();
			this._lblName = new System.Windows.Forms.Label();
			this.txbFirst = new System.Windows.Forms.TextBox();
			this._lblFirst = new System.Windows.Forms.Label();
			this._lblSecond = new System.Windows.Forms.Label();
			this.txbSecond = new System.Windows.Forms.TextBox();
			this._lblThird = new System.Windows.Forms.Label();
			this.txbThird = new System.Windows.Forms.TextBox();
			this._lblLast = new System.Windows.Forms.Label();
			this.txbLast = new System.Windows.Forms.TextBox();
			this.txbNationalNo = new System.Windows.Forms.TextBox();
			this.txbPhone = new System.Windows.Forms.TextBox();
			this.txbAddress = new System.Windows.Forms.TextBox();
			this.cbCountries = new System.Windows.Forms.ComboBox();
			this.txbEmail = new System.Windows.Forms.TextBox();
			this.rbMale = new System.Windows.Forms.RadioButton();
			this.rbFemale = new System.Windows.Forms.RadioButton();
			this.dtpDateOfBirth = new System.Windows.Forms.DateTimePicker();
			this.liblSetImage = new System.Windows.Forms.LinkLabel();
			this.liblRemove = new System.Windows.Forms.LinkLabel();
			this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
			this.errorProvider1 = new System.Windows.Forms.ErrorProvider(this.components);
			this.btnClose = new System.Windows.Forms.Button();
			this.btnSave = new System.Windows.Forms.Button();
			this.pbPersonImage = new System.Windows.Forms.PictureBox();
			((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.pbPersonImage)).BeginInit();
			this.SuspendLayout();
			// 
			// _lblCountry
			// 
			this._lblCountry.AutoSize = true;
			this._lblCountry.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this._lblCountry.Location = new System.Drawing.Point(405, 115);
			this._lblCountry.Name = "_lblCountry";
			this._lblCountry.Size = new System.Drawing.Size(90, 26);
			this._lblCountry.TabIndex = 27;
			this._lblCountry.Text = "Country :";
			// 
			// _lblPhone
			// 
			this._lblPhone.AutoSize = true;
			this._lblPhone.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this._lblPhone.Location = new System.Drawing.Point(31, 181);
			this._lblPhone.Name = "_lblPhone";
			this._lblPhone.Size = new System.Drawing.Size(75, 26);
			this._lblPhone.TabIndex = 26;
			this._lblPhone.Text = "Phone :";
			// 
			// _lblDateOfBirth
			// 
			this._lblDateOfBirth.AutoSize = true;
			this._lblDateOfBirth.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this._lblDateOfBirth.Location = new System.Drawing.Point(405, 180);
			this._lblDateOfBirth.Name = "_lblDateOfBirth";
			this._lblDateOfBirth.Size = new System.Drawing.Size(133, 26);
			this._lblDateOfBirth.TabIndex = 25;
			this._lblDateOfBirth.Text = "Date Of Birth :";
			// 
			// _lblAddress
			// 
			this._lblAddress.AutoSize = true;
			this._lblAddress.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this._lblAddress.Location = new System.Drawing.Point(31, 311);
			this._lblAddress.Name = "_lblAddress";
			this._lblAddress.Size = new System.Drawing.Size(91, 26);
			this._lblAddress.TabIndex = 24;
			this._lblAddress.Text = "Address :";
			// 
			// _lblEmail
			// 
			this._lblEmail.AutoSize = true;
			this._lblEmail.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this._lblEmail.Location = new System.Drawing.Point(31, 246);
			this._lblEmail.Name = "_lblEmail";
			this._lblEmail.Size = new System.Drawing.Size(70, 26);
			this._lblEmail.TabIndex = 23;
			this._lblEmail.Text = "Email :";
			// 
			// _lblGender
			// 
			this._lblGender.AutoSize = true;
			this._lblGender.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this._lblGender.Location = new System.Drawing.Point(405, 245);
			this._lblGender.Name = "_lblGender";
			this._lblGender.Size = new System.Drawing.Size(83, 26);
			this._lblGender.TabIndex = 22;
			this._lblGender.Text = "Gender :";
			// 
			// _lblNationalNo
			// 
			this._lblNationalNo.AutoSize = true;
			this._lblNationalNo.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this._lblNationalNo.Location = new System.Drawing.Point(31, 116);
			this._lblNationalNo.Name = "_lblNationalNo";
			this._lblNationalNo.Size = new System.Drawing.Size(124, 26);
			this._lblNationalNo.TabIndex = 21;
			this._lblNationalNo.Text = "National No :";
			// 
			// _lblName
			// 
			this._lblName.AutoSize = true;
			this._lblName.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this._lblName.Location = new System.Drawing.Point(31, 51);
			this._lblName.Name = "_lblName";
			this._lblName.Size = new System.Drawing.Size(73, 26);
			this._lblName.TabIndex = 20;
			this._lblName.Text = "Name :";
			// 
			// txbFirst
			// 
			this.txbFirst.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.txbFirst.Location = new System.Drawing.Point(126, 51);
			this.txbFirst.Name = "txbFirst";
			this.txbFirst.Size = new System.Drawing.Size(193, 29);
			this.txbFirst.TabIndex = 0;
			this.txbFirst.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			// 
			// _lblFirst
			// 
			this._lblFirst.AutoSize = true;
			this._lblFirst.Font = new System.Drawing.Font("Aldhabi", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this._lblFirst.ForeColor = System.Drawing.Color.DarkViolet;
			this._lblFirst.Location = new System.Drawing.Point(207, 14);
			this._lblFirst.Name = "_lblFirst";
			this._lblFirst.Size = new System.Drawing.Size(41, 34);
			this._lblFirst.TabIndex = 39;
			this._lblFirst.Text = "First";
			this._lblFirst.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// _lblSecond
			// 
			this._lblSecond.AutoSize = true;
			this._lblSecond.Font = new System.Drawing.Font("Aldhabi", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this._lblSecond.ForeColor = System.Drawing.Color.DarkViolet;
			this._lblSecond.Location = new System.Drawing.Point(402, 14);
			this._lblSecond.Name = "_lblSecond";
			this._lblSecond.Size = new System.Drawing.Size(56, 34);
			this._lblSecond.TabIndex = 41;
			this._lblSecond.Text = "Second";
			this._lblSecond.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// txbSecond
			// 
			this.txbSecond.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.txbSecond.Location = new System.Drawing.Point(335, 51);
			this.txbSecond.Name = "txbSecond";
			this.txbSecond.Size = new System.Drawing.Size(193, 29);
			this.txbSecond.TabIndex = 1;
			this.txbSecond.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			// 
			// _lblThird
			// 
			this._lblThird.AutoSize = true;
			this._lblThird.Font = new System.Drawing.Font("Aldhabi", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this._lblThird.ForeColor = System.Drawing.Color.DarkViolet;
			this._lblThird.Location = new System.Drawing.Point(612, 14);
			this._lblThird.Name = "_lblThird";
			this._lblThird.Size = new System.Drawing.Size(48, 34);
			this._lblThird.TabIndex = 43;
			this._lblThird.Text = "Third";
			this._lblThird.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// txbThird
			// 
			this.txbThird.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.txbThird.Location = new System.Drawing.Point(544, 51);
			this.txbThird.Name = "txbThird";
			this.txbThird.Size = new System.Drawing.Size(193, 29);
			this.txbThird.TabIndex = 2;
			this.txbThird.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			// 
			// _lblLast
			// 
			this._lblLast.AutoSize = true;
			this._lblLast.Font = new System.Drawing.Font("Aldhabi", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this._lblLast.ForeColor = System.Drawing.Color.DarkViolet;
			this._lblLast.Location = new System.Drawing.Point(814, 14);
			this._lblLast.Name = "_lblLast";
			this._lblLast.Size = new System.Drawing.Size(40, 34);
			this._lblLast.TabIndex = 45;
			this._lblLast.Text = "Last";
			this._lblLast.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// txbLast
			// 
			this.txbLast.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.txbLast.Location = new System.Drawing.Point(753, 51);
			this.txbLast.Name = "txbLast";
			this.txbLast.Size = new System.Drawing.Size(193, 29);
			this.txbLast.TabIndex = 3;
			this.txbLast.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			// 
			// txbNationalNo
			// 
			this.txbNationalNo.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.txbNationalNo.Location = new System.Drawing.Point(160, 115);
			this.txbNationalNo.Name = "txbNationalNo";
			this.txbNationalNo.Size = new System.Drawing.Size(193, 29);
			this.txbNationalNo.TabIndex = 4;
			this.txbNationalNo.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			this.txbNationalNo.Validating += new System.ComponentModel.CancelEventHandler(this.txbNationalNo_Validating);
			// 
			// txbPhone
			// 
			this.txbPhone.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.txbPhone.Location = new System.Drawing.Point(160, 181);
			this.txbPhone.Name = "txbPhone";
			this.txbPhone.Size = new System.Drawing.Size(193, 29);
			this.txbPhone.TabIndex = 5;
			// 
			// txbAddress
			// 
			this.txbAddress.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.txbAddress.Location = new System.Drawing.Point(146, 309);
			this.txbAddress.Multiline = true;
			this.txbAddress.Name = "txbAddress";
			this.txbAddress.Size = new System.Drawing.Size(573, 88);
			this.txbAddress.TabIndex = 7;
			// 
			// cbCountries
			// 
			this.cbCountries.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.cbCountries.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.cbCountries.FormattingEnabled = true;
			this.cbCountries.Location = new System.Drawing.Point(526, 115);
			this.cbCountries.Name = "cbCountries";
			this.cbCountries.Size = new System.Drawing.Size(193, 26);
			this.cbCountries.TabIndex = 49;
			this.cbCountries.TabStop = false;
			// 
			// txbEmail
			// 
			this.txbEmail.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.txbEmail.Location = new System.Drawing.Point(160, 246);
			this.txbEmail.Name = "txbEmail";
			this.txbEmail.Size = new System.Drawing.Size(193, 26);
			this.txbEmail.TabIndex = 6;
			this.txbEmail.Validating += new System.ComponentModel.CancelEventHandler(this.txbEmail_Validating);
			// 
			// rbMale
			// 
			this.rbMale.AutoSize = true;
			this.rbMale.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
			this.rbMale.Font = new System.Drawing.Font("Malgun Gothic", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.rbMale.Location = new System.Drawing.Point(526, 246);
			this.rbMale.Name = "rbMale";
			this.rbMale.Size = new System.Drawing.Size(61, 24);
			this.rbMale.TabIndex = 51;
			this.rbMale.Text = "Male";
			this.rbMale.UseVisualStyleBackColor = false;
			this.rbMale.CheckedChanged += new System.EventHandler(this.rbMale_CheckedChanged);
			// 
			// rbFemale
			// 
			this.rbFemale.AutoSize = true;
			this.rbFemale.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
			this.rbFemale.Font = new System.Drawing.Font("Malgun Gothic", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.rbFemale.Location = new System.Drawing.Point(615, 246);
			this.rbFemale.Name = "rbFemale";
			this.rbFemale.Size = new System.Drawing.Size(77, 24);
			this.rbFemale.TabIndex = 52;
			this.rbFemale.Text = "Female";
			this.rbFemale.UseVisualStyleBackColor = false;
			this.rbFemale.CheckedChanged += new System.EventHandler(this.rbFemale_CheckedChanged);
			// 
			// dtpDateOfBirth
			// 
			this.dtpDateOfBirth.CalendarFont = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.dtpDateOfBirth.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.dtpDateOfBirth.Format = System.Windows.Forms.DateTimePickerFormat.Short;
			this.dtpDateOfBirth.Location = new System.Drawing.Point(552, 179);
			this.dtpDateOfBirth.MaximumSize = new System.Drawing.Size(167, 29);
			this.dtpDateOfBirth.MinimumSize = new System.Drawing.Size(167, 29);
			this.dtpDateOfBirth.Name = "dtpDateOfBirth";
			this.dtpDateOfBirth.Size = new System.Drawing.Size(167, 29);
			this.dtpDateOfBirth.TabIndex = 53;
			this.dtpDateOfBirth.TabStop = false;
			// 
			// liblSetImage
			// 
			this.liblSetImage.AutoSize = true;
			this.liblSetImage.Font = new System.Drawing.Font("Sylfaen", 13F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.liblSetImage.Location = new System.Drawing.Point(779, 322);
			this.liblSetImage.Name = "liblSetImage";
			this.liblSetImage.Size = new System.Drawing.Size(92, 23);
			this.liblSetImage.TabIndex = 10;
			this.liblSetImage.TabStop = true;
			this.liblSetImage.Text = "Set Image";
			this.liblSetImage.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			this.liblSetImage.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.liblSetImage_LinkClicked);
			// 
			// liblRemove
			// 
			this.liblRemove.AutoSize = true;
			this.liblRemove.Font = new System.Drawing.Font("Sylfaen", 13F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.liblRemove.LinkColor = System.Drawing.Color.Red;
			this.liblRemove.Location = new System.Drawing.Point(887, 322);
			this.liblRemove.Name = "liblRemove";
			this.liblRemove.Size = new System.Drawing.Size(76, 23);
			this.liblRemove.TabIndex = 11;
			this.liblRemove.TabStop = true;
			this.liblRemove.Text = "Remove";
			this.liblRemove.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			this.liblRemove.Visible = false;
			this.liblRemove.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.liblRemoveImage_LinkClicked);
			// 
			// openFileDialog1
			// 
			this.openFileDialog1.FileName = "openFileDialog1";
			// 
			// errorProvider1
			// 
			this.errorProvider1.ContainerControl = this;
			// 
			// btnClose
			// 
			this.btnClose.BackColor = System.Drawing.Color.Pink;
			this.btnClose.FlatAppearance.BorderColor = System.Drawing.Color.Cyan;
			this.btnClose.FlatAppearance.BorderSize = 3;
			this.btnClose.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
			this.btnClose.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
			this.btnClose.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnClose.Font = new System.Drawing.Font("Microsoft YaHei UI", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnClose.ForeColor = System.Drawing.Color.Red;
			this.btnClose.Image = global::_02_DVLD_Mine.Properties.Resources.close1;
			this.btnClose.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btnClose.Location = new System.Drawing.Point(897, 357);
			this.btnClose.Name = "btnClose";
			this.btnClose.Size = new System.Drawing.Size(62, 52);
			this.btnClose.TabIndex = 9;
			this.btnClose.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.btnClose.UseVisualStyleBackColor = false;
			this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
			// 
			// btnSave
			// 
			this.btnSave.BackColor = System.Drawing.Color.Pink;
			this.btnSave.FlatAppearance.BorderColor = System.Drawing.Color.Cyan;
			this.btnSave.FlatAppearance.BorderSize = 3;
			this.btnSave.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
			this.btnSave.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
			this.btnSave.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnSave.Font = new System.Drawing.Font("Microsoft YaHei UI", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnSave.ForeColor = System.Drawing.Color.DarkOrchid;
			this.btnSave.Image = global::_02_DVLD_Mine.Properties.Resources.save_27_16;
			this.btnSave.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btnSave.Location = new System.Drawing.Point(794, 357);
			this.btnSave.Name = "btnSave";
			this.btnSave.Size = new System.Drawing.Size(100, 52);
			this.btnSave.TabIndex = 8;
			this.btnSave.Text = "SAVE";
			this.btnSave.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.btnSave.UseVisualStyleBackColor = false;
			this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
			// 
			// pbPersonImage
			// 
			this.pbPersonImage.BackColor = System.Drawing.Color.LavenderBlush;
			this.pbPersonImage.Image = global::_02_DVLD_Mine.Properties.Resources.find;
			this.pbPersonImage.Location = new System.Drawing.Point(754, 100);
			this.pbPersonImage.Name = "pbPersonImage";
			this.pbPersonImage.Size = new System.Drawing.Size(220, 215);
			this.pbPersonImage.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
			this.pbPersonImage.TabIndex = 28;
			this.pbPersonImage.TabStop = false;
			// 
			// ucAdd_Update
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
			this.Controls.Add(this.btnClose);
			this.Controls.Add(this.btnSave);
			this.Controls.Add(this.liblRemove);
			this.Controls.Add(this.liblSetImage);
			this.Controls.Add(this.dtpDateOfBirth);
			this.Controls.Add(this.rbFemale);
			this.Controls.Add(this.rbMale);
			this.Controls.Add(this.txbEmail);
			this.Controls.Add(this.cbCountries);
			this.Controls.Add(this.txbAddress);
			this.Controls.Add(this.txbPhone);
			this.Controls.Add(this.txbNationalNo);
			this.Controls.Add(this._lblLast);
			this.Controls.Add(this.txbLast);
			this.Controls.Add(this._lblThird);
			this.Controls.Add(this.txbThird);
			this.Controls.Add(this._lblSecond);
			this.Controls.Add(this.txbSecond);
			this.Controls.Add(this._lblFirst);
			this.Controls.Add(this.txbFirst);
			this.Controls.Add(this.pbPersonImage);
			this.Controls.Add(this._lblCountry);
			this.Controls.Add(this._lblPhone);
			this.Controls.Add(this._lblDateOfBirth);
			this.Controls.Add(this._lblAddress);
			this.Controls.Add(this._lblEmail);
			this.Controls.Add(this._lblGender);
			this.Controls.Add(this._lblNationalNo);
			this.Controls.Add(this._lblName);
			this.Name = "ucAdd_Update";
			this.Size = new System.Drawing.Size(1009, 424);
			((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.pbPersonImage)).EndInit();
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion
		private System.Windows.Forms.PictureBox pbPersonImage;
		private System.Windows.Forms.Label _lblCountry;
		private System.Windows.Forms.Label _lblPhone;
		private System.Windows.Forms.Label _lblDateOfBirth;
		private System.Windows.Forms.Label _lblAddress;
		private System.Windows.Forms.Label _lblEmail;
		private System.Windows.Forms.Label _lblGender;
		private System.Windows.Forms.Label _lblNationalNo;
		private System.Windows.Forms.Label _lblName;
		private System.Windows.Forms.TextBox txbFirst;
		private System.Windows.Forms.Label _lblFirst;
		private System.Windows.Forms.Label _lblSecond;
		private System.Windows.Forms.TextBox txbSecond;
		private System.Windows.Forms.Label _lblThird;
		private System.Windows.Forms.TextBox txbThird;
		private System.Windows.Forms.Label _lblLast;
		private System.Windows.Forms.TextBox txbLast;
		private System.Windows.Forms.TextBox txbNationalNo;
		private System.Windows.Forms.TextBox txbPhone;
		private System.Windows.Forms.TextBox txbAddress;
		private System.Windows.Forms.ComboBox cbCountries;
		private System.Windows.Forms.TextBox txbEmail;
		private System.Windows.Forms.RadioButton rbMale;
		private System.Windows.Forms.RadioButton rbFemale;
		private System.Windows.Forms.DateTimePicker dtpDateOfBirth;
		private System.Windows.Forms.LinkLabel liblSetImage;
		private System.Windows.Forms.LinkLabel liblRemove;
		private System.Windows.Forms.Button btnSave;
		private System.Windows.Forms.OpenFileDialog openFileDialog1;
		private System.Windows.Forms.Button btnClose;
		private System.Windows.Forms.ErrorProvider errorProvider1;
	}
}
