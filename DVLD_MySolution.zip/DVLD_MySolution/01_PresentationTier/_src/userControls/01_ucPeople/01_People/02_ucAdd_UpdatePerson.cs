﻿using System;
using System.ComponentModel;
using System.Data;
using System.IO;
using System.Windows.Forms;
using _02_DVLD_Mine.Properties;
using _03_DataAccessTier.src;
using DVLD_Business;

namespace _02_DVLD_Mine._src.userControls.People
{
	public partial class uc1_Add_UpdatePerson : UserControl
	{
		public delegate void DataBackEventHandler(object sender, int personID);
		public event DataBackEventHandler ReturnPersonID;

		public event EventHandler CloseClicked;
		private enum enMode { enAddNew, enUpdate };
		private enMode _Mode = enMode.enAddNew;
		private int _currentPersonID;
		clsBusinessPeople _currentPerson;

		private void _FillCountriesInComoboBox()
		{
			DataTable dtCountries = clsBusinessCountries.GetAllCountries();

			foreach (DataRow row in dtCountries.Rows)
			{
				cbCountries.Items.Add(row["CountryName"]);
			}
		}
		private void _PrepareUserControl()
		{
			_FillCountriesInComoboBox();
			cbCountries.SelectedItem = "Syria";
			dtpDateOfBirth.MaxDate = DateTime.Today.AddYears(-18);
			dtpDateOfBirth.Value = dtpDateOfBirth.MaxDate;
		}
		private void _FillUserInformation()
		{
			txbNationalNo.Text = _currentPerson.nationalNo;
			txbFirst.Text = _currentPerson.firstName;
			txbSecond.Text = _currentPerson.secondName;
			txbThird.Text = _currentPerson.thirdName;
			txbLast.Text = _currentPerson.lastName;
			txbAddress.Text = _currentPerson.address;
			txbPhone.Text = _currentPerson.phone;
			txbEmail.Text = _currentPerson.email;

			if (_currentPerson.gender == 0)
			{
				rbMale.Checked = true;
			}
			else
				rbFemale.Checked = true;

			dtpDateOfBirth.Value = _currentPerson.dateOfBirth;


			if (_currentPerson.imagePath != "")
			{
				if (File.Exists(_currentPerson.imagePath))
				{
					pbPersonImage.Load(_currentPerson.imagePath);
					pbPersonImage.SizeMode = PictureBoxSizeMode.Zoom;
					liblRemove.Visible = (!string.IsNullOrEmpty(_currentPerson.imagePath));
				}
			}
			else
			{
				if (_currentPerson.gender == 0)
				{
					pbPersonImage.Image = Resources.Male;
				}
				else
				{
					pbPersonImage.Image = Resources.Female;
				}
			}
			cbCountries.SelectedIndex = cbCountries.FindString(clsBusinessCountries.Find(_currentPerson.nationalityCountryID).countryName);
		}
		private void _LoadData()
		{
			_PrepareUserControl();

			if (_Mode == enMode.enAddNew)
			{
				_currentPerson = new clsBusinessPeople();
				txbFirst.Focus();
				return;
			}

			_currentPerson = clsBusinessPeople.Find(_currentPersonID);

			if (_currentPerson == null)
			{
				return;
			}

			_FillUserInformation();
		}

		// Save And Image Handling.
		private bool _CheckAllInfoCompleted()
		{
			if (txbFirst.Text == "")
			{
				txbFirst.Focus();
				return false;
			}
			if (txbSecond.Text == "")
			{
				txbSecond.Focus();
				return false;
			}
			if (txbLast.Text == "")
			{
				txbLast.Focus();
				return false;
			}
			if (txbNationalNo.Text == "")
			{
				txbNationalNo.Focus();
				return false;
			}
			if (txbPhone.Text == "")
			{
				txbPhone.Focus();
				return false;
			}
			if (txbAddress.Text == "")
			{
				txbAddress.Focus();
				return false;
			}
			if (rbFemale.Checked == rbMale.Checked)
			{
				return false;
			}
			return true;
		}
		private bool _DeleteImagePath(string path)
		{
			if (!string.IsNullOrEmpty(path) && File.Exists(path))
			{
				File.Delete(path);
				return true;
			}
			return false;
		}
		private string _SaveImage(string sourceImagePath)
		{
			if (_currentPerson.imagePath == sourceImagePath && !string.IsNullOrEmpty(sourceImagePath))
			{
				return sourceImagePath;
			}

			try
			{
				if (!File.Exists(sourceImagePath))
				{
					MessageBox.Show("Picture Is Not Existed!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
					return null;
				}

				string MainFolderPath = "C:\\Me\\Mohammed_Abu_Hadhoud\\PracticalStudy\\Course_19\\02_DVLD_MySolution\\01_PresentationTier\\Images\\People\\";

				if (!Directory.Exists(MainFolderPath))
				{
					MessageBox.Show("Directory Is Not Existed!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
					return null;
				}

				string imageExtension = Path.GetExtension(sourceImagePath);
				string newFileName = Guid.NewGuid().ToString() + imageExtension;  // just the file Name.
				string newImagePath = Path.Combine(MainFolderPath, newFileName);  // get the path.

				File.Copy(sourceImagePath, newImagePath, true);
				return newImagePath;
			}
			catch (Exception ex)
			{
				MessageBox.Show("Somthing Went Wrong!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
				return null;
			}
		}


		public uc1_Add_UpdatePerson(int personID)
		{
			InitializeComponent();
			_currentPersonID = personID;
			if (_currentPersonID == -1)
			{
				_Mode = enMode.enAddNew;
			}
			else
			{
				_Mode = enMode.enUpdate;
			}
			_LoadData();
		}


		private void liblSetImage_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
		{
			openFileDialog1.Filter = "Image Files|*.jpg;*.jpeg;*.png;*.gif;*.bmp";
			openFileDialog1.FilterIndex = 1;
			openFileDialog1.RestoreDirectory = true;

			string oldImage = _currentPerson.imagePath;
			if (openFileDialog1.ShowDialog() == DialogResult.OK)
			{
				string selectedFilePath = openFileDialog1.FileName;
				pbPersonImage.Load(selectedFilePath);
				_DeleteImagePath(oldImage);
				_currentPerson.imagePath = selectedFilePath;
				pbPersonImage.SizeMode = PictureBoxSizeMode.Zoom;
				liblRemove.Visible = true;
			}
		}
		private void liblRemoveImage_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
		{
			pbPersonImage.ImageLocation = null;
			if (rbMale.Checked)
			{
				pbPersonImage.Image = Resources.Male;
			}
			else if (rbFemale.Checked)
			{
				pbPersonImage.Image = Resources.Female;
			}
			else
			{
				pbPersonImage.Image = Resources.find;
			}
			liblRemove.Visible = false;
		}


		private void btnSave_Click(object sender, System.EventArgs e)
		{
			if (!_CheckAllInfoCompleted())
			{
				MessageBox.Show("Not All Information Completed!", "Warrning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
				return;
			}

			int countryID = clsBusinessCountries.Find(cbCountries.Text).countryID;

			_currentPerson.nationalNo = txbNationalNo.Text;
			_currentPerson.firstName = txbFirst.Text;
			_currentPerson.secondName = txbSecond.Text;
			_currentPerson.thirdName = txbThird.Text;
			_currentPerson.lastName = txbLast.Text;
			_currentPerson.email = txbEmail.Text;
			_currentPerson.phone = txbPhone.Text;
			_currentPerson.address = txbAddress.Text;
			_currentPerson.dateOfBirth = dtpDateOfBirth.Value;
			_currentPerson.nationalityCountryID = countryID;

			if (rbMale.Checked)
			{
				_currentPerson.gender = 0;
			}
			else
				_currentPerson.gender = 1;

			if (pbPersonImage.ImageLocation != null)
				_currentPerson.imagePath = _SaveImage(pbPersonImage.ImageLocation);
			else
				_currentPerson.imagePath = "";

			if (_currentPerson.Save())
				MessageBox.Show("Data Saved Successfully.");
			else
				MessageBox.Show("Error: Data Is not Saved Successfully.");

			_Mode = enMode.enUpdate;
			_currentPersonID = _currentPerson.personID;


			//OnSavedClicked(EventArgs.Empty);
			//SaveClicked?.Invoke(this, e);
			ReturnPersonID?.Invoke(this, _currentPersonID);
		}
		private void btnClose_Click(object sender, EventArgs e)
		{
			AnyNameOfFunction(EventArgs.Empty);
			//CloseClicked?.Invoke(this, e);
		}
		protected void AnyNameOfFunction(EventArgs e)
		{
			CloseClicked?.Invoke(this, e);
		}


		private void txbNationalNo_Validating(object sender, CancelEventArgs e)
		{
			if (clsBusinessPeople.IsPersonExist(txbNationalNo.Text))
			{
				e.Cancel = true;
				txbNationalNo.Focus();
				errorProvider1.SetError(txbNationalNo, "This National No Is Existed Before!");
			}
			else
			{
				e.Cancel = false;
				errorProvider1.SetError(txbNationalNo, "");
			}
		}
		private void txbEmail_Validating(object sender, CancelEventArgs e)
		{
			if (!txbEmail.Text.Contains("@"))
			{
				e.Cancel = true;
				txbNationalNo.Focus();
				errorProvider1.SetError(txbEmail, "Envaleid Email!");
			}
			else
			{
				e.Cancel = false;
				errorProvider1.SetError(txbEmail, "");
			}
		}


		private void rbMale_CheckedChanged(object sender, EventArgs e)
		{
			if (string.IsNullOrEmpty(_currentPerson.imagePath))
				pbPersonImage.Image = Resources.Male;
		}
		private void rbFemale_CheckedChanged(object sender, EventArgs e)
		{
			if (string.IsNullOrEmpty(_currentPerson.imagePath))
				pbPersonImage.Image = Resources.Female;
		}
	}
}
