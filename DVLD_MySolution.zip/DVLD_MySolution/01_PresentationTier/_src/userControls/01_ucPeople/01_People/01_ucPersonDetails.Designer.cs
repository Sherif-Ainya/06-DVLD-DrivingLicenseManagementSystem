﻿namespace _02_DVLD_Mine._src.userControls.People
{
	partial class uc1_PersonDetails
	{
		/// <summary> 
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary> 
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Component Designer generated code

		/// <summary> 
		/// Required method for Designer support - do not modify 
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.gbPersonDetails = new System.Windows.Forms.GroupBox();
			this.btnEdit = new System.Windows.Forms.Button();
			this.lblDateOfBirth = new System.Windows.Forms.Label();
			this.lblPhone = new System.Windows.Forms.Label();
			this.lblCountry = new System.Windows.Forms.Label();
			this.lblAddress = new System.Windows.Forms.Label();
			this.lblEmail = new System.Windows.Forms.Label();
			this.lblNationalNo = new System.Windows.Forms.Label();
			this.lblName = new System.Windows.Forms.Label();
			this.lblPersonID = new System.Windows.Forms.Label();
			this.pbPersonImage = new System.Windows.Forms.PictureBox();
			this._lblCountry = new System.Windows.Forms.Label();
			this._lblPhone = new System.Windows.Forms.Label();
			this._lblDateOfBirth = new System.Windows.Forms.Label();
			this._lblAddress = new System.Windows.Forms.Label();
			this._lblEmail = new System.Windows.Forms.Label();
			this._lblNationalNo = new System.Windows.Forms.Label();
			this._lblName = new System.Windows.Forms.Label();
			this._lblPersonID = new System.Windows.Forms.Label();
			this.gbPersonDetails.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.pbPersonImage)).BeginInit();
			this.SuspendLayout();
			// 
			// gbPersonDetails
			// 
			this.gbPersonDetails.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
			this.gbPersonDetails.Controls.Add(this.btnEdit);
			this.gbPersonDetails.Controls.Add(this.lblDateOfBirth);
			this.gbPersonDetails.Controls.Add(this.lblPhone);
			this.gbPersonDetails.Controls.Add(this.lblCountry);
			this.gbPersonDetails.Controls.Add(this.lblAddress);
			this.gbPersonDetails.Controls.Add(this.lblEmail);
			this.gbPersonDetails.Controls.Add(this.lblNationalNo);
			this.gbPersonDetails.Controls.Add(this.lblName);
			this.gbPersonDetails.Controls.Add(this.lblPersonID);
			this.gbPersonDetails.Controls.Add(this.pbPersonImage);
			this.gbPersonDetails.Controls.Add(this._lblCountry);
			this.gbPersonDetails.Controls.Add(this._lblPhone);
			this.gbPersonDetails.Controls.Add(this._lblDateOfBirth);
			this.gbPersonDetails.Controls.Add(this._lblAddress);
			this.gbPersonDetails.Controls.Add(this._lblEmail);
			this.gbPersonDetails.Controls.Add(this._lblNationalNo);
			this.gbPersonDetails.Controls.Add(this._lblName);
			this.gbPersonDetails.Controls.Add(this._lblPersonID);
			this.gbPersonDetails.Dock = System.Windows.Forms.DockStyle.Fill;
			this.gbPersonDetails.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.gbPersonDetails.Location = new System.Drawing.Point(0, 0);
			this.gbPersonDetails.Name = "gbPersonDetails";
			this.gbPersonDetails.Size = new System.Drawing.Size(809, 465);
			this.gbPersonDetails.TabIndex = 0;
			this.gbPersonDetails.TabStop = false;
			this.gbPersonDetails.Text = "Person Information :";
			// 
			// btnEdit
			// 
			this.btnEdit.BackColor = System.Drawing.SystemColors.ScrollBar;
			this.btnEdit.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
			this.btnEdit.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
			this.btnEdit.FlatAppearance.BorderSize = 2;
			this.btnEdit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnEdit.Font = new System.Drawing.Font("Microsoft YaHei UI", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnEdit.ForeColor = System.Drawing.Color.Red;
			this.btnEdit.Image = global::_02_DVLD_Mine.Properties.Resources.highlighter_pen;
			this.btnEdit.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btnEdit.Location = new System.Drawing.Point(100, 363);
			this.btnEdit.Name = "btnEdit";
			this.btnEdit.Size = new System.Drawing.Size(83, 53);
			this.btnEdit.TabIndex = 0;
			this.btnEdit.Text = "Edit";
			this.btnEdit.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.btnEdit.UseVisualStyleBackColor = false;
			this.btnEdit.Click += new System.EventHandler(this.btnEditPerson_Click);
			// 
			// lblDateOfBirth
			// 
			this.lblDateOfBirth.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
			this.lblDateOfBirth.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.lblDateOfBirth.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblDateOfBirth.Location = new System.Drawing.Point(471, 158);
			this.lblDateOfBirth.Name = "lblDateOfBirth";
			this.lblDateOfBirth.Size = new System.Drawing.Size(291, 35);
			this.lblDateOfBirth.TabIndex = 18;
			this.lblDateOfBirth.Text = "!";
			this.lblDateOfBirth.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// lblPhone
			// 
			this.lblPhone.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
			this.lblPhone.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.lblPhone.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblPhone.Location = new System.Drawing.Point(471, 280);
			this.lblPhone.Name = "lblPhone";
			this.lblPhone.Size = new System.Drawing.Size(291, 35);
			this.lblPhone.TabIndex = 17;
			this.lblPhone.Text = "!";
			this.lblPhone.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// lblCountry
			// 
			this.lblCountry.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
			this.lblCountry.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.lblCountry.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblCountry.Location = new System.Drawing.Point(471, 219);
			this.lblCountry.Name = "lblCountry";
			this.lblCountry.Size = new System.Drawing.Size(291, 35);
			this.lblCountry.TabIndex = 16;
			this.lblCountry.Text = "!";
			this.lblCountry.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// lblAddress
			// 
			this.lblAddress.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
			this.lblAddress.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.lblAddress.Font = new System.Drawing.Font("Palatino Linotype", 13F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblAddress.Location = new System.Drawing.Point(471, 402);
			this.lblAddress.Name = "lblAddress";
			this.lblAddress.Size = new System.Drawing.Size(291, 35);
			this.lblAddress.TabIndex = 15;
			this.lblAddress.Text = "!";
			this.lblAddress.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// lblEmail
			// 
			this.lblEmail.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
			this.lblEmail.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.lblEmail.Font = new System.Drawing.Font("Palatino Linotype", 13.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblEmail.Location = new System.Drawing.Point(471, 341);
			this.lblEmail.Name = "lblEmail";
			this.lblEmail.Size = new System.Drawing.Size(291, 35);
			this.lblEmail.TabIndex = 14;
			this.lblEmail.Text = "!";
			this.lblEmail.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// lblNationalNo
			// 
			this.lblNationalNo.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
			this.lblNationalNo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.lblNationalNo.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblNationalNo.Location = new System.Drawing.Point(471, 97);
			this.lblNationalNo.Name = "lblNationalNo";
			this.lblNationalNo.Size = new System.Drawing.Size(291, 35);
			this.lblNationalNo.TabIndex = 12;
			this.lblNationalNo.Text = "!";
			this.lblNationalNo.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// lblName
			// 
			this.lblName.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
			this.lblName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.lblName.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblName.Location = new System.Drawing.Point(471, 36);
			this.lblName.Name = "lblName";
			this.lblName.Size = new System.Drawing.Size(291, 35);
			this.lblName.TabIndex = 11;
			this.lblName.Text = "!";
			this.lblName.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// lblPersonID
			// 
			this.lblPersonID.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
			this.lblPersonID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.lblPersonID.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblPersonID.ForeColor = System.Drawing.Color.Red;
			this.lblPersonID.Location = new System.Drawing.Point(121, 50);
			this.lblPersonID.Name = "lblPersonID";
			this.lblPersonID.Size = new System.Drawing.Size(73, 41);
			this.lblPersonID.TabIndex = 10;
			this.lblPersonID.Text = "-1";
			this.lblPersonID.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// pbPersonImage
			// 
			this.pbPersonImage.BackColor = System.Drawing.Color.LavenderBlush;
			this.pbPersonImage.Image = global::_02_DVLD_Mine.Properties.Resources.find;
			this.pbPersonImage.Location = new System.Drawing.Point(29, 106);
			this.pbPersonImage.Name = "pbPersonImage";
			this.pbPersonImage.Size = new System.Drawing.Size(229, 225);
			this.pbPersonImage.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
			this.pbPersonImage.TabIndex = 9;
			this.pbPersonImage.TabStop = false;
			// 
			// _lblCountry
			// 
			this._lblCountry.AutoSize = true;
			this._lblCountry.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this._lblCountry.Location = new System.Drawing.Point(310, 223);
			this._lblCountry.Name = "_lblCountry";
			this._lblCountry.Size = new System.Drawing.Size(90, 26);
			this._lblCountry.TabIndex = 8;
			this._lblCountry.Text = "Country :";
			// 
			// _lblPhone
			// 
			this._lblPhone.AutoSize = true;
			this._lblPhone.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this._lblPhone.Location = new System.Drawing.Point(310, 284);
			this._lblPhone.Name = "_lblPhone";
			this._lblPhone.Size = new System.Drawing.Size(75, 26);
			this._lblPhone.TabIndex = 7;
			this._lblPhone.Text = "Phone :";
			// 
			// _lblDateOfBirth
			// 
			this._lblDateOfBirth.AutoSize = true;
			this._lblDateOfBirth.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this._lblDateOfBirth.Location = new System.Drawing.Point(310, 162);
			this._lblDateOfBirth.Name = "_lblDateOfBirth";
			this._lblDateOfBirth.Size = new System.Drawing.Size(133, 26);
			this._lblDateOfBirth.TabIndex = 6;
			this._lblDateOfBirth.Text = "Date Of Birth :";
			// 
			// _lblAddress
			// 
			this._lblAddress.AutoSize = true;
			this._lblAddress.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this._lblAddress.Location = new System.Drawing.Point(310, 406);
			this._lblAddress.Name = "_lblAddress";
			this._lblAddress.Size = new System.Drawing.Size(91, 26);
			this._lblAddress.TabIndex = 5;
			this._lblAddress.Text = "Address :";
			// 
			// _lblEmail
			// 
			this._lblEmail.AutoSize = true;
			this._lblEmail.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this._lblEmail.Location = new System.Drawing.Point(310, 345);
			this._lblEmail.Name = "_lblEmail";
			this._lblEmail.Size = new System.Drawing.Size(70, 26);
			this._lblEmail.TabIndex = 4;
			this._lblEmail.Text = "Email :";
			// 
			// _lblNationalNo
			// 
			this._lblNationalNo.AutoSize = true;
			this._lblNationalNo.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this._lblNationalNo.Location = new System.Drawing.Point(310, 101);
			this._lblNationalNo.Name = "_lblNationalNo";
			this._lblNationalNo.Size = new System.Drawing.Size(124, 26);
			this._lblNationalNo.TabIndex = 2;
			this._lblNationalNo.Text = "National No :";
			// 
			// _lblName
			// 
			this._lblName.AutoSize = true;
			this._lblName.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this._lblName.Location = new System.Drawing.Point(310, 40);
			this._lblName.Name = "_lblName";
			this._lblName.Size = new System.Drawing.Size(73, 26);
			this._lblName.TabIndex = 1;
			this._lblName.Text = "Name :";
			// 
			// _lblPersonID
			// 
			this._lblPersonID.AutoSize = true;
			this._lblPersonID.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this._lblPersonID.Location = new System.Drawing.Point(53, 58);
			this._lblPersonID.Name = "_lblPersonID";
			this._lblPersonID.Size = new System.Drawing.Size(44, 26);
			this._lblPersonID.TabIndex = 0;
			this._lblPersonID.Text = "ID :";
			// 
			// ucPersonDetails
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.Controls.Add(this.gbPersonDetails);
			this.Name = "ucPersonDetails";
			this.Size = new System.Drawing.Size(809, 465);
			this.gbPersonDetails.ResumeLayout(false);
			this.gbPersonDetails.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.pbPersonImage)).EndInit();
			this.ResumeLayout(false);

		}

		#endregion

		private System.Windows.Forms.GroupBox gbPersonDetails;
		private System.Windows.Forms.PictureBox pbPersonImage;
		private System.Windows.Forms.Label _lblCountry;
		private System.Windows.Forms.Label _lblPhone;
		private System.Windows.Forms.Label _lblDateOfBirth;
		private System.Windows.Forms.Label _lblAddress;
		private System.Windows.Forms.Label _lblEmail;
		private System.Windows.Forms.Label _lblNationalNo;
		private System.Windows.Forms.Label _lblName;
		private System.Windows.Forms.Label _lblPersonID;
		private System.Windows.Forms.Label lblName;
		private System.Windows.Forms.Label lblPersonID;
		private System.Windows.Forms.Label lblAddress;
		private System.Windows.Forms.Label lblEmail;
		private System.Windows.Forms.Label lblNationalNo;
		private System.Windows.Forms.Label lblCountry;
		private System.Windows.Forms.Label lblDateOfBirth;
		private System.Windows.Forms.Label lblPhone;
		private System.Windows.Forms.Button btnEdit;
	}
}
