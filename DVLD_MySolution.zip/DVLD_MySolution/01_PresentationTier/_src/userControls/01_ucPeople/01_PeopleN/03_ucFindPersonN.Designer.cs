﻿namespace _02_DVLD_Mine._src.userControls._01_People
{
	partial class uc1N_FindPersonN
	{
		/// <summary> 
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary> 
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Component Designer generated code

		/// <summary> 
		/// Required method for Designer support - do not modify 
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.mtxbFindPerson = new System.Windows.Forms.MaskedTextBox();
			this.lblFiindBy = new System.Windows.Forms.Label();
			this.cbPersonID_NationalNo = new System.Windows.Forms.ComboBox();
			this.btnFindPerson = new System.Windows.Forms.Button();
			this.btnAddNew = new System.Windows.Forms.Button();
			this.btnFind = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// mtxbFindPerson
			// 
			this.mtxbFindPerson.AsciiOnly = true;
			this.mtxbFindPerson.Font = new System.Drawing.Font("Microsoft Sans Serif", 17F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.mtxbFindPerson.Location = new System.Drawing.Point(84, 89);
			this.mtxbFindPerson.Mask = "00000";
			this.mtxbFindPerson.Name = "mtxbFindPerson";
			this.mtxbFindPerson.Size = new System.Drawing.Size(211, 33);
			this.mtxbFindPerson.TabIndex = 0;
			this.mtxbFindPerson.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			this.mtxbFindPerson.ValidatingType = typeof(int);
			// 
			// lblFiindBy
			// 
			this.lblFiindBy.AutoSize = true;
			this.lblFiindBy.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblFiindBy.Location = new System.Drawing.Point(43, 16);
			this.lblFiindBy.Name = "lblFiindBy";
			this.lblFiindBy.Size = new System.Drawing.Size(81, 22);
			this.lblFiindBy.TabIndex = 0;
			this.lblFiindBy.Text = "Find By :";
			// 
			// cbPersonID_NationalNo
			// 
			this.cbPersonID_NationalNo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.cbPersonID_NationalNo.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F);
			this.cbPersonID_NationalNo.FormattingEnabled = true;
			this.cbPersonID_NationalNo.ItemHeight = 20;
			this.cbPersonID_NationalNo.Items.AddRange(new object[] {
            "PersonID",
            "NationalNo"});
			this.cbPersonID_NationalNo.Location = new System.Drawing.Point(22, 41);
			this.cbPersonID_NationalNo.Name = "cbPersonID_NationalNo";
			this.cbPersonID_NationalNo.Size = new System.Drawing.Size(223, 28);
			this.cbPersonID_NationalNo.TabIndex = 0;
			this.cbPersonID_NationalNo.TabStop = false;
			this.cbPersonID_NationalNo.SelectedIndexChanged += new System.EventHandler(this.cbPersonID_NationalNo_SelectedIndexChanged);
			// 
			// btnFindPerson
			// 
			this.btnFindPerson.BackColor = System.Drawing.Color.LightSkyBlue;
			this.btnFindPerson.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
			this.btnFindPerson.FlatAppearance.BorderSize = 7;
			this.btnFindPerson.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnFindPerson.Font = new System.Drawing.Font("Microsoft Tai Le", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnFindPerson.Location = new System.Drawing.Point(515, 32);
			this.btnFindPerson.Name = "btnFindPerson";
			this.btnFindPerson.Size = new System.Drawing.Size(259, 99);
			this.btnFindPerson.TabIndex = 2;
			this.btnFindPerson.Text = "Find A Person From People Managment";
			this.btnFindPerson.UseVisualStyleBackColor = false;
			this.btnFindPerson.Click += new System.EventHandler(this.btnFindPerson_Click);
			// 
			// btnAddNew
			// 
			this.btnAddNew.BackColor = System.Drawing.Color.Plum;
			this.btnAddNew.FlatAppearance.BorderColor = System.Drawing.Color.CornflowerBlue;
			this.btnAddNew.FlatAppearance.BorderSize = 5;
			this.btnAddNew.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
			this.btnAddNew.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
			this.btnAddNew.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnAddNew.Font = new System.Drawing.Font("Microsoft YaHei UI", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnAddNew.ForeColor = System.Drawing.Color.Red;
			this.btnAddNew.Image = global::_02_DVLD_Mine.Properties.Resources.administrator;
			this.btnAddNew.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btnAddNew.Location = new System.Drawing.Point(351, 71);
			this.btnAddNew.Name = "btnAddNew";
			this.btnAddNew.Size = new System.Drawing.Size(94, 71);
			this.btnAddNew.TabIndex = 3;
			this.btnAddNew.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.btnAddNew.UseVisualStyleBackColor = false;
			this.btnAddNew.Click += new System.EventHandler(this.btnAddNew_Click);
			// 
			// btnFind
			// 
			this.btnFind.BackColor = System.Drawing.Color.NavajoWhite;
			this.btnFind.FlatAppearance.BorderColor = System.Drawing.Color.Black;
			this.btnFind.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
			this.btnFind.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
			this.btnFind.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnFind.Font = new System.Drawing.Font("Microsoft YaHei UI", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnFind.ForeColor = System.Drawing.Color.Red;
			this.btnFind.Image = global::_02_DVLD_Mine.Properties.Resources.find;
			this.btnFind.Location = new System.Drawing.Point(301, 81);
			this.btnFind.Name = "btnFind";
			this.btnFind.Size = new System.Drawing.Size(44, 50);
			this.btnFind.TabIndex = 1;
			this.btnFind.UseVisualStyleBackColor = false;
			this.btnFind.Click += new System.EventHandler(this.btnFind_Click);
			// 
			// uc1N_FindPersonN
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
			this.Controls.Add(this.btnFind);
			this.Controls.Add(this.btnAddNew);
			this.Controls.Add(this.btnFindPerson);
			this.Controls.Add(this.mtxbFindPerson);
			this.Controls.Add(this.lblFiindBy);
			this.Controls.Add(this.cbPersonID_NationalNo);
			this.Name = "uc1N_FindPersonN";
			this.Size = new System.Drawing.Size(809, 163);
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion
		private System.Windows.Forms.MaskedTextBox mtxbFindPerson;
		private System.Windows.Forms.Label lblFiindBy;
		private System.Windows.Forms.ComboBox cbPersonID_NationalNo;
		private System.Windows.Forms.Button btnFindPerson;
		private System.Windows.Forms.Button btnAddNew;
		private System.Windows.Forms.Button btnFind;
	}
}
