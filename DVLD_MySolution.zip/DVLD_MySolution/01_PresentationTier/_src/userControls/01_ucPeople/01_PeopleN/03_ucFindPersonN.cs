﻿using System;
using System.Windows.Forms;
using _02_DVLD_Mine._src.Forms._02_People;
using _02_DVLD_Mine._src.Forms._02_PeopleN;
using DVLD_Business;

namespace _02_DVLD_Mine._src.userControls._01_People
{
	public partial class uc1N_FindPersonN : UserControl
	{
		public event Action<int> OnFound;
		protected virtual void Found(int personID)
		{
			Action<int> handler = OnFound;
			if (handler != null)
			{
				handler(personID);
			}
		}

		public uc1N_FindPersonN()
		{
			InitializeComponent();
			cbPersonID_NationalNo.SelectedIndex = 0;
		}

		frmManagePeopleN.enReturnPerson _returnMode;

		private void cbPersonID_NationalNo_SelectedIndexChanged(object sender, EventArgs e)
		{
			if (cbPersonID_NationalNo.SelectedIndex == 0)
			{
				mtxbFindPerson.Mask = "00000";
			}
			else
			{
				mtxbFindPerson.Mask = "";
			}
		}
		private void ClearFindPerson_Focus()
		{
			mtxbFindPerson.Text = "";
			mtxbFindPerson.Focus();
		}
		private void btnFind_Click(object sender, EventArgs e)
		{
			if (string.IsNullOrEmpty(mtxbFindPerson.Text))
			{
				mtxbFindPerson.Focus();
				return;
			}

			if (cbPersonID_NationalNo.SelectedIndex == 0)
			{
				int personID = Convert.ToInt32(mtxbFindPerson.Text);
				if (!clsBusinessPeople.IsPersonExist(personID))
				{
					MessageBox.Show("The Person With ID [" + mtxbFindPerson.Text + "] Is Not Found!", "Person Was Not Found!", MessageBoxButtons.OK, MessageBoxIcon.Information);
					ClearFindPerson_Focus();
					return;
				}
				if (_returnMode == frmManagePeopleN.enReturnPerson.enReturnPerson_CheckUser && clsBusinessPeople.IsThisPersonUser(personID))
				{
					MessageBox.Show("This Person Is Already A User!", "Error!", MessageBoxButtons.OK, MessageBoxIcon.Information);
					ClearFindPerson_Focus();
					return;
				}
				if (OnFound != null)
					Found(personID);
			}
			else
			{
				string nationalNo = mtxbFindPerson.Text.Trim();
				clsBusinessPeople person = clsBusinessPeople.Find(nationalNo);
				if (!clsBusinessPeople.IsPersonExist(person.personID))
				{
					MessageBox.Show("The Person With National No [" + mtxbFindPerson.Text + "] Is Not Found!", "Person Was Not Found!", MessageBoxButtons.OK, MessageBoxIcon.Information);
					ClearFindPerson_Focus();
					return;
				}
				if (_returnMode == frmManagePeopleN.enReturnPerson.enReturnPerson_CheckUser && clsBusinessPeople.IsThisPersonUser(person.personID))
				{
					MessageBox.Show("This Person Is Already A User!", "Error!", MessageBoxButtons.OK, MessageBoxIcon.Information);
					ClearFindPerson_Focus();
					return;
				}
				if (OnFound != null)
					Found(person.personID);
			}
		}


		private void btnAddNew_Click(object sender, EventArgs e)
		{
			frmAdd_UpdatePersonN frm = new frmAdd_UpdatePersonN();
			frm.ReturnPersonID += AddedNewPerson;
			frm.ShowDialog();
		}
		private void AddedNewPerson(object sender, int personID)
		{
			if (OnFound != null && personID != -1)
				Found(personID);
		}


		public void FindPersonFor(frmManagePeopleN.enReturnPerson ReturnMode)
		{
			_returnMode = ReturnMode;
		}
		private void btnFindPerson_Click(object sender, EventArgs e)
		{
			frmManagePeopleN returnvalue = new frmManagePeopleN(_returnMode);
			returnvalue.ReturnPersonID += LoadPersonData;
			returnvalue.ShowDialog();
		}
		private void LoadPersonData(object sender, int personID)
		{
			if (OnFound != null)
				Found(personID);
		}
	}
}
