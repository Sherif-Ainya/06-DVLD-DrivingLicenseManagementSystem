﻿using System;
using System.Windows.Forms;
using _02_DVLD_Mine._src.Forms._02_PeopleN;

namespace _02_DVLD_Mine._src.userControls._01_People
{
	public partial class uc1N_FindPersonThenFillData : UserControl
	{
		public event Action<int> OnFound;
		protected virtual void Found(int personID)
		{
			Action<int> handler = OnFound;
			if (handler != null)
			{
				handler(personID);
			}
		}
		public event Action<int> OnFound_Hide;
		protected virtual void Found_Hide(int personID)
		{
			Action<int> handler = OnFound_Hide;
			if (handler != null)
			{
				handler(personID);
			}
		}


		public uc1N_FindPersonThenFillData()
		{
			InitializeComponent();
		}


		public void FindPersonFor(frmManagePeopleN.enReturnPerson returnMode)
		{
			uc1N_FindPersonN1.FindPersonFor(returnMode);
		}
		private void uc1N_FindPersonN1_OnFound(int obj)
		{
			uc1N_PersonDetailsN1.LoadPersonData(obj);
			if (OnFound != null)
				Found(obj);

			if (OnFound_Hide != null)
			{
				Found_Hide(obj);
				uc1N_FindPersonN1.Visible = false;
				uc1N_PersonDetailsN1.Dock = DockStyle.Fill;
			}
		}
	}
}
