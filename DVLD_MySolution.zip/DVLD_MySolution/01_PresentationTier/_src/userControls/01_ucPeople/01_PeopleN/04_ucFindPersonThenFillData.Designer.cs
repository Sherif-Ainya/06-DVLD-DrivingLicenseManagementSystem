﻿namespace _02_DVLD_Mine._src.userControls._01_People
{
	partial class uc1N_FindPersonThenFillData
	{
		/// <summary> 
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary> 
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Component Designer generated code

		/// <summary> 
		/// Required method for Designer support - do not modify 
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.uc1N_FindPersonN1 = new _02_DVLD_Mine._src.userControls._01_People.uc1N_FindPersonN();
			this.uc1N_PersonDetailsN1 = new _02_DVLD_Mine._src.userControls._01_PeopleNewWay.uc1N_PersonDetailsN();
			this.SuspendLayout();
			// 
			// uc1N_FindPersonN1
			// 
			this.uc1N_FindPersonN1.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
			this.uc1N_FindPersonN1.Dock = System.Windows.Forms.DockStyle.Top;
			this.uc1N_FindPersonN1.Location = new System.Drawing.Point(0, 0);
			this.uc1N_FindPersonN1.Name = "uc1N_FindPersonN1";
			this.uc1N_FindPersonN1.Size = new System.Drawing.Size(809, 163);
			this.uc1N_FindPersonN1.TabIndex = 0;
			this.uc1N_FindPersonN1.OnFound += new System.Action<int>(this.uc1N_FindPersonN1_OnFound);
			// 
			// uc1N_PersonDetailsN1
			// 
			this.uc1N_PersonDetailsN1.Dock = System.Windows.Forms.DockStyle.Bottom;
			this.uc1N_PersonDetailsN1.Location = new System.Drawing.Point(0, 175);
			this.uc1N_PersonDetailsN1.Name = "uc1N_PersonDetailsN1";
			this.uc1N_PersonDetailsN1.Size = new System.Drawing.Size(809, 465);
			this.uc1N_PersonDetailsN1.TabIndex = 1;
			// 
			// uc1N_FindPersonThenFillData
			// 
			this.BackColor = System.Drawing.Color.DarkMagenta;
			this.Controls.Add(this.uc1N_PersonDetailsN1);
			this.Controls.Add(this.uc1N_FindPersonN1);
			this.Name = "uc1N_FindPersonThenFillData";
			this.Size = new System.Drawing.Size(809, 640);
			this.ResumeLayout(false);

		}

		private uc1N_FindPersonN uc1N_FindPersonN1;
		private _01_PeopleNewWay.uc1N_PersonDetailsN uc1N_PersonDetailsN1;

		#endregion

		//private uc01N_FindPersonN ucFindPersonN1;
		//private _01_PeopleNewWay.uc01N_PersonDetailsN ucPersonDetailsN1;
	}
}
