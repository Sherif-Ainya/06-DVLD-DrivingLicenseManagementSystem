﻿namespace _02_DVLD_Mine._src.userControls._01_PeopleNewWay
{
	partial class uc1N_Add_UpdatePersonN
	{
		/// <summary> 
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary> 
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Component Designer generated code

		/// <summary> 
		/// Required method for Designer support - do not modify 
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			this.txbAddress = new System.Windows.Forms.TextBox();
			this.errorProvider1 = new System.Windows.Forms.ErrorProvider(this.components);
			this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
			this.liblRemove = new System.Windows.Forms.LinkLabel();
			this.liblSetImage = new System.Windows.Forms.LinkLabel();
			this.dtpDateOfBirth = new System.Windows.Forms.DateTimePicker();
			this.rbFemale = new System.Windows.Forms.RadioButton();
			this.rbMale = new System.Windows.Forms.RadioButton();
			this.txbEmail = new System.Windows.Forms.TextBox();
			this.cbCountries = new System.Windows.Forms.ComboBox();
			this.txbPhone = new System.Windows.Forms.TextBox();
			this.txbNationalNo = new System.Windows.Forms.TextBox();
			this._lblLast = new System.Windows.Forms.Label();
			this.txbLast = new System.Windows.Forms.TextBox();
			this._lblThird = new System.Windows.Forms.Label();
			this.txbThird = new System.Windows.Forms.TextBox();
			this._lblSecond = new System.Windows.Forms.Label();
			this.txbSecond = new System.Windows.Forms.TextBox();
			this._lblFirst = new System.Windows.Forms.Label();
			this.txbFirst = new System.Windows.Forms.TextBox();
			this._lblCountry = new System.Windows.Forms.Label();
			this._lblPhone = new System.Windows.Forms.Label();
			this._lblDateOfBirth = new System.Windows.Forms.Label();
			this._lblAddress = new System.Windows.Forms.Label();
			this._lblEmail = new System.Windows.Forms.Label();
			this._lblGender = new System.Windows.Forms.Label();
			this._lblNationalNo = new System.Windows.Forms.Label();
			this._lblName = new System.Windows.Forms.Label();
			this.btnClose = new System.Windows.Forms.Button();
			this.btnSave = new System.Windows.Forms.Button();
			this.pbPersonImage = new System.Windows.Forms.PictureBox();
			((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.pbPersonImage)).BeginInit();
			this.SuspendLayout();
			// 
			// txbAddress
			// 
			this.txbAddress.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.txbAddress.Location = new System.Drawing.Point(149, 310);
			this.txbAddress.Multiline = true;
			this.txbAddress.Name = "txbAddress";
			this.txbAddress.Size = new System.Drawing.Size(573, 88);
			this.txbAddress.TabIndex = 7;
			// 
			// errorProvider1
			// 
			this.errorProvider1.ContainerControl = this;
			// 
			// openFileDialog1
			// 
			this.openFileDialog1.FileName = "openFileDialog1";
			// 
			// liblRemove
			// 
			this.liblRemove.AutoSize = true;
			this.liblRemove.Font = new System.Drawing.Font("Sylfaen", 13F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.liblRemove.LinkColor = System.Drawing.Color.Red;
			this.liblRemove.Location = new System.Drawing.Point(890, 323);
			this.liblRemove.Name = "liblRemove";
			this.liblRemove.Size = new System.Drawing.Size(76, 23);
			this.liblRemove.TabIndex = 13;
			this.liblRemove.TabStop = true;
			this.liblRemove.Text = "Remove";
			this.liblRemove.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			this.liblRemove.Visible = false;
			this.liblRemove.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.liblRemoveImage_LinkClicked);
			// 
			// liblSetImage
			// 
			this.liblSetImage.AutoSize = true;
			this.liblSetImage.Font = new System.Drawing.Font("Sylfaen", 13F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.liblSetImage.Location = new System.Drawing.Point(782, 323);
			this.liblSetImage.Name = "liblSetImage";
			this.liblSetImage.Size = new System.Drawing.Size(92, 23);
			this.liblSetImage.TabIndex = 12;
			this.liblSetImage.TabStop = true;
			this.liblSetImage.Text = "Set Image";
			this.liblSetImage.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			this.liblSetImage.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.liblSetImage_LinkClicked);
			// 
			// dtpDateOfBirth
			// 
			this.dtpDateOfBirth.CalendarFont = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.dtpDateOfBirth.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.dtpDateOfBirth.Format = System.Windows.Forms.DateTimePickerFormat.Short;
			this.dtpDateOfBirth.Location = new System.Drawing.Point(555, 180);
			this.dtpDateOfBirth.MaximumSize = new System.Drawing.Size(167, 29);
			this.dtpDateOfBirth.MinimumSize = new System.Drawing.Size(167, 29);
			this.dtpDateOfBirth.Name = "dtpDateOfBirth";
			this.dtpDateOfBirth.Size = new System.Drawing.Size(167, 29);
			this.dtpDateOfBirth.TabIndex = 82;
			this.dtpDateOfBirth.TabStop = false;
			// 
			// rbFemale
			// 
			this.rbFemale.AutoSize = true;
			this.rbFemale.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
			this.rbFemale.Font = new System.Drawing.Font("Malgun Gothic", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.rbFemale.Location = new System.Drawing.Point(618, 247);
			this.rbFemale.Name = "rbFemale";
			this.rbFemale.Size = new System.Drawing.Size(77, 24);
			this.rbFemale.TabIndex = 9;
			this.rbFemale.TabStop = true;
			this.rbFemale.Text = "Female";
			this.rbFemale.UseVisualStyleBackColor = false;
			this.rbFemale.Click += new System.EventHandler(this.rbFemale_CheckedChanged);
			// 
			// rbMale
			// 
			this.rbMale.AutoSize = true;
			this.rbMale.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
			this.rbMale.Font = new System.Drawing.Font("Malgun Gothic", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.rbMale.Location = new System.Drawing.Point(529, 247);
			this.rbMale.Name = "rbMale";
			this.rbMale.Size = new System.Drawing.Size(61, 24);
			this.rbMale.TabIndex = 8;
			this.rbMale.TabStop = true;
			this.rbMale.Text = "Male";
			this.rbMale.UseVisualStyleBackColor = false;
			this.rbMale.Click += new System.EventHandler(this.rbMale_CheckedChanged);
			// 
			// txbEmail
			// 
			this.txbEmail.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.txbEmail.Location = new System.Drawing.Point(163, 247);
			this.txbEmail.Name = "txbEmail";
			this.txbEmail.Size = new System.Drawing.Size(193, 26);
			this.txbEmail.TabIndex = 6;
			this.txbEmail.Validating += new System.ComponentModel.CancelEventHandler(this.txbEmail_Validating);
			// 
			// cbCountries
			// 
			this.cbCountries.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.cbCountries.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.cbCountries.FormattingEnabled = true;
			this.cbCountries.Location = new System.Drawing.Point(529, 116);
			this.cbCountries.Name = "cbCountries";
			this.cbCountries.Size = new System.Drawing.Size(193, 26);
			this.cbCountries.TabIndex = 0;
			this.cbCountries.TabStop = false;
			// 
			// txbPhone
			// 
			this.txbPhone.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.txbPhone.Location = new System.Drawing.Point(163, 182);
			this.txbPhone.Name = "txbPhone";
			this.txbPhone.Size = new System.Drawing.Size(193, 29);
			this.txbPhone.TabIndex = 5;
			// 
			// txbNationalNo
			// 
			this.txbNationalNo.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.txbNationalNo.Location = new System.Drawing.Point(163, 116);
			this.txbNationalNo.Name = "txbNationalNo";
			this.txbNationalNo.Size = new System.Drawing.Size(193, 29);
			this.txbNationalNo.TabIndex = 4;
			this.txbNationalNo.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			this.txbNationalNo.Validating += new System.ComponentModel.CancelEventHandler(this.txbNationalNo_Validating);
			// 
			// _lblLast
			// 
			this._lblLast.AutoSize = true;
			this._lblLast.Font = new System.Drawing.Font("Aldhabi", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this._lblLast.ForeColor = System.Drawing.Color.DarkViolet;
			this._lblLast.Location = new System.Drawing.Point(817, 15);
			this._lblLast.Name = "_lblLast";
			this._lblLast.Size = new System.Drawing.Size(40, 34);
			this._lblLast.TabIndex = 78;
			this._lblLast.Text = "Last";
			this._lblLast.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// txbLast
			// 
			this.txbLast.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.txbLast.Location = new System.Drawing.Point(756, 52);
			this.txbLast.Name = "txbLast";
			this.txbLast.Size = new System.Drawing.Size(193, 29);
			this.txbLast.TabIndex = 3;
			this.txbLast.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			// 
			// _lblThird
			// 
			this._lblThird.AutoSize = true;
			this._lblThird.Font = new System.Drawing.Font("Aldhabi", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this._lblThird.ForeColor = System.Drawing.Color.DarkViolet;
			this._lblThird.Location = new System.Drawing.Point(615, 15);
			this._lblThird.Name = "_lblThird";
			this._lblThird.Size = new System.Drawing.Size(48, 34);
			this._lblThird.TabIndex = 77;
			this._lblThird.Text = "Third";
			this._lblThird.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// txbThird
			// 
			this.txbThird.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.txbThird.Location = new System.Drawing.Point(547, 52);
			this.txbThird.Name = "txbThird";
			this.txbThird.Size = new System.Drawing.Size(193, 29);
			this.txbThird.TabIndex = 2;
			this.txbThird.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			// 
			// _lblSecond
			// 
			this._lblSecond.AutoSize = true;
			this._lblSecond.Font = new System.Drawing.Font("Aldhabi", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this._lblSecond.ForeColor = System.Drawing.Color.DarkViolet;
			this._lblSecond.Location = new System.Drawing.Point(405, 15);
			this._lblSecond.Name = "_lblSecond";
			this._lblSecond.Size = new System.Drawing.Size(56, 34);
			this._lblSecond.TabIndex = 76;
			this._lblSecond.Text = "Second";
			this._lblSecond.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// txbSecond
			// 
			this.txbSecond.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.txbSecond.Location = new System.Drawing.Point(338, 52);
			this.txbSecond.Name = "txbSecond";
			this.txbSecond.Size = new System.Drawing.Size(193, 29);
			this.txbSecond.TabIndex = 1;
			this.txbSecond.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			// 
			// _lblFirst
			// 
			this._lblFirst.AutoSize = true;
			this._lblFirst.Font = new System.Drawing.Font("Aldhabi", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this._lblFirst.ForeColor = System.Drawing.Color.DarkViolet;
			this._lblFirst.Location = new System.Drawing.Point(210, 15);
			this._lblFirst.Name = "_lblFirst";
			this._lblFirst.Size = new System.Drawing.Size(41, 34);
			this._lblFirst.TabIndex = 75;
			this._lblFirst.Text = "First";
			this._lblFirst.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// txbFirst
			// 
			this.txbFirst.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.txbFirst.Location = new System.Drawing.Point(129, 52);
			this.txbFirst.Name = "txbFirst";
			this.txbFirst.Size = new System.Drawing.Size(193, 29);
			this.txbFirst.TabIndex = 0;
			this.txbFirst.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			// 
			// _lblCountry
			// 
			this._lblCountry.AutoSize = true;
			this._lblCountry.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this._lblCountry.Location = new System.Drawing.Point(408, 116);
			this._lblCountry.Name = "_lblCountry";
			this._lblCountry.Size = new System.Drawing.Size(90, 26);
			this._lblCountry.TabIndex = 73;
			this._lblCountry.Text = "Country :";
			// 
			// _lblPhone
			// 
			this._lblPhone.AutoSize = true;
			this._lblPhone.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this._lblPhone.Location = new System.Drawing.Point(34, 182);
			this._lblPhone.Name = "_lblPhone";
			this._lblPhone.Size = new System.Drawing.Size(75, 26);
			this._lblPhone.TabIndex = 72;
			this._lblPhone.Text = "Phone :";
			// 
			// _lblDateOfBirth
			// 
			this._lblDateOfBirth.AutoSize = true;
			this._lblDateOfBirth.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this._lblDateOfBirth.Location = new System.Drawing.Point(408, 181);
			this._lblDateOfBirth.Name = "_lblDateOfBirth";
			this._lblDateOfBirth.Size = new System.Drawing.Size(133, 26);
			this._lblDateOfBirth.TabIndex = 71;
			this._lblDateOfBirth.Text = "Date Of Birth :";
			// 
			// _lblAddress
			// 
			this._lblAddress.AutoSize = true;
			this._lblAddress.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this._lblAddress.Location = new System.Drawing.Point(34, 312);
			this._lblAddress.Name = "_lblAddress";
			this._lblAddress.Size = new System.Drawing.Size(91, 26);
			this._lblAddress.TabIndex = 70;
			this._lblAddress.Text = "Address :";
			// 
			// _lblEmail
			// 
			this._lblEmail.AutoSize = true;
			this._lblEmail.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this._lblEmail.Location = new System.Drawing.Point(34, 247);
			this._lblEmail.Name = "_lblEmail";
			this._lblEmail.Size = new System.Drawing.Size(70, 26);
			this._lblEmail.TabIndex = 69;
			this._lblEmail.Text = "Email :";
			// 
			// _lblGender
			// 
			this._lblGender.AutoSize = true;
			this._lblGender.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this._lblGender.Location = new System.Drawing.Point(408, 246);
			this._lblGender.Name = "_lblGender";
			this._lblGender.Size = new System.Drawing.Size(83, 26);
			this._lblGender.TabIndex = 68;
			this._lblGender.Text = "Gender :";
			// 
			// _lblNationalNo
			// 
			this._lblNationalNo.AutoSize = true;
			this._lblNationalNo.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this._lblNationalNo.Location = new System.Drawing.Point(34, 117);
			this._lblNationalNo.Name = "_lblNationalNo";
			this._lblNationalNo.Size = new System.Drawing.Size(124, 26);
			this._lblNationalNo.TabIndex = 67;
			this._lblNationalNo.Text = "National No :";
			// 
			// _lblName
			// 
			this._lblName.AutoSize = true;
			this._lblName.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this._lblName.Location = new System.Drawing.Point(34, 52);
			this._lblName.Name = "_lblName";
			this._lblName.Size = new System.Drawing.Size(73, 26);
			this._lblName.TabIndex = 66;
			this._lblName.Text = "Name :";
			// 
			// btnClose
			// 
			this.btnClose.BackColor = System.Drawing.Color.Pink;
			this.btnClose.FlatAppearance.BorderColor = System.Drawing.Color.Cyan;
			this.btnClose.FlatAppearance.BorderSize = 3;
			this.btnClose.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
			this.btnClose.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
			this.btnClose.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnClose.Font = new System.Drawing.Font("Microsoft YaHei UI", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnClose.ForeColor = System.Drawing.Color.Red;
			this.btnClose.Image = global::_02_DVLD_Mine.Properties.Resources.close1;
			this.btnClose.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btnClose.Location = new System.Drawing.Point(900, 358);
			this.btnClose.Name = "btnClose";
			this.btnClose.Size = new System.Drawing.Size(62, 52);
			this.btnClose.TabIndex = 11;
			this.btnClose.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.btnClose.UseVisualStyleBackColor = false;
			this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
			// 
			// btnSave
			// 
			this.btnSave.BackColor = System.Drawing.Color.Pink;
			this.btnSave.FlatAppearance.BorderColor = System.Drawing.Color.Cyan;
			this.btnSave.FlatAppearance.BorderSize = 3;
			this.btnSave.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
			this.btnSave.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
			this.btnSave.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnSave.Font = new System.Drawing.Font("Microsoft YaHei UI", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnSave.ForeColor = System.Drawing.Color.DarkOrchid;
			this.btnSave.Image = global::_02_DVLD_Mine.Properties.Resources.save_27_16;
			this.btnSave.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btnSave.Location = new System.Drawing.Point(797, 358);
			this.btnSave.Name = "btnSave";
			this.btnSave.Size = new System.Drawing.Size(100, 52);
			this.btnSave.TabIndex = 10;
			this.btnSave.Text = "SAVE";
			this.btnSave.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.btnSave.UseVisualStyleBackColor = false;
			this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
			// 
			// pbPersonImage
			// 
			this.pbPersonImage.BackColor = System.Drawing.Color.LavenderBlush;
			this.pbPersonImage.Image = global::_02_DVLD_Mine.Properties.Resources.find;
			this.pbPersonImage.Location = new System.Drawing.Point(757, 101);
			this.pbPersonImage.Name = "pbPersonImage";
			this.pbPersonImage.Size = new System.Drawing.Size(220, 215);
			this.pbPersonImage.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
			this.pbPersonImage.TabIndex = 74;
			this.pbPersonImage.TabStop = false;
			// 
			// uc1N_Add_UpdatePersonN
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
			this.Controls.Add(this.btnClose);
			this.Controls.Add(this.txbAddress);
			this.Controls.Add(this.btnSave);
			this.Controls.Add(this.liblRemove);
			this.Controls.Add(this.liblSetImage);
			this.Controls.Add(this.dtpDateOfBirth);
			this.Controls.Add(this.rbFemale);
			this.Controls.Add(this.rbMale);
			this.Controls.Add(this.txbEmail);
			this.Controls.Add(this.cbCountries);
			this.Controls.Add(this.txbPhone);
			this.Controls.Add(this.txbNationalNo);
			this.Controls.Add(this._lblLast);
			this.Controls.Add(this.txbLast);
			this.Controls.Add(this._lblThird);
			this.Controls.Add(this.txbThird);
			this.Controls.Add(this._lblSecond);
			this.Controls.Add(this.txbSecond);
			this.Controls.Add(this._lblFirst);
			this.Controls.Add(this.txbFirst);
			this.Controls.Add(this.pbPersonImage);
			this.Controls.Add(this._lblCountry);
			this.Controls.Add(this._lblPhone);
			this.Controls.Add(this._lblDateOfBirth);
			this.Controls.Add(this._lblAddress);
			this.Controls.Add(this._lblEmail);
			this.Controls.Add(this._lblGender);
			this.Controls.Add(this._lblNationalNo);
			this.Controls.Add(this._lblName);
			this.Name = "uc1N_Add_UpdatePersonN";
			this.Size = new System.Drawing.Size(1009, 424);
			((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.pbPersonImage)).EndInit();
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.Button btnClose;
		private System.Windows.Forms.TextBox txbAddress;
		private System.Windows.Forms.ErrorProvider errorProvider1;
		private System.Windows.Forms.Button btnSave;
		private System.Windows.Forms.LinkLabel liblRemove;
		private System.Windows.Forms.LinkLabel liblSetImage;
		private System.Windows.Forms.DateTimePicker dtpDateOfBirth;
		private System.Windows.Forms.RadioButton rbFemale;
		private System.Windows.Forms.RadioButton rbMale;
		private System.Windows.Forms.TextBox txbEmail;
		private System.Windows.Forms.ComboBox cbCountries;
		private System.Windows.Forms.TextBox txbPhone;
		private System.Windows.Forms.TextBox txbNationalNo;
		private System.Windows.Forms.Label _lblLast;
		private System.Windows.Forms.TextBox txbLast;
		private System.Windows.Forms.Label _lblThird;
		private System.Windows.Forms.TextBox txbThird;
		private System.Windows.Forms.Label _lblSecond;
		private System.Windows.Forms.TextBox txbSecond;
		private System.Windows.Forms.Label _lblFirst;
		private System.Windows.Forms.TextBox txbFirst;
		private System.Windows.Forms.PictureBox pbPersonImage;
		private System.Windows.Forms.Label _lblCountry;
		private System.Windows.Forms.Label _lblPhone;
		private System.Windows.Forms.Label _lblDateOfBirth;
		private System.Windows.Forms.Label _lblAddress;
		private System.Windows.Forms.Label _lblEmail;
		private System.Windows.Forms.Label _lblGender;
		private System.Windows.Forms.Label _lblNationalNo;
		private System.Windows.Forms.Label _lblName;
		private System.Windows.Forms.OpenFileDialog openFileDialog1;
	}
}
