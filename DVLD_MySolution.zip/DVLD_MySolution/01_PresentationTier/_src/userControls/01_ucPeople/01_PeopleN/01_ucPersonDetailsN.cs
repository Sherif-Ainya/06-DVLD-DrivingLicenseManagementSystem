﻿using System.IO;
using System.Windows.Forms;
using _02_DVLD_Mine._src.Forms._02_People;
using _02_DVLD_Mine.Properties;
using _03_DataAccessTier.src;
using DVLD_Business;

namespace _02_DVLD_Mine._src.userControls._01_PeopleNewWay
{
	public partial class uc1N_PersonDetailsN : UserControl
	{
		public uc1N_PersonDetailsN()
		{
			InitializeComponent();
		}


		clsBusinessPeople _currentPerson;


		private void _LoadData()
		{
			lblPersonID.Text = _currentPerson.personID.ToString();
			lblName.Text = _currentPerson.FullName;
			lblNationalNo.Text = _currentPerson.nationalNo;
			lblDateOfBirth.Text = _currentPerson.dateOfBirth.ToString();
			lblCountry.Text = clsBusinessCountries.Find(_currentPerson.nationalityCountryID).countryName;
			lblAddress.Text = _currentPerson.address;
			lblPhone.Text = _currentPerson.phone;
			lblEmail.Text = _currentPerson.email;

			if (!string.IsNullOrEmpty(_currentPerson.imagePath) && File.Exists(_currentPerson.imagePath))
			{
				pbPersonImage.Load(_currentPerson.imagePath);
				pbPersonImage.SizeMode = PictureBoxSizeMode.Zoom;
				return;
			}

			if (_currentPerson.gender == 0)
				pbPersonImage.Image = Resources.Male;
			else
				pbPersonImage.Image = Resources.Female;
		}
		public void LoadPersonData(int personID)
		{
			_currentPerson = clsBusinessPeople.Find(personID);

			if (_currentPerson == null)
			{
				return;
			}

			btnEdit.Visible = true;
			_LoadData();
		}
		public void LoadPersonData(string nationalNo)
		{
			_currentPerson = clsBusinessPeople.Find(nationalNo);

			if (_currentPerson == null)
			{
				return;
			}

			btnEdit.Visible = true;
			_LoadData();
		}


		private void btnEditPerson_Click(object sender, System.EventArgs e)
		{
			Form update = new frmAdd_UpdatePersonN(_currentPerson.personID);
			update.ShowDialog();

			_currentPerson = clsBusinessPeople.Find(_currentPerson.personID);

			if (_currentPerson == null)
			{
				return;
			}
			_LoadData();
		}
	}
}
