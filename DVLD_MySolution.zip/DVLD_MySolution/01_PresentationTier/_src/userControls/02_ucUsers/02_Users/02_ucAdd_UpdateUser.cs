﻿using System;
using System.ComponentModel;
using System.Windows.Forms;
using DVLD_Business;

namespace _02_DVLD_Mine._src.userControls.Users
{
	public partial class uc02_Add_UpdateUser : UserControl
	{
		public delegate void DataBackEventHandler(object sender, int userID);
		public event DataBackEventHandler ReturnUserID;

		//public event EventHandler SaveClicked;
		public event EventHandler CloseClicked;
		private enum enMode { enAddNew, enUpdate };
		private enMode _Mode = enMode.enAddNew;
		private clsBusinessUsers _currentUser;
		private string _oldPassword;
		private int _currentUserID, _currentPersonID;


		private void _FillUserInformation()
		{
			txbUserName.Text = _currentUser.userName;
			cbIsActive.Checked = _currentUser.active;
			_oldPassword = _currentUser.password;
			txbPassword.Text = _currentUser.password;
			txbConfim.Text = _currentUser.password;
			lblUserID.Text = _currentUser.userID.ToString();
			lblUserID.Visible = true;
		}
		private void _LoadData()
		{
			if (_Mode == enMode.enAddNew)
			{
				_currentUser = new clsBusinessUsers();
				txbUserName.Focus();
				lblOldPassword.Visible = false;
				txbOldPassword.Visible = false;
				lblUserName.Location = new System.Drawing.Point(22, 98);
				txbUserName.Location = new System.Drawing.Point(173, 98);
				return;
			}

			_currentUser = clsBusinessUsers.Find(_currentUserID);

			if (_currentUser == null)
			{
				return;
			}

			_FillUserInformation();
		}


		public uc02_Add_UpdateUser(int userID, int personID = -1)
		{
			InitializeComponent();
			_currentUserID = userID;
			_currentPersonID = personID;
			if (_currentUserID == -1)
			{
				_Mode = enMode.enAddNew;
			}
			else
			{
				_Mode = enMode.enUpdate;
			}
			_LoadData();
		}


		private bool _CheckAllInfoCompleted()
		{
			if (txbUserName.Text == "")
			{
				txbUserName.Focus();
				return false;
			}
			if (txbPassword.Text == "")
			{
				txbPassword.Focus();
				return false;
			}
			if (txbOldPassword.Visible)
			{
				if (!string.IsNullOrEmpty(txbOldPassword.Text) && txbOldPassword.Text != _oldPassword)
				{
					txbOldPassword.Focus();
					return false;
				}
			}
			if (txbConfim.Text != txbPassword.Text)
			{
				txbConfim.Focus();
				return false;
			}
			return true;
		}
		private void btnSave_Click(object sender, System.EventArgs e)
		{
			if (!_CheckAllInfoCompleted())
			{
				MessageBox.Show("Not All Information Completed!", "Warrning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
				return;
			}

			_currentUser.userName = txbUserName.Text;
			_currentUser.password = txbPassword.Text;
			_currentUser.active = cbIsActive.Checked;
			_currentUser.personID = _currentPersonID;

			if (_currentUser.personID != -1)
				if (_currentUser.Save())
					MessageBox.Show("Data Saved Successfully.");
				else
				{
					MessageBox.Show("Error: Data Is not Saved Successfully.");
					return;
				}
			else
				return;

			_Mode = enMode.enUpdate;
			_currentUserID = _currentUser.userID;

			ReturnUserID?.Invoke(this, _currentUserID);
			//OnSavedClicked(EventArgs.Empty);
			//SaveClicked?.Invoke(this, e);
		}
		private void btnClose_Click(object sender, EventArgs e)
		{
			CloseClicked?.Invoke(this, e);
		}


		private void txbOldPassword_Validating(object sender, CancelEventArgs e)
		{
			if (!string.IsNullOrEmpty(txbOldPassword.Text))
			{
				if (txbOldPassword.Text != _oldPassword)
				{
					e.Cancel = true;
					txbOldPassword.Focus();
					errorProvider1.SetError(txbOldPassword, "Not Currect Password!");
				}
				else
				{
					e.Cancel = false;
					errorProvider1.SetError(txbOldPassword, "");
				}
			}
			else
			{
				e.Cancel = false;
				errorProvider1.SetError(txbOldPassword, "");
			}
		}
		private void txbConfirm_Validating(object sender, CancelEventArgs e)
		{
			if (!string.IsNullOrEmpty(txbConfim.Text) && txbConfim.Text != txbPassword.Text)
			{
				e.Cancel = true;
				txbConfim.Text = "";
				txbConfim.Focus();
				errorProvider1.SetError(txbConfim, "Password Dosen't Match The Confirm Value!");
			}
			else
			{
				e.Cancel = false;
				errorProvider1.SetError(txbConfim, "");
			}
		}

		private void cbIsActive_CheckedChanged(object sender, EventArgs e)
		{
			if (cbIsActive.Checked)
			{
				cbIsActive.Text = "Active";
			}
			else
			{
				cbIsActive.Text = "Not Active";
			}
		}
	}
}
