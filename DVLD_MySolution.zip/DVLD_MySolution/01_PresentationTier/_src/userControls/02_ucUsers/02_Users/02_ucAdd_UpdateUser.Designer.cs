﻿namespace _02_DVLD_Mine._src.userControls.Users
{
	partial class uc02_Add_UpdateUser
	{
		/// <summary> 
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary> 
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Component Designer generated code

		/// <summary> 
		/// Required method for Designer support - do not modify 
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			this.btnClose = new System.Windows.Forms.Button();
			this.btnSave = new System.Windows.Forms.Button();
			this.txbUserName = new System.Windows.Forms.TextBox();
			this.lblUserName = new System.Windows.Forms.Label();
			this.txbPassword = new System.Windows.Forms.TextBox();
			this.lblPassword = new System.Windows.Forms.Label();
			this.txbConfim = new System.Windows.Forms.TextBox();
			this.lblConfirm = new System.Windows.Forms.Label();
			this.lblIsActive = new System.Windows.Forms.Label();
			this.cbIsActive = new System.Windows.Forms.CheckBox();
			this.errorProvider1 = new System.Windows.Forms.ErrorProvider(this.components);
			this.txbOldPassword = new System.Windows.Forms.TextBox();
			this.lblOldPassword = new System.Windows.Forms.Label();
			this.lblUserID = new System.Windows.Forms.Label();
			((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).BeginInit();
			this.SuspendLayout();
			// 
			// btnClose
			// 
			this.btnClose.BackColor = System.Drawing.Color.Pink;
			this.btnClose.FlatAppearance.BorderColor = System.Drawing.Color.Cyan;
			this.btnClose.FlatAppearance.BorderSize = 3;
			this.btnClose.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
			this.btnClose.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
			this.btnClose.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnClose.Font = new System.Drawing.Font("Microsoft YaHei UI", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnClose.ForeColor = System.Drawing.Color.Red;
			this.btnClose.Image = global::_02_DVLD_Mine.Properties.Resources.close1;
			this.btnClose.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btnClose.Location = new System.Drawing.Point(744, 3);
			this.btnClose.Name = "btnClose";
			this.btnClose.Size = new System.Drawing.Size(62, 52);
			this.btnClose.TabIndex = 5;
			this.btnClose.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.btnClose.UseVisualStyleBackColor = false;
			this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
			// 
			// btnSave
			// 
			this.btnSave.BackColor = System.Drawing.Color.Pink;
			this.btnSave.FlatAppearance.BorderColor = System.Drawing.Color.Cyan;
			this.btnSave.FlatAppearance.BorderSize = 3;
			this.btnSave.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
			this.btnSave.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
			this.btnSave.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnSave.Font = new System.Drawing.Font("Microsoft YaHei UI", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnSave.ForeColor = System.Drawing.Color.DarkOrchid;
			this.btnSave.Image = global::_02_DVLD_Mine.Properties.Resources.save_27_16;
			this.btnSave.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btnSave.Location = new System.Drawing.Point(642, 3);
			this.btnSave.Name = "btnSave";
			this.btnSave.Size = new System.Drawing.Size(100, 52);
			this.btnSave.TabIndex = 4;
			this.btnSave.Text = "SAVE";
			this.btnSave.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.btnSave.UseVisualStyleBackColor = false;
			this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
			// 
			// txbUserName
			// 
			this.txbUserName.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.txbUserName.Location = new System.Drawing.Point(174, 72);
			this.txbUserName.Name = "txbUserName";
			this.txbUserName.Size = new System.Drawing.Size(193, 29);
			this.txbUserName.TabIndex = 0;
			this.txbUserName.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			// 
			// lblUserName
			// 
			this.lblUserName.AutoSize = true;
			this.lblUserName.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblUserName.Location = new System.Drawing.Point(22, 72);
			this.lblUserName.Name = "lblUserName";
			this.lblUserName.Size = new System.Drawing.Size(122, 26);
			this.lblUserName.TabIndex = 22;
			this.lblUserName.Text = "User Name :";
			// 
			// txbPassword
			// 
			this.txbPassword.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.txbPassword.Location = new System.Drawing.Point(568, 71);
			this.txbPassword.Name = "txbPassword";
			this.txbPassword.PasswordChar = '*';
			this.txbPassword.Size = new System.Drawing.Size(193, 29);
			this.txbPassword.TabIndex = 2;
			this.txbPassword.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			// 
			// lblPassword
			// 
			this.lblPassword.AutoSize = true;
			this.lblPassword.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblPassword.Location = new System.Drawing.Point(403, 71);
			this.lblPassword.Name = "lblPassword";
			this.lblPassword.Size = new System.Drawing.Size(146, 26);
			this.lblPassword.TabIndex = 24;
			this.lblPassword.Text = "New Password :";
			// 
			// txbConfim
			// 
			this.txbConfim.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.txbConfim.Location = new System.Drawing.Point(567, 122);
			this.txbConfim.Name = "txbConfim";
			this.txbConfim.PasswordChar = '*';
			this.txbConfim.Size = new System.Drawing.Size(193, 29);
			this.txbConfim.TabIndex = 3;
			this.txbConfim.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			this.txbConfim.Validating += new System.ComponentModel.CancelEventHandler(this.txbConfirm_Validating);
			// 
			// lblConfirm
			// 
			this.lblConfirm.AutoSize = true;
			this.lblConfirm.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblConfirm.Location = new System.Drawing.Point(438, 124);
			this.lblConfirm.Name = "lblConfirm";
			this.lblConfirm.Size = new System.Drawing.Size(90, 26);
			this.lblConfirm.TabIndex = 26;
			this.lblConfirm.Text = "Confirm :";
			// 
			// lblIsActive
			// 
			this.lblIsActive.AutoSize = true;
			this.lblIsActive.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblIsActive.ForeColor = System.Drawing.Color.DarkRed;
			this.lblIsActive.Location = new System.Drawing.Point(250, 15);
			this.lblIsActive.Name = "lblIsActive";
			this.lblIsActive.Size = new System.Drawing.Size(98, 26);
			this.lblIsActive.TabIndex = 27;
			this.lblIsActive.Text = "Is Active :";
			// 
			// cbIsActive
			// 
			this.cbIsActive.AutoSize = true;
			this.cbIsActive.Font = new System.Drawing.Font("Modern No. 20", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.cbIsActive.ForeColor = System.Drawing.Color.DarkBlue;
			this.cbIsActive.Location = new System.Drawing.Point(364, 16);
			this.cbIsActive.Name = "cbIsActive";
			this.cbIsActive.Size = new System.Drawing.Size(124, 26);
			this.cbIsActive.TabIndex = 99;
			this.cbIsActive.TabStop = false;
			this.cbIsActive.Text = "Not Active";
			this.cbIsActive.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			this.cbIsActive.UseVisualStyleBackColor = true;
			this.cbIsActive.CheckedChanged += new System.EventHandler(this.cbIsActive_CheckedChanged);
			// 
			// errorProvider1
			// 
			this.errorProvider1.ContainerControl = this;
			// 
			// txbOldPassword
			// 
			this.txbOldPassword.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.txbOldPassword.Location = new System.Drawing.Point(174, 122);
			this.txbOldPassword.Name = "txbOldPassword";
			this.txbOldPassword.PasswordChar = '*';
			this.txbOldPassword.Size = new System.Drawing.Size(193, 29);
			this.txbOldPassword.TabIndex = 1;
			this.txbOldPassword.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			this.txbOldPassword.Validating += new System.ComponentModel.CancelEventHandler(this.txbOldPassword_Validating);
			// 
			// lblOldPassword
			// 
			this.lblOldPassword.AutoSize = true;
			this.lblOldPassword.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblOldPassword.Location = new System.Drawing.Point(22, 122);
			this.lblOldPassword.Name = "lblOldPassword";
			this.lblOldPassword.Size = new System.Drawing.Size(145, 26);
			this.lblOldPassword.TabIndex = 30;
			this.lblOldPassword.Text = "Old Password :";
			// 
			// lblUserID
			// 
			this.lblUserID.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
			this.lblUserID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.lblUserID.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblUserID.ForeColor = System.Drawing.Color.Red;
			this.lblUserID.Location = new System.Drawing.Point(9, 8);
			this.lblUserID.Name = "lblUserID";
			this.lblUserID.Size = new System.Drawing.Size(73, 41);
			this.lblUserID.TabIndex = 100;
			this.lblUserID.Text = "-1";
			this.lblUserID.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			this.lblUserID.Visible = false;
			// 
			// uc02_Add_UpdateUser
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
			this.Controls.Add(this.lblUserID);
			this.Controls.Add(this.txbOldPassword);
			this.Controls.Add(this.lblOldPassword);
			this.Controls.Add(this.cbIsActive);
			this.Controls.Add(this.lblIsActive);
			this.Controls.Add(this.txbConfim);
			this.Controls.Add(this.lblConfirm);
			this.Controls.Add(this.txbPassword);
			this.Controls.Add(this.lblPassword);
			this.Controls.Add(this.txbUserName);
			this.Controls.Add(this.lblUserName);
			this.Controls.Add(this.btnClose);
			this.Controls.Add(this.btnSave);
			this.Name = "uc02_Add_UpdateUser";
			this.Size = new System.Drawing.Size(809, 173);
			((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).EndInit();
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.Button btnClose;
		private System.Windows.Forms.Button btnSave;
		private System.Windows.Forms.TextBox txbUserName;
		private System.Windows.Forms.Label lblUserName;
		private System.Windows.Forms.TextBox txbPassword;
		private System.Windows.Forms.Label lblPassword;
		private System.Windows.Forms.TextBox txbConfim;
		private System.Windows.Forms.Label lblConfirm;
		private System.Windows.Forms.Label lblIsActive;
		private System.Windows.Forms.CheckBox cbIsActive;
		private System.Windows.Forms.ErrorProvider errorProvider1;
		private System.Windows.Forms.TextBox txbOldPassword;
		private System.Windows.Forms.Label lblOldPassword;
		private System.Windows.Forms.Label lblUserID;
	}
}
