﻿using System.Windows.Forms;
using _02_DVLD_Mine._src.Main.Users;
using DVLD_Business;

namespace _02_DVLD_Mine._src.userControls.Users
{
	public partial class uc02_UserShortDetails : UserControl
	{
		int _currentUserID;
		clsBusinessUsers _currentUser;
		private void _LoadData()
		{
			_currentUser = clsBusinessUsers.Find(_currentUserID);
			lblUserID.Text = _currentUser.userID.ToString();
			lblUserName.Text = _currentUser.userName;
			cbIsActive.Checked = _currentUser.active;
		}


		public uc02_UserShortDetails(int UserID)
		{
			InitializeComponent();
			_currentUserID = UserID;
			_LoadData();
		}

		private void btnEditUser_Click(object sender, System.EventArgs e)
		{
			Form update = new frmAdd_UpdateUser(_currentUserID, _currentUser.personID);
			update.ShowDialog();
			_LoadData();
		}
	}
}
