﻿namespace _02_DVLD_Mine._src.userControls.Users
{
	partial class uc02_UserShortDetails
	{
		/// <summary> 
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary> 
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Component Designer generated code

		/// <summary> 
		/// Required method for Designer support - do not modify 
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.lblUserName = new System.Windows.Forms.Label();
			this.lblUserID = new System.Windows.Forms.Label();
			this._lblUserName = new System.Windows.Forms.Label();
			this._lblUserID = new System.Windows.Forms.Label();
			this.gbUserShortDetails = new System.Windows.Forms.GroupBox();
			this.cbIsActive = new System.Windows.Forms.CheckBox();
			this.btnEdit = new System.Windows.Forms.Button();
			this.gbUserShortDetails.SuspendLayout();
			this.SuspendLayout();
			// 
			// lblUserName
			// 
			this.lblUserName.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
			this.lblUserName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.lblUserName.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblUserName.Location = new System.Drawing.Point(271, 37);
			this.lblUserName.Name = "lblUserName";
			this.lblUserName.Size = new System.Drawing.Size(291, 35);
			this.lblUserName.TabIndex = 11;
			this.lblUserName.Text = "????";
			this.lblUserName.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// lblUserID
			// 
			this.lblUserID.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
			this.lblUserID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.lblUserID.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblUserID.ForeColor = System.Drawing.Color.Red;
			this.lblUserID.Location = new System.Drawing.Point(59, 37);
			this.lblUserID.Name = "lblUserID";
			this.lblUserID.Size = new System.Drawing.Size(65, 35);
			this.lblUserID.TabIndex = 10;
			this.lblUserID.Text = "-1";
			this.lblUserID.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// _lblUserName
			// 
			this._lblUserName.AutoSize = true;
			this._lblUserName.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this._lblUserName.Location = new System.Drawing.Point(146, 42);
			this._lblUserName.Name = "_lblUserName";
			this._lblUserName.Size = new System.Drawing.Size(117, 26);
			this._lblUserName.TabIndex = 1;
			this._lblUserName.Text = "User Name :";
			// 
			// _lblUserID
			// 
			this._lblUserID.AutoSize = true;
			this._lblUserID.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this._lblUserID.Location = new System.Drawing.Point(9, 42);
			this._lblUserID.Name = "_lblUserID";
			this._lblUserID.Size = new System.Drawing.Size(44, 26);
			this._lblUserID.TabIndex = 0;
			this._lblUserID.Text = "ID :";
			// 
			// gbUserShortDetails
			// 
			this.gbUserShortDetails.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
			this.gbUserShortDetails.Controls.Add(this.cbIsActive);
			this.gbUserShortDetails.Controls.Add(this.btnEdit);
			this.gbUserShortDetails.Controls.Add(this.lblUserName);
			this.gbUserShortDetails.Controls.Add(this.lblUserID);
			this.gbUserShortDetails.Controls.Add(this._lblUserName);
			this.gbUserShortDetails.Controls.Add(this._lblUserID);
			this.gbUserShortDetails.Dock = System.Windows.Forms.DockStyle.Fill;
			this.gbUserShortDetails.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.gbUserShortDetails.Location = new System.Drawing.Point(0, 0);
			this.gbUserShortDetails.Name = "gbUserShortDetails";
			this.gbUserShortDetails.Size = new System.Drawing.Size(809, 100);
			this.gbUserShortDetails.TabIndex = 1;
			this.gbUserShortDetails.TabStop = false;
			this.gbUserShortDetails.Text = "User Information :";
			// 
			// cbIsActive
			// 
			this.cbIsActive.AutoSize = true;
			this.cbIsActive.Font = new System.Drawing.Font("Modern No. 20", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.cbIsActive.ForeColor = System.Drawing.Color.DarkBlue;
			this.cbIsActive.Location = new System.Drawing.Point(575, 43);
			this.cbIsActive.Name = "cbIsActive";
			this.cbIsActive.Size = new System.Drawing.Size(124, 26);
			this.cbIsActive.TabIndex = 99;
			this.cbIsActive.TabStop = false;
			this.cbIsActive.Text = "Not Active";
			this.cbIsActive.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			this.cbIsActive.UseVisualStyleBackColor = true;
			// 
			// btnEdit
			// 
			this.btnEdit.BackColor = System.Drawing.SystemColors.ScrollBar;
			this.btnEdit.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
			this.btnEdit.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
			this.btnEdit.FlatAppearance.BorderSize = 2;
			this.btnEdit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnEdit.Font = new System.Drawing.Font("Microsoft YaHei UI", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnEdit.ForeColor = System.Drawing.Color.Red;
			this.btnEdit.Image = global::_02_DVLD_Mine.Properties.Resources.highlighter_pen;
			this.btnEdit.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btnEdit.Location = new System.Drawing.Point(712, 34);
			this.btnEdit.Name = "btnEdit";
			this.btnEdit.Size = new System.Drawing.Size(80, 43);
			this.btnEdit.TabIndex = 0;
			this.btnEdit.Text = "Edit";
			this.btnEdit.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.btnEdit.UseVisualStyleBackColor = false;
			this.btnEdit.Click += new System.EventHandler(this.btnEditUser_Click);
			// 
			// uc02_UserShortDetails
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.Controls.Add(this.gbUserShortDetails);
			this.Name = "uc02_UserShortDetails";
			this.Size = new System.Drawing.Size(809, 100);
			this.gbUserShortDetails.ResumeLayout(false);
			this.gbUserShortDetails.PerformLayout();
			this.ResumeLayout(false);

		}

		#endregion

		private System.Windows.Forms.Button btnEdit;
		private System.Windows.Forms.Label lblUserName;
		private System.Windows.Forms.Label lblUserID;
		private System.Windows.Forms.Label _lblUserName;
		private System.Windows.Forms.Label _lblUserID;
		private System.Windows.Forms.GroupBox gbUserShortDetails;
		private System.Windows.Forms.CheckBox cbIsActive;
	}
}
