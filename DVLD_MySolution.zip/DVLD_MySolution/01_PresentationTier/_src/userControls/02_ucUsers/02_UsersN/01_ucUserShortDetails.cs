﻿using System.Windows.Forms;
using _02_DVLD_Mine._src.Forms._03_Users;
using DVLD_Business;

namespace _02_DVLD_Mine._src.userControls._02_UsersN
{
	public partial class uc02N_UserShortDetails : UserControl
	{
		public uc02N_UserShortDetails()
		{
			InitializeComponent();
		}

		int _currentUserID;
		clsBusinessUsers _currentUser;

		private void _Reload()
		{
			_currentUser = clsBusinessUsers.Find(_currentUserID);

			if (_currentUser == null) { btnEdit.Enabled = false; return; }

			lblUserID.Text = _currentUser.userID.ToString();
			lblUserName.Text = _currentUser.userName;
			cbIsActive.Checked = _currentUser.active;
		}
		public void LoadUserShortData(int userID)
		{
			_currentUserID = userID;
			_Reload();
		}

		private void btnEdit_Click(object sender, System.EventArgs e)
		{
			Form update = new frmAdd_UpdateUserN(_currentUserID);
			update.ShowDialog();
			_Reload();
		}
	}
}
