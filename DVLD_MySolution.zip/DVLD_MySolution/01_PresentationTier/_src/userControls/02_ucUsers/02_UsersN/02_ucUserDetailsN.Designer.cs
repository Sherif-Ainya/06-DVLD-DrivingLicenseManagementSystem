﻿namespace _02_DVLD_Mine._src.userControls._02_UsersN
{
	partial class uc02N_ucUserDetailsN
	{
		/// <summary> 
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary> 
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Component Designer generated code

		/// <summary> 
		/// Required method for Designer support - do not modify 
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.userDetails = new _02_DVLD_Mine._src.userControls._02_UsersN.uc02N_UserShortDetails();
			this.personDetails = new _02_DVLD_Mine._src.userControls._01_PeopleNewWay.uc1N_PersonDetailsN();
			this.SuspendLayout();
			// 
			// userDetails
			// 
			this.userDetails.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
			this.userDetails.Dock = System.Windows.Forms.DockStyle.Top;
			this.userDetails.Location = new System.Drawing.Point(0, 0);
			this.userDetails.Name = "userDetails";
			this.userDetails.Size = new System.Drawing.Size(809, 100);
			this.userDetails.TabIndex = 0;
			// 
			// personDetails
			// 
			this.personDetails.Dock = System.Windows.Forms.DockStyle.Bottom;
			this.personDetails.Location = new System.Drawing.Point(0, 110);
			this.personDetails.Name = "personDetails";
			this.personDetails.Size = new System.Drawing.Size(809, 465);
			this.personDetails.TabIndex = 1;
			// 
			// uc02N_ucUserDetailsN
			// 
			this.BackColor = System.Drawing.Color.SlateBlue;
			this.Controls.Add(this.personDetails);
			this.Controls.Add(this.userDetails);
			this.Name = "uc02N_ucUserDetailsN";
			this.Size = new System.Drawing.Size(809, 575);
			this.ResumeLayout(false);

		}

		#endregion

		private uc02N_UserShortDetails userDetails;
		private _01_PeopleNewWay.uc1N_PersonDetailsN personDetails;
	}
}
