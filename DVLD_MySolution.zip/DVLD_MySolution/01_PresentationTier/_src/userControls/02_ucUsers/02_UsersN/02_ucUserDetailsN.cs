﻿using System.Windows.Forms;
using _02_DVLD_Mine._src.Forms._03_Users;
using DVLD_Business;

namespace _02_DVLD_Mine._src.userControls._02_UsersN
{
	public partial class uc02N_ucUserDetailsN : UserControl
	{
		public uc02N_ucUserDetailsN()
		{
			InitializeComponent();
		}

		clsBusinessUsers _currentUser;

		private void _ReloadData()
		{
			personDetails.LoadPersonData(_currentUser.personID);
			userDetails.LoadUserShortData(_currentUser.userID);
		}
		public void LoadUserData(int userID)
		{
			if (userID == -1)
				return;

			_currentUser = clsBusinessUsers.Find(userID);

			if (_currentUser == null)
				return;

			_ReloadData();
		}


		private void btnEditUser_Click(object sender, System.EventArgs e)
		{
			Form update = new frmAdd_UpdateUserN(_currentUser.userID);
			update.ShowDialog();
			_ReloadData();
		}
	}
}
