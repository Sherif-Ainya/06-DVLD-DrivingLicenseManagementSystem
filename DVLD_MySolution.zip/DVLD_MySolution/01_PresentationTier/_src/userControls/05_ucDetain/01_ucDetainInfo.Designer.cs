﻿namespace _02_DVLD_Mine._src.userControls._05_ucDetain
{
	partial class _01_ucDetainInfo
	{
		/// <summary> 
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary> 
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Component Designer generated code

		/// <summary> 
		/// Required method for Designer support - do not modify 
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.gbDetainDetails = new System.Windows.Forms.GroupBox();
			this.lblCreatedBy = new System.Windows.Forms.Label();
			this._lblCreatedBy = new System.Windows.Forms.Label();
			this.lblDetainID = new System.Windows.Forms.Label();
			this._lblDetainID = new System.Windows.Forms.Label();
			this.lblFees = new System.Windows.Forms.Label();
			this.lblDetainDate = new System.Windows.Forms.Label();
			this.lblLicenseID = new System.Windows.Forms.Label();
			this._lblFees = new System.Windows.Forms.Label();
			this._lblDetainDate = new System.Windows.Forms.Label();
			this._lblLicenseID = new System.Windows.Forms.Label();
			this.gbDetainDetails.SuspendLayout();
			this.SuspendLayout();
			// 
			// gbDetainDetails
			// 
			this.gbDetainDetails.BackColor = System.Drawing.Color.PaleTurquoise;
			this.gbDetainDetails.Controls.Add(this.lblCreatedBy);
			this.gbDetainDetails.Controls.Add(this._lblCreatedBy);
			this.gbDetainDetails.Controls.Add(this.lblDetainID);
			this.gbDetainDetails.Controls.Add(this._lblDetainID);
			this.gbDetainDetails.Controls.Add(this.lblFees);
			this.gbDetainDetails.Controls.Add(this.lblDetainDate);
			this.gbDetainDetails.Controls.Add(this.lblLicenseID);
			this.gbDetainDetails.Controls.Add(this._lblFees);
			this.gbDetainDetails.Controls.Add(this._lblDetainDate);
			this.gbDetainDetails.Controls.Add(this._lblLicenseID);
			this.gbDetainDetails.Dock = System.Windows.Forms.DockStyle.Fill;
			this.gbDetainDetails.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.gbDetainDetails.Location = new System.Drawing.Point(0, 0);
			this.gbDetainDetails.Name = "gbDetainDetails";
			this.gbDetainDetails.Size = new System.Drawing.Size(809, 211);
			this.gbDetainDetails.TabIndex = 3;
			this.gbDetainDetails.TabStop = false;
			this.gbDetainDetails.Text = "Detain Information  :";
			// 
			// lblCreatedBy
			// 
			this.lblCreatedBy.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
			this.lblCreatedBy.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.lblCreatedBy.Font = new System.Drawing.Font("Script MT Bold", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblCreatedBy.ForeColor = System.Drawing.Color.Blue;
			this.lblCreatedBy.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.lblCreatedBy.Location = new System.Drawing.Point(640, 156);
			this.lblCreatedBy.Name = "lblCreatedBy";
			this.lblCreatedBy.Size = new System.Drawing.Size(141, 35);
			this.lblCreatedBy.TabIndex = 28;
			this.lblCreatedBy.Text = "????";
			this.lblCreatedBy.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// _lblCreatedBy
			// 
			this._lblCreatedBy.AutoSize = true;
			this._lblCreatedBy.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold);
			this._lblCreatedBy.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this._lblCreatedBy.Location = new System.Drawing.Point(473, 161);
			this._lblCreatedBy.Name = "_lblCreatedBy";
			this._lblCreatedBy.Size = new System.Drawing.Size(133, 25);
			this._lblCreatedBy.TabIndex = 27;
			this._lblCreatedBy.Text = "Created By :";
			// 
			// lblDetainID
			// 
			this.lblDetainID.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
			this.lblDetainID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.lblDetainID.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblDetainID.ForeColor = System.Drawing.Color.Black;
			this.lblDetainID.Location = new System.Drawing.Point(223, 43);
			this.lblDetainID.Name = "lblDetainID";
			this.lblDetainID.Size = new System.Drawing.Size(73, 41);
			this.lblDetainID.TabIndex = 26;
			this.lblDetainID.Text = "???";
			this.lblDetainID.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// _lblDetainID
			// 
			this._lblDetainID.AutoSize = true;
			this._lblDetainID.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this._lblDetainID.Location = new System.Drawing.Point(23, 50);
			this._lblDetainID.Name = "_lblDetainID";
			this._lblDetainID.Size = new System.Drawing.Size(104, 26);
			this._lblDetainID.TabIndex = 25;
			this._lblDetainID.Text = "Detain ID :";
			// 
			// lblFees
			// 
			this.lblFees.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
			this.lblFees.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.lblFees.Font = new System.Drawing.Font("Palatino Linotype", 14F, System.Drawing.FontStyle.Bold);
			this.lblFees.ForeColor = System.Drawing.Color.Red;
			this.lblFees.Location = new System.Drawing.Point(545, 68);
			this.lblFees.Name = "lblFees";
			this.lblFees.Size = new System.Drawing.Size(221, 40);
			this.lblFees.TabIndex = 15;
			this.lblFees.Text = "????";
			this.lblFees.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// lblDetainDate
			// 
			this.lblDetainDate.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
			this.lblDetainDate.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.lblDetainDate.Font = new System.Drawing.Font("Palatino Linotype", 13.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblDetainDate.Location = new System.Drawing.Point(143, 153);
			this.lblDetainDate.Name = "lblDetainDate";
			this.lblDetainDate.Size = new System.Drawing.Size(291, 41);
			this.lblDetainDate.TabIndex = 14;
			this.lblDetainDate.Text = "????";
			this.lblDetainDate.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// lblLicenseID
			// 
			this.lblLicenseID.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
			this.lblLicenseID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.lblLicenseID.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblLicenseID.ForeColor = System.Drawing.Color.Red;
			this.lblLicenseID.Location = new System.Drawing.Point(251, 97);
			this.lblLicenseID.Name = "lblLicenseID";
			this.lblLicenseID.Size = new System.Drawing.Size(73, 41);
			this.lblLicenseID.TabIndex = 10;
			this.lblLicenseID.Text = "???";
			this.lblLicenseID.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// _lblFees
			// 
			this._lblFees.AutoSize = true;
			this._lblFees.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold);
			this._lblFees.Location = new System.Drawing.Point(423, 75);
			this._lblFees.Name = "_lblFees";
			this._lblFees.Size = new System.Drawing.Size(79, 25);
			this._lblFees.TabIndex = 5;
			this._lblFees.Text = "Fees  :";
			// 
			// _lblDetainDate
			// 
			this._lblDetainDate.AutoSize = true;
			this._lblDetainDate.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this._lblDetainDate.Location = new System.Drawing.Point(6, 160);
			this._lblDetainDate.Name = "_lblDetainDate";
			this._lblDetainDate.Size = new System.Drawing.Size(121, 26);
			this._lblDetainDate.TabIndex = 4;
			this._lblDetainDate.Text = "Detain Date :";
			// 
			// _lblLicenseID
			// 
			this._lblLicenseID.AutoSize = true;
			this._lblLicenseID.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this._lblLicenseID.Location = new System.Drawing.Point(35, 104);
			this._lblLicenseID.Name = "_lblLicenseID";
			this._lblLicenseID.Size = new System.Drawing.Size(111, 26);
			this._lblLicenseID.TabIndex = 0;
			this._lblLicenseID.Text = "License ID :";
			// 
			// _01_ucDetainInfo
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.Controls.Add(this.gbDetainDetails);
			this.Name = "_01_ucDetainInfo";
			this.Size = new System.Drawing.Size(809, 211);
			this.gbDetainDetails.ResumeLayout(false);
			this.gbDetainDetails.PerformLayout();
			this.ResumeLayout(false);

		}

		#endregion

		private System.Windows.Forms.GroupBox gbDetainDetails;
		private System.Windows.Forms.Label lblDetainID;
		private System.Windows.Forms.Label _lblDetainID;
		private System.Windows.Forms.Label lblFees;
		private System.Windows.Forms.Label lblDetainDate;
		private System.Windows.Forms.Label lblLicenseID;
		private System.Windows.Forms.Label _lblFees;
		private System.Windows.Forms.Label _lblDetainDate;
		private System.Windows.Forms.Label _lblLicenseID;
		private System.Windows.Forms.Label lblCreatedBy;
		private System.Windows.Forms.Label _lblCreatedBy;
	}
}
