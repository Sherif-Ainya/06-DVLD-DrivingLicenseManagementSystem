﻿using System;
using System.Windows.Forms;
using DVLD_Business;

namespace _02_DVLD_Mine._src.userControls._05_ucDetain
{
	public partial class _02_ucReleaseInfo : UserControl
	{
		public _02_ucReleaseInfo()
		{
			InitializeComponent();
		}


		private clsBusinessDetainedLicenses _detainRecord;
		private decimal appFees = clsBusinessApplicationTypes.Find(5).applicationTypeFees;


		private void _LoadData()
		{
			lblDetainID.Text = _detainRecord.DetainID.ToString();
			lblLicenseID.Text = _detainRecord.LicenseID.ToString();
			lblDetainDate.Text = _detainRecord.DetainDate.ToString();
			lblCreatedBy.Text = clsBusinessUsers.Find(_detainRecord.CreatedByUserID).userName;

			lblApplicationFees.Text = (_detainRecord.ReleaseApplicaitonID == -1) ? "???" : _detainRecord.ReleaseApplicaitonID.ToString();
			lblApplicationFees.Text = appFees.ToString();
			lblFineFees.Text = _detainRecord.FineFees.ToString();
			lblTotalFees.Text = (appFees + _detainRecord.FineFees).ToString();
		}
		public void LoadDetainInfo(int licenseID)
		{
			_detainRecord = clsBusinessDetainedLicenses.FindBy(licenseID);

			if (_detainRecord != null)
			{
				_LoadData();
			}
		}


		private int _CreateReleaseApplication()
		{
			clsBusinessApplications newApp = new clsBusinessApplications();

			newApp.ApplicationPersonID = clsBusinessDrivers.Find(clsBusinessLicenses.FindByLicenseID(_detainRecord.LicenseID).DriverID).PersonID;
			newApp.ApplicationDateTime = DateTime.Now;
			newApp.ApplicationTypeID = 5;  // Release.
			newApp.ApplicationStatus = 3;
			newApp.LastStatusDate = DateTime.Now;
			newApp.PaidFees = appFees;
			newApp.CreatedByUserID = clsGlobal.currentUser.userID;

			newApp.Save();
			return newApp.ApplicationID;
		}
		public void ReleaseLicense()
		{
			_detainRecord.IsReleased = true;
			_detainRecord.ReleaseDate = DateTime.Now;
			_detainRecord.ReleasedByUserID = clsGlobal.currentUser.userID;

			int relatedApp = _CreateReleaseApplication();

			if (relatedApp == -1)
				return;

			_detainRecord.ReleaseApplicaitonID = relatedApp;

			if (_detainRecord.Save())
				MessageBox.Show("Data Saved Successfully.");
			else
			{ MessageBox.Show("Error: Data Is not Saved Successfully."); return; }

			lblApplicationID.Text = _detainRecord.ReleaseApplicaitonID.ToString();
		}
	}
}
