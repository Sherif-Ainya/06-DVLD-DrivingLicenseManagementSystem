﻿namespace _02_DVLD_Mine._src.userControls._05_ucDetain
{
	partial class _02_ucReleaseInfo
	{
		/// <summary> 
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary> 
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Component Designer generated code

		/// <summary> 
		/// Required method for Designer support - do not modify 
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.gbDetainDetails = new System.Windows.Forms.GroupBox();
			this.lblFineFees = new System.Windows.Forms.Label();
			this._lblFineFees = new System.Windows.Forms.Label();
			this.lblApplicationFees = new System.Windows.Forms.Label();
			this._lblApplicationFees = new System.Windows.Forms.Label();
			this.lblApplicationID = new System.Windows.Forms.Label();
			this._lblApplicationID = new System.Windows.Forms.Label();
			this.lblCreatedBy = new System.Windows.Forms.Label();
			this._lblCreatedBy = new System.Windows.Forms.Label();
			this.lblDetainID = new System.Windows.Forms.Label();
			this._lblDetainID = new System.Windows.Forms.Label();
			this.lblTotalFees = new System.Windows.Forms.Label();
			this.lblDetainDate = new System.Windows.Forms.Label();
			this.lblLicenseID = new System.Windows.Forms.Label();
			this._lblTotalFees = new System.Windows.Forms.Label();
			this._lblDetainDate = new System.Windows.Forms.Label();
			this._lblLicenseID = new System.Windows.Forms.Label();
			this.gbDetainDetails.SuspendLayout();
			this.SuspendLayout();
			// 
			// gbDetainDetails
			// 
			this.gbDetainDetails.BackColor = System.Drawing.Color.PaleTurquoise;
			this.gbDetainDetails.Controls.Add(this.lblFineFees);
			this.gbDetainDetails.Controls.Add(this._lblFineFees);
			this.gbDetainDetails.Controls.Add(this.lblApplicationFees);
			this.gbDetainDetails.Controls.Add(this._lblApplicationFees);
			this.gbDetainDetails.Controls.Add(this.lblApplicationID);
			this.gbDetainDetails.Controls.Add(this._lblApplicationID);
			this.gbDetainDetails.Controls.Add(this.lblCreatedBy);
			this.gbDetainDetails.Controls.Add(this._lblCreatedBy);
			this.gbDetainDetails.Controls.Add(this.lblDetainID);
			this.gbDetainDetails.Controls.Add(this._lblDetainID);
			this.gbDetainDetails.Controls.Add(this.lblTotalFees);
			this.gbDetainDetails.Controls.Add(this.lblDetainDate);
			this.gbDetainDetails.Controls.Add(this.lblLicenseID);
			this.gbDetainDetails.Controls.Add(this._lblTotalFees);
			this.gbDetainDetails.Controls.Add(this._lblDetainDate);
			this.gbDetainDetails.Controls.Add(this._lblLicenseID);
			this.gbDetainDetails.Dock = System.Windows.Forms.DockStyle.Fill;
			this.gbDetainDetails.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.gbDetainDetails.Location = new System.Drawing.Point(0, 0);
			this.gbDetainDetails.Name = "gbDetainDetails";
			this.gbDetainDetails.Size = new System.Drawing.Size(809, 281);
			this.gbDetainDetails.TabIndex = 4;
			this.gbDetainDetails.TabStop = false;
			this.gbDetainDetails.Text = "Detain Information  :";
			// 
			// lblFineFees
			// 
			this.lblFineFees.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
			this.lblFineFees.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.lblFineFees.Font = new System.Drawing.Font("Palatino Linotype", 14F, System.Drawing.FontStyle.Bold);
			this.lblFineFees.ForeColor = System.Drawing.Color.Black;
			this.lblFineFees.Location = new System.Drawing.Point(595, 158);
			this.lblFineFees.Name = "lblFineFees";
			this.lblFineFees.Size = new System.Drawing.Size(198, 40);
			this.lblFineFees.TabIndex = 34;
			this.lblFineFees.Text = "????";
			this.lblFineFees.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// _lblFineFees
			// 
			this._lblFineFees.AutoSize = true;
			this._lblFineFees.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this._lblFineFees.Location = new System.Drawing.Point(449, 165);
			this._lblFineFees.Name = "_lblFineFees";
			this._lblFineFees.Size = new System.Drawing.Size(100, 26);
			this._lblFineFees.TabIndex = 33;
			this._lblFineFees.Text = "Fine Fees :";
			// 
			// lblApplicationFees
			// 
			this.lblApplicationFees.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
			this.lblApplicationFees.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.lblApplicationFees.Font = new System.Drawing.Font("Palatino Linotype", 14F, System.Drawing.FontStyle.Bold);
			this.lblApplicationFees.ForeColor = System.Drawing.Color.Black;
			this.lblApplicationFees.Location = new System.Drawing.Point(595, 104);
			this.lblApplicationFees.Name = "lblApplicationFees";
			this.lblApplicationFees.Size = new System.Drawing.Size(198, 40);
			this.lblApplicationFees.TabIndex = 32;
			this.lblApplicationFees.Text = "????";
			this.lblApplicationFees.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// _lblApplicationFees
			// 
			this._lblApplicationFees.AutoSize = true;
			this._lblApplicationFees.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this._lblApplicationFees.Location = new System.Drawing.Point(418, 112);
			this._lblApplicationFees.Name = "_lblApplicationFees";
			this._lblApplicationFees.Size = new System.Drawing.Size(160, 26);
			this._lblApplicationFees.TabIndex = 31;
			this._lblApplicationFees.Text = "Application Fees :";
			// 
			// lblApplicationID
			// 
			this.lblApplicationID.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
			this.lblApplicationID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.lblApplicationID.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblApplicationID.ForeColor = System.Drawing.Color.Red;
			this.lblApplicationID.Location = new System.Drawing.Point(660, 35);
			this.lblApplicationID.Name = "lblApplicationID";
			this.lblApplicationID.Size = new System.Drawing.Size(73, 41);
			this.lblApplicationID.TabIndex = 30;
			this.lblApplicationID.Text = "???";
			this.lblApplicationID.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// _lblApplicationID
			// 
			this._lblApplicationID.AutoSize = true;
			this._lblApplicationID.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this._lblApplicationID.Location = new System.Drawing.Point(433, 42);
			this._lblApplicationID.Name = "_lblApplicationID";
			this._lblApplicationID.Size = new System.Drawing.Size(145, 26);
			this._lblApplicationID.TabIndex = 29;
			this._lblApplicationID.Text = "Application ID :";
			// 
			// lblCreatedBy
			// 
			this.lblCreatedBy.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
			this.lblCreatedBy.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.lblCreatedBy.Font = new System.Drawing.Font("Script MT Bold", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblCreatedBy.ForeColor = System.Drawing.Color.Blue;
			this.lblCreatedBy.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.lblCreatedBy.Location = new System.Drawing.Point(168, 230);
			this.lblCreatedBy.Name = "lblCreatedBy";
			this.lblCreatedBy.Size = new System.Drawing.Size(198, 35);
			this.lblCreatedBy.TabIndex = 28;
			this.lblCreatedBy.Text = "????";
			this.lblCreatedBy.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// _lblCreatedBy
			// 
			this._lblCreatedBy.AutoSize = true;
			this._lblCreatedBy.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold);
			this._lblCreatedBy.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this._lblCreatedBy.Location = new System.Drawing.Point(13, 235);
			this._lblCreatedBy.Name = "_lblCreatedBy";
			this._lblCreatedBy.Size = new System.Drawing.Size(133, 25);
			this._lblCreatedBy.TabIndex = 27;
			this._lblCreatedBy.Text = "Created By :";
			// 
			// lblDetainID
			// 
			this.lblDetainID.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
			this.lblDetainID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.lblDetainID.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblDetainID.ForeColor = System.Drawing.Color.Black;
			this.lblDetainID.Location = new System.Drawing.Point(201, 43);
			this.lblDetainID.Name = "lblDetainID";
			this.lblDetainID.Size = new System.Drawing.Size(73, 41);
			this.lblDetainID.TabIndex = 26;
			this.lblDetainID.Text = "???";
			this.lblDetainID.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// _lblDetainID
			// 
			this._lblDetainID.AutoSize = true;
			this._lblDetainID.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this._lblDetainID.Location = new System.Drawing.Point(23, 50);
			this._lblDetainID.Name = "_lblDetainID";
			this._lblDetainID.Size = new System.Drawing.Size(104, 26);
			this._lblDetainID.TabIndex = 25;
			this._lblDetainID.Text = "Detain ID :";
			// 
			// lblTotalFees
			// 
			this.lblTotalFees.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
			this.lblTotalFees.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.lblTotalFees.Font = new System.Drawing.Font("Palatino Linotype", 14F, System.Drawing.FontStyle.Bold);
			this.lblTotalFees.ForeColor = System.Drawing.Color.Red;
			this.lblTotalFees.Location = new System.Drawing.Point(595, 225);
			this.lblTotalFees.Name = "lblTotalFees";
			this.lblTotalFees.Size = new System.Drawing.Size(198, 40);
			this.lblTotalFees.TabIndex = 15;
			this.lblTotalFees.Text = "????";
			this.lblTotalFees.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// lblDetainDate
			// 
			this.lblDetainDate.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
			this.lblDetainDate.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.lblDetainDate.Font = new System.Drawing.Font("Palatino Linotype", 13.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblDetainDate.Location = new System.Drawing.Point(145, 160);
			this.lblDetainDate.Name = "lblDetainDate";
			this.lblDetainDate.Size = new System.Drawing.Size(235, 41);
			this.lblDetainDate.TabIndex = 14;
			this.lblDetainDate.Text = "????";
			this.lblDetainDate.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// lblLicenseID
			// 
			this.lblLicenseID.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
			this.lblLicenseID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.lblLicenseID.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblLicenseID.ForeColor = System.Drawing.Color.Red;
			this.lblLicenseID.Location = new System.Drawing.Point(223, 97);
			this.lblLicenseID.Name = "lblLicenseID";
			this.lblLicenseID.Size = new System.Drawing.Size(73, 41);
			this.lblLicenseID.TabIndex = 10;
			this.lblLicenseID.Text = "???";
			this.lblLicenseID.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// _lblTotalFees
			// 
			this._lblTotalFees.AutoSize = true;
			this._lblTotalFees.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold);
			this._lblTotalFees.Location = new System.Drawing.Point(433, 232);
			this._lblTotalFees.Name = "_lblTotalFees";
			this._lblTotalFees.Size = new System.Drawing.Size(134, 25);
			this._lblTotalFees.TabIndex = 5;
			this._lblTotalFees.Text = "Total Fees  :";
			// 
			// _lblDetainDate
			// 
			this._lblDetainDate.AutoSize = true;
			this._lblDetainDate.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this._lblDetainDate.Location = new System.Drawing.Point(13, 167);
			this._lblDetainDate.Name = "_lblDetainDate";
			this._lblDetainDate.Size = new System.Drawing.Size(121, 26);
			this._lblDetainDate.TabIndex = 4;
			this._lblDetainDate.Text = "Detain Date :";
			// 
			// _lblLicenseID
			// 
			this._lblLicenseID.AutoSize = true;
			this._lblLicenseID.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this._lblLicenseID.Location = new System.Drawing.Point(35, 104);
			this._lblLicenseID.Name = "_lblLicenseID";
			this._lblLicenseID.Size = new System.Drawing.Size(111, 26);
			this._lblLicenseID.TabIndex = 0;
			this._lblLicenseID.Text = "License ID :";
			// 
			// _02_ucReleaseInfo
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.Controls.Add(this.gbDetainDetails);
			this.Name = "_02_ucReleaseInfo";
			this.Size = new System.Drawing.Size(809, 281);
			this.gbDetainDetails.ResumeLayout(false);
			this.gbDetainDetails.PerformLayout();
			this.ResumeLayout(false);

		}

		#endregion

		private System.Windows.Forms.GroupBox gbDetainDetails;
		private System.Windows.Forms.Label lblCreatedBy;
		private System.Windows.Forms.Label _lblCreatedBy;
		private System.Windows.Forms.Label lblDetainID;
		private System.Windows.Forms.Label _lblDetainID;
		private System.Windows.Forms.Label lblTotalFees;
		private System.Windows.Forms.Label lblDetainDate;
		private System.Windows.Forms.Label lblLicenseID;
		private System.Windows.Forms.Label _lblTotalFees;
		private System.Windows.Forms.Label _lblDetainDate;
		private System.Windows.Forms.Label _lblLicenseID;
		private System.Windows.Forms.Label _lblApplicationFees;
		private System.Windows.Forms.Label lblApplicationID;
		private System.Windows.Forms.Label _lblApplicationID;
		private System.Windows.Forms.Label lblApplicationFees;
		private System.Windows.Forms.Label lblFineFees;
		private System.Windows.Forms.Label _lblFineFees;
	}
}
