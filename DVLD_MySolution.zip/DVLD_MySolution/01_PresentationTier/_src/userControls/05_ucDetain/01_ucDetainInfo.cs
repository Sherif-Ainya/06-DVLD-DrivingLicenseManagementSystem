﻿using System;
using System.Windows.Forms;
using DVLD_Business;

namespace _02_DVLD_Mine._src.userControls._05_ucDetain
{
	public partial class _01_ucDetainInfo : UserControl
	{
		public _01_ucDetainInfo()
		{
			InitializeComponent();
		}


		public void LoadInfoBeforeFound(int licenseID)
		{
			lblLicenseID.Text = licenseID.ToString();
			lblCreatedBy.Text = clsGlobal.currentUser.userName;
			lblDetainDate.Text = DateTime.Now.ToString("d");
		}


		public void LoadAfterDetainLicense(int DetainID)
		{
			clsBusinessDetainedLicenses _detainRecord = clsBusinessDetainedLicenses.FindBy_(DetainID);

			if (_detainRecord != null)
			{
				lblDetainID.Text = _detainRecord.DetainID.ToString();
				lblDetainDate.Text = _detainRecord.DetainDate.ToString();
				lblFees.Text = _detainRecord.FineFees.ToString();
				lblLicenseID.Text = _detainRecord.LicenseID.ToString();
				lblCreatedBy.Text = clsBusinessUsers.Find(_detainRecord.CreatedByUserID).userName;
			}
		}
	}
}
