﻿using DVLD_Business;

namespace _02_DVLD_Mine
{
	public static class clsGlobal
	{
		public static clsBusinessUsers currentUser;
		public static bool isSignOut = false;
	}
}
