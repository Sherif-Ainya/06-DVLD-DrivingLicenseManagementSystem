﻿namespace _02_DVLD_Mine._src.Forms
{
	partial class frmRenewLicenseApp
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.lblRenewTitle = new System.Windows.Forms.Label();
			this.btnClose = new System.Windows.Forms.Button();
			this.btnShowPersonLicenseHistory = new System.Windows.Forms.Button();
			this.liblShowNewLicense = new System.Windows.Forms.LinkLabel();
			this.btnRenewLicense = new System.Windows.Forms.Button();
			this.txbNotes = new System.Windows.Forms.TextBox();
			this.RenewLicenseInfo = new _02_DVLD_Mine._src.userControls._03_ucDLA._05_ucRenewLicAppInfo();
			this.FindLocalLicense = new _02_DVLD_Mine._src.userControls._04_ucLicenses._03_ucFindLDL();
			this.LocalLicenseDetails = new _02_DVLD_Mine._src.userControls._04_ucLicenses._01_ucLicenseDetails();
			this.SuspendLayout();
			// 
			// lblRenewTitle
			// 
			this.lblRenewTitle.AutoSize = true;
			this.lblRenewTitle.Font = new System.Drawing.Font("Palatino Linotype", 33F, System.Drawing.FontStyle.Bold);
			this.lblRenewTitle.ForeColor = System.Drawing.Color.BlueViolet;
			this.lblRenewTitle.Location = new System.Drawing.Point(152, 9);
			this.lblRenewTitle.Name = "lblRenewTitle";
			this.lblRenewTitle.Size = new System.Drawing.Size(578, 60);
			this.lblRenewTitle.TabIndex = 24;
			this.lblRenewTitle.Text = "Renew License Application";
			// 
			// btnClose
			// 
			this.btnClose.BackColor = System.Drawing.SystemColors.ScrollBar;
			this.btnClose.DialogResult = System.Windows.Forms.DialogResult.Cancel;
			this.btnClose.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
			this.btnClose.FlatAppearance.BorderSize = 2;
			this.btnClose.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnClose.Font = new System.Drawing.Font("Microsoft YaHei UI", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnClose.ForeColor = System.Drawing.Color.Red;
			this.btnClose.Image = global::_02_DVLD_Mine.Properties.Resources.close;
			this.btnClose.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btnClose.Location = new System.Drawing.Point(951, 0);
			this.btnClose.Name = "btnClose";
			this.btnClose.Size = new System.Drawing.Size(63, 53);
			this.btnClose.TabIndex = 0;
			this.btnClose.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.btnClose.UseVisualStyleBackColor = false;
			this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
			// 
			// btnShowPersonLicenseHistory
			// 
			this.btnShowPersonLicenseHistory.BackColor = System.Drawing.Color.PaleTurquoise;
			this.btnShowPersonLicenseHistory.FlatAppearance.BorderColor = System.Drawing.Color.DeepSkyBlue;
			this.btnShowPersonLicenseHistory.FlatAppearance.BorderSize = 3;
			this.btnShowPersonLicenseHistory.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnShowPersonLicenseHistory.Font = new System.Drawing.Font("Modern No. 20", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnShowPersonLicenseHistory.Location = new System.Drawing.Point(986, 590);
			this.btnShowPersonLicenseHistory.Name = "btnShowPersonLicenseHistory";
			this.btnShowPersonLicenseHistory.Size = new System.Drawing.Size(257, 40);
			this.btnShowPersonLicenseHistory.TabIndex = 1;
			this.btnShowPersonLicenseHistory.Text = "Show Person Licenses History";
			this.btnShowPersonLicenseHistory.UseVisualStyleBackColor = false;
			this.btnShowPersonLicenseHistory.Visible = false;
			this.btnShowPersonLicenseHistory.Click += new System.EventHandler(this.btnShowPersonLicenseHistory_Click_1);
			// 
			// liblShowNewLicense
			// 
			this.liblShowNewLicense.AutoSize = true;
			this.liblShowNewLicense.Font = new System.Drawing.Font("Microsoft YaHei", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.liblShowNewLicense.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
			this.liblShowNewLicense.Location = new System.Drawing.Point(1389, 597);
			this.liblShowNewLicense.Name = "liblShowNewLicense";
			this.liblShowNewLicense.Size = new System.Drawing.Size(205, 24);
			this.liblShowNewLicense.TabIndex = 3;
			this.liblShowNewLicense.TabStop = true;
			this.liblShowNewLicense.Text = "Show New License Info";
			this.liblShowNewLicense.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			this.liblShowNewLicense.Visible = false;
			this.liblShowNewLicense.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.liblShowNewLicense_LinkClicked);
			// 
			// btnRenewLicense
			// 
			this.btnRenewLicense.BackColor = System.Drawing.Color.Pink;
			this.btnRenewLicense.FlatAppearance.BorderColor = System.Drawing.Color.Fuchsia;
			this.btnRenewLicense.FlatAppearance.BorderSize = 3;
			this.btnRenewLicense.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnRenewLicense.Font = new System.Drawing.Font("Microsoft YaHei UI", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnRenewLicense.ForeColor = System.Drawing.Color.Red;
			this.btnRenewLicense.Image = global::_02_DVLD_Mine.Properties.Resources.save_27_16;
			this.btnRenewLicense.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btnRenewLicense.Location = new System.Drawing.Point(1609, 584);
			this.btnRenewLicense.Name = "btnRenewLicense";
			this.btnRenewLicense.Size = new System.Drawing.Size(102, 53);
			this.btnRenewLicense.TabIndex = 2;
			this.btnRenewLicense.Text = "Renew";
			this.btnRenewLicense.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.btnRenewLicense.UseVisualStyleBackColor = false;
			this.btnRenewLicense.Visible = false;
			this.btnRenewLicense.Click += new System.EventHandler(this.btnRenewLicense_Click);
			// 
			// txbNotes
			// 
			this.txbNotes.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
			this.txbNotes.Font = new System.Drawing.Font("Palatino Linotype", 11F, System.Drawing.FontStyle.Bold);
			this.txbNotes.Location = new System.Drawing.Point(1108, 455);
			this.txbNotes.Multiline = true;
			this.txbNotes.Name = "txbNotes";
			this.txbNotes.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
			this.txbNotes.Size = new System.Drawing.Size(568, 91);
			this.txbNotes.TabIndex = 91;
			this.txbNotes.Text = "...";
			this.txbNotes.Enter += new System.EventHandler(this.txbNotes_FocusEnter);
			// 
			// RenewLicenseInfo
			// 
			this.RenewLicenseInfo.Location = new System.Drawing.Point(934, 137);
			this.RenewLicenseInfo.Name = "RenewLicenseInfo";
			this.RenewLicenseInfo.Size = new System.Drawing.Size(809, 428);
			this.RenewLicenseInfo.TabIndex = 25;
			this.RenewLicenseInfo.Visible = false;
			// 
			// FindLocalLicense
			// 
			this.FindLocalLicense.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
			this.FindLocalLicense.Location = new System.Drawing.Point(91, 143);
			this.FindLocalLicense.Name = "FindLocalLicense";
			this.FindLocalLicense.Size = new System.Drawing.Size(809, 163);
			this.FindLocalLicense.TabIndex = 21;
			this.FindLocalLicense.OnFound_ReturnLDL_ID += new System.Action<int>(this.FindLocalLicense_OnFound_ReturnLDL_ID);
			this.FindLocalLicense.OnFound_ReturnObject += new System.Action<DVLD_Business.clsBusinessLicenses>(this.FindLocalLicense_OnFound_ReturnObject);
			// 
			// LocalLicenseDetails
			// 
			this.LocalLicenseDetails.Location = new System.Drawing.Point(15, 80);
			this.LocalLicenseDetails.Name = "LocalLicenseDetails";
			this.LocalLicenseDetails.Size = new System.Drawing.Size(908, 570);
			this.LocalLicenseDetails.TabIndex = 22;
			this.LocalLicenseDetails.Visible = false;
			// 
			// frmRenewLicenseApp
			// 
			this.AcceptButton = this.btnShowPersonLicenseHistory;
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = System.Drawing.Color.MediumSpringGreen;
			this.CancelButton = this.btnClose;
			this.ClientSize = new System.Drawing.Size(1754, 665);
			this.Controls.Add(this.txbNotes);
			this.Controls.Add(this.btnShowPersonLicenseHistory);
			this.Controls.Add(this.liblShowNewLicense);
			this.Controls.Add(this.btnRenewLicense);
			this.Controls.Add(this.RenewLicenseInfo);
			this.Controls.Add(this.lblRenewTitle);
			this.Controls.Add(this.btnClose);
			this.Controls.Add(this.FindLocalLicense);
			this.Controls.Add(this.LocalLicenseDetails);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
			this.Name = "frmRenewLicenseApp";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "_01_RenewLicenseApp";
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.Label lblRenewTitle;
		private System.Windows.Forms.Button btnClose;
		private userControls._04_ucLicenses._03_ucFindLDL FindLocalLicense;
		private userControls._04_ucLicenses._01_ucLicenseDetails LocalLicenseDetails;
		private userControls._03_ucDLA._05_ucRenewLicAppInfo RenewLicenseInfo;
		private System.Windows.Forms.Button btnShowPersonLicenseHistory;
		private System.Windows.Forms.LinkLabel liblShowNewLicense;
		private System.Windows.Forms.Button btnRenewLicense;
		private System.Windows.Forms.TextBox txbNotes;
	}
}