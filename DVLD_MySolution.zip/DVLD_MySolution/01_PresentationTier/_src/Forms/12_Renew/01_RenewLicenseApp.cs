﻿using System;
using System.Windows.Forms;
using _02_DVLD_Mine._src.Forms._09_Licenses;
using DVLD_Business;

namespace _02_DVLD_Mine._src.Forms
{
	public partial class frmRenewLicenseApp : Form
	{
		public frmRenewLicenseApp()
		{
			InitializeComponent();
			this.Size = new System.Drawing.Size(1013, 395);
			FindLocalLicense.FindFor(userControls._04_ucLicenses._03_ucFindLDL.enFindMode.eRenew);
		}


		private clsBusinessLicenses _oldLicense;
		private clsBusinessLicenses _newLicense = new clsBusinessLicenses();

		private void FindLocalLicense_OnFound_ReturnLDL_ID(int obj)
		{
			LocalLicenseDetails.LoadLicenseDataByLicenseID(obj);
		}
		private void FindLocalLicense_OnFound_ReturnObject(clsBusinessLicenses obj)
		{
			_oldLicense = obj;
			this.Size = new System.Drawing.Size(1754, 665);
			lblRenewTitle.Location = new System.Drawing.Point(564, 9);
			this.Location = new System.Drawing.Point(90, 150);

			btnClose.Location = new System.Drawing.Point(1691, 0);  // 951, 0
			FindLocalLicense.Visible = false;
			LocalLicenseDetails.Visible = true;
			RenewLicenseInfo.Visible = true;
			RenewLicenseInfo.LoadMainInfo(_oldLicense.LicenseID, _oldLicense.LicenseClass);
			btnRenewLicense.Visible = true;

			btnShowPersonLicenseHistory.Visible = true;
		}


		private void _FillInfoAfterLicenseIssued()
		{
			LocalLicenseDetails.LoadLicenseDataByLicenseID(_oldLicense.LicenseID);
			RenewLicenseInfo.LoadLicenseData(_newLicense.LicenseID, _oldLicense.LicenseID);

			btnRenewLicense.Enabled = false;
			liblShowNewLicense.Visible = true;
			txbNotes.Visible = false;
		}
		private int _CreateNew_RenewApp()
		{
			clsBusinessApplications newLicenseApp = new clsBusinessApplications();

			newLicenseApp.ApplicationPersonID = clsBusinessDrivers.Find(_oldLicense.DriverID).PersonID;
			newLicenseApp.ApplicationDateTime = DateTime.Now;
			newLicenseApp.ApplicationTypeID = 2;  // Renew.
			newLicenseApp.ApplicationStatus = 3;
			newLicenseApp.LastStatusDate = DateTime.Now;
			newLicenseApp.PaidFees = clsBusinessApplicationTypes.Find(2).applicationTypeFees;
			newLicenseApp.CreatedByUserID = clsGlobal.currentUser.userID;

			if (newLicenseApp.Save())
				return newLicenseApp.ApplicationID;

			MessageBox.Show("Somthing Went Wrong With Creating New License Application!", "Error!", MessageBoxButtons.OK, MessageBoxIcon.Error);
			return -1;
		}
		private void btnRenewLicense_Click(object sender, System.EventArgs e)
		{
			int Application_ID = _CreateNew_RenewApp();

			if (Application_ID == -1)
				return;

			_newLicense.ApplicationID = Application_ID;
			_newLicense.DriverID = _oldLicense.DriverID;
			_newLicense.LicenseClass = _oldLicense.LicenseClass;
			_newLicense.IssueDate = DateTime.Now;
			_newLicense.ExpirationDate = DateTime.Today.AddYears(clsBusinessLicenseClasses.Find(_newLicense.LicenseClass).DefaultValidittyLength);
			_newLicense.Notes = (txbNotes.Text == "...") ? "" : txbNotes.Text;
			_newLicense.PaidFees = clsBusinessLicenseClasses.Find(_newLicense.LicenseClass).ClassFees;
			_newLicense.IsActive = true;
			_newLicense.IssueReason = 2;  // Renew.
			_newLicense.CreatedByUserID = clsGlobal.currentUser.userID;

			_oldLicense.IsActive = false;

			if (_newLicense.Save())
			{
				if (_oldLicense.Save())
					_FillInfoAfterLicenseIssued();
			}
			else
				MessageBox.Show("Somthing Went Wrong With Creating New License!", "Error!", MessageBoxButtons.OK, MessageBoxIcon.Error);
		}
		private void txbNotes_FocusEnter(object sender, EventArgs e)
		{
			txbNotes.Text = "";
		}


		private void liblShowNewLicense_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
		{
			Form frm = new frmLicenseDetails(_newLicense.LicenseID, frmLicenseDetails.enFindBy.eLicenseID);
			frm.ShowDialog();
		}
		private void btnShowPersonLicenseHistory_Click_1(object sender, EventArgs e)
		{
			Form frm = new frmLicensesHistory(clsBusinessDrivers.Find(_oldLicense.DriverID).PersonID);
			frm.ShowDialog();
		}
		private void btnClose_Click(object sender, System.EventArgs e)
		{
			this.Close();
		}
	}
}
