﻿namespace _02_DVLD_Mine._src.Forms._12_Replacment
{
	partial class frmReplacment
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.btnShowPersonLicenseHistory = new System.Windows.Forms.Button();
			this.liblShowNewLicense = new System.Windows.Forms.LinkLabel();
			this.lblReplacmentTitle = new System.Windows.Forms.Label();
			this.btnReplaceLicense = new System.Windows.Forms.Button();
			this.btnClose = new System.Windows.Forms.Button();
			this.rbLost = new System.Windows.Forms.RadioButton();
			this.rbDamaged = new System.Windows.Forms.RadioButton();
			this.label1 = new System.Windows.Forms.Label();
			this.txbNotes = new System.Windows.Forms.TextBox();
			this.FindLocalLicense = new _02_DVLD_Mine._src.userControls._04_ucLicenses._03_ucFindLDL();
			this.LocalLicenseDetails = new _02_DVLD_Mine._src.userControls._04_ucLicenses._01_ucLicenseDetails();
			this.Replacment = new _02_DVLD_Mine._src.userControls._03_ucDLA._06_ucReplacment();
			this.SuspendLayout();
			// 
			// btnShowPersonLicenseHistory
			// 
			this.btnShowPersonLicenseHistory.BackColor = System.Drawing.Color.PaleTurquoise;
			this.btnShowPersonLicenseHistory.FlatAppearance.BorderColor = System.Drawing.Color.DeepSkyBlue;
			this.btnShowPersonLicenseHistory.FlatAppearance.BorderSize = 3;
			this.btnShowPersonLicenseHistory.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnShowPersonLicenseHistory.Font = new System.Drawing.Font("Modern No. 20", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnShowPersonLicenseHistory.Location = new System.Drawing.Point(980, 569);
			this.btnShowPersonLicenseHistory.Name = "btnShowPersonLicenseHistory";
			this.btnShowPersonLicenseHistory.Size = new System.Drawing.Size(257, 40);
			this.btnShowPersonLicenseHistory.TabIndex = 3;
			this.btnShowPersonLicenseHistory.Text = "Show Person Licenses History";
			this.btnShowPersonLicenseHistory.UseVisualStyleBackColor = false;
			this.btnShowPersonLicenseHistory.Visible = false;
			this.btnShowPersonLicenseHistory.Click += new System.EventHandler(this.btnShowPersonLicenseHistory_Click_1);
			// 
			// liblShowNewLicense
			// 
			this.liblShowNewLicense.AutoSize = true;
			this.liblShowNewLicense.Font = new System.Drawing.Font("Microsoft YaHei", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.liblShowNewLicense.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
			this.liblShowNewLicense.Location = new System.Drawing.Point(1383, 576);
			this.liblShowNewLicense.Name = "liblShowNewLicense";
			this.liblShowNewLicense.Size = new System.Drawing.Size(205, 24);
			this.liblShowNewLicense.TabIndex = 5;
			this.liblShowNewLicense.TabStop = true;
			this.liblShowNewLicense.Text = "Show New License Info";
			this.liblShowNewLicense.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			this.liblShowNewLicense.Visible = false;
			this.liblShowNewLicense.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.liblShowNewLicense_LinkClicked);
			// 
			// lblReplacmentTitle
			// 
			this.lblReplacmentTitle.Font = new System.Drawing.Font("Palatino Linotype", 33F, System.Drawing.FontStyle.Bold);
			this.lblReplacmentTitle.ForeColor = System.Drawing.Color.BlueViolet;
			this.lblReplacmentTitle.Location = new System.Drawing.Point(72, 19);
			this.lblReplacmentTitle.Name = "lblReplacmentTitle";
			this.lblReplacmentTitle.Size = new System.Drawing.Size(842, 60);
			this.lblReplacmentTitle.TabIndex = 95;
			this.lblReplacmentTitle.Text = "Replacement For Lost/Damaged License.";
			this.lblReplacmentTitle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// btnReplaceLicense
			// 
			this.btnReplaceLicense.BackColor = System.Drawing.Color.Pink;
			this.btnReplaceLicense.FlatAppearance.BorderColor = System.Drawing.Color.Fuchsia;
			this.btnReplaceLicense.FlatAppearance.BorderSize = 3;
			this.btnReplaceLicense.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnReplaceLicense.Font = new System.Drawing.Font("Microsoft YaHei UI", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnReplaceLicense.ForeColor = System.Drawing.Color.Red;
			this.btnReplaceLicense.Image = global::_02_DVLD_Mine.Properties.Resources.save_27_16;
			this.btnReplaceLicense.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btnReplaceLicense.Location = new System.Drawing.Point(1603, 563);
			this.btnReplaceLicense.Name = "btnReplaceLicense";
			this.btnReplaceLicense.Size = new System.Drawing.Size(108, 53);
			this.btnReplaceLicense.TabIndex = 4;
			this.btnReplaceLicense.Text = "Replace";
			this.btnReplaceLicense.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.btnReplaceLicense.UseVisualStyleBackColor = false;
			this.btnReplaceLicense.Visible = false;
			this.btnReplaceLicense.Click += new System.EventHandler(this.btnReplaceLicense_Click);
			// 
			// btnClose
			// 
			this.btnClose.BackColor = System.Drawing.SystemColors.ScrollBar;
			this.btnClose.DialogResult = System.Windows.Forms.DialogResult.Cancel;
			this.btnClose.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
			this.btnClose.FlatAppearance.BorderSize = 2;
			this.btnClose.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnClose.Font = new System.Drawing.Font("Microsoft YaHei UI", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnClose.ForeColor = System.Drawing.Color.Red;
			this.btnClose.Image = global::_02_DVLD_Mine.Properties.Resources.close;
			this.btnClose.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btnClose.Location = new System.Drawing.Point(951, 0);
			this.btnClose.Name = "btnClose";
			this.btnClose.Size = new System.Drawing.Size(63, 53);
			this.btnClose.TabIndex = 0;
			this.btnClose.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.btnClose.UseVisualStyleBackColor = false;
			this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
			// 
			// rbLost
			// 
			this.rbLost.AutoSize = true;
			this.rbLost.Font = new System.Drawing.Font("Microsoft Uighur", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.rbLost.Location = new System.Drawing.Point(1310, 125);
			this.rbLost.Name = "rbLost";
			this.rbLost.Size = new System.Drawing.Size(144, 46);
			this.rbLost.TabIndex = 1;
			this.rbLost.Text = "Lost License";
			this.rbLost.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			this.rbLost.UseVisualStyleBackColor = true;
			this.rbLost.CheckedChanged += new System.EventHandler(this.rbLost_CheckedChanged);
			// 
			// rbDamaged
			// 
			this.rbDamaged.AutoSize = true;
			this.rbDamaged.Font = new System.Drawing.Font("Microsoft Uighur", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.rbDamaged.Location = new System.Drawing.Point(1460, 125);
			this.rbDamaged.Name = "rbDamaged";
			this.rbDamaged.Size = new System.Drawing.Size(192, 46);
			this.rbDamaged.TabIndex = 2;
			this.rbDamaged.Text = "Damaged License";
			this.rbDamaged.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			this.rbDamaged.UseVisualStyleBackColor = true;
			this.rbDamaged.CheckedChanged += new System.EventHandler(this.rbDamaged_CheckedChanged);
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Font = new System.Drawing.Font("Palatino Linotype", 23F, System.Drawing.FontStyle.Bold);
			this.label1.ForeColor = System.Drawing.Color.Red;
			this.label1.Location = new System.Drawing.Point(1015, 119);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(257, 43);
			this.label1.TabIndex = 103;
			this.label1.Text = "Replacment For :";
			// 
			// txbNotes
			// 
			this.txbNotes.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
			this.txbNotes.Font = new System.Drawing.Font("Palatino Linotype", 11F, System.Drawing.FontStyle.Bold);
			this.txbNotes.Location = new System.Drawing.Point(1110, 444);
			this.txbNotes.Multiline = true;
			this.txbNotes.Name = "txbNotes";
			this.txbNotes.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
			this.txbNotes.Size = new System.Drawing.Size(568, 91);
			this.txbNotes.TabIndex = 104;
			this.txbNotes.Text = "...";
			this.txbNotes.Enter += new System.EventHandler(this.txbNotes_FocusEnter);
			// 
			// FindLocalLicense
			// 
			this.FindLocalLicense.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
			this.FindLocalLicense.Location = new System.Drawing.Point(90, 145);
			this.FindLocalLicense.Name = "FindLocalLicense";
			this.FindLocalLicense.Size = new System.Drawing.Size(809, 163);
			this.FindLocalLicense.TabIndex = 92;
			this.FindLocalLicense.OnFound_ReturnLDL_ID += new System.Action<int>(this.FindLocalLicense_OnFound_ReturnLDL_ID);
			this.FindLocalLicense.OnFound_ReturnObject += new System.Action<DVLD_Business.clsBusinessLicenses>(this.FindLocalLicense_OnFound_ReturnObject);
			// 
			// LocalLicenseDetails
			// 
			this.LocalLicenseDetails.Location = new System.Drawing.Point(14, 82);
			this.LocalLicenseDetails.Name = "LocalLicenseDetails";
			this.LocalLicenseDetails.Size = new System.Drawing.Size(908, 570);
			this.LocalLicenseDetails.TabIndex = 93;
			this.LocalLicenseDetails.Visible = false;
			// 
			// Replacment
			// 
			this.Replacment.Location = new System.Drawing.Point(932, 193);
			this.Replacment.Name = "Replacment";
			this.Replacment.Size = new System.Drawing.Size(809, 351);
			this.Replacment.TabIndex = 105;
			this.Replacment.Visible = false;
			// 
			// frmReplacment
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = System.Drawing.Color.Thistle;
			this.CancelButton = this.btnClose;
			this.ClientSize = new System.Drawing.Size(1754, 665);
			this.Controls.Add(this.txbNotes);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.rbDamaged);
			this.Controls.Add(this.rbLost);
			this.Controls.Add(this.btnShowPersonLicenseHistory);
			this.Controls.Add(this.liblShowNewLicense);
			this.Controls.Add(this.btnReplaceLicense);
			this.Controls.Add(this.lblReplacmentTitle);
			this.Controls.Add(this.btnClose);
			this.Controls.Add(this.FindLocalLicense);
			this.Controls.Add(this.LocalLicenseDetails);
			this.Controls.Add(this.Replacment);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
			this.Name = "frmReplacment";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "_02_Replacment";
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion
		private System.Windows.Forms.Button btnShowPersonLicenseHistory;
		private System.Windows.Forms.LinkLabel liblShowNewLicense;
		private System.Windows.Forms.Button btnReplaceLicense;
		private System.Windows.Forms.Label lblReplacmentTitle;
		private System.Windows.Forms.Button btnClose;
		private userControls._04_ucLicenses._03_ucFindLDL FindLocalLicense;
		private userControls._04_ucLicenses._01_ucLicenseDetails LocalLicenseDetails;
		private System.Windows.Forms.RadioButton rbLost;
		private System.Windows.Forms.RadioButton rbDamaged;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.TextBox txbNotes;
		private userControls._03_ucDLA._06_ucReplacment Replacment;
	}
}