﻿using System;
using System.Windows.Forms;
using _02_DVLD_Mine._src.Forms._09_Licenses;
using DVLD_Business;

namespace _02_DVLD_Mine._src.Forms._12_Replacment
{
	public partial class frmReplacment : Form
	{
		public enum enReplacmentMode { eLost = 3, eDamaged = 4 };
		private enReplacmentMode _Mode = enReplacmentMode.eLost;

		public frmReplacment()
		{
			InitializeComponent();
			this.Size = new System.Drawing.Size(1013, 395);
			FindLocalLicense.FindFor(userControls._04_ucLicenses._03_ucFindLDL.enFindMode.eReplacment);
		}


		private clsBusinessLicenses _oldLicense;
		private clsBusinessLicenses _newLicense = new clsBusinessLicenses();

		private void FindLocalLicense_OnFound_ReturnLDL_ID(int obj)
		{
			LocalLicenseDetails.LoadLicenseDataByLicenseID(obj);
		}
		private void FindLocalLicense_OnFound_ReturnObject(clsBusinessLicenses obj)
		{
			_oldLicense = obj;
			this.Size = new System.Drawing.Size(1754, 665);
			lblReplacmentTitle.Location = new System.Drawing.Point(457, 19);
			this.Location = new System.Drawing.Point(90, 150);

			btnClose.Location = new System.Drawing.Point(1691, 0);

			FindLocalLicense.Visible = false;
			LocalLicenseDetails.Visible = true;
			Replacment.Visible = true;
			Replacment.LoadMainInfo(_oldLicense.LicenseID, (int)enReplacmentMode.eLost);  // Lost Default.
			btnReplaceLicense.Visible = true;

			btnShowPersonLicenseHistory.Visible = true;
		}


		private void rbLost_CheckedChanged(object sender, EventArgs e)
		{
			if (rbLost.Checked)
			{
				_Mode = enReplacmentMode.eLost;
				lblReplacmentTitle.Text = "Replacment For Lost License.";
				Replacment.LoadMainInfo(_oldLicense.LicenseID, (int)_Mode);
			}
		}
		private void rbDamaged_CheckedChanged(object sender, EventArgs e)
		{
			if (rbDamaged.Checked)
			{
				_Mode = enReplacmentMode.eDamaged;
				lblReplacmentTitle.Text = "Replacment For Damaged License.";
				Replacment.LoadMainInfo(_oldLicense.LicenseID, (int)_Mode);
			}
		}


		private void _FillInfoAfterLicenseIssued()
		{
			LocalLicenseDetails.LoadLicenseDataByLicenseID(_oldLicense.LicenseID);
			Replacment.LoadLicenseData(_newLicense.LicenseID);

			btnReplaceLicense.Enabled = false;
			liblShowNewLicense.Visible = true;
			txbNotes.Visible = false;
		}
		private int _CreateNew_ReplaceApp()
		{
			clsBusinessApplications newLicenseApp = new clsBusinessApplications();

			newLicenseApp.ApplicationPersonID = clsBusinessDrivers.Find(_oldLicense.DriverID).PersonID;
			newLicenseApp.ApplicationDateTime = DateTime.Now;
			newLicenseApp.ApplicationTypeID = (int)_Mode;
			newLicenseApp.ApplicationStatus = 3;
			newLicenseApp.LastStatusDate = DateTime.Now;
			newLicenseApp.PaidFees = clsBusinessApplicationTypes.Find((int)_Mode).applicationTypeFees;
			newLicenseApp.CreatedByUserID = clsGlobal.currentUser.userID;

			if (newLicenseApp.Save())
				return newLicenseApp.ApplicationID;

			MessageBox.Show("Somthing Went Wrong With Creating New License Application!", "Error!", MessageBoxButtons.OK, MessageBoxIcon.Error);
			return -1;
		}
		private void btnReplaceLicense_Click(object sender, System.EventArgs e)
		{
			if (rbLost.Checked == rbDamaged.Checked)
			{
				MessageBox.Show("Replacment Type Was Not Selected, Please Select One...", "Missing Info!", MessageBoxButtons.OK, MessageBoxIcon.Error);
				return;
			}

			int Application_ID = _CreateNew_ReplaceApp();

			if (Application_ID == -1)
				return;

			_newLicense.ApplicationID = Application_ID;
			_newLicense.DriverID = _oldLicense.DriverID;
			_newLicense.LicenseClass = _oldLicense.LicenseClass;
			_newLicense.IssueDate = DateTime.Now;
			_newLicense.ExpirationDate = DateTime.Today.AddYears(clsBusinessLicenseClasses.Find(_newLicense.LicenseClass).DefaultValidittyLength);
			_newLicense.Notes = (txbNotes.Text == "...") ? "" : txbNotes.Text;
			_newLicense.PaidFees = 0;
			_newLicense.IsActive = true;
			_newLicense.IssueReason = (_Mode == enReplacmentMode.eLost) ? (byte)(_Mode + 1) : (byte)(_Mode - 1);
			_newLicense.CreatedByUserID = clsGlobal.currentUser.userID;

			_oldLicense.IsActive = false;

			if (_newLicense.Save())
			{
				if (_oldLicense.Save())
					_FillInfoAfterLicenseIssued();
			}
			else
				MessageBox.Show("Somthing Went Wrong With Creating New License!", "Error!", MessageBoxButtons.OK, MessageBoxIcon.Error);
		}
		private void txbNotes_FocusEnter(object sender, EventArgs e)
		{
			txbNotes.Text = "";
		}


		private void liblShowNewLicense_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
		{
			Form frm = new frmLicenseDetails(_newLicense.LicenseID, frmLicenseDetails.enFindBy.eLicenseID);
			frm.ShowDialog();
		}
		private void btnShowPersonLicenseHistory_Click_1(object sender, EventArgs e)
		{
			Form frm = new frmLicensesHistory(clsBusinessDrivers.Find(_oldLicense.DriverID).PersonID);
			frm.ShowDialog();
		}
		private void btnClose_Click(object sender, System.EventArgs e)
		{
			this.Close();
		}
	}
}
