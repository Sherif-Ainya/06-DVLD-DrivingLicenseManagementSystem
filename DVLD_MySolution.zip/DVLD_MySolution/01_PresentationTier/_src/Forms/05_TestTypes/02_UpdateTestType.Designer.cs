﻿namespace _02_DVLD_Mine._src.Forms._05_TestTypes
{
	partial class frmUpdateTestType
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.txbTestTypeFees = new System.Windows.Forms.TextBox();
			this.lblUpdateTestType = new System.Windows.Forms.Label();
			this.lblTestTypeID = new System.Windows.Forms.Label();
			this.lblAppTypeFees = new System.Windows.Forms.Label();
			this.txbTestTypeTitle = new System.Windows.Forms.TextBox();
			this.lblTestTypeTitle = new System.Windows.Forms.Label();
			this.btnClose = new System.Windows.Forms.Button();
			this.btnSave = new System.Windows.Forms.Button();
			this.txbTestTypeDesc = new System.Windows.Forms.TextBox();
			this.lblTestTypeDescription = new System.Windows.Forms.Label();
			this.SuspendLayout();
			// 
			// txbTestTypeFees
			// 
			this.txbTestTypeFees.Font = new System.Drawing.Font("Microsoft Sans Serif", 17F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.txbTestTypeFees.Location = new System.Drawing.Point(178, 291);
			this.txbTestTypeFees.Name = "txbTestTypeFees";
			this.txbTestTypeFees.Size = new System.Drawing.Size(221, 33);
			this.txbTestTypeFees.TabIndex = 3;
			this.txbTestTypeFees.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			this.txbTestTypeFees.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.mtxbTestTypeFees_KeyPress);
			// 
			// lblUpdateTestType
			// 
			this.lblUpdateTestType.AutoSize = true;
			this.lblUpdateTestType.Font = new System.Drawing.Font("Palatino Linotype", 25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblUpdateTestType.ForeColor = System.Drawing.Color.Navy;
			this.lblUpdateTestType.Location = new System.Drawing.Point(144, 30);
			this.lblUpdateTestType.Name = "lblUpdateTestType";
			this.lblUpdateTestType.Size = new System.Drawing.Size(295, 46);
			this.lblUpdateTestType.TabIndex = 122;
			this.lblUpdateTestType.Text = "Update Test Type";
			// 
			// lblTestTypeID
			// 
			this.lblTestTypeID.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
			this.lblTestTypeID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.lblTestTypeID.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblTestTypeID.ForeColor = System.Drawing.Color.Red;
			this.lblTestTypeID.Location = new System.Drawing.Point(240, 339);
			this.lblTestTypeID.Name = "lblTestTypeID";
			this.lblTestTypeID.Size = new System.Drawing.Size(73, 41);
			this.lblTestTypeID.TabIndex = 121;
			this.lblTestTypeID.Text = "-1";
			this.lblTestTypeID.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// lblAppTypeFees
			// 
			this.lblAppTypeFees.AutoSize = true;
			this.lblAppTypeFees.Font = new System.Drawing.Font("Palatino Linotype", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblAppTypeFees.Location = new System.Drawing.Point(49, 295);
			this.lblAppTypeFees.Name = "lblAppTypeFees";
			this.lblAppTypeFees.Size = new System.Drawing.Size(75, 29);
			this.lblAppTypeFees.TabIndex = 120;
			this.lblAppTypeFees.Text = "Fees  :";
			// 
			// txbTestTypeTitle
			// 
			this.txbTestTypeTitle.Enabled = false;
			this.txbTestTypeTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.txbTestTypeTitle.Location = new System.Drawing.Point(178, 126);
			this.txbTestTypeTitle.Name = "txbTestTypeTitle";
			this.txbTestTypeTitle.Size = new System.Drawing.Size(372, 27);
			this.txbTestTypeTitle.TabIndex = 1;
			this.txbTestTypeTitle.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			// 
			// lblTestTypeTitle
			// 
			this.lblTestTypeTitle.AutoSize = true;
			this.lblTestTypeTitle.Font = new System.Drawing.Font("Palatino Linotype", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblTestTypeTitle.Location = new System.Drawing.Point(47, 123);
			this.lblTestTypeTitle.Name = "lblTestTypeTitle";
			this.lblTestTypeTitle.Size = new System.Drawing.Size(78, 29);
			this.lblTestTypeTitle.TabIndex = 119;
			this.lblTestTypeTitle.Text = "Title  :";
			// 
			// btnClose
			// 
			this.btnClose.BackColor = System.Drawing.Color.Pink;
			this.btnClose.FlatAppearance.BorderColor = System.Drawing.Color.Cyan;
			this.btnClose.FlatAppearance.BorderSize = 3;
			this.btnClose.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
			this.btnClose.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
			this.btnClose.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnClose.Font = new System.Drawing.Font("Microsoft YaHei UI", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnClose.ForeColor = System.Drawing.Color.Red;
			this.btnClose.Image = global::_02_DVLD_Mine.Properties.Resources.close1;
			this.btnClose.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btnClose.Location = new System.Drawing.Point(519, 317);
			this.btnClose.Name = "btnClose";
			this.btnClose.Size = new System.Drawing.Size(62, 52);
			this.btnClose.TabIndex = 0;
			this.btnClose.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.btnClose.UseVisualStyleBackColor = false;
			this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
			// 
			// btnSave
			// 
			this.btnSave.BackColor = System.Drawing.Color.Pink;
			this.btnSave.FlatAppearance.BorderColor = System.Drawing.Color.Cyan;
			this.btnSave.FlatAppearance.BorderSize = 3;
			this.btnSave.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
			this.btnSave.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
			this.btnSave.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnSave.Font = new System.Drawing.Font("Microsoft YaHei UI", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnSave.ForeColor = System.Drawing.Color.DarkOrchid;
			this.btnSave.Image = global::_02_DVLD_Mine.Properties.Resources.save_27_16;
			this.btnSave.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btnSave.Location = new System.Drawing.Point(417, 317);
			this.btnSave.Name = "btnSave";
			this.btnSave.Size = new System.Drawing.Size(100, 52);
			this.btnSave.TabIndex = 4;
			this.btnSave.Text = "SAVE";
			this.btnSave.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.btnSave.UseVisualStyleBackColor = false;
			this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
			// 
			// txbTestTypeDesc
			// 
			this.txbTestTypeDesc.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.txbTestTypeDesc.Location = new System.Drawing.Point(178, 173);
			this.txbTestTypeDesc.Multiline = true;
			this.txbTestTypeDesc.Name = "txbTestTypeDesc";
			this.txbTestTypeDesc.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
			this.txbTestTypeDesc.Size = new System.Drawing.Size(372, 98);
			this.txbTestTypeDesc.TabIndex = 2;
			this.txbTestTypeDesc.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			// 
			// lblTestTypeDescription
			// 
			this.lblTestTypeDescription.AutoSize = true;
			this.lblTestTypeDescription.Font = new System.Drawing.Font("Palatino Linotype", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblTestTypeDescription.Location = new System.Drawing.Point(12, 207);
			this.lblTestTypeDescription.Name = "lblTestTypeDescription";
			this.lblTestTypeDescription.Size = new System.Drawing.Size(149, 29);
			this.lblTestTypeDescription.TabIndex = 124;
			this.lblTestTypeDescription.Text = "Description  :";
			// 
			// frmUpdateTestType
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = System.Drawing.Color.HotPink;
			this.CancelButton = this.btnClose;
			this.ClientSize = new System.Drawing.Size(593, 391);
			this.Controls.Add(this.txbTestTypeDesc);
			this.Controls.Add(this.lblTestTypeDescription);
			this.Controls.Add(this.txbTestTypeFees);
			this.Controls.Add(this.lblUpdateTestType);
			this.Controls.Add(this.lblTestTypeID);
			this.Controls.Add(this.lblAppTypeFees);
			this.Controls.Add(this.txbTestTypeTitle);
			this.Controls.Add(this.lblTestTypeTitle);
			this.Controls.Add(this.btnClose);
			this.Controls.Add(this.btnSave);
			this.Name = "frmUpdateTestType";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Update Test Type";
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.TextBox txbTestTypeFees;
		private System.Windows.Forms.Label lblUpdateTestType;
		private System.Windows.Forms.Label lblTestTypeID;
		private System.Windows.Forms.Label lblAppTypeFees;
		private System.Windows.Forms.TextBox txbTestTypeTitle;
		private System.Windows.Forms.Label lblTestTypeTitle;
		private System.Windows.Forms.Button btnClose;
		private System.Windows.Forms.Button btnSave;
		private System.Windows.Forms.TextBox txbTestTypeDesc;
		private System.Windows.Forms.Label lblTestTypeDescription;
	}
}