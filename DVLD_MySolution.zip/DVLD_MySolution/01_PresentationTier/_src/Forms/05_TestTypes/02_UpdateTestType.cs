﻿using System;
using System.Windows.Forms;
using DVLD_Business;

namespace _02_DVLD_Mine._src.Forms._05_TestTypes
{
	public partial class frmUpdateTestType : Form
	{
		private int _TestTypeID;
		private clsBusinessTestTypes _currentType;
		private void _LoadData()
		{
			_currentType = clsBusinessTestTypes.Find(_TestTypeID);

			if (_currentType == null)
			{
				return;
			}

			lblTestTypeID.Text = _currentType.TestTypeID.ToString();
			txbTestTypeTitle.Text = _currentType.TestTypeTitle;
			txbTestTypeDesc.Text = _currentType.TestTypeDescription;
			txbTestTypeFees.Text = _currentType.TestTypeFees.ToString();
		}


		public frmUpdateTestType(int testID)
		{
			InitializeComponent();
			_TestTypeID = testID;
			_LoadData();
		}


		private void mtxbTestTypeFees_KeyPress(object sender, KeyPressEventArgs e)
		{
			if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && e.KeyChar != ',' && e.KeyChar != '.')
			{
				e.Handled = true;
			}

			if ((e.KeyChar == ',' || e.KeyChar == '.') && (sender as TextBox).Text.IndexOfAny(new char[] { ',', '.' }) > -1)
			{
				e.Handled = true;
			}
		}
		private bool _CheckAllInfoCompleted()
		{
			//if (txbTestTypeTitle.Text == "")
			//{
			//	txbTestTypeTitle.Focus();
			//	return false;
			//}
			if (txbTestTypeDesc.Text == "")
			{
				txbTestTypeDesc.Focus();
				return false;
			}
			if (txbTestTypeFees.Text == "")
			{
				txbTestTypeFees.Focus();
				return false;
			}
			return true;
		}
		private void btnSave_Click(object sender, System.EventArgs e)
		{
			if (!_CheckAllInfoCompleted())
			{
				MessageBox.Show("Not All Information Completed!", "Warrning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
				return;
			}

			//_currentType.TestTypeTitle = txbTestTypeTitle.Text;
			_currentType.TestTypeDescription = txbTestTypeDesc.Text;
			_currentType.TestTypeFees = Convert.ToDecimal(txbTestTypeFees.Text);

			if (_currentType.Save())
				MessageBox.Show("Data Saved Successfully.");
			else
				MessageBox.Show("Error: Data Is not Saved Successfully.");

			btnSave.Enabled = false;
		}
		private void btnClose_Click(object sender, System.EventArgs e)
		{
			this.Close();
		}
	}
}
