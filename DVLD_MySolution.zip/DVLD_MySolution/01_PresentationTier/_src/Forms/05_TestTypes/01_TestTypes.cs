﻿using System;
using System.Windows.Forms;
using DVLD_Business;

namespace _02_DVLD_Mine._src.Forms._05_TestTypes
{
	public partial class frmTestTypes : Form
	{
		private void dgvTestTypes_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
		{
			// Header Height.
			dgvTestTypes.ColumnHeadersHeight = 60;

			// Rows Height, Or [Properties > RowTemplate.Height], Or AutoSizeRowsMode.
			dgvTestTypes.RowTemplate.Height = 37;

			// Cell Width Firsth Put DataGridView AutoSizeColumnsMode = Fill. Then Make Changes To Some Of The Columns Like This.
			dgvTestTypes.Columns[0].Width = 100;
			dgvTestTypes.Columns[1].Width = 180;
			dgvTestTypes.Columns[3].Width = 142;

			dgvTestTypes.Columns[0].HeaderText = "ID";
			dgvTestTypes.Columns[1].HeaderText = "Test Title";
			dgvTestTypes.Columns[2].HeaderText = "Test Description";
			dgvTestTypes.Columns[3].HeaderText = "Fees";
		}
		private void _RefreshTestTypes()
		{
			dgvTestTypes.SuspendLayout();
			dgvTestTypes.DataSource = clsBusinessTestTypes.GetAllTestTypes();
			dgvTestTypes.ResumeLayout();
			lblTotalTestTypes.Text = "Total Test Types [" + dgvTestTypes.RowCount.ToString() + "].";
		}


		public frmTestTypes()
		{
			InitializeComponent();
			_RefreshTestTypes();
		}


		private void tsmiEdit_Click(object sender, EventArgs e)
		{
			int testID = (int)dgvTestTypes.CurrentRow.Cells[0].Value;
			Form update = new frmUpdateTestType(testID);
			update.ShowDialog();
			_RefreshTestTypes();
		}
		private void btnClose_Click(object sender, EventArgs e)
		{
			this.Close();
		}
	}
}
