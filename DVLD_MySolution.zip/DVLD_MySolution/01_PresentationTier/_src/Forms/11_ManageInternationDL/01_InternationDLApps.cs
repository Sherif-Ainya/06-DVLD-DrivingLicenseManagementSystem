﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Windows.Forms;
using _02_DVLD_Mine._src.Forms._02_People;
using _02_DVLD_Mine._src.Forms._09_Licenses;
using DVLD_Business;

namespace _02_DVLD_Mine._src.Forms._10_ManageInternationDL
{
	public partial class frmInternationDLApps : Form
	{
		public frmInternationDLApps()
		{
			InitializeComponent();
			_PrepareThisForm();
		}

		private void dgvInternationlDL_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
		{
			dgvInternationlDL.ColumnHeadersHeight = 60;
			dgvInternationlDL.RowTemplate.Height = 30;

			dgvInternationlDL.Columns[1].Width = 120;
			dgvInternationlDL.Columns[2].Width = 120;
			dgvInternationlDL.Columns[6].Width = 120;

			dgvInternationlDL.Columns[0].HeaderText = "International ID";
			dgvInternationlDL.Columns[1].HeaderText = "App ID";
			dgvInternationlDL.Columns[2].HeaderText = "Driver ID";
			dgvInternationlDL.Columns[3].HeaderText = "Issued Using Local ID";
			dgvInternationlDL.Columns[4].HeaderText = "Issued Date";
			dgvInternationlDL.Columns[5].HeaderText = "Expiration Date";
			dgvInternationlDL.Columns[6].HeaderText = "Is Active?";
			dgvInternationlDL.Columns[7].Visible = false;
		}
		private void _RefreshIntLicenses()
		{
			mtxbFilter.Text = "";
			mtxbFilter.Visible = false;

			dgvInternationlDL.SuspendLayout();
			dgvInternationlDL.DataSource = clsBusinessInternationDL.GetAll_InDL();
			dgvInternationlDL.ResumeLayout();
			lblTotalInternationDL.Text = "Total International DL [" + dgvInternationlDL.RowCount.ToString() + "].";
		}
		private void _PrepareThisForm()
		{
			_RefreshIntLicenses();
			cbFilterBy.Items.AddRange(new string[] { "None", "int DL ID", "App ID", "Driver ID", "Local DL ID", "Status" });
		}


		Dictionary<string, string> columnMapping = new Dictionary<string, string>()
		{
			{"int DL ID", "InternationalLicenseID" },
			{"App ID", "ApplicationID" },
			{"Driver ID", "DriverID" },
			{"Local DL ID", "IssuedUsingLocalLicenseID" }
		};
		private void FilterData()
		{
			if (dgvInternationlDL.DataSource is DataTable dt)
			{
				string searchValue = mtxbFilter.Text.Replace("-", "").Trim();

				string displayName = cbFilterBy.SelectedItem.ToString();
				string actualColumnName = columnMapping[displayName];

				if (!string.IsNullOrEmpty(searchValue))
				{
					string filterExpression = $"{actualColumnName} = {searchValue}";
					dt.DefaultView.RowFilter = filterExpression;

				}
				else
				{
					dt.DefaultView.RowFilter = "";
				}
			}
		}
		private void cbFilterBy_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			mtxbFilter.Visible = false;
			cbStatus.Visible = false;

			if (cbFilterBy.SelectedItem.ToString() == "None")
			{
				if (dgvInternationlDL.DataSource is DataTable dt)
				{
					dt.DefaultView.RowFilter = "";
					lblTotalInternationDL.Text = "Total International DL [" + dgvInternationlDL.RowCount.ToString() + "].";
				}
				return;
			}

			if (cbFilterBy.SelectedItem.ToString() == "Status")
			{
				cbStatus.Visible = true;
				return;
			}

			if (cbFilterBy.SelectedItem.ToString().Contains("ID"))
			{
				mtxbFilter.Mask = "000000";
			}
			else
			{
				mtxbFilter.Mask = "";
			}
			mtxbFilter.Visible = true;
			mtxbFilter.Text = string.Empty;
			mtxbFilter.Focus();
		}
		//
		private void mtxbFilter_TextChanged(object sender, System.EventArgs e)
		{
			FilterData();
			lblTotalInternationDL.Text = "# Records [" + dgvInternationlDL.RowCount.ToString() + "].";
		}
		private void cbStatus_DropDownClosed(object sender, EventArgs e)
		{
			if (dgvInternationlDL.DataSource is DataTable dt)
			{
				string filterExpression = $"IsActive = {1 - cbStatus.SelectedIndex}";
				dt.DefaultView.RowFilter = filterExpression;
				lblTotalInternationDL.Text = "# Records [" + dgvInternationlDL.RowCount.ToString() + "].";
			}
		}



		private void tsmiShowDetails_Click(object sender, EventArgs e)
		{
			Form frm = new frmPersonDetailsN(clsBusinessDrivers.Find((int)dgvInternationlDL.CurrentRow.Cells[2].Value).PersonID);
			frm.ShowDialog();
			_RefreshIntLicenses();
		}
		private void tsmiShowLicense_Click(object sender, EventArgs e)
		{
			Form frm = new frmInternationalDetails((int)dgvInternationlDL.CurrentRow.Cells[0].Value);
			frm.ShowDialog();
			_RefreshIntLicenses();
		}
		private void tsmiPersonDL_History_Click(object sender, EventArgs e)
		{
			Form frm = new frmLicensesHistory(clsBusinessDrivers.Find((int)dgvInternationlDL.CurrentRow.Cells[2].Value).PersonID);
			frm.ShowDialog();
			_RefreshIntLicenses();
		}


		private void btnAddNew_Click(object sender, System.EventArgs e)
		{
			Form frm = new frmAddNewIntDL();
			frm.ShowDialog();
			_RefreshIntLicenses();
		}


		private void btnClose_Click(object sender, System.EventArgs e)
		{
			this.Close();
		}

	}
}
