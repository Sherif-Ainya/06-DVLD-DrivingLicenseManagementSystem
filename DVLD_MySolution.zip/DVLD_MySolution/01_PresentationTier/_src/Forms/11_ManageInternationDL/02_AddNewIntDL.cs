﻿using System;
using System.Windows.Forms;
using _02_DVLD_Mine._src.Forms._09_Licenses;
using DVLD_Business;

namespace _02_DVLD_Mine._src.Forms._10_ManageInternationDL
{
	public partial class frmAddNewIntDL : Form
	{
		public frmAddNewIntDL()
		{
			InitializeComponent();
			this.Size = new System.Drawing.Size(1013, 395);
		}


		private clsBusinessLicenses _LocalLicense;
		private clsBusinessInternationDL _InternationDL = new clsBusinessInternationDL();


		private void FindLocalLicense_OnFound_ReturnLDL_ID(int obj)
		{
			LocalLicenseDetails.LoadLicenseDataByLicenseID(obj);
		}
		private void FindLocalLicense_OnFound_ReturnObject(clsBusinessLicenses obj)
		{
			_LocalLicense = obj;

			this.Size = new System.Drawing.Size(1013, 1000);
			if (this.WindowState == FormWindowState.Normal)
			{
				//Rectangle workingArea = Screen.PrimaryScreen.WorkingArea;
				this.Top = 30;
			}

			FindLocalLicense.Visible = false;
			LocalLicenseDetails.Visible = true;
			InternationalApplicationInfo.Visible = true;
			InternationalApplicationInfo.LoadMainInfo();
			btnIssueLicense.Visible = true;

			btnShowPersonLicenseHistory.Enabled = true;
		}


		private void _FillInfoAfterLicenseIssued()
		{
			InternationalApplicationInfo.LoadAppBasicData(_InternationDL.InternationalLicenseID);

			btnIssueLicense.Enabled = false;
			liblShowIntDL.Visible = true;
		}
		private int _CreatedNewInternationApp()
		{
			clsBusinessApplications newIntApp = new clsBusinessApplications();

			newIntApp.ApplicationPersonID = clsBusinessDrivers.Find(_LocalLicense.DriverID).PersonID;
			newIntApp.ApplicationDateTime = DateTime.Now;
			newIntApp.ApplicationTypeID = 6;  // International Application.
			newIntApp.ApplicationStatus = 3;
			newIntApp.LastStatusDate = DateTime.Now;
			newIntApp.PaidFees = clsBusinessLicenseClasses.Find(6).ClassFees;
			newIntApp.CreatedByUserID = clsGlobal.currentUser.userID;

			if (newIntApp.Save())
				return newIntApp.ApplicationID;

			MessageBox.Show("Somthing Went Wrong With Creating New International Application!", "Error!", MessageBoxButtons.OK, MessageBoxIcon.Error);
			return -1;
		}
		private void btnIssueLicense_Click(object sender, System.EventArgs e)
		{
			int Application_ID = _CreatedNewInternationApp();

			if (Application_ID == -1)
				return;

			_InternationDL.ApplicationID = Application_ID;
			_InternationDL.DriverID = _LocalLicense.DriverID;
			_InternationDL.IssuedUsingLocalLicenseID = _LocalLicense.LicenseID;
			_InternationDL.IssueDate = DateTime.Now;
			_InternationDL.ExpirationDate = DateTime.Today.AddYears(1);
			_InternationDL.IsActive = true;
			_InternationDL.CreatedByUserID = clsGlobal.currentUser.userID;

			if (_InternationDL.Save())
				_FillInfoAfterLicenseIssued();
			else
				MessageBox.Show("Somthing Went Wrong With Creating New International!", "Error!", MessageBoxButtons.OK, MessageBoxIcon.Error);
		}




		private void btnShowPersonLicenseHistory_Click(object sender, EventArgs e)
		{
			Form frm = new frmLicensesHistory(clsBusinessDrivers.Find(_LocalLicense.DriverID).PersonID);
			frm.ShowDialog();
		}
		private void liblShowIntDL_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
		{
			Form frm = new frmInternationalDetails(_InternationDL.InternationalLicenseID);
			frm.ShowDialog();
		}
		private void btnClose_Click(object sender, System.EventArgs e)
		{
			this.Close();
		}
	}
}
