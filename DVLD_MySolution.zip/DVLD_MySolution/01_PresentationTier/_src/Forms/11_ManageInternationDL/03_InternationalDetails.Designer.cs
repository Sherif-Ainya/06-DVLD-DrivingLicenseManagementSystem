﻿namespace _02_DVLD_Mine._src.Forms._10_ManageInternationDL
{
	partial class frmInternationalDetails
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.lblPersonDetails = new System.Windows.Forms.Label();
			this.btnClose = new System.Windows.Forms.Button();
			this._04_ucInternationalDetails1 = new _02_DVLD_Mine._src.userControls._04_ucLicenses._04_ucInternationalDetails();
			this.SuspendLayout();
			// 
			// lblPersonDetails
			// 
			this.lblPersonDetails.AutoSize = true;
			this.lblPersonDetails.Font = new System.Drawing.Font("Palatino Linotype", 36F, System.Drawing.FontStyle.Bold);
			this.lblPersonDetails.ForeColor = System.Drawing.Color.BlueViolet;
			this.lblPersonDetails.Location = new System.Drawing.Point(128, 30);
			this.lblPersonDetails.Name = "lblPersonDetails";
			this.lblPersonDetails.Size = new System.Drawing.Size(661, 65);
			this.lblPersonDetails.TabIndex = 16;
			this.lblPersonDetails.Text = "International License Details";
			// 
			// btnClose
			// 
			this.btnClose.BackColor = System.Drawing.SystemColors.ScrollBar;
			this.btnClose.DialogResult = System.Windows.Forms.DialogResult.Cancel;
			this.btnClose.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
			this.btnClose.FlatAppearance.BorderSize = 2;
			this.btnClose.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnClose.Font = new System.Drawing.Font("Microsoft YaHei UI", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnClose.ForeColor = System.Drawing.Color.Red;
			this.btnClose.Image = global::_02_DVLD_Mine.Properties.Resources.close;
			this.btnClose.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btnClose.Location = new System.Drawing.Point(860, 0);
			this.btnClose.Name = "btnClose";
			this.btnClose.Size = new System.Drawing.Size(60, 53);
			this.btnClose.TabIndex = 15;
			this.btnClose.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.btnClose.UseVisualStyleBackColor = false;
			this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
			// 
			// _04_ucInternationalDetails1
			// 
			this._04_ucInternationalDetails1.Location = new System.Drawing.Point(46, 121);
			this._04_ucInternationalDetails1.Name = "_04_ucInternationalDetails1";
			this._04_ucInternationalDetails1.Size = new System.Drawing.Size(847, 462);
			this._04_ucInternationalDetails1.TabIndex = 17;
			// 
			// frmInternationalDetails
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = System.Drawing.SystemColors.ActiveCaption;
			this.CancelButton = this.btnClose;
			this.ClientSize = new System.Drawing.Size(921, 611);
			this.Controls.Add(this._04_ucInternationalDetails1);
			this.Controls.Add(this.lblPersonDetails);
			this.Controls.Add(this.btnClose);
			this.Name = "frmInternationalDetails";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "International License Details";
			this.Load += new System.EventHandler(this.frmInternationalDetails_Load);
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.Label lblPersonDetails;
		private System.Windows.Forms.Button btnClose;
		private userControls._04_ucLicenses._04_ucInternationalDetails _04_ucInternationalDetails1;
	}
}