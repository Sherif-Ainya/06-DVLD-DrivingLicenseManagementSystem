﻿namespace _02_DVLD_Mine._src.Forms._10_ManageInternationDL
{
	partial class frmAddNewIntDL
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.btnIssueLicense = new System.Windows.Forms.Button();
			this.btnClose = new System.Windows.Forms.Button();
			this.lblPersonDetails = new System.Windows.Forms.Label();
			this.liblShowIntDL = new System.Windows.Forms.LinkLabel();
			this.btnShowPersonLicenseHistory = new System.Windows.Forms.Button();
			this.InternationalApplicationInfo = new _02_DVLD_Mine._src.userControls._03_ucDLA.ucInternationalAppInfo();
			this.FindLocalLicense = new _02_DVLD_Mine._src.userControls._04_ucLicenses._03_ucFindLDL();
			this.LocalLicenseDetails = new _02_DVLD_Mine._src.userControls._04_ucLicenses._01_ucLicenseDetails();
			this.SuspendLayout();
			// 
			// btnIssueLicense
			// 
			this.btnIssueLicense.BackColor = System.Drawing.Color.Pink;
			this.btnIssueLicense.FlatAppearance.BorderColor = System.Drawing.Color.Fuchsia;
			this.btnIssueLicense.FlatAppearance.BorderSize = 3;
			this.btnIssueLicense.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnIssueLicense.Font = new System.Drawing.Font("Microsoft YaHei UI", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnIssueLicense.ForeColor = System.Drawing.Color.Red;
			this.btnIssueLicense.Image = global::_02_DVLD_Mine.Properties.Resources.save_27_16;
			this.btnIssueLicense.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btnIssueLicense.Location = new System.Drawing.Point(793, 941);
			this.btnIssueLicense.Name = "btnIssueLicense";
			this.btnIssueLicense.Size = new System.Drawing.Size(102, 53);
			this.btnIssueLicense.TabIndex = 2;
			this.btnIssueLicense.Text = "Issue";
			this.btnIssueLicense.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.btnIssueLicense.UseVisualStyleBackColor = false;
			this.btnIssueLicense.Visible = false;
			this.btnIssueLicense.Click += new System.EventHandler(this.btnIssueLicense_Click);
			// 
			// btnClose
			// 
			this.btnClose.BackColor = System.Drawing.SystemColors.ScrollBar;
			this.btnClose.DialogResult = System.Windows.Forms.DialogResult.Cancel;
			this.btnClose.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
			this.btnClose.FlatAppearance.BorderSize = 2;
			this.btnClose.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnClose.Font = new System.Drawing.Font("Microsoft YaHei UI", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnClose.ForeColor = System.Drawing.Color.Red;
			this.btnClose.Image = global::_02_DVLD_Mine.Properties.Resources.close;
			this.btnClose.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btnClose.Location = new System.Drawing.Point(951, -1);
			this.btnClose.Name = "btnClose";
			this.btnClose.Size = new System.Drawing.Size(63, 53);
			this.btnClose.TabIndex = 0;
			this.btnClose.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.btnClose.UseVisualStyleBackColor = false;
			this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
			// 
			// lblPersonDetails
			// 
			this.lblPersonDetails.AutoSize = true;
			this.lblPersonDetails.Font = new System.Drawing.Font("Palatino Linotype", 33F, System.Drawing.FontStyle.Bold);
			this.lblPersonDetails.ForeColor = System.Drawing.Color.BlueViolet;
			this.lblPersonDetails.Location = new System.Drawing.Point(153, 9);
			this.lblPersonDetails.Name = "lblPersonDetails";
			this.lblPersonDetails.Size = new System.Drawing.Size(704, 60);
			this.lblPersonDetails.TabIndex = 20;
			this.lblPersonDetails.Text = "International License Application";
			// 
			// liblShowIntDL
			// 
			this.liblShowIntDL.AutoSize = true;
			this.liblShowIntDL.Font = new System.Drawing.Font("Microsoft YaHei", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.liblShowIntDL.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
			this.liblShowIntDL.Location = new System.Drawing.Point(511, 948);
			this.liblShowIntDL.Name = "liblShowIntDL";
			this.liblShowIntDL.Size = new System.Drawing.Size(276, 24);
			this.liblShowIntDL.TabIndex = 3;
			this.liblShowIntDL.TabStop = true;
			this.liblShowIntDL.Text = "Show International License Info";
			this.liblShowIntDL.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			this.liblShowIntDL.Visible = false;
			this.liblShowIntDL.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.liblShowIntDL_LinkClicked);
			// 
			// btnShowPersonLicenseHistory
			// 
			this.btnShowPersonLicenseHistory.BackColor = System.Drawing.Color.PaleTurquoise;
			this.btnShowPersonLicenseHistory.Enabled = false;
			this.btnShowPersonLicenseHistory.FlatAppearance.BorderColor = System.Drawing.Color.DeepSkyBlue;
			this.btnShowPersonLicenseHistory.FlatAppearance.BorderSize = 3;
			this.btnShowPersonLicenseHistory.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnShowPersonLicenseHistory.Font = new System.Drawing.Font("Modern No. 20", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnShowPersonLicenseHistory.Location = new System.Drawing.Point(103, 948);
			this.btnShowPersonLicenseHistory.Name = "btnShowPersonLicenseHistory";
			this.btnShowPersonLicenseHistory.Size = new System.Drawing.Size(257, 40);
			this.btnShowPersonLicenseHistory.TabIndex = 1;
			this.btnShowPersonLicenseHistory.Text = "Show Person Licenses History";
			this.btnShowPersonLicenseHistory.UseVisualStyleBackColor = false;
			this.btnShowPersonLicenseHistory.Click += new System.EventHandler(this.btnShowPersonLicenseHistory_Click);
			// 
			// InternationalApplicationInfo
			// 
			this.InternationalApplicationInfo.Location = new System.Drawing.Point(95, 662);
			this.InternationalApplicationInfo.Name = "InternationalApplicationInfo";
			this.InternationalApplicationInfo.Size = new System.Drawing.Size(809, 273);
			this.InternationalApplicationInfo.TabIndex = 21;
			// 
			// FindLocalLicense
			// 
			this.FindLocalLicense.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
			this.FindLocalLicense.Location = new System.Drawing.Point(103, 154);
			this.FindLocalLicense.Name = "FindLocalLicense";
			this.FindLocalLicense.Size = new System.Drawing.Size(809, 163);
			this.FindLocalLicense.TabIndex = 0;
			this.FindLocalLicense.OnFound_ReturnLDL_ID += new System.Action<int>(this.FindLocalLicense_OnFound_ReturnLDL_ID);
			this.FindLocalLicense.OnFound_ReturnObject += new System.Action<DVLD_Business.clsBusinessLicenses>(this.FindLocalLicense_OnFound_ReturnObject);
			// 
			// LocalLicenseDetails
			// 
			this.LocalLicenseDetails.Location = new System.Drawing.Point(57, 87);
			this.LocalLicenseDetails.Name = "LocalLicenseDetails";
			this.LocalLicenseDetails.Size = new System.Drawing.Size(908, 570);
			this.LocalLicenseDetails.TabIndex = 1;
			this.LocalLicenseDetails.Visible = false;
			// 
			// frmAddNewIntDL
			// 
			this.AcceptButton = this.btnShowPersonLicenseHistory;
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = System.Drawing.Color.LightPink;
			this.CancelButton = this.btnClose;
			this.ClientSize = new System.Drawing.Size(1013, 1000);
			this.Controls.Add(this.btnShowPersonLicenseHistory);
			this.Controls.Add(this.liblShowIntDL);
			this.Controls.Add(this.InternationalApplicationInfo);
			this.Controls.Add(this.lblPersonDetails);
			this.Controls.Add(this.btnIssueLicense);
			this.Controls.Add(this.btnClose);
			this.Controls.Add(this.FindLocalLicense);
			this.Controls.Add(this.LocalLicenseDetails);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
			this.Name = "frmAddNewIntDL";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Add New Internation Driving License";
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private userControls._04_ucLicenses._03_ucFindLDL FindLocalLicense;
		private userControls._04_ucLicenses._01_ucLicenseDetails LocalLicenseDetails;
		private System.Windows.Forms.Button btnIssueLicense;
		private System.Windows.Forms.Button btnClose;
		private System.Windows.Forms.Label lblPersonDetails;
		private userControls._03_ucDLA.ucInternationalAppInfo InternationalApplicationInfo;
		private System.Windows.Forms.LinkLabel liblShowIntDL;
		private System.Windows.Forms.Button btnShowPersonLicenseHistory;
	}
}