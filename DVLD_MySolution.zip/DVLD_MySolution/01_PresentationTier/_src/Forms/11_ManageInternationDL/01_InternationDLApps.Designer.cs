﻿namespace _02_DVLD_Mine._src.Forms._10_ManageInternationDL
{
	partial class frmInternationDLApps
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
			this.btnAddNew = new System.Windows.Forms.Button();
			this.cbStatus = new System.Windows.Forms.ComboBox();
			this.btnClose = new System.Windows.Forms.Button();
			this.lblFilterBy = new System.Windows.Forms.Label();
			this.mtxbFilter = new System.Windows.Forms.MaskedTextBox();
			this.lblTotalInternationDL = new System.Windows.Forms.Label();
			this.cbFilterBy = new System.Windows.Forms.ComboBox();
			this.dgvInternationlDL = new System.Windows.Forms.DataGridView();
			this.cmsIntLicenses = new System.Windows.Forms.ContextMenuStrip(this.components);
			this.tsmiShowDetails = new System.Windows.Forms.ToolStripMenuItem();
			this.tsmiLine1 = new System.Windows.Forms.ToolStripSeparator();
			this.tsmiShowLicense = new System.Windows.Forms.ToolStripMenuItem();
			this.tsmiLine2 = new System.Windows.Forms.ToolStripSeparator();
			this.tsmiPersonDL_History = new System.Windows.Forms.ToolStripMenuItem();
			this.label1 = new System.Windows.Forms.Label();
			((System.ComponentModel.ISupportInitialize)(this.dgvInternationlDL)).BeginInit();
			this.cmsIntLicenses.SuspendLayout();
			this.SuspendLayout();
			// 
			// btnAddNew
			// 
			this.btnAddNew.BackColor = System.Drawing.Color.PaleTurquoise;
			this.btnAddNew.FlatAppearance.BorderColor = System.Drawing.Color.DeepSkyBlue;
			this.btnAddNew.FlatAppearance.BorderSize = 3;
			this.btnAddNew.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnAddNew.Font = new System.Drawing.Font("Modern No. 20", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnAddNew.Location = new System.Drawing.Point(1094, 198);
			this.btnAddNew.Name = "btnAddNew";
			this.btnAddNew.Size = new System.Drawing.Size(119, 53);
			this.btnAddNew.TabIndex = 0;
			this.btnAddNew.Text = "ADD NEW";
			this.btnAddNew.UseVisualStyleBackColor = false;
			this.btnAddNew.Click += new System.EventHandler(this.btnAddNew_Click);
			// 
			// cbStatus
			// 
			this.cbStatus.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.cbStatus.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.cbStatus.FormattingEnabled = true;
			this.cbStatus.ItemHeight = 18;
			this.cbStatus.Items.AddRange(new object[] {
            "Active",
            "Not Active"});
			this.cbStatus.Location = new System.Drawing.Point(347, 225);
			this.cbStatus.Name = "cbStatus";
			this.cbStatus.Size = new System.Drawing.Size(223, 26);
			this.cbStatus.TabIndex = 99;
			this.cbStatus.TabStop = false;
			this.cbStatus.Visible = false;
			this.cbStatus.DropDownClosed += new System.EventHandler(this.cbStatus_DropDownClosed);
			// 
			// btnClose
			// 
			this.btnClose.BackColor = System.Drawing.SystemColors.ScrollBar;
			this.btnClose.DialogResult = System.Windows.Forms.DialogResult.Cancel;
			this.btnClose.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
			this.btnClose.FlatAppearance.BorderSize = 2;
			this.btnClose.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnClose.Font = new System.Drawing.Font("Microsoft YaHei UI", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnClose.ForeColor = System.Drawing.Color.Red;
			this.btnClose.Image = global::_02_DVLD_Mine.Properties.Resources.close;
			this.btnClose.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btnClose.Location = new System.Drawing.Point(1094, 598);
			this.btnClose.Name = "btnClose";
			this.btnClose.Size = new System.Drawing.Size(119, 53);
			this.btnClose.TabIndex = 1;
			this.btnClose.Text = "Close";
			this.btnClose.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.btnClose.UseVisualStyleBackColor = false;
			this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
			// 
			// lblFilterBy
			// 
			this.lblFilterBy.AutoSize = true;
			this.lblFilterBy.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblFilterBy.Location = new System.Drawing.Point(23, 227);
			this.lblFilterBy.Name = "lblFilterBy";
			this.lblFilterBy.Size = new System.Drawing.Size(86, 22);
			this.lblFilterBy.TabIndex = 83;
			this.lblFilterBy.Text = "Filter By :";
			// 
			// mtxbFilter
			// 
			this.mtxbFilter.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.mtxbFilter.Location = new System.Drawing.Point(347, 225);
			this.mtxbFilter.Name = "mtxbFilter";
			this.mtxbFilter.Size = new System.Drawing.Size(223, 26);
			this.mtxbFilter.TabIndex = 3;
			this.mtxbFilter.Visible = false;
			this.mtxbFilter.TextChanged += new System.EventHandler(this.mtxbFilter_TextChanged);
			// 
			// lblTotalInternationDL
			// 
			this.lblTotalInternationDL.AutoSize = true;
			this.lblTotalInternationDL.Font = new System.Drawing.Font("Mongolian Baiti", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblTotalInternationDL.Location = new System.Drawing.Point(39, 610);
			this.lblTotalInternationDL.Name = "lblTotalInternationDL";
			this.lblTotalInternationDL.Size = new System.Drawing.Size(252, 25);
			this.lblTotalInternationDL.TabIndex = 81;
			this.lblTotalInternationDL.Text = "Total International DL";
			// 
			// cbFilterBy
			// 
			this.cbFilterBy.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.cbFilterBy.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.cbFilterBy.FormattingEnabled = true;
			this.cbFilterBy.ItemHeight = 18;
			this.cbFilterBy.Location = new System.Drawing.Point(115, 225);
			this.cbFilterBy.Name = "cbFilterBy";
			this.cbFilterBy.Size = new System.Drawing.Size(223, 26);
			this.cbFilterBy.TabIndex = 99;
			this.cbFilterBy.TabStop = false;
			this.cbFilterBy.SelectedIndexChanged += new System.EventHandler(this.cbFilterBy_SelectedIndexChanged);
			// 
			// dgvInternationlDL
			// 
			this.dgvInternationlDL.AllowUserToAddRows = false;
			this.dgvInternationlDL.AllowUserToDeleteRows = false;
			this.dgvInternationlDL.AllowUserToOrderColumns = true;
			this.dgvInternationlDL.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
			this.dgvInternationlDL.BackgroundColor = System.Drawing.SystemColors.GradientInactiveCaption;
			dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
			dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
			dataGridViewCellStyle1.Font = new System.Drawing.Font("Viner Hand ITC", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
			dataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.Aqua;
			dataGridViewCellStyle1.SelectionForeColor = System.Drawing.Color.Violet;
			dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
			this.dgvInternationlDL.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
			this.dgvInternationlDL.ColumnHeadersHeight = 50;
			this.dgvInternationlDL.ContextMenuStrip = this.cmsIntLicenses;
			dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
			dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
			dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
			dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.SkyBlue;
			dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.ControlText;
			dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
			this.dgvInternationlDL.DefaultCellStyle = dataGridViewCellStyle2;
			this.dgvInternationlDL.Location = new System.Drawing.Point(15, 267);
			this.dgvInternationlDL.Name = "dgvInternationlDL";
			this.dgvInternationlDL.ReadOnly = true;
			this.dgvInternationlDL.RowHeadersWidth = 35;
			this.dgvInternationlDL.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
			this.dgvInternationlDL.Size = new System.Drawing.Size(1226, 321);
			this.dgvInternationlDL.TabIndex = 0;
			this.dgvInternationlDL.TabStop = false;
			this.dgvInternationlDL.CellFormatting += new System.Windows.Forms.DataGridViewCellFormattingEventHandler(this.dgvInternationlDL_CellFormatting);
			this.dgvInternationlDL.DoubleClick += new System.EventHandler(this.tsmiShowLicense_Click);
			// 
			// cmsIntLicenses
			// 
			this.cmsIntLicenses.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsmiShowDetails,
            this.tsmiLine1,
            this.tsmiShowLicense,
            this.tsmiLine2,
            this.tsmiPersonDL_History});
			this.cmsIntLicenses.Name = "cmsPeople";
			this.cmsIntLicenses.Size = new System.Drawing.Size(254, 136);
			// 
			// tsmiShowDetails
			// 
			this.tsmiShowDetails.Font = new System.Drawing.Font("Aldhabi", 17F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.tsmiShowDetails.Image = global::_02_DVLD_Mine.Properties.Resources.wrap;
			this.tsmiShowDetails.Name = "tsmiShowDetails";
			this.tsmiShowDetails.Size = new System.Drawing.Size(253, 40);
			this.tsmiShowDetails.Text = "Show Person Details";
			this.tsmiShowDetails.TextDirection = System.Windows.Forms.ToolStripTextDirection.Horizontal;
			this.tsmiShowDetails.Click += new System.EventHandler(this.tsmiShowDetails_Click);
			// 
			// tsmiLine1
			// 
			this.tsmiLine1.Name = "tsmiLine1";
			this.tsmiLine1.Size = new System.Drawing.Size(250, 6);
			// 
			// tsmiShowLicense
			// 
			this.tsmiShowLicense.Font = new System.Drawing.Font("Aldhabi", 17F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.tsmiShowLicense.Image = global::_02_DVLD_Mine.Properties.Resources._01_mainLicensesServices;
			this.tsmiShowLicense.Name = "tsmiShowLicense";
			this.tsmiShowLicense.Size = new System.Drawing.Size(253, 40);
			this.tsmiShowLicense.Text = "Show License Details";
			this.tsmiShowLicense.TextDirection = System.Windows.Forms.ToolStripTextDirection.Horizontal;
			this.tsmiShowLicense.Click += new System.EventHandler(this.tsmiShowLicense_Click);
			// 
			// tsmiLine2
			// 
			this.tsmiLine2.Name = "tsmiLine2";
			this.tsmiLine2.Size = new System.Drawing.Size(250, 6);
			// 
			// tsmiPersonDL_History
			// 
			this.tsmiPersonDL_History.Font = new System.Drawing.Font("Aldhabi", 17F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.tsmiPersonDL_History.Image = global::_02_DVLD_Mine.Properties.Resources._01_mainManageApps;
			this.tsmiPersonDL_History.Name = "tsmiPersonDL_History";
			this.tsmiPersonDL_History.Size = new System.Drawing.Size(253, 40);
			this.tsmiPersonDL_History.Text = "Show Person License History";
			this.tsmiPersonDL_History.TextDirection = System.Windows.Forms.ToolStripTextDirection.Horizontal;
			this.tsmiPersonDL_History.Click += new System.EventHandler(this.tsmiPersonDL_History_Click);
			// 
			// label1
			// 
			this.label1.Font = new System.Drawing.Font("Palatino Linotype", 33F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
			this.label1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
			this.label1.Location = new System.Drawing.Point(120, 57);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(1026, 62);
			this.label1.TabIndex = 78;
			this.label1.Text = "Manage Internationl Drving Licenses Applications";
			this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// frmInternationDLApps
			// 
			this.AcceptButton = this.btnAddNew;
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = System.Drawing.Color.Thistle;
			this.CancelButton = this.btnClose;
			this.ClientSize = new System.Drawing.Size(1254, 661);
			this.Controls.Add(this.btnAddNew);
			this.Controls.Add(this.cbStatus);
			this.Controls.Add(this.btnClose);
			this.Controls.Add(this.lblFilterBy);
			this.Controls.Add(this.mtxbFilter);
			this.Controls.Add(this.lblTotalInternationDL);
			this.Controls.Add(this.cbFilterBy);
			this.Controls.Add(this.dgvInternationlDL);
			this.Controls.Add(this.label1);
			this.Name = "frmInternationDLApps";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Internation Driving License Applications";
			((System.ComponentModel.ISupportInitialize)(this.dgvInternationlDL)).EndInit();
			this.cmsIntLicenses.ResumeLayout(false);
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.Button btnAddNew;
		private System.Windows.Forms.ComboBox cbStatus;
		private System.Windows.Forms.Button btnClose;
		private System.Windows.Forms.Label lblFilterBy;
		private System.Windows.Forms.MaskedTextBox mtxbFilter;
		private System.Windows.Forms.Label lblTotalInternationDL;
		private System.Windows.Forms.ComboBox cbFilterBy;
		private System.Windows.Forms.DataGridView dgvInternationlDL;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.ContextMenuStrip cmsIntLicenses;
		private System.Windows.Forms.ToolStripMenuItem tsmiShowDetails;
		private System.Windows.Forms.ToolStripSeparator tsmiLine1;
		private System.Windows.Forms.ToolStripMenuItem tsmiShowLicense;
		private System.Windows.Forms.ToolStripSeparator tsmiLine2;
		private System.Windows.Forms.ToolStripMenuItem tsmiPersonDL_History;
	}
}