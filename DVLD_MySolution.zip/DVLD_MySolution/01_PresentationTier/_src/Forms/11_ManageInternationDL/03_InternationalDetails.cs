﻿using System.Windows.Forms;

namespace _02_DVLD_Mine._src.Forms._10_ManageInternationDL
{
	public partial class frmInternationalDetails : Form
	{
		public frmInternationalDetails(int intLicenseID)
		{
			InitializeComponent();
			_intLicenseID = intLicenseID;
		}


		private int _intLicenseID = -1;

		private void frmInternationalDetails_Load(object sender, System.EventArgs e)
		{
			_04_ucInternationalDetails1.LoadLicenseDataByLicenseID(_intLicenseID);
		}

		private void btnClose_Click(object sender, System.EventArgs e)
		{
			this.Close();
		}
	}
}
