﻿namespace _02_DVLD_Mine._src.Forms._09_Licenses
{
	partial class frmLicenseDetails
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.lblPersonDetails = new System.Windows.Forms.Label();
			this._01_ucLicenseDetails1 = new _02_DVLD_Mine._src.userControls._04_ucLicenses._01_ucLicenseDetails();
			this.btnClose = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// lblPersonDetails
			// 
			this.lblPersonDetails.AutoSize = true;
			this.lblPersonDetails.Font = new System.Drawing.Font("Palatino Linotype", 39F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblPersonDetails.ForeColor = System.Drawing.Color.BlueViolet;
			this.lblPersonDetails.Location = new System.Drawing.Point(317, 22);
			this.lblPersonDetails.Name = "lblPersonDetails";
			this.lblPersonDetails.Size = new System.Drawing.Size(391, 71);
			this.lblPersonDetails.TabIndex = 14;
			this.lblPersonDetails.Text = "License Details";
			// 
			// _01_ucLicenseDetails1
			// 
			this._01_ucLicenseDetails1.Location = new System.Drawing.Point(45, 111);
			this._01_ucLicenseDetails1.Name = "_01_ucLicenseDetails1";
			this._01_ucLicenseDetails1.Size = new System.Drawing.Size(908, 570);
			this._01_ucLicenseDetails1.TabIndex = 0;
			// 
			// btnClose
			// 
			this.btnClose.BackColor = System.Drawing.SystemColors.ScrollBar;
			this.btnClose.DialogResult = System.Windows.Forms.DialogResult.Cancel;
			this.btnClose.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
			this.btnClose.FlatAppearance.BorderSize = 2;
			this.btnClose.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnClose.Font = new System.Drawing.Font("Microsoft YaHei UI", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnClose.ForeColor = System.Drawing.Color.Red;
			this.btnClose.Image = global::_02_DVLD_Mine.Properties.Resources.close;
			this.btnClose.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btnClose.Location = new System.Drawing.Point(938, 1);
			this.btnClose.Name = "btnClose";
			this.btnClose.Size = new System.Drawing.Size(60, 53);
			this.btnClose.TabIndex = 0;
			this.btnClose.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.btnClose.UseVisualStyleBackColor = false;
			this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
			// 
			// frmLicenseDetails
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = System.Drawing.SystemColors.ActiveCaption;
			this.CancelButton = this.btnClose;
			this.ClientSize = new System.Drawing.Size(998, 711);
			this.Controls.Add(this.lblPersonDetails);
			this.Controls.Add(this.btnClose);
			this.Controls.Add(this._01_ucLicenseDetails1);
			this.Name = "frmLicenseDetails";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "License Details";
			this.Load += new System.EventHandler(this.frmLicenseDetails_Load);
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private userControls._04_ucLicenses._01_ucLicenseDetails _01_ucLicenseDetails1;
		private System.Windows.Forms.Button btnClose;
		private System.Windows.Forms.Label lblPersonDetails;
	}
}