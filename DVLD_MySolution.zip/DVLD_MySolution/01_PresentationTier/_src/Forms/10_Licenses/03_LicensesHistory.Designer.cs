﻿namespace _02_DVLD_Mine._src.Forms._09_Licenses
{
	partial class frmLicensesHistory
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.lblPersonDetails = new System.Windows.Forms.Label();
			this.btnClose = new System.Windows.Forms.Button();
			this.uc1N_PersonDetailsN1 = new _02_DVLD_Mine._src.userControls._01_PeopleNewWay.uc1N_PersonDetailsN();
			this._02_ucLicenseHistory1 = new _02_DVLD_Mine._src.userControls._04_ucLicenses._02_ucLicenseHistory();
			this.SuspendLayout();
			// 
			// lblPersonDetails
			// 
			this.lblPersonDetails.AutoSize = true;
			this.lblPersonDetails.Font = new System.Drawing.Font("Palatino Linotype", 25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblPersonDetails.ForeColor = System.Drawing.Color.BlueViolet;
			this.lblPersonDetails.Location = new System.Drawing.Point(391, 9);
			this.lblPersonDetails.Name = "lblPersonDetails";
			this.lblPersonDetails.Size = new System.Drawing.Size(262, 46);
			this.lblPersonDetails.TabIndex = 16;
			this.lblPersonDetails.Text = "License History";
			// 
			// btnClose
			// 
			this.btnClose.BackColor = System.Drawing.SystemColors.ScrollBar;
			this.btnClose.DialogResult = System.Windows.Forms.DialogResult.Cancel;
			this.btnClose.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
			this.btnClose.FlatAppearance.BorderSize = 2;
			this.btnClose.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnClose.Font = new System.Drawing.Font("Microsoft YaHei UI", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnClose.ForeColor = System.Drawing.Color.Red;
			this.btnClose.Image = global::_02_DVLD_Mine.Properties.Resources.close;
			this.btnClose.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btnClose.Location = new System.Drawing.Point(1041, 1);
			this.btnClose.Name = "btnClose";
			this.btnClose.Size = new System.Drawing.Size(60, 53);
			this.btnClose.TabIndex = 0;
			this.btnClose.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.btnClose.UseVisualStyleBackColor = false;
			this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
			// 
			// uc1N_PersonDetailsN1
			// 
			this.uc1N_PersonDetailsN1.Location = new System.Drawing.Point(138, 62);
			this.uc1N_PersonDetailsN1.Name = "uc1N_PersonDetailsN1";
			this.uc1N_PersonDetailsN1.Size = new System.Drawing.Size(810, 465);
			this.uc1N_PersonDetailsN1.TabIndex = 17;
			// 
			// _02_ucLicenseHistory1
			// 
			this._02_ucLicenseHistory1.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
			this._02_ucLicenseHistory1.Location = new System.Drawing.Point(48, 533);
			this._02_ucLicenseHistory1.Name = "_02_ucLicenseHistory1";
			this._02_ucLicenseHistory1.Size = new System.Drawing.Size(1001, 392);
			this._02_ucLicenseHistory1.TabIndex = 18;
			// 
			// frmLicensesHistory
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = System.Drawing.SystemColors.ActiveCaption;
			this.CancelButton = this.btnClose;
			this.ClientSize = new System.Drawing.Size(1100, 958);
			this.Controls.Add(this._02_ucLicenseHistory1);
			this.Controls.Add(this.uc1N_PersonDetailsN1);
			this.Controls.Add(this.lblPersonDetails);
			this.Controls.Add(this.btnClose);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
			this.Name = "frmLicensesHistory";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Licenses History";
			this.Load += new System.EventHandler(this.frmLicensesHistory_Load);
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.Label lblPersonDetails;
		private System.Windows.Forms.Button btnClose;
		private userControls._01_PeopleNewWay.uc1N_PersonDetailsN uc1N_PersonDetailsN1;
		private userControls._04_ucLicenses._02_ucLicenseHistory _02_ucLicenseHistory1;
	}
}