﻿using System;
using System.Windows.Forms;
using DVLD_Business;

namespace _02_DVLD_Mine._src.Forms._09_Licenses
{
	public partial class frmIssueLicenseFirstTime : Form
	{
		private int _LDLA_ID = 0;
		private string _personNationalNo = string.Empty;
		clsBusiness_LDLA _currentDLA;
		clsBusinessLicenseClasses _currentDLA_Class;

		public frmIssueLicenseFirstTime(int LDLA_ID, string personNationalNo)
		{
			InitializeComponent();
			_LDLA_ID = LDLA_ID;
			_personNationalNo = personNationalNo;
		}
		private void frmIssueLicenseFirstTime_Load(object sender, EventArgs e)
		{
			ucADL_BasicInfo1.LoadData(_LDLA_ID);

			_currentDLA = clsBusiness_LDLA.Find(_LDLA_ID);
			_currentDLA_Class = clsBusinessLicenseClasses.Find(_currentDLA.LicenseClassID);
			lblFees.Text = _currentDLA_Class.ClassFees.ToString();
		}


		private void txbNotes_FocusEnter(object sender, EventArgs e)
		{
			txbNotes.Text = "";
		}


		private void btnIssueLicense_Click(object sender, EventArgs e)
		{
			int driverID = clsBusinessDrivers.IsPersonDriver(_personNationalNo);
			if (driverID == -1)  // This Person Is Not A Driver Yet!
			{
				driverID = clsBusinessDrivers.AddNewDriver(clsBusinessPeople.Find(_personNationalNo).personID, clsGlobal.currentUser.userID);
				MessageBox.Show("This Person With National No [" + _personNationalNo + "], Is Now A Driver With The ID [" + driverID + "].", "Information",
					MessageBoxButtons.OK, MessageBoxIcon.Information);
			}

			//

			clsBusinessLicenses newLicense = new clsBusinessLicenses();
			newLicense.ApplicationID = _currentDLA.ApplicationID;
			newLicense.DriverID = driverID;
			newLicense.LicenseClass = _currentDLA.LicenseClassID;
			//newLicense.LicenseClass = _currentDLA_Class.LicenseClassID;
			newLicense.IssueDate = DateTime.Now;
			newLicense.ExpirationDate = DateTime.Today.AddYears(_currentDLA_Class.DefaultValidittyLength);
			newLicense.Notes = (txbNotes.Text == "...") ? "" : txbNotes.Text;
			newLicense.PaidFees = _currentDLA_Class.ClassFees;
			newLicense.IsActive = true;
			newLicense.IssueReason = 1;
			newLicense.CreatedByUserID = clsGlobal.currentUser.userID;

			if (newLicense.Save())
			{
				clsBusiness_LDLA.ChangeAppStatusByLDLA_ID(_LDLA_ID, clsBusiness_LDLA.enLA_Status.eCompleted);
				MessageBox.Show("License Issued Successfully With License ID [" + newLicense.LicenseID + "].", "Succeeded!", MessageBoxButtons.OK, MessageBoxIcon.Information);
			}
			else
				MessageBox.Show("Error: Data Is not Saved Successfully.");
		}

		private void btnClose_Click(object sender, EventArgs e)
		{
			this.Close();
		}
	}
}
