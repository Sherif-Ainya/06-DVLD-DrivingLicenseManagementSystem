﻿using System.Windows.Forms;

namespace _02_DVLD_Mine._src.Forms._09_Licenses
{
	public partial class frmLicenseDetails : Form
	{
		private int _LDLA_License = -1;
		public enum enFindBy { eLDLA_ID, eLicenseID };
		private enFindBy _FindBy = enFindBy.eLDLA_ID;

		public frmLicenseDetails(int LDLA_License, enFindBy findBy)
		{
			InitializeComponent();
			_LDLA_License = LDLA_License;
			_FindBy = findBy;
		}


		private void frmLicenseDetails_Load(object sender, System.EventArgs e)
		{
			if (_FindBy == enFindBy.eLDLA_ID)
			{ _01_ucLicenseDetails1.LoadLicenseDataByLDLA_ID(_LDLA_License); return; }

			if (_FindBy == enFindBy.eLicenseID)
			{ _01_ucLicenseDetails1.LoadLicenseDataByLicenseID(_LDLA_License); return; }
		}


		private void btnClose_Click(object sender, System.EventArgs e)
		{
			this.Close();
		}
	}
}
