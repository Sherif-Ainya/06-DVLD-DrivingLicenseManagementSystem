﻿using System.Windows.Forms;

namespace _02_DVLD_Mine._src.Forms._09_Licenses
{
	public partial class frmLicensesHistory : Form
	{
		private string _personNationalNo = string.Empty;
		private int _personID = -1;

		public frmLicensesHistory(string personNationalNo)
		{
			InitializeComponent();
			_personNationalNo = personNationalNo;
		}

		public frmLicensesHistory(int personID)
		{
			InitializeComponent();
			_personID = personID;
		}

		private void frmLicensesHistory_Load(object sender, System.EventArgs e)
		{
			if (!string.IsNullOrEmpty(_personNationalNo))
			{
				uc1N_PersonDetailsN1.LoadPersonData(_personNationalNo);
				_02_ucLicenseHistory1.LoadPersonData(_personNationalNo);
				return;
			}


			if (_personID != -1)
			{
				uc1N_PersonDetailsN1.LoadPersonData(_personID);
				_02_ucLicenseHistory1.LoadPersonData(_personID);
			}
		}

		private void btnClose_Click(object sender, System.EventArgs e)
		{
			this.Close();
		}
	}
}
