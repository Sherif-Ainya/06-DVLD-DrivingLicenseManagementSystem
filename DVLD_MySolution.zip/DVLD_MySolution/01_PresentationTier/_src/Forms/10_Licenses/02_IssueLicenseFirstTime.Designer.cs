﻿namespace _02_DVLD_Mine._src.Forms._09_Licenses
{
	partial class frmIssueLicenseFirstTime
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.btnClose = new System.Windows.Forms.Button();
			this.btnIssueLicense = new System.Windows.Forms.Button();
			this._lblNotes = new System.Windows.Forms.Label();
			this.lblFees = new System.Windows.Forms.Label();
			this._lblFees = new System.Windows.Forms.Label();
			this.txbNotes = new System.Windows.Forms.TextBox();
			this.ucADL_BasicInfo1 = new _02_DVLD_Mine._src.userControls._03_ucDLA.ucADL_BasicInfo();
			this.SuspendLayout();
			// 
			// btnClose
			// 
			this.btnClose.BackColor = System.Drawing.SystemColors.ScrollBar;
			this.btnClose.DialogResult = System.Windows.Forms.DialogResult.Cancel;
			this.btnClose.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
			this.btnClose.FlatAppearance.BorderSize = 2;
			this.btnClose.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnClose.Font = new System.Drawing.Font("Microsoft YaHei UI", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnClose.ForeColor = System.Drawing.Color.Red;
			this.btnClose.Image = global::_02_DVLD_Mine.Properties.Resources.close;
			this.btnClose.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btnClose.Location = new System.Drawing.Point(914, 1);
			this.btnClose.Name = "btnClose";
			this.btnClose.Size = new System.Drawing.Size(63, 53);
			this.btnClose.TabIndex = 0;
			this.btnClose.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.btnClose.UseVisualStyleBackColor = false;
			this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
			// 
			// btnIssueLicense
			// 
			this.btnIssueLicense.BackColor = System.Drawing.Color.Pink;
			this.btnIssueLicense.FlatAppearance.BorderColor = System.Drawing.Color.Fuchsia;
			this.btnIssueLicense.FlatAppearance.BorderSize = 3;
			this.btnIssueLicense.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnIssueLicense.Font = new System.Drawing.Font("Microsoft YaHei UI", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnIssueLicense.ForeColor = System.Drawing.Color.Red;
			this.btnIssueLicense.Image = global::_02_DVLD_Mine.Properties.Resources.save_27_16;
			this.btnIssueLicense.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btnIssueLicense.Location = new System.Drawing.Point(834, 163);
			this.btnIssueLicense.Name = "btnIssueLicense";
			this.btnIssueLicense.Size = new System.Drawing.Size(102, 53);
			this.btnIssueLicense.TabIndex = 1;
			this.btnIssueLicense.Text = "Issue";
			this.btnIssueLicense.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.btnIssueLicense.UseVisualStyleBackColor = false;
			this.btnIssueLicense.Click += new System.EventHandler(this.btnIssueLicense_Click);
			// 
			// _lblNotes
			// 
			this._lblNotes.AutoSize = true;
			this._lblNotes.Font = new System.Drawing.Font("Palatino Linotype", 17F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this._lblNotes.Location = new System.Drawing.Point(62, 82);
			this._lblNotes.Name = "_lblNotes";
			this._lblNotes.Size = new System.Drawing.Size(139, 31);
			this._lblNotes.TabIndex = 18;
			this._lblNotes.Text = "Any Notes :";
			// 
			// lblFees
			// 
			this.lblFees.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
			this.lblFees.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.lblFees.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblFees.Location = new System.Drawing.Point(413, 171);
			this.lblFees.Name = "lblFees";
			this.lblFees.Size = new System.Drawing.Size(163, 35);
			this.lblFees.TabIndex = 21;
			this.lblFees.Text = "????";
			this.lblFees.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// _lblFees
			// 
			this._lblFees.AutoSize = true;
			this._lblFees.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this._lblFees.Location = new System.Drawing.Point(45, 171);
			this._lblFees.Name = "_lblFees";
			this._lblFees.Size = new System.Drawing.Size(196, 26);
			this._lblFees.TabIndex = 20;
			this._lblFees.Text = "Fees For This Type  :";
			// 
			// txbNotes
			// 
			this.txbNotes.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
			this.txbNotes.Font = new System.Drawing.Font("Palatino Linotype", 11F, System.Drawing.FontStyle.Bold);
			this.txbNotes.Location = new System.Drawing.Point(225, 38);
			this.txbNotes.Multiline = true;
			this.txbNotes.Name = "txbNotes";
			this.txbNotes.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
			this.txbNotes.Size = new System.Drawing.Size(585, 115);
			this.txbNotes.TabIndex = 2;
			this.txbNotes.Text = "...";
			this.txbNotes.Enter += new System.EventHandler(this.txbNotes_FocusEnter);
			// 
			// ucADL_BasicInfo1
			// 
			this.ucADL_BasicInfo1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
			this.ucADL_BasicInfo1.Location = new System.Drawing.Point(84, 234);
			this.ucADL_BasicInfo1.Name = "ucADL_BasicInfo1";
			this.ucADL_BasicInfo1.Size = new System.Drawing.Size(809, 443);
			this.ucADL_BasicInfo1.TabIndex = 0;
			// 
			// frmIssueLicenseFirstTime
			// 
			this.AcceptButton = this.btnIssueLicense;
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = System.Drawing.SystemColors.ActiveCaption;
			this.CancelButton = this.btnClose;
			this.ClientSize = new System.Drawing.Size(978, 688);
			this.Controls.Add(this.txbNotes);
			this.Controls.Add(this.lblFees);
			this.Controls.Add(this._lblFees);
			this.Controls.Add(this._lblNotes);
			this.Controls.Add(this.btnIssueLicense);
			this.Controls.Add(this.btnClose);
			this.Controls.Add(this.ucADL_BasicInfo1);
			this.Name = "frmIssueLicenseFirstTime";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Issue License First Time";
			this.Load += new System.EventHandler(this.frmIssueLicenseFirstTime_Load);
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private userControls._03_ucDLA.ucADL_BasicInfo ucADL_BasicInfo1;
		private System.Windows.Forms.Button btnClose;
		private System.Windows.Forms.Button btnIssueLicense;
		private System.Windows.Forms.Label _lblNotes;
		private System.Windows.Forms.Label lblFees;
		private System.Windows.Forms.Label _lblFees;
		private System.Windows.Forms.TextBox txbNotes;
	}
}