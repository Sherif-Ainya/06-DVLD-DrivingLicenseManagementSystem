﻿namespace _02_DVLD_Mine
{
	partial class frmLoginScreen
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
            this.panLeft = new System.Windows.Forms.Panel();
            this.lblVersion_ = new System.Windows.Forms.Label();
            this.lblWelcomTo = new System.Windows.Forms.Label();
            this._lblLoginToYourAccount = new System.Windows.Forms.Label();
            this.txbUserName = new System.Windows.Forms.TextBox();
            this._lblUserName = new System.Windows.Forms.Label();
            this._lblPassword = new System.Windows.Forms.Label();
            this.txbPassword = new System.Windows.Forms.TextBox();
            this.cbRememberMe = new System.Windows.Forms.CheckBox();
            this.btnLogin = new System.Windows.Forms.Button();
            this.lblLoginFailed = new System.Windows.Forms.Label();
            this.panLeft.SuspendLayout();
            this.SuspendLayout();
            // 
            // panLeft
            // 
            this.panLeft.BackgroundImage = global::_02_DVLD_Mine.Properties.Resources.CarLoginScreen;
            this.panLeft.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.panLeft.Controls.Add(this.lblVersion_);
            this.panLeft.Controls.Add(this.lblWelcomTo);
            this.panLeft.Dock = System.Windows.Forms.DockStyle.Left;
            this.panLeft.Location = new System.Drawing.Point(0, 0);
            this.panLeft.Name = "panLeft";
            this.panLeft.Size = new System.Drawing.Size(348, 520);
            this.panLeft.TabIndex = 0;
            // 
            // lblVersion_
            // 
            this.lblVersion_.BackColor = System.Drawing.Color.Transparent;
            this.lblVersion_.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblVersion_.Location = new System.Drawing.Point(238, 484);
            this.lblVersion_.Name = "lblVersion_";
            this.lblVersion_.Size = new System.Drawing.Size(96, 27);
            this.lblVersion_.TabIndex = 1;
            this.lblVersion_.Text = "Version 1.2";
            this.lblVersion_.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblWelcomTo
            // 
            this.lblWelcomTo.BackColor = System.Drawing.Color.Transparent;
            this.lblWelcomTo.Font = new System.Drawing.Font("Microsoft YaHei", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblWelcomTo.Location = new System.Drawing.Point(28, 9);
            this.lblWelcomTo.Name = "lblWelcomTo";
            this.lblWelcomTo.Size = new System.Drawing.Size(289, 220);
            this.lblWelcomTo.TabIndex = 0;
            this.lblWelcomTo.Text = "_";
            this.lblWelcomTo.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // _lblLoginToYourAccount
            // 
            this._lblLoginToYourAccount.AutoSize = true;
            this._lblLoginToYourAccount.Font = new System.Drawing.Font("Monotype Corsiva", 22F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this._lblLoginToYourAccount.Location = new System.Drawing.Point(430, 67);
            this._lblLoginToYourAccount.Name = "_lblLoginToYourAccount";
            this._lblLoginToYourAccount.Size = new System.Drawing.Size(289, 37);
            this._lblLoginToYourAccount.TabIndex = 1;
            this._lblLoginToYourAccount.Text = "Login To Your Account";
            // 
            // txbUserName
            // 
            this.txbUserName.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txbUserName.Location = new System.Drawing.Point(535, 185);
            this.txbUserName.Name = "txbUserName";
            this.txbUserName.Size = new System.Drawing.Size(193, 29);
            this.txbUserName.TabIndex = 1;
            this.txbUserName.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // _lblUserName
            // 
            this._lblUserName.AutoSize = true;
            this._lblUserName.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this._lblUserName.Location = new System.Drawing.Point(406, 185);
            this._lblUserName.Name = "_lblUserName";
            this._lblUserName.Size = new System.Drawing.Size(117, 26);
            this._lblUserName.TabIndex = 30;
            this._lblUserName.Text = "User Name :";
            // 
            // _lblPassword
            // 
            this._lblPassword.AutoSize = true;
            this._lblPassword.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this._lblPassword.Location = new System.Drawing.Point(415, 240);
            this._lblPassword.Name = "_lblPassword";
            this._lblPassword.Size = new System.Drawing.Size(101, 26);
            this._lblPassword.TabIndex = 29;
            this._lblPassword.Text = "Password :";
            // 
            // txbPassword
            // 
            this.txbPassword.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txbPassword.Location = new System.Drawing.Point(535, 238);
            this.txbPassword.Name = "txbPassword";
            this.txbPassword.PasswordChar = '*';
            this.txbPassword.Size = new System.Drawing.Size(193, 29);
            this.txbPassword.TabIndex = 2;
            this.txbPassword.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // cbRememberMe
            // 
            this.cbRememberMe.AutoSize = true;
            this.cbRememberMe.Checked = true;
            this.cbRememberMe.CheckState = System.Windows.Forms.CheckState.Checked;
            this.cbRememberMe.Font = new System.Drawing.Font("Microsoft Uighur", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbRememberMe.Location = new System.Drawing.Point(567, 282);
            this.cbRememberMe.Name = "cbRememberMe";
            this.cbRememberMe.Size = new System.Drawing.Size(126, 31);
            this.cbRememberMe.TabIndex = 3;
            this.cbRememberMe.TabStop = false;
            this.cbRememberMe.Text = "Remember Me";
            this.cbRememberMe.UseVisualStyleBackColor = true;
            // 
            // btnLogin
            // 
            this.btnLogin.BackColor = System.Drawing.Color.LavenderBlush;
            this.btnLogin.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnLogin.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnLogin.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.btnLogin.FlatAppearance.BorderSize = 4;
            this.btnLogin.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLogin.Font = new System.Drawing.Font("Microsoft YaHei UI", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLogin.ForeColor = System.Drawing.Color.Red;
            this.btnLogin.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnLogin.Location = new System.Drawing.Point(638, 346);
            this.btnLogin.Name = "btnLogin";
            this.btnLogin.Size = new System.Drawing.Size(127, 61);
            this.btnLogin.TabIndex = 0;
            this.btnLogin.Text = "Login";
            this.btnLogin.UseVisualStyleBackColor = false;
            this.btnLogin.Click += new System.EventHandler(this.btnLogin_Click);
            // 
            // lblLoginFailed
            // 
            this.lblLoginFailed.BackColor = System.Drawing.Color.PaleTurquoise;
            this.lblLoginFailed.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblLoginFailed.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lblLoginFailed.Font = new System.Drawing.Font("Microsoft Uighur", 15.75F, System.Drawing.FontStyle.Bold);
            this.lblLoginFailed.Location = new System.Drawing.Point(381, 448);
            this.lblLoginFailed.Name = "lblLoginFailed";
            this.lblLoginFailed.Size = new System.Drawing.Size(398, 63);
            this.lblLoginFailed.TabIndex = 34;
            this.lblLoginFailed.Text = "Login Failed";
            this.lblLoginFailed.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblLoginFailed.Visible = false;
            // 
            // frmLoginScreen
            // 
            this.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.CancelButton = this.btnLogin;
            this.ClientSize = new System.Drawing.Size(805, 520);
            this.Controls.Add(this.lblLoginFailed);
            this.Controls.Add(this.btnLogin);
            this.Controls.Add(this.cbRememberMe);
            this.Controls.Add(this.txbPassword);
            this.Controls.Add(this.txbUserName);
            this.Controls.Add(this._lblUserName);
            this.Controls.Add(this._lblPassword);
            this.Controls.Add(this._lblLoginToYourAccount);
            this.Controls.Add(this.panLeft);
            this.Name = "frmLoginScreen";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Login Screen";
            this.Load += new System.EventHandler(this.LoginScreen_Load_1);
            this.panLeft.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.Panel panel1;
		private System.Windows.Forms.Label lblWelcom;
		private System.Windows.Forms.Label lblVersion;
		private System.Windows.Forms.PictureBox pictureBox1;
		private System.Windows.Forms.Panel panLeft;
		private System.Windows.Forms.Label lblVersion_;
		private System.Windows.Forms.Label lblWelcomTo;
		private System.Windows.Forms.Label _lblLoginToYourAccount;
		private System.Windows.Forms.TextBox txbUserName;
		private System.Windows.Forms.Label _lblUserName;
		private System.Windows.Forms.Label _lblPassword;
		private System.Windows.Forms.TextBox txbPassword;
		private System.Windows.Forms.CheckBox cbRememberMe;
		private System.Windows.Forms.Button btnLogin;
		private System.Windows.Forms.Label lblLoginFailed;
	}
}

