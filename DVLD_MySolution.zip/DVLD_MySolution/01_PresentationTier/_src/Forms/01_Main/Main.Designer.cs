﻿namespace _02_DVLD_Mine._src.Main
{
	partial class frmMainScreen
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmMainScreen));
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.tsmi1_Applications = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmi1_ManageApplication = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmi1_ManageLocalDL = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmi1_ManageInterDL = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmi1_Line0 = new System.Windows.Forms.ToolStripSeparator();
            this.tsmi1_DrivingLicensesServices = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmi1_NewDL = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmi1_LocalDL = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmi1_Line7 = new System.Windows.Forms.ToolStripSeparator();
            this.tsmi1_InternationalDL = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmi1_RenewDL = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmi1_Line5 = new System.Windows.Forms.ToolStripSeparator();
            this.tsmi1_ReplacDL = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmi1_Line6 = new System.Windows.Forms.ToolStripSeparator();
            this.tsmi1_ReleaseDetainedDL = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmi1_RetakeTest = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmi1_Line1 = new System.Windows.Forms.ToolStripSeparator();
            this.tsmi1_DetainLicenses = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmiManageDetainL = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmiLine99 = new System.Windows.Forms.ToolStripSeparator();
            this.tsmiDetainL = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmiLine100 = new System.Windows.Forms.ToolStripSeparator();
            this.tsmiReleaseL = new System.Windows.Forms.ToolStripMenuItem();
            this.manageToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmiApplicationTypes = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmiLine0 = new System.Windows.Forms.ToolStripSeparator();
            this.tsmiTestTypes = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmiLine1 = new System.Windows.Forms.ToolStripSeparator();
            this.tsmiLicensesClasses = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmi2_Manage = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmi2_AllPeople = new System.Windows.Forms.ToolStripMenuItem();
            this.oldToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.newToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmi2_AllUsers = new System.Windows.Forms.ToolStripMenuItem();
            this.oldWayToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.newToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmi2_AllDrivers = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmi2_Line1 = new System.Windows.Forms.ToolStripSeparator();
            this.tsmi2_MyAcount = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmi2_MyAcountDetails = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmi2_MyAcountEdit = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmi2_Line2 = new System.Windows.Forms.ToolStripSeparator();
            this.tsmi2_MyAcountSignOut = new System.Windows.Forms.ToolStripMenuItem();
            this.panMainScreenBackColor = new System.Windows.Forms.Panel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnClose = new System.Windows.Forms.Button();
            this.menuStrip1.SuspendLayout();
            this.panMainScreenBackColor.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsmi1_Applications,
            this.manageToolStripMenuItem,
            this.tsmi2_Manage});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1574, 104);
            this.menuStrip1.TabIndex = 1;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // tsmi1_Applications
            // 
            this.tsmi1_Applications.AutoSize = false;
            this.tsmi1_Applications.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.tsmi1_Applications.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsmi1_ManageApplication,
            this.tsmi1_Line0,
            this.tsmi1_DrivingLicensesServices,
            this.tsmi1_Line1,
            this.tsmi1_DetainLicenses});
            this.tsmi1_Applications.Font = new System.Drawing.Font("Britannic Bold", 22F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tsmi1_Applications.ForeColor = System.Drawing.SystemColors.ControlText;
            this.tsmi1_Applications.Image = global::_02_DVLD_Mine.Properties.Resources.align_left;
            this.tsmi1_Applications.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.tsmi1_Applications.Name = "tsmi1_Applications";
            this.tsmi1_Applications.Size = new System.Drawing.Size(372, 100);
            this.tsmi1_Applications.Text = "&Applications";
            this.tsmi1_Applications.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tsmi1_ManageApplication
            // 
            this.tsmi1_ManageApplication.BackColor = System.Drawing.Color.Thistle;
            this.tsmi1_ManageApplication.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsmi1_ManageLocalDL,
            this.tsmi1_ManageInterDL});
            this.tsmi1_ManageApplication.Font = new System.Drawing.Font("Andalus", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tsmi1_ManageApplication.Image = global::_02_DVLD_Mine.Properties.Resources._01_mainManageApps;
            this.tsmi1_ManageApplication.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.tsmi1_ManageApplication.Margin = new System.Windows.Forms.Padding(3, 7, 3, 3);
            this.tsmi1_ManageApplication.Name = "tsmi1_ManageApplication";
            this.tsmi1_ManageApplication.Size = new System.Drawing.Size(367, 70);
            this.tsmi1_ManageApplication.Text = "&Manage Application";
            // 
            // tsmi1_ManageLocalDL
            // 
            this.tsmi1_ManageLocalDL.Font = new System.Drawing.Font("Andalus", 14F, System.Drawing.FontStyle.Bold);
            this.tsmi1_ManageLocalDL.Name = "tsmi1_ManageLocalDL";
            this.tsmi1_ManageLocalDL.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Alt | System.Windows.Forms.Keys.L)));
            this.tsmi1_ManageLocalDL.Size = new System.Drawing.Size(515, 34);
            this.tsmi1_ManageLocalDL.Text = "Local Driving License Applications";
            this.tsmi1_ManageLocalDL.Click += new System.EventHandler(this.tsmi1_ManageLocalDL_Click);
            // 
            // tsmi1_ManageInterDL
            // 
            this.tsmi1_ManageInterDL.Font = new System.Drawing.Font("Andalus", 14F, System.Drawing.FontStyle.Bold);
            this.tsmi1_ManageInterDL.Name = "tsmi1_ManageInterDL";
            this.tsmi1_ManageInterDL.ShortcutKeyDisplayString = "alt+i";
            this.tsmi1_ManageInterDL.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Alt | System.Windows.Forms.Keys.I)));
            this.tsmi1_ManageInterDL.Size = new System.Drawing.Size(515, 34);
            this.tsmi1_ManageInterDL.Text = "International Driving License Applications";
            this.tsmi1_ManageInterDL.Click += new System.EventHandler(this.tsmi1_ManageInterDL_Click);
            // 
            // tsmi1_Line0
            // 
            this.tsmi1_Line0.BackColor = System.Drawing.Color.RoyalBlue;
            this.tsmi1_Line0.Name = "tsmi1_Line0";
            this.tsmi1_Line0.Size = new System.Drawing.Size(364, 6);
            // 
            // tsmi1_DrivingLicensesServices
            // 
            this.tsmi1_DrivingLicensesServices.BackColor = System.Drawing.Color.Thistle;
            this.tsmi1_DrivingLicensesServices.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsmi1_NewDL,
            this.tsmi1_RenewDL,
            this.tsmi1_Line5,
            this.tsmi1_ReplacDL,
            this.tsmi1_Line6,
            this.tsmi1_ReleaseDetainedDL,
            this.tsmi1_RetakeTest});
            this.tsmi1_DrivingLicensesServices.Font = new System.Drawing.Font("Andalus", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tsmi1_DrivingLicensesServices.Image = global::_02_DVLD_Mine.Properties.Resources._01_mainLicensesServices;
            this.tsmi1_DrivingLicensesServices.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.tsmi1_DrivingLicensesServices.Margin = new System.Windows.Forms.Padding(3, 7, 3, 3);
            this.tsmi1_DrivingLicensesServices.Name = "tsmi1_DrivingLicensesServices";
            this.tsmi1_DrivingLicensesServices.Size = new System.Drawing.Size(367, 70);
            this.tsmi1_DrivingLicensesServices.Text = "Driving Licenses &Services";
            // 
            // tsmi1_NewDL
            // 
            this.tsmi1_NewDL.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsmi1_LocalDL,
            this.tsmi1_Line7,
            this.tsmi1_InternationalDL});
            this.tsmi1_NewDL.Font = new System.Drawing.Font("Andalus", 14F, System.Drawing.FontStyle.Bold);
            this.tsmi1_NewDL.Name = "tsmi1_NewDL";
            this.tsmi1_NewDL.Size = new System.Drawing.Size(459, 34);
            this.tsmi1_NewDL.Text = "New Driving License";
            // 
            // tsmi1_LocalDL
            // 
            this.tsmi1_LocalDL.Font = new System.Drawing.Font("Andalus", 12F, System.Drawing.FontStyle.Bold);
            this.tsmi1_LocalDL.Name = "tsmi1_LocalDL";
            this.tsmi1_LocalDL.Size = new System.Drawing.Size(245, 30);
            this.tsmi1_LocalDL.Text = "Local License";
            this.tsmi1_LocalDL.Click += new System.EventHandler(this.tsmi1_LocalDL_Click);
            // 
            // tsmi1_Line7
            // 
            this.tsmi1_Line7.Name = "tsmi1_Line7";
            this.tsmi1_Line7.Size = new System.Drawing.Size(242, 6);
            // 
            // tsmi1_InternationalDL
            // 
            this.tsmi1_InternationalDL.Font = new System.Drawing.Font("Andalus", 12F, System.Drawing.FontStyle.Bold);
            this.tsmi1_InternationalDL.Name = "tsmi1_InternationalDL";
            this.tsmi1_InternationalDL.Size = new System.Drawing.Size(245, 30);
            this.tsmi1_InternationalDL.Text = "International License";
            this.tsmi1_InternationalDL.Click += new System.EventHandler(this.tsmi1_InternationalDL_Click);
            // 
            // tsmi1_RenewDL
            // 
            this.tsmi1_RenewDL.Font = new System.Drawing.Font("Andalus", 14F, System.Drawing.FontStyle.Bold);
            this.tsmi1_RenewDL.Name = "tsmi1_RenewDL";
            this.tsmi1_RenewDL.Size = new System.Drawing.Size(459, 34);
            this.tsmi1_RenewDL.Text = "Renew Driving License";
            this.tsmi1_RenewDL.Click += new System.EventHandler(this.tsmi1_RenewDL_Click);
            // 
            // tsmi1_Line5
            // 
            this.tsmi1_Line5.Name = "tsmi1_Line5";
            this.tsmi1_Line5.Size = new System.Drawing.Size(456, 6);
            // 
            // tsmi1_ReplacDL
            // 
            this.tsmi1_ReplacDL.Font = new System.Drawing.Font("Andalus", 14F, System.Drawing.FontStyle.Bold);
            this.tsmi1_ReplacDL.Name = "tsmi1_ReplacDL";
            this.tsmi1_ReplacDL.Size = new System.Drawing.Size(459, 34);
            this.tsmi1_ReplacDL.Text = "Replacement For Lost Or Damaged License";
            this.tsmi1_ReplacDL.Click += new System.EventHandler(this.tsmi1_ReplacDL_Click);
            // 
            // tsmi1_Line6
            // 
            this.tsmi1_Line6.Name = "tsmi1_Line6";
            this.tsmi1_Line6.Size = new System.Drawing.Size(456, 6);
            // 
            // tsmi1_ReleaseDetainedDL
            // 
            this.tsmi1_ReleaseDetainedDL.Font = new System.Drawing.Font("Andalus", 14F, System.Drawing.FontStyle.Bold);
            this.tsmi1_ReleaseDetainedDL.Name = "tsmi1_ReleaseDetainedDL";
            this.tsmi1_ReleaseDetainedDL.Size = new System.Drawing.Size(459, 34);
            this.tsmi1_ReleaseDetainedDL.Text = "Release Detained Driving License";
            // 
            // tsmi1_RetakeTest
            // 
            this.tsmi1_RetakeTest.Font = new System.Drawing.Font("Andalus", 14F, System.Drawing.FontStyle.Bold);
            this.tsmi1_RetakeTest.Name = "tsmi1_RetakeTest";
            this.tsmi1_RetakeTest.Size = new System.Drawing.Size(459, 34);
            this.tsmi1_RetakeTest.Text = "Retake Test";
            this.tsmi1_RetakeTest.Click += new System.EventHandler(this.tsmi1_RetakeTest_Click);
            // 
            // tsmi1_Line1
            // 
            this.tsmi1_Line1.BackColor = System.Drawing.Color.RoyalBlue;
            this.tsmi1_Line1.Name = "tsmi1_Line1";
            this.tsmi1_Line1.Size = new System.Drawing.Size(364, 6);
            // 
            // tsmi1_DetainLicenses
            // 
            this.tsmi1_DetainLicenses.BackColor = System.Drawing.Color.Thistle;
            this.tsmi1_DetainLicenses.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsmiManageDetainL,
            this.tsmiLine99,
            this.tsmiDetainL,
            this.tsmiLine100,
            this.tsmiReleaseL});
            this.tsmi1_DetainLicenses.Font = new System.Drawing.Font("Andalus", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tsmi1_DetainLicenses.Image = global::_02_DVLD_Mine.Properties.Resources.pedestrian_traffic_light_stop2;
            this.tsmi1_DetainLicenses.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.tsmi1_DetainLicenses.Margin = new System.Windows.Forms.Padding(3, 7, 3, 3);
            this.tsmi1_DetainLicenses.Name = "tsmi1_DetainLicenses";
            this.tsmi1_DetainLicenses.Size = new System.Drawing.Size(367, 70);
            this.tsmi1_DetainLicenses.Text = "&Detain Licenses";
            // 
            // tsmiManageDetainL
            // 
            this.tsmiManageDetainL.Name = "tsmiManageDetainL";
            this.tsmiManageDetainL.Size = new System.Drawing.Size(327, 36);
            this.tsmiManageDetainL.Text = "Manage Detained Licenses";
            this.tsmiManageDetainL.Click += new System.EventHandler(this.tsmiManageDetainL_Click);
            // 
            // tsmiLine99
            // 
            this.tsmiLine99.Name = "tsmiLine99";
            this.tsmiLine99.Size = new System.Drawing.Size(324, 6);
            // 
            // tsmiDetainL
            // 
            this.tsmiDetainL.Name = "tsmiDetainL";
            this.tsmiDetainL.Size = new System.Drawing.Size(327, 36);
            this.tsmiDetainL.Text = "Detain License";
            this.tsmiDetainL.Click += new System.EventHandler(this.tsmiDetainL_Click);
            // 
            // tsmiLine100
            // 
            this.tsmiLine100.Name = "tsmiLine100";
            this.tsmiLine100.Size = new System.Drawing.Size(324, 6);
            // 
            // tsmiReleaseL
            // 
            this.tsmiReleaseL.Name = "tsmiReleaseL";
            this.tsmiReleaseL.Size = new System.Drawing.Size(327, 36);
            this.tsmiReleaseL.Text = "Release License";
            this.tsmiReleaseL.Click += new System.EventHandler(this.tsmiReleaseL_Click);
            // 
            // manageToolStripMenuItem
            // 
            this.manageToolStripMenuItem.AutoSize = false;
            this.manageToolStripMenuItem.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.manageToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsmiApplicationTypes,
            this.tsmiLine0,
            this.tsmiTestTypes,
            this.tsmiLine1,
            this.tsmiLicensesClasses});
            this.manageToolStripMenuItem.Font = new System.Drawing.Font("Britannic Bold", 22F);
            this.manageToolStripMenuItem.Image = global::_02_DVLD_Mine.Properties.Resources._01_mainManageApps;
            this.manageToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.manageToolStripMenuItem.Name = "manageToolStripMenuItem";
            this.manageToolStripMenuItem.Size = new System.Drawing.Size(352, 100);
            this.manageToolStripMenuItem.Text = "&Fees Managment";
            this.manageToolStripMenuItem.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tsmiApplicationTypes
            // 
            this.tsmiApplicationTypes.BackColor = System.Drawing.Color.Thistle;
            this.tsmiApplicationTypes.Font = new System.Drawing.Font("Andalus", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tsmiApplicationTypes.Image = global::_02_DVLD_Mine.Properties.Resources._01_mainappTypes;
            this.tsmiApplicationTypes.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.tsmiApplicationTypes.Margin = new System.Windows.Forms.Padding(3, 7, 3, 3);
            this.tsmiApplicationTypes.Name = "tsmiApplicationTypes";
            this.tsmiApplicationTypes.Size = new System.Drawing.Size(292, 70);
            this.tsmiApplicationTypes.Text = "Application Types";
            this.tsmiApplicationTypes.Click += new System.EventHandler(this.tsmiApplicationTypes_Click);
            // 
            // tsmiLine0
            // 
            this.tsmiLine0.BackColor = System.Drawing.Color.RoyalBlue;
            this.tsmiLine0.Name = "tsmiLine0";
            this.tsmiLine0.Size = new System.Drawing.Size(289, 6);
            // 
            // tsmiTestTypes
            // 
            this.tsmiTestTypes.BackColor = System.Drawing.Color.Thistle;
            this.tsmiTestTypes.Font = new System.Drawing.Font("Andalus", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tsmiTestTypes.Image = global::_02_DVLD_Mine.Properties.Resources._01_maintestTypes;
            this.tsmiTestTypes.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.tsmiTestTypes.Margin = new System.Windows.Forms.Padding(3, 7, 3, 3);
            this.tsmiTestTypes.Name = "tsmiTestTypes";
            this.tsmiTestTypes.Size = new System.Drawing.Size(292, 70);
            this.tsmiTestTypes.Text = "Test Types";
            this.tsmiTestTypes.Click += new System.EventHandler(this.tsmiTestTypes_Click);
            // 
            // tsmiLine1
            // 
            this.tsmiLine1.BackColor = System.Drawing.Color.RoyalBlue;
            this.tsmiLine1.Name = "tsmiLine1";
            this.tsmiLine1.Size = new System.Drawing.Size(289, 6);
            // 
            // tsmiLicensesClasses
            // 
            this.tsmiLicensesClasses.BackColor = System.Drawing.Color.Thistle;
            this.tsmiLicensesClasses.Font = new System.Drawing.Font("Andalus", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tsmiLicensesClasses.Image = global::_02_DVLD_Mine.Properties.Resources.repetitive_tasks;
            this.tsmiLicensesClasses.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.tsmiLicensesClasses.Margin = new System.Windows.Forms.Padding(3, 7, 3, 3);
            this.tsmiLicensesClasses.Name = "tsmiLicensesClasses";
            this.tsmiLicensesClasses.Size = new System.Drawing.Size(292, 70);
            this.tsmiLicensesClasses.Text = "License Classes";
            this.tsmiLicensesClasses.Click += new System.EventHandler(this.tsmiLicensesClasses_Click);
            // 
            // tsmi2_Manage
            // 
            this.tsmi2_Manage.AutoSize = false;
            this.tsmi2_Manage.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.tsmi2_Manage.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsmi2_AllPeople,
            this.tsmi2_AllUsers,
            this.tsmi2_AllDrivers,
            this.tsmi2_Line1,
            this.tsmi2_MyAcount});
            this.tsmi2_Manage.Font = new System.Drawing.Font("Britannic Bold", 22F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tsmi2_Manage.Image = ((System.Drawing.Image)(resources.GetObject("tsmi2_Manage.Image")));
            this.tsmi2_Manage.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.tsmi2_Manage.Name = "tsmi2_Manage";
            this.tsmi2_Manage.Size = new System.Drawing.Size(332, 100);
            this.tsmi2_Manage.Text = "&Manage";
            this.tsmi2_Manage.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tsmi2_AllPeople
            // 
            this.tsmi2_AllPeople.BackColor = System.Drawing.Color.Thistle;
            this.tsmi2_AllPeople.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.oldToolStripMenuItem,
            this.newToolStripMenuItem});
            this.tsmi2_AllPeople.Font = new System.Drawing.Font("Andalus", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tsmi2_AllPeople.Image = global::_02_DVLD_Mine.Properties.Resources._01_mainPerson;
            this.tsmi2_AllPeople.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.tsmi2_AllPeople.Margin = new System.Windows.Forms.Padding(3, 7, 3, 3);
            this.tsmi2_AllPeople.Name = "tsmi2_AllPeople";
            this.tsmi2_AllPeople.Size = new System.Drawing.Size(238, 38);
            this.tsmi2_AllPeople.Text = "People";
            this.tsmi2_AllPeople.Click += new System.EventHandler(this.tsmi2_AllPeopleN_Click);
            // 
            // oldToolStripMenuItem
            // 
            this.oldToolStripMenuItem.Name = "oldToolStripMenuItem";
            this.oldToolStripMenuItem.Size = new System.Drawing.Size(189, 34);
            this.oldToolStripMenuItem.Text = "Old";
            this.oldToolStripMenuItem.Click += new System.EventHandler(this.tsmi2_AllPeople_Click);
            // 
            // newToolStripMenuItem
            // 
            this.newToolStripMenuItem.Name = "newToolStripMenuItem";
            this.newToolStripMenuItem.ShortcutKeyDisplayString = "ctrl+P";
            this.newToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.P)));
            this.newToolStripMenuItem.Size = new System.Drawing.Size(189, 34);
            this.newToolStripMenuItem.Text = "New";
            this.newToolStripMenuItem.Click += new System.EventHandler(this.tsmi2_AllPeopleN_Click);
            // 
            // tsmi2_AllUsers
            // 
            this.tsmi2_AllUsers.BackColor = System.Drawing.Color.Thistle;
            this.tsmi2_AllUsers.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.oldWayToolStripMenuItem,
            this.newToolStripMenuItem1});
            this.tsmi2_AllUsers.Font = new System.Drawing.Font("Andalus", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tsmi2_AllUsers.Image = global::_02_DVLD_Mine.Properties.Resources._01_mainUser;
            this.tsmi2_AllUsers.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.tsmi2_AllUsers.Margin = new System.Windows.Forms.Padding(3);
            this.tsmi2_AllUsers.Name = "tsmi2_AllUsers";
            this.tsmi2_AllUsers.ShortcutKeyDisplayString = "";
            this.tsmi2_AllUsers.Size = new System.Drawing.Size(238, 38);
            this.tsmi2_AllUsers.Text = "Users";
            this.tsmi2_AllUsers.Click += new System.EventHandler(this.tsmi2_AllUsersN_Click);
            // 
            // oldWayToolStripMenuItem
            // 
            this.oldWayToolStripMenuItem.Name = "oldWayToolStripMenuItem";
            this.oldWayToolStripMenuItem.Size = new System.Drawing.Size(193, 34);
            this.oldWayToolStripMenuItem.Text = "Old";
            this.oldWayToolStripMenuItem.Click += new System.EventHandler(this.tsmi2_AllUsers_Click);
            // 
            // newToolStripMenuItem1
            // 
            this.newToolStripMenuItem1.Name = "newToolStripMenuItem1";
            this.newToolStripMenuItem1.ShortcutKeyDisplayString = "ctrl+U";
            this.newToolStripMenuItem1.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.U)));
            this.newToolStripMenuItem1.Size = new System.Drawing.Size(193, 34);
            this.newToolStripMenuItem1.Text = "New";
            this.newToolStripMenuItem1.Click += new System.EventHandler(this.tsmi2_AllUsersN_Click);
            // 
            // tsmi2_AllDrivers
            // 
            this.tsmi2_AllDrivers.BackColor = System.Drawing.Color.Thistle;
            this.tsmi2_AllDrivers.Font = new System.Drawing.Font("Andalus", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tsmi2_AllDrivers.Image = global::_02_DVLD_Mine.Properties.Resources._01_mainDriver;
            this.tsmi2_AllDrivers.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.tsmi2_AllDrivers.Margin = new System.Windows.Forms.Padding(3);
            this.tsmi2_AllDrivers.Name = "tsmi2_AllDrivers";
            this.tsmi2_AllDrivers.ShortcutKeyDisplayString = "ctrl+D";
            this.tsmi2_AllDrivers.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.D)));
            this.tsmi2_AllDrivers.Size = new System.Drawing.Size(238, 38);
            this.tsmi2_AllDrivers.Text = "Drivers";
            this.tsmi2_AllDrivers.Click += new System.EventHandler(this.tsmi2_AllDrivers_Click);
            // 
            // tsmi2_Line1
            // 
            this.tsmi2_Line1.Name = "tsmi2_Line1";
            this.tsmi2_Line1.Size = new System.Drawing.Size(235, 6);
            // 
            // tsmi2_MyAcount
            // 
            this.tsmi2_MyAcount.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.tsmi2_MyAcount.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsmi2_MyAcountDetails,
            this.tsmi2_MyAcountEdit,
            this.tsmi2_Line2,
            this.tsmi2_MyAcountSignOut});
            this.tsmi2_MyAcount.Font = new System.Drawing.Font("Andalus", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tsmi2_MyAcount.Image = global::_02_DVLD_Mine.Properties.Resources._01_mainSettings;
            this.tsmi2_MyAcount.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.tsmi2_MyAcount.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.tsmi2_MyAcount.Margin = new System.Windows.Forms.Padding(0, 5, 0, 0);
            this.tsmi2_MyAcount.Name = "tsmi2_MyAcount";
            this.tsmi2_MyAcount.Size = new System.Drawing.Size(238, 38);
            this.tsmi2_MyAcount.Text = "My Acount";
            // 
            // tsmi2_MyAcountDetails
            // 
            this.tsmi2_MyAcountDetails.Font = new System.Drawing.Font("Andalus", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tsmi2_MyAcountDetails.Image = global::_02_DVLD_Mine.Properties.Resources.wrap;
            this.tsmi2_MyAcountDetails.Name = "tsmi2_MyAcountDetails";
            this.tsmi2_MyAcountDetails.Padding = new System.Windows.Forms.Padding(3, 1, 0, 1);
            this.tsmi2_MyAcountDetails.Size = new System.Drawing.Size(169, 34);
            this.tsmi2_MyAcountDetails.Text = "Details";
            this.tsmi2_MyAcountDetails.Click += new System.EventHandler(this.tsmi2_MyAcountDetails_Click);
            // 
            // tsmi2_MyAcountEdit
            // 
            this.tsmi2_MyAcountEdit.Font = new System.Drawing.Font("Andalus", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tsmi2_MyAcountEdit.Image = global::_02_DVLD_Mine.Properties.Resources.highlighter_pen;
            this.tsmi2_MyAcountEdit.Name = "tsmi2_MyAcountEdit";
            this.tsmi2_MyAcountEdit.Padding = new System.Windows.Forms.Padding(3, 1, 0, 1);
            this.tsmi2_MyAcountEdit.Size = new System.Drawing.Size(169, 34);
            this.tsmi2_MyAcountEdit.Text = " Edit";
            this.tsmi2_MyAcountEdit.Click += new System.EventHandler(this.tsmi2_MyAcountEdit_Click);
            // 
            // tsmi2_Line2
            // 
            this.tsmi2_Line2.Name = "tsmi2_Line2";
            this.tsmi2_Line2.Size = new System.Drawing.Size(163, 6);
            // 
            // tsmi2_MyAcountSignOut
            // 
            this.tsmi2_MyAcountSignOut.Font = new System.Drawing.Font("Andalus", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tsmi2_MyAcountSignOut.Image = global::_02_DVLD_Mine.Properties.Resources.undo;
            this.tsmi2_MyAcountSignOut.Name = "tsmi2_MyAcountSignOut";
            this.tsmi2_MyAcountSignOut.Padding = new System.Windows.Forms.Padding(3, 1, 0, 1);
            this.tsmi2_MyAcountSignOut.Size = new System.Drawing.Size(169, 34);
            this.tsmi2_MyAcountSignOut.Text = "Sign Out";
            this.tsmi2_MyAcountSignOut.Click += new System.EventHandler(this.tsmi2_MyAcountSignOut_Click);
            // 
            // panMainScreenBackColor
            // 
            this.panMainScreenBackColor.BackColor = System.Drawing.Color.MidnightBlue;
            this.panMainScreenBackColor.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panMainScreenBackColor.Controls.Add(this.panel1);
            this.panMainScreenBackColor.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panMainScreenBackColor.Location = new System.Drawing.Point(0, 104);
            this.panMainScreenBackColor.Name = "panMainScreenBackColor";
            this.panMainScreenBackColor.Size = new System.Drawing.Size(1574, 630);
            this.panMainScreenBackColor.TabIndex = 3;
            // 
            // panel1
            // 
            this.panel1.BackgroundImage = global::_02_DVLD_Mine.Properties.Resources.CarMainScreen;
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1574, 630);
            this.panel1.TabIndex = 1;
            // 
            // btnClose
            // 
            this.btnClose.BackColor = System.Drawing.Color.Transparent;
            this.btnClose.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnClose.Location = new System.Drawing.Point(-999, 0);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(16, 23);
            this.btnClose.TabIndex = 0;
            this.btnClose.UseVisualStyleBackColor = false;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // frmMainScreen
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Black;
            this.CancelButton = this.btnClose;
            this.ClientSize = new System.Drawing.Size(1574, 734);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.panMainScreenBackColor);
            this.Controls.Add(this.menuStrip1);
            this.IsMdiContainer = true;
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "frmMainScreen";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Main Screen";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Resize += new System.EventHandler(this.frmMainScreen_Resize);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.panMainScreenBackColor.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

		}

		#endregion
		private System.ComponentModel.BackgroundWorker backgroundWorker1;
		private System.Windows.Forms.ToolStripMenuItem tsmi1_Applications;
		private System.Windows.Forms.ToolStripMenuItem tsmi2_Manage;
		private System.Windows.Forms.ToolStripMenuItem tsmi2_AllPeople;
		private System.Windows.Forms.ToolStripMenuItem tsmi2_AllUsers;
		private System.Windows.Forms.ToolStripMenuItem tsmi2_AllDrivers;
		private System.Windows.Forms.MenuStrip menuStrip1;
		private System.Windows.Forms.ToolStripMenuItem tsmi2_MyAcount;
		private System.Windows.Forms.Panel panMainScreenBackColor;
		private System.Windows.Forms.ToolStripMenuItem tsmi2_MyAcountDetails;
		private System.Windows.Forms.ToolStripMenuItem tsmi2_MyAcountEdit;
		private System.Windows.Forms.ToolStripSeparator tsmi2_Line2;
		private System.Windows.Forms.ToolStripMenuItem tsmi2_MyAcountSignOut;
		private System.Windows.Forms.ToolStripSeparator tsmi2_Line1;
		private System.Windows.Forms.ToolStripMenuItem tsmi1_DrivingLicensesServices;
		private System.Windows.Forms.ToolStripMenuItem tsmi1_ManageApplication;
		private System.Windows.Forms.ToolStripMenuItem tsmi1_DetainLicenses;
		private System.Windows.Forms.ToolStripSeparator tsmi1_Line0;
		private System.Windows.Forms.ToolStripSeparator tsmi1_Line1;
		private System.Windows.Forms.ToolStripMenuItem tsmi1_NewDL;
		private System.Windows.Forms.ToolStripMenuItem tsmiManageDetainL;
		private System.Windows.Forms.ToolStripMenuItem tsmi1_RenewDL;
		private System.Windows.Forms.ToolStripSeparator tsmi1_Line5;
		private System.Windows.Forms.ToolStripMenuItem tsmi1_ReplacDL;
		private System.Windows.Forms.ToolStripSeparator tsmi1_Line6;
		private System.Windows.Forms.ToolStripMenuItem tsmi1_LocalDL;
		private System.Windows.Forms.ToolStripSeparator tsmi1_Line7;
		private System.Windows.Forms.ToolStripMenuItem tsmi1_InternationalDL;
		private System.Windows.Forms.ToolStripMenuItem tsmi1_ReleaseDetainedDL;
		private System.Windows.Forms.ToolStripMenuItem tsmi1_RetakeTest;
		private System.Windows.Forms.ToolStripMenuItem tsmi1_ManageLocalDL;
		private System.Windows.Forms.ToolStripMenuItem tsmi1_ManageInterDL;
		private System.Windows.Forms.ToolStripMenuItem oldToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem newToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem newToolStripMenuItem1;
		private System.Windows.Forms.ToolStripMenuItem oldWayToolStripMenuItem;
		private System.Windows.Forms.Button btnClose;
		private System.Windows.Forms.ToolStripMenuItem manageToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem tsmiApplicationTypes;
		private System.Windows.Forms.ToolStripMenuItem tsmiTestTypes;
		private System.Windows.Forms.ToolStripMenuItem tsmiLicensesClasses;
		private System.Windows.Forms.ToolStripSeparator tsmiLine0;
		private System.Windows.Forms.ToolStripSeparator tsmiLine1;
		private System.Windows.Forms.ToolStripSeparator tsmiLine99;
		private System.Windows.Forms.ToolStripMenuItem tsmiDetainL;
		private System.Windows.Forms.ToolStripSeparator tsmiLine100;
		private System.Windows.Forms.ToolStripMenuItem tsmiReleaseL;
				private System.Windows.Forms.Panel panel1;
		}
}