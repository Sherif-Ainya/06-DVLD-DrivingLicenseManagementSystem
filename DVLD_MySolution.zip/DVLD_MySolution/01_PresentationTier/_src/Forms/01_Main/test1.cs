﻿using System.Windows.Forms;

namespace _02_DVLD_Mine
{
	public partial class test1 : Form
	{
		public test1()
		{
			InitializeComponent();
		}
	}
}
