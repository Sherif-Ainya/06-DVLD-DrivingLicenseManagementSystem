﻿using System;
using System.Drawing;
using System.Windows.Forms;
using _02_DVLD_Mine._src.Forms;
using _02_DVLD_Mine._src.Forms._02_PeopleN;
using _02_DVLD_Mine._src.Forms._03_Users;
using _02_DVLD_Mine._src.Forms._03_UsersN;
using _02_DVLD_Mine._src.Forms._04_ApplicationTypes;
using _02_DVLD_Mine._src.Forms._05_TestTypes;
using _02_DVLD_Mine._src.Forms._06_LicenseClasses;
using _02_DVLD_Mine._src.Forms._06_ManageLocalDL;
using _02_DVLD_Mine._src.Forms._08_ManageDrivers;
using _02_DVLD_Mine._src.Forms._10_ManageInternationDL;
using _02_DVLD_Mine._src.Forms._12_Replacment;
using _02_DVLD_Mine._src.Forms._14_Detain;
using _02_DVLD_Mine._src.Main.Users;


namespace _02_DVLD_Mine._src.Main
{
	public partial class frmMainScreen : Form
	{
		public frmMainScreen()
		{
			InitializeComponent();
		}

		private void frmMainScreen_Resize(object sender, EventArgs e)
		{
			if (this.WindowState == FormWindowState.Normal)
			{
				Rectangle workingArea = Screen.PrimaryScreen.WorkingArea;

				double widthDouble = workingArea.Width / 1.4;
				int width = Convert.ToInt32(widthDouble);

				this.Left = workingArea.Width - (width + ((workingArea.Width - width) / 2));
				this.Width = width;

				//this.Top = workingArea.Height / 4;
				this.Top = 30;
				this.Height = workingArea.Height - (workingArea.Height / 4);
			}
		}

		// Applications.
		#region
		// 01 - Manage Application.
		private void tsmi1_ManageLocalDL_Click(object sender, EventArgs e)
		{
			Form frm = new frmManageLDLA();
			frm.ShowDialog();
		}
		private void tsmi1_ManageInterDL_Click(object sender, EventArgs e)
		{
			Form frm = new frmInternationDLApps();
			frm.ShowDialog();
		}
		// 02 - Driving Licenses Services.		
		private void tsmi1_LocalDL_Click(object sender, EventArgs e)
		{
			Form frm = new frmAddNewLDLA();
			frm.ShowDialog();
		}
		private void tsmi1_InternationalDL_Click(object sender, EventArgs e)
		{
			Form frm = new frmAddNewIntDL();
			frm.ShowDialog();
		}
		private void tsmi1_RenewDL_Click(object sender, EventArgs e)
		{
			Form frm = new frmRenewLicenseApp();
			frm.ShowDialog();
		}
		private void tsmi1_ReplacDL_Click(object sender, EventArgs e)
		{
			Form frm = new frmReplacment();
			frm.ShowDialog();
		}
		// 03 - Detain Licenses.
		private void tsmiManageDetainL_Click(object sender, EventArgs e)
		{
			Form frm = new frmManageDetainedL();
			frm.ShowDialog();
		}
		private void tsmiDetainL_Click(object sender, EventArgs e)
		{
			Form frm = new frmDetainLicense();
			frm.ShowDialog();
		}
		private void tsmiReleaseL_Click(object sender, EventArgs e)
		{
			Form frm = new frmReleaseLicense();
			frm.ShowDialog();
		}
		private void tsmi1_RetakeTest_Click(object sender, EventArgs e)
		{
			Form frm = new frmManageLDLA();
			frm.ShowDialog();
		}
		#endregion


		// Fees Managment.
		#region
		private void tsmiApplicationTypes_Click(object sender, EventArgs e)
		{
			Form frm = new frmApplicationTypes();
			frm.ShowDialog();
		}
		private void tsmiTestTypes_Click(object sender, EventArgs e)
		{
			Form frm = new frmTestTypes();
			frm.ShowDialog();
		}
		private void tsmiLicensesClasses_Click(object sender, EventArgs e)
		{
			Form frm = new frmLicenseClasses();
			frm.ShowDialog();
		}
		#endregion


		// Manage.
		#region
		// 01 - People.
		private void tsmi2_AllPeople_Click(object sender, EventArgs e)
		{
			Form managePeople = new frmManagePeople();
			managePeople.ShowDialog();
		}
		private void tsmi2_AllPeopleN_Click(object sender, EventArgs e)
		{
			Form managePeople = new frmManagePeopleN();
			managePeople.ShowDialog();
		}
		// 02 - Users.
		private void tsmi2_AllUsers_Click(object sender, EventArgs e)
		{
			Form frmManageUsers = new frmManageUsers();
			frmManageUsers.ShowDialog();
		}
		private void tsmi2_AllUsersN_Click(object sender, EventArgs e)
		{
			Form frmManageUsers = new frmManageUsersN();
			frmManageUsers.ShowDialog();
		}
		// 04 - Drivers.
		private void tsmi2_AllDrivers_Click(object sender, EventArgs e)
		{
			Form frm = new frmManageDrivers();
			frm.ShowDialog();
		}
		// 04 - My Account.
		private void tsmi2_MyAcountDetails_Click(object sender, EventArgs e)
		{
			Form myAccountDetails = new frmUserDetailsN(clsGlobal.currentUser.userID);
			myAccountDetails.ShowDialog();
		}
		private void tsmi2_MyAcountEdit_Click(object sender, EventArgs e)
		{
			Form myAccountEdit = new frmAdd_UpdateUserN(clsGlobal.currentUser.userID);
			myAccountEdit.ShowDialog();
		}
		private void tsmi2_MyAcountSignOut_Click(object sender, EventArgs e)
		{
			clsGlobal.isSignOut = true;
			this.Close();
		}
		#endregion


		private void btnClose_Click(object sender, EventArgs e)
		{
			this.Close();
		}
	}
}
