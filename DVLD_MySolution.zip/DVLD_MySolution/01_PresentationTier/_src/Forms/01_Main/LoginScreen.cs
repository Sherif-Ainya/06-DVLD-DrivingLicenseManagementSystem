﻿using System;
using System.Windows.Forms;
using _02_DVLD_Mine._src.Main;
using DVLD_Business;

namespace _02_DVLD_Mine
{
	public partial class frmLoginScreen : Form
	{
		public frmLoginScreen()
		{
			InitializeComponent();
		}


		private byte _LoginFailed = 0;
		private void LoginScreen_Load_1(object sender, EventArgs e)
		{
			lblWelcomTo.Text = "WELCOME TO " + Environment.NewLine + "DRIVERS - VEHICLES" + Environment.NewLine + "LICENSE DEPARTMENT" + Environment.NewLine + "(DVLD) SYSTEM";
			txbUserName.Focus();
		}


		private bool _CheckAllInfoCompleted()
		{
			if (txbUserName.Text == "")
			{
				txbUserName.Focus();
				return false;
			}
			if (txbPassword.Text == "")
			{
				txbPassword.Focus();
				return false;
			}
			return true;
		}
		private void btnLogin_Click(object sender, EventArgs e)
		{
			if (!_CheckAllInfoCompleted())
				return;

			clsGlobal.currentUser = clsBusinessUsers.Find(txbUserName.Text, txbPassword.Text);

			if (clsGlobal.currentUser == null)
			{
				++_LoginFailed;
				txbUserName.Focus();
				lblLoginFailed.Visible = true;
				lblLoginFailed.Text = "Login Failed!, You Have [" + (3 - _LoginFailed) + "] Attempt(s).";

				if (_LoginFailed == 3)
				{
					MessageBox.Show("Sorry You Don't Have Any Attempts Left!", "Close Form", MessageBoxButtons.OK, MessageBoxIcon.Information);
					this.Close();
				}
			}
			else if (!clsGlobal.currentUser.active)
			{
				MessageBox.Show("Your Acount Is Deactivated Please Contact Your Administration!", "Close Form", MessageBoxButtons.OK, MessageBoxIcon.Information);
				this.Close();
			}
			else
			{
				this.Hide();
				Form mainScr = new frmMainScreen();
				mainScr.ShowDialog();

				if (clsGlobal.isSignOut)
					this.Show();
				else
				{
					this.Close();
					return;
				}

				_LoginFailed = 0;
				if (!cbRememberMe.Checked)
				{
					txbUserName.Text = "";
					txbPassword.Text = "";
				}
				txbUserName.Focus();
				lblLoginFailed.Visible = false;
			}
		}
    }
}
