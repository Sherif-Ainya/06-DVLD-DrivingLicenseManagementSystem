﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Windows.Forms;
using _02_DVLD_Mine._src.Forms._02_People;
using _02_DVLD_Mine._src.Forms._09_Licenses;
using DVLD_Business;

namespace _02_DVLD_Mine._src.Forms._14_Detain
{
	public partial class frmManageDetainedL : Form
	{
		private void dgvDetainLicenses_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
		{
			dgvDetainLicenses.ColumnHeadersHeight = 60;
			dgvDetainLicenses.RowTemplate.Height = 30;

			dgvDetainLicenses.Columns[0].Width = 130;
			dgvDetainLicenses.Columns[1].Width = 130;
			dgvDetainLicenses.Columns[2].Width = 155;
			dgvDetainLicenses.Columns[3].Width = 130;
			dgvDetainLicenses.Columns[4].Width = 135;
			dgvDetainLicenses.Columns[5].Width = 155;
			dgvDetainLicenses.Columns[6].Width = 142;
			dgvDetainLicenses.Columns[8].Width = 150;


			dgvDetainLicenses.Columns[0].HeaderText = "Detain ID";
			dgvDetainLicenses.Columns[1].HeaderText = "License ID";
			dgvDetainLicenses.Columns[2].HeaderText = "Detain Date";
			dgvDetainLicenses.Columns[3].HeaderText = "Is Released?";
			//if (dgvDetainLicenses.Columns[e.ColumnIndex].Name == "IsReleased")
			//{
			//	if (e.Value != null)
			//	{
			//		if (e.Value.ToString() == "0")
			//		{
			//			e.Value = "Male";
			//		}
			//		else
			//		{
			//			e.Value = "Female";
			//		}
			//		e.FormattingApplied = true;
			//	}
			//}
			dgvDetainLicenses.Columns[4].HeaderText = "Fine Fees";
			dgvDetainLicenses.Columns[5].HeaderText = "Released Date";
			dgvDetainLicenses.Columns[6].HeaderText = "National No";
			dgvDetainLicenses.Columns[7].HeaderText = "Full Name";
			dgvDetainLicenses.Columns[8].HeaderText = "Release Applicaiton ID";
		}
		private void _RefreshDetainLiceses()
		{
			mtxbFilter.Text = "";
			mtxbFilter.Visible = false;

			dgvDetainLicenses.SuspendLayout();
			dgvDetainLicenses.DataSource = clsBusinessDetainedLicenses.GetAllDetainedLicenses();
			dgvDetainLicenses.ResumeLayout();
			lblTotalDetainedL.Text = "Total Detain Licenses [" + dgvDetainLicenses.RowCount.ToString() + "].";
		}
		private void _PrepareThisForm()
		{
			_RefreshDetainLiceses();
			cbFilterBy.Items.AddRange(new string[] { "None", "License ID", "National No", "Full Name", "Status" });
		}


		public frmManageDetainedL()
		{
			InitializeComponent();
			_PrepareThisForm();
		}


		Dictionary<string, string> columnMapping = new Dictionary<string, string>()
		{
			{"License ID", "LicenseID" },
			{"National No", "NationalNo" },
			{"Full Name", "FullName" }
		};
		private void FilterData()
		{
			if (dgvDetainLicenses.DataSource is DataTable dt)
			{
				string searchValue = mtxbFilter.Text.Replace("-", "").Trim();

				string displayName = cbFilterBy.SelectedItem.ToString();
				string actualColumnName = columnMapping[displayName];

				if (!string.IsNullOrEmpty(searchValue))
				{
					if (displayName.Contains("ID"))
					{
						string filterExpression = $"{actualColumnName} = {searchValue}";
						dt.DefaultView.RowFilter = filterExpression;
					}
					else
					{
						string filterExpression = $"{actualColumnName} LIKE '%{searchValue}%'";
						dt.DefaultView.RowFilter = filterExpression;
					}
				}
				else
				{
					dt.DefaultView.RowFilter = "";
				}
			}
		}
		private void cbFilterBy_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			mtxbFilter.Visible = false;
			cbStatus.Visible = false;

			if (cbFilterBy.SelectedItem.ToString() == "None")
			{
				if (dgvDetainLicenses.DataSource is DataTable dt)
				{
					dt.DefaultView.RowFilter = "";
					lblTotalDetainedL.Text = "Total Local DL [" + dgvDetainLicenses.RowCount.ToString() + "].";
				}
				return;
			}

			if (cbFilterBy.SelectedItem.ToString() == "Status")
			{
				cbStatus.Visible = true;
				return;
			}

			if (cbFilterBy.SelectedItem.ToString().Contains("ID"))
			{
				mtxbFilter.Mask = "000000";
			}
			else
			{
				mtxbFilter.Mask = "";
			}
			mtxbFilter.Visible = true;
			mtxbFilter.Text = string.Empty;
			mtxbFilter.Focus();
		}
		//
		private void mtxbFilter_TextChanged(object sender, System.EventArgs e)
		{
			FilterData();
			lblTotalDetainedL.Text = "# Records [" + dgvDetainLicenses.RowCount.ToString() + "].";
		}
		private void cbStatus_DropDownClosed(object sender, EventArgs e)
		{
			if (dgvDetainLicenses.DataSource is DataTable dt)
			{
				if (cbStatus.SelectedIndex != -1)
				{
					string filterExpression = $"IsReleased = {cbStatus.SelectedIndex}";
					dt.DefaultView.RowFilter = filterExpression;
					lblTotalDetainedL.Text = "# Records [" + dgvDetainLicenses.RowCount.ToString() + "].";
				}
			}
		}


		//


		private void btnDetainLicense_Click(object sender, EventArgs e)
		{
			Form frm = new frmDetainLicense();
			frm.ShowDialog();
			_RefreshDetainLiceses();
		}
		private void btnReleaseLicense_Click(object sender, EventArgs e)
		{
			Form frm = new frmReleaseLicense();
			frm.ShowDialog();
			_RefreshDetainLiceses();
		}


		//////////////////// Contest Menu Strip /////////////////////
		#region
		private void cmsDetainedL_Opened(object sender, EventArgs e)
		{
			tsmiReleaseDetainedL.Enabled = !(bool)dgvDetainLicenses.CurrentRow.Cells[3].Value;
		}

		private void tsmiShowPersonDetails_Click(object sender, EventArgs e)
		{
			Form frm = new frmPersonDetailsN((dgvDetainLicenses.CurrentRow.Cells[6].Value).ToString());
			frm.ShowDialog();
			_RefreshDetainLiceses();
		}
		private void tsmiShowLicense_Click(object sender, EventArgs e)
		{
			Form frm = new frmLicenseDetails((int)dgvDetainLicenses.CurrentRow.Cells[1].Value, frmLicenseDetails.enFindBy.eLicenseID);
			frm.ShowDialog();
			_RefreshDetainLiceses();
		}
		private void tsmiPersonDL_History_Click(object sender, EventArgs e)
		{
			string personNationalNo = (string)dgvDetainLicenses.CurrentRow.Cells[6].Value;
			Form frm = new frmLicensesHistory(personNationalNo);
			frm.ShowDialog();
			_RefreshDetainLiceses();
		}
		//
		private void tsmiReleaseDetainedL_Click(object sender, EventArgs e)
		{
			Form frm = new frmReleaseLicense((int)dgvDetainLicenses.CurrentRow.Cells[1].Value);
			frm.ShowDialog();
			_RefreshDetainLiceses();
		}
		#endregion


		private void btnClose_Click(object sender, EventArgs e)
		{
			this.Close();
		}
	}
}
