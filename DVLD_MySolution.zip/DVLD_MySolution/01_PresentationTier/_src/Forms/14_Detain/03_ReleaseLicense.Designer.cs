﻿namespace _02_DVLD_Mine._src.Forms._14_Detain
{
	partial class frmReleaseLicense
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.btnShowPersonLicenseHistory = new System.Windows.Forms.Button();
			this.lblReleaseTitle = new System.Windows.Forms.Label();
			this.btnReleaseLicense = new System.Windows.Forms.Button();
			this.btnClose = new System.Windows.Forms.Button();
			this.ReleaseInfo1 = new _02_DVLD_Mine._src.userControls._05_ucDetain._02_ucReleaseInfo();
			this.FindLocalLicense = new _02_DVLD_Mine._src.userControls._04_ucLicenses._03_ucFindLDL();
			this.LocalLicenseDetails = new _02_DVLD_Mine._src.userControls._04_ucLicenses._01_ucLicenseDetails();
			this.SuspendLayout();
			// 
			// btnShowPersonLicenseHistory
			// 
			this.btnShowPersonLicenseHistory.BackColor = System.Drawing.Color.PaleTurquoise;
			this.btnShowPersonLicenseHistory.FlatAppearance.BorderColor = System.Drawing.Color.DeepSkyBlue;
			this.btnShowPersonLicenseHistory.FlatAppearance.BorderSize = 3;
			this.btnShowPersonLicenseHistory.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnShowPersonLicenseHistory.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Bold);
			this.btnShowPersonLicenseHistory.Location = new System.Drawing.Point(987, 474);
			this.btnShowPersonLicenseHistory.Name = "btnShowPersonLicenseHistory";
			this.btnShowPersonLicenseHistory.Size = new System.Drawing.Size(257, 53);
			this.btnShowPersonLicenseHistory.TabIndex = 118;
			this.btnShowPersonLicenseHistory.Text = "Show Person Licenses History";
			this.btnShowPersonLicenseHistory.UseVisualStyleBackColor = false;
			this.btnShowPersonLicenseHistory.Visible = false;
			this.btnShowPersonLicenseHistory.Click += new System.EventHandler(this.btnShowPersonLicenseHistory_Click_1);
			// 
			// lblReleaseTitle
			// 
			this.lblReleaseTitle.Font = new System.Drawing.Font("Palatino Linotype", 33F, System.Drawing.FontStyle.Bold);
			this.lblReleaseTitle.ForeColor = System.Drawing.Color.BlueViolet;
			this.lblReleaseTitle.Location = new System.Drawing.Point(71, 19);
			this.lblReleaseTitle.Name = "lblReleaseTitle";
			this.lblReleaseTitle.Size = new System.Drawing.Size(842, 60);
			this.lblReleaseTitle.TabIndex = 123;
			this.lblReleaseTitle.Text = "Release License";
			this.lblReleaseTitle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// btnReleaseLicense
			// 
			this.btnReleaseLicense.BackColor = System.Drawing.Color.Pink;
			this.btnReleaseLicense.FlatAppearance.BorderColor = System.Drawing.Color.Fuchsia;
			this.btnReleaseLicense.FlatAppearance.BorderSize = 3;
			this.btnReleaseLicense.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnReleaseLicense.Font = new System.Drawing.Font("Microsoft YaHei UI", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnReleaseLicense.ForeColor = System.Drawing.Color.Red;
			this.btnReleaseLicense.Image = global::_02_DVLD_Mine.Properties.Resources.save_27_16;
			this.btnReleaseLicense.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btnReleaseLicense.Location = new System.Drawing.Point(1598, 468);
			this.btnReleaseLicense.Name = "btnReleaseLicense";
			this.btnReleaseLicense.Size = new System.Drawing.Size(108, 53);
			this.btnReleaseLicense.TabIndex = 119;
			this.btnReleaseLicense.Text = "Release";
			this.btnReleaseLicense.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.btnReleaseLicense.UseVisualStyleBackColor = false;
			this.btnReleaseLicense.Visible = false;
			this.btnReleaseLicense.Click += new System.EventHandler(this.btnReleaseLicense_Click);
			// 
			// btnClose
			// 
			this.btnClose.BackColor = System.Drawing.SystemColors.ScrollBar;
			this.btnClose.DialogResult = System.Windows.Forms.DialogResult.Cancel;
			this.btnClose.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
			this.btnClose.FlatAppearance.BorderSize = 2;
			this.btnClose.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnClose.Font = new System.Drawing.Font("Microsoft YaHei UI", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnClose.ForeColor = System.Drawing.Color.Red;
			this.btnClose.Image = global::_02_DVLD_Mine.Properties.Resources.close;
			this.btnClose.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btnClose.Location = new System.Drawing.Point(950, 0);
			this.btnClose.Name = "btnClose";
			this.btnClose.Size = new System.Drawing.Size(63, 53);
			this.btnClose.TabIndex = 117;
			this.btnClose.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.btnClose.UseVisualStyleBackColor = false;
			this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
			// 
			// ReleaseInfo1
			// 
			this.ReleaseInfo1.Location = new System.Drawing.Point(933, 158);
			this.ReleaseInfo1.Name = "ReleaseInfo1";
			this.ReleaseInfo1.Size = new System.Drawing.Size(809, 281);
			this.ReleaseInfo1.TabIndex = 124;
			this.ReleaseInfo1.Visible = false;
			// 
			// FindLocalLicense
			// 
			this.FindLocalLicense.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
			this.FindLocalLicense.Location = new System.Drawing.Point(89, 145);
			this.FindLocalLicense.Name = "FindLocalLicense";
			this.FindLocalLicense.Size = new System.Drawing.Size(809, 163);
			this.FindLocalLicense.TabIndex = 121;
			// 
			// LocalLicenseDetails
			// 
			this.LocalLicenseDetails.Location = new System.Drawing.Point(13, 82);
			this.LocalLicenseDetails.Name = "LocalLicenseDetails";
			this.LocalLicenseDetails.Size = new System.Drawing.Size(908, 570);
			this.LocalLicenseDetails.TabIndex = 122;
			this.LocalLicenseDetails.Visible = false;
			// 
			// frmReleaseLicense
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = System.Drawing.Color.Cyan;
			this.ClientSize = new System.Drawing.Size(1754, 665);
			this.Controls.Add(this.ReleaseInfo1);
			this.Controls.Add(this.btnShowPersonLicenseHistory);
			this.Controls.Add(this.btnReleaseLicense);
			this.Controls.Add(this.lblReleaseTitle);
			this.Controls.Add(this.btnClose);
			this.Controls.Add(this.FindLocalLicense);
			this.Controls.Add(this.LocalLicenseDetails);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
			this.Name = "frmReleaseLicense";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Release License";
			this.ResumeLayout(false);

		}

		#endregion
		private System.Windows.Forms.Button btnShowPersonLicenseHistory;
		private System.Windows.Forms.Button btnReleaseLicense;
		private System.Windows.Forms.Label lblReleaseTitle;
		private System.Windows.Forms.Button btnClose;
		private userControls._04_ucLicenses._03_ucFindLDL FindLocalLicense;
		private userControls._04_ucLicenses._01_ucLicenseDetails LocalLicenseDetails;
		private userControls._05_ucDetain._02_ucReleaseInfo ReleaseInfo1;
	}
}