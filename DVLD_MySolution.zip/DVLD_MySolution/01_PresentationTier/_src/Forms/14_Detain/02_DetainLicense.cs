﻿using System;
using System.Windows.Forms;
using _02_DVLD_Mine._src.Forms._09_Licenses;
using DVLD_Business;

namespace _02_DVLD_Mine._src.Forms._14_Detain
{
	public partial class frmDetainLicense : Form
	{
		public frmDetainLicense()
		{
			InitializeComponent();
			this.Size = new System.Drawing.Size(1013, 395);
			FindLocalLicense.FindFor(userControls._04_ucLicenses._03_ucFindLDL.enFindMode.eDetain);
		}


		private clsBusinessLicenses _License;

		private void FindLocalLicense_OnFound_ReturnLDL_ID(int obj)
		{
			LocalLicenseDetails.LoadLicenseDataByLicenseID(obj);
			DetainInfo1.LoadInfoBeforeFound(obj);
		}
		private void FindLocalLicense_OnFound_ReturnObject(clsBusinessLicenses obj)
		{
			_License = obj;
			this.Size = new System.Drawing.Size(1754, 665);
			lblDetainTitle.Location = new System.Drawing.Point(457, 19);
			this.Location = new System.Drawing.Point(90, 150);

			btnClose.Location = new System.Drawing.Point(1691, 0);

			FindLocalLicense.Visible = false;
			LocalLicenseDetails.Visible = true;

			btnDetainLicense.Visible = true;
			btnShowPersonLicenseHistory.Visible = true;

			DetainInfo1.Visible = true;
		}


		private void txbFees_FocusEnter(object sender, EventArgs e)
		{
			txbFees.Text = "";
		}
		private void mtxbAppTypeFees_KeyPress(object sender, KeyPressEventArgs e)
		{
			if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && e.KeyChar != ',' && e.KeyChar != '.')
			{
				e.Handled = true;
			}

			if ((e.KeyChar == ',' || e.KeyChar == '.') && (sender as TextBox).Text.IndexOfAny(new char[] { ',', '.' }) > -1)
			{
				e.Handled = true;
			}
		}


		private void btnDetainLicense_Click(object sender, System.EventArgs e)
		{
			if (string.IsNullOrEmpty(txbFees.Text) || txbFees.Text == "...")
			{ txbFees.Focus(); return; }

			clsBusinessDetainedLicenses newDetainRecord = new clsBusinessDetainedLicenses();

			newDetainRecord.LicenseID = _License.LicenseID;
			newDetainRecord.DetainDate = DateTime.Now;
			newDetainRecord.FineFees = Convert.ToDecimal(txbFees.Text);
			newDetainRecord.CreatedByUserID = clsGlobal.currentUser.userID;

			if (newDetainRecord.Save())
			{
				MessageBox.Show("Data Saved Successfully.");
				LocalLicenseDetails.LoadLicenseDataByLicenseID(_License.LicenseID);
				DetainInfo1.LoadAfterDetainLicense(newDetainRecord.DetainID);
				txbFees.Visible = false;
			}
			else
				MessageBox.Show("Somthing Went Wrong With Creating New License!", "Error!", MessageBoxButtons.OK, MessageBoxIcon.Error);

			btnDetainLicense.Enabled = false;
		}


		private void btnShowPersonLicenseHistory_Click_1(object sender, EventArgs e)
		{
			Form frm = new frmLicensesHistory(clsBusinessDrivers.Find(_License.DriverID).PersonID);
			frm.ShowDialog();
		}
		private void btnClose_Click(object sender, System.EventArgs e)
		{
			this.Close();
		}
	}
}
