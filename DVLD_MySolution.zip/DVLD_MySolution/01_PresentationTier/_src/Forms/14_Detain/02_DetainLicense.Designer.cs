﻿namespace _02_DVLD_Mine._src.Forms._14_Detain
{
	partial class frmDetainLicense
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.btnShowPersonLicenseHistory = new System.Windows.Forms.Button();
			this.btnDetainLicense = new System.Windows.Forms.Button();
			this.lblDetainTitle = new System.Windows.Forms.Label();
			this.btnClose = new System.Windows.Forms.Button();
			this.FindLocalLicense = new _02_DVLD_Mine._src.userControls._04_ucLicenses._03_ucFindLDL();
			this.LocalLicenseDetails = new _02_DVLD_Mine._src.userControls._04_ucLicenses._01_ucLicenseDetails();
			this.DetainInfo1 = new _02_DVLD_Mine._src.userControls._05_ucDetain._01_ucDetainInfo();
			this.txbFees = new System.Windows.Forms.TextBox();
			this.SuspendLayout();
			// 
			// btnShowPersonLicenseHistory
			// 
			this.btnShowPersonLicenseHistory.BackColor = System.Drawing.Color.PaleTurquoise;
			this.btnShowPersonLicenseHistory.FlatAppearance.BorderColor = System.Drawing.Color.DeepSkyBlue;
			this.btnShowPersonLicenseHistory.FlatAppearance.BorderSize = 3;
			this.btnShowPersonLicenseHistory.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnShowPersonLicenseHistory.Font = new System.Drawing.Font("Modern No. 20", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnShowPersonLicenseHistory.Location = new System.Drawing.Point(989, 451);
			this.btnShowPersonLicenseHistory.Name = "btnShowPersonLicenseHistory";
			this.btnShowPersonLicenseHistory.Size = new System.Drawing.Size(257, 40);
			this.btnShowPersonLicenseHistory.TabIndex = 109;
			this.btnShowPersonLicenseHistory.Text = "Show Person Licenses History";
			this.btnShowPersonLicenseHistory.UseVisualStyleBackColor = false;
			this.btnShowPersonLicenseHistory.Visible = false;
			this.btnShowPersonLicenseHistory.Click += new System.EventHandler(this.btnShowPersonLicenseHistory_Click_1);
			// 
			// btnDetainLicense
			// 
			this.btnDetainLicense.BackColor = System.Drawing.Color.Pink;
			this.btnDetainLicense.FlatAppearance.BorderColor = System.Drawing.Color.Fuchsia;
			this.btnDetainLicense.FlatAppearance.BorderSize = 3;
			this.btnDetainLicense.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnDetainLicense.Font = new System.Drawing.Font("Microsoft YaHei UI", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnDetainLicense.ForeColor = System.Drawing.Color.Red;
			this.btnDetainLicense.Image = global::_02_DVLD_Mine.Properties.Resources.save_27_16;
			this.btnDetainLicense.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btnDetainLicense.Location = new System.Drawing.Point(1599, 445);
			this.btnDetainLicense.Name = "btnDetainLicense";
			this.btnDetainLicense.Size = new System.Drawing.Size(108, 53);
			this.btnDetainLicense.TabIndex = 110;
			this.btnDetainLicense.Text = "Detain";
			this.btnDetainLicense.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.btnDetainLicense.UseVisualStyleBackColor = false;
			this.btnDetainLicense.Visible = false;
			this.btnDetainLicense.Click += new System.EventHandler(this.btnDetainLicense_Click);
			// 
			// lblDetainTitle
			// 
			this.lblDetainTitle.Font = new System.Drawing.Font("Palatino Linotype", 33F, System.Drawing.FontStyle.Bold);
			this.lblDetainTitle.ForeColor = System.Drawing.Color.BlueViolet;
			this.lblDetainTitle.Location = new System.Drawing.Point(71, 19);
			this.lblDetainTitle.Name = "lblDetainTitle";
			this.lblDetainTitle.Size = new System.Drawing.Size(842, 60);
			this.lblDetainTitle.TabIndex = 114;
			this.lblDetainTitle.Text = "Detain License";
			this.lblDetainTitle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// btnClose
			// 
			this.btnClose.BackColor = System.Drawing.SystemColors.ScrollBar;
			this.btnClose.DialogResult = System.Windows.Forms.DialogResult.Cancel;
			this.btnClose.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
			this.btnClose.FlatAppearance.BorderSize = 2;
			this.btnClose.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnClose.Font = new System.Drawing.Font("Microsoft YaHei UI", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnClose.ForeColor = System.Drawing.Color.Red;
			this.btnClose.Image = global::_02_DVLD_Mine.Properties.Resources.close;
			this.btnClose.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btnClose.Location = new System.Drawing.Point(950, 0);
			this.btnClose.Name = "btnClose";
			this.btnClose.Size = new System.Drawing.Size(63, 53);
			this.btnClose.TabIndex = 106;
			this.btnClose.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.btnClose.UseVisualStyleBackColor = false;
			this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
			// 
			// FindLocalLicense
			// 
			this.FindLocalLicense.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
			this.FindLocalLicense.Location = new System.Drawing.Point(89, 145);
			this.FindLocalLicense.Name = "FindLocalLicense";
			this.FindLocalLicense.Size = new System.Drawing.Size(809, 163);
			this.FindLocalLicense.TabIndex = 112;
			this.FindLocalLicense.OnFound_ReturnLDL_ID += new System.Action<int>(this.FindLocalLicense_OnFound_ReturnLDL_ID);
			this.FindLocalLicense.OnFound_ReturnObject += new System.Action<DVLD_Business.clsBusinessLicenses>(this.FindLocalLicense_OnFound_ReturnObject);
			// 
			// LocalLicenseDetails
			// 
			this.LocalLicenseDetails.Location = new System.Drawing.Point(13, 82);
			this.LocalLicenseDetails.Name = "LocalLicenseDetails";
			this.LocalLicenseDetails.Size = new System.Drawing.Size(908, 570);
			this.LocalLicenseDetails.TabIndex = 113;
			this.LocalLicenseDetails.Visible = false;
			// 
			// DetainInfo1
			// 
			this.DetainInfo1.Location = new System.Drawing.Point(933, 211);
			this.DetainInfo1.Name = "DetainInfo1";
			this.DetainInfo1.Size = new System.Drawing.Size(809, 211);
			this.DetainInfo1.TabIndex = 115;
			this.DetainInfo1.Visible = false;
			// 
			// txbFees
			// 
			this.txbFees.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
			this.txbFees.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.txbFees.Font = new System.Drawing.Font("Palatino Linotype", 20F, System.Drawing.FontStyle.Bold);
			this.txbFees.Location = new System.Drawing.Point(1469, 277);
			this.txbFees.Name = "txbFees";
			this.txbFees.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
			this.txbFees.Size = new System.Drawing.Size(238, 43);
			this.txbFees.TabIndex = 116;
			this.txbFees.Text = "...";
			this.txbFees.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			this.txbFees.Enter += new System.EventHandler(this.txbFees_FocusEnter);
			this.txbFees.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.mtxbAppTypeFees_KeyPress);
			// 
			// frmDetainLicense
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = System.Drawing.Color.Turquoise;
			this.ClientSize = new System.Drawing.Size(1754, 665);
			this.Controls.Add(this.txbFees);
			this.Controls.Add(this.DetainInfo1);
			this.Controls.Add(this.btnShowPersonLicenseHistory);
			this.Controls.Add(this.btnDetainLicense);
			this.Controls.Add(this.lblDetainTitle);
			this.Controls.Add(this.btnClose);
			this.Controls.Add(this.FindLocalLicense);
			this.Controls.Add(this.LocalLicenseDetails);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
			this.Name = "frmDetainLicense";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "_02_DetainLicense";
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion
		private System.Windows.Forms.Button btnShowPersonLicenseHistory;
		private System.Windows.Forms.Button btnDetainLicense;
		private System.Windows.Forms.Label lblDetainTitle;
		private System.Windows.Forms.Button btnClose;
		private userControls._04_ucLicenses._03_ucFindLDL FindLocalLicense;
		private userControls._04_ucLicenses._01_ucLicenseDetails LocalLicenseDetails;
		private userControls._05_ucDetain._01_ucDetainInfo DetainInfo1;
		private System.Windows.Forms.TextBox txbFees;
	}
}