﻿using System;
using System.Windows.Forms;
using _02_DVLD_Mine._src.Forms._09_Licenses;
using DVLD_Business;

namespace _02_DVLD_Mine._src.Forms._14_Detain
{
	public partial class frmReleaseLicense : Form
	{
		public frmReleaseLicense()
		{
			InitializeComponent();
			this.Size = new System.Drawing.Size(1013, 395);
			FindLocalLicense.FindFor(userControls._04_ucLicenses._03_ucFindLDL.enFindMode.eRelease);
		}

		public frmReleaseLicense(int licenseID)
		{
			InitializeComponent();
			FindLocalLicense_OnFound_ReturnObject(clsBusinessLicenses.FindByLicenseID(licenseID));
		}


		private clsBusinessLicenses _License;

		private void FindLocalLicense_OnFound_ReturnObject(clsBusinessLicenses obj)
		{
			_License = obj;
			LocalLicenseDetails.LoadLicenseDataByLicenseID(_License.LicenseID);
			this.Size = new System.Drawing.Size(1754, 665);
			lblReleaseTitle.Location = new System.Drawing.Point(457, 19);
			this.Location = new System.Drawing.Point(90, 150);

			btnClose.Location = new System.Drawing.Point(1691, 0);

			FindLocalLicense.Visible = false;
			LocalLicenseDetails.Visible = true;

			btnReleaseLicense.Visible = true;
			btnShowPersonLicenseHistory.Visible = true;

			ReleaseInfo1.Visible = true;
			ReleaseInfo1.LoadDetainInfo(_License.LicenseID);
		}


		private void btnReleaseLicense_Click(object sender, EventArgs e)
		{
			ReleaseInfo1.ReleaseLicense();
			LocalLicenseDetails.LoadLicenseDataByLicenseID(_License.LicenseID);
			btnReleaseLicense.Enabled = false;
		}


		private void btnShowPersonLicenseHistory_Click_1(object sender, EventArgs e)
		{
			Form frm = new frmLicensesHistory(clsBusinessDrivers.Find(_License.DriverID).PersonID);
			frm.ShowDialog();
		}
		private void btnClose_Click(object sender, System.EventArgs e)
		{
			this.Close();
		}
	}
}
