﻿namespace _02_DVLD_Mine._src.Forms._14_Detain
{
	partial class frmManageDetainedL
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
			this.cbStatus = new System.Windows.Forms.ComboBox();
			this.lblFilterBy = new System.Windows.Forms.Label();
			this.mtxbFilter = new System.Windows.Forms.MaskedTextBox();
			this.lblTotalDetainedL = new System.Windows.Forms.Label();
			this.cbFilterBy = new System.Windows.Forms.ComboBox();
			this.dgvDetainLicenses = new System.Windows.Forms.DataGridView();
			this.cmsDetainedL = new System.Windows.Forms.ContextMenuStrip(this.components);
			this.tsmiShowLicense = new System.Windows.Forms.ToolStripMenuItem();
			this.tsmiPersonDL_History = new System.Windows.Forms.ToolStripMenuItem();
			this.tsmiLine1 = new System.Windows.Forms.ToolStripSeparator();
			this.tsmiReleaseDetainedL = new System.Windows.Forms.ToolStripMenuItem();
			this.label1 = new System.Windows.Forms.Label();
			this.btnReleaseLicense = new System.Windows.Forms.Button();
			this.btnDetainLicense = new System.Windows.Forms.Button();
			this.btnClose = new System.Windows.Forms.Button();
			this.tsmiShowPersonDetails = new System.Windows.Forms.ToolStripMenuItem();
			((System.ComponentModel.ISupportInitialize)(this.dgvDetainLicenses)).BeginInit();
			this.cmsDetainedL.SuspendLayout();
			this.SuspendLayout();
			// 
			// cbStatus
			// 
			this.cbStatus.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.cbStatus.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.cbStatus.FormattingEnabled = true;
			this.cbStatus.ItemHeight = 18;
			this.cbStatus.Items.AddRange(new object[] {
            "Detained",
            "Released"});
			this.cbStatus.Location = new System.Drawing.Point(347, 228);
			this.cbStatus.Name = "cbStatus";
			this.cbStatus.Size = new System.Drawing.Size(223, 26);
			this.cbStatus.TabIndex = 0;
			this.cbStatus.TabStop = false;
			this.cbStatus.Visible = false;
			this.cbStatus.DropDownClosed += new System.EventHandler(this.cbStatus_DropDownClosed);
			// 
			// lblFilterBy
			// 
			this.lblFilterBy.AutoSize = true;
			this.lblFilterBy.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblFilterBy.Location = new System.Drawing.Point(23, 227);
			this.lblFilterBy.Name = "lblFilterBy";
			this.lblFilterBy.Size = new System.Drawing.Size(86, 22);
			this.lblFilterBy.TabIndex = 81;
			this.lblFilterBy.Text = "Filter By :";
			// 
			// mtxbFilter
			// 
			this.mtxbFilter.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.mtxbFilter.Location = new System.Drawing.Point(347, 228);
			this.mtxbFilter.Name = "mtxbFilter";
			this.mtxbFilter.Size = new System.Drawing.Size(223, 26);
			this.mtxbFilter.TabIndex = 3;
			this.mtxbFilter.Visible = false;
			this.mtxbFilter.TextChanged += new System.EventHandler(this.mtxbFilter_TextChanged);
			// 
			// lblTotalDetainedL
			// 
			this.lblTotalDetainedL.AutoSize = true;
			this.lblTotalDetainedL.Font = new System.Drawing.Font("Mongolian Baiti", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblTotalDetainedL.Location = new System.Drawing.Point(39, 610);
			this.lblTotalDetainedL.Name = "lblTotalDetainedL";
			this.lblTotalDetainedL.Size = new System.Drawing.Size(269, 25);
			this.lblTotalDetainedL.TabIndex = 80;
			this.lblTotalDetainedL.Text = "Total Detianed Licenses";
			// 
			// cbFilterBy
			// 
			this.cbFilterBy.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.cbFilterBy.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.cbFilterBy.FormattingEnabled = true;
			this.cbFilterBy.ItemHeight = 18;
			this.cbFilterBy.Location = new System.Drawing.Point(115, 228);
			this.cbFilterBy.Name = "cbFilterBy";
			this.cbFilterBy.Size = new System.Drawing.Size(223, 26);
			this.cbFilterBy.TabIndex = 0;
			this.cbFilterBy.TabStop = false;
			this.cbFilterBy.SelectedIndexChanged += new System.EventHandler(this.cbFilterBy_SelectedIndexChanged);
			// 
			// dgvDetainLicenses
			// 
			this.dgvDetainLicenses.AllowUserToAddRows = false;
			this.dgvDetainLicenses.AllowUserToDeleteRows = false;
			this.dgvDetainLicenses.AllowUserToOrderColumns = true;
			this.dgvDetainLicenses.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
			this.dgvDetainLicenses.BackgroundColor = System.Drawing.SystemColors.GradientInactiveCaption;
			dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
			dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
			dataGridViewCellStyle1.Font = new System.Drawing.Font("Viner Hand ITC", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
			dataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.Aqua;
			dataGridViewCellStyle1.SelectionForeColor = System.Drawing.Color.Violet;
			dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
			this.dgvDetainLicenses.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
			this.dgvDetainLicenses.ColumnHeadersHeight = 50;
			this.dgvDetainLicenses.ContextMenuStrip = this.cmsDetainedL;
			dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
			dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
			dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
			dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.SkyBlue;
			dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.ControlText;
			dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
			this.dgvDetainLicenses.DefaultCellStyle = dataGridViewCellStyle2;
			this.dgvDetainLicenses.Location = new System.Drawing.Point(15, 267);
			this.dgvDetainLicenses.Name = "dgvDetainLicenses";
			this.dgvDetainLicenses.ReadOnly = true;
			this.dgvDetainLicenses.RowHeadersWidth = 35;
			this.dgvDetainLicenses.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
			this.dgvDetainLicenses.Size = new System.Drawing.Size(1339, 321);
			this.dgvDetainLicenses.TabIndex = 0;
			this.dgvDetainLicenses.TabStop = false;
			this.dgvDetainLicenses.CellFormatting += new System.Windows.Forms.DataGridViewCellFormattingEventHandler(this.dgvDetainLicenses_CellFormatting);
			this.dgvDetainLicenses.DoubleClick += new System.EventHandler(this.tsmiShowLicense_Click);
			// 
			// cmsDetainedL
			// 
			this.cmsDetainedL.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsmiShowPersonDetails,
            this.tsmiShowLicense,
            this.tsmiPersonDL_History,
            this.tsmiLine1,
            this.tsmiReleaseDetainedL});
			this.cmsDetainedL.Name = "cmsPeople";
			this.cmsDetainedL.Size = new System.Drawing.Size(254, 170);
			this.cmsDetainedL.Opened += new System.EventHandler(this.cmsDetainedL_Opened);
			// 
			// tsmiShowLicense
			// 
			this.tsmiShowLicense.Font = new System.Drawing.Font("Aldhabi", 17F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.tsmiShowLicense.Name = "tsmiShowLicense";
			this.tsmiShowLicense.Size = new System.Drawing.Size(253, 40);
			this.tsmiShowLicense.Text = "Show License Details";
			this.tsmiShowLicense.TextDirection = System.Windows.Forms.ToolStripTextDirection.Horizontal;
			this.tsmiShowLicense.Click += new System.EventHandler(this.tsmiShowLicense_Click);
			// 
			// tsmiPersonDL_History
			// 
			this.tsmiPersonDL_History.Font = new System.Drawing.Font("Aldhabi", 17F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.tsmiPersonDL_History.Name = "tsmiPersonDL_History";
			this.tsmiPersonDL_History.Size = new System.Drawing.Size(253, 40);
			this.tsmiPersonDL_History.Text = "Show Person License History";
			this.tsmiPersonDL_History.TextDirection = System.Windows.Forms.ToolStripTextDirection.Horizontal;
			this.tsmiPersonDL_History.Click += new System.EventHandler(this.tsmiPersonDL_History_Click);
			// 
			// tsmiLine1
			// 
			this.tsmiLine1.Name = "tsmiLine1";
			this.tsmiLine1.Size = new System.Drawing.Size(250, 6);
			// 
			// tsmiReleaseDetainedL
			// 
			this.tsmiReleaseDetainedL.Enabled = false;
			this.tsmiReleaseDetainedL.Font = new System.Drawing.Font("Aldhabi", 17F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.tsmiReleaseDetainedL.Name = "tsmiReleaseDetainedL";
			this.tsmiReleaseDetainedL.Size = new System.Drawing.Size(253, 40);
			this.tsmiReleaseDetainedL.Text = "Release Detained License";
			this.tsmiReleaseDetainedL.TextDirection = System.Windows.Forms.ToolStripTextDirection.Horizontal;
			this.tsmiReleaseDetainedL.Click += new System.EventHandler(this.tsmiReleaseDetainedL_Click);
			// 
			// label1
			// 
			this.label1.Font = new System.Drawing.Font("Palatino Linotype", 35F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
			this.label1.Location = new System.Drawing.Point(188, 58);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(953, 62);
			this.label1.TabIndex = 79;
			this.label1.Text = "Manage Detained Licenses";
			this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// btnReleaseLicense
			// 
			this.btnReleaseLicense.BackColor = System.Drawing.Color.Cyan;
			this.btnReleaseLicense.FlatAppearance.BorderColor = System.Drawing.Color.DarkOrchid;
			this.btnReleaseLicense.FlatAppearance.BorderSize = 5;
			this.btnReleaseLicense.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnReleaseLicense.Font = new System.Drawing.Font("Modern No. 20", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnReleaseLicense.Image = global::_02_DVLD_Mine.Properties.Resources.pedestrian_traffic_light_stop2__4_;
			this.btnReleaseLicense.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btnReleaseLicense.Location = new System.Drawing.Point(961, 201);
			this.btnReleaseLicense.Name = "btnReleaseLicense";
			this.btnReleaseLicense.Size = new System.Drawing.Size(178, 53);
			this.btnReleaseLicense.TabIndex = 82;
			this.btnReleaseLicense.Text = "R E L E A S E";
			this.btnReleaseLicense.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.btnReleaseLicense.UseVisualStyleBackColor = false;
			this.btnReleaseLicense.Click += new System.EventHandler(this.btnReleaseLicense_Click);
			// 
			// btnDetainLicense
			// 
			this.btnDetainLicense.BackColor = System.Drawing.Color.Turquoise;
			this.btnDetainLicense.FlatAppearance.BorderColor = System.Drawing.Color.MediumOrchid;
			this.btnDetainLicense.FlatAppearance.BorderSize = 5;
			this.btnDetainLicense.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnDetainLicense.Font = new System.Drawing.Font("Modern No. 20", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnDetainLicense.Image = global::_02_DVLD_Mine.Properties.Resources.pedestrian_traffic_light_stop2__3_;
			this.btnDetainLicense.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btnDetainLicense.Location = new System.Drawing.Point(1145, 201);
			this.btnDetainLicense.Name = "btnDetainLicense";
			this.btnDetainLicense.Size = new System.Drawing.Size(165, 53);
			this.btnDetainLicense.TabIndex = 1;
			this.btnDetainLicense.Text = "D E T A I N";
			this.btnDetainLicense.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.btnDetainLicense.UseVisualStyleBackColor = false;
			this.btnDetainLicense.Click += new System.EventHandler(this.btnDetainLicense_Click);
			// 
			// btnClose
			// 
			this.btnClose.BackColor = System.Drawing.SystemColors.ScrollBar;
			this.btnClose.DialogResult = System.Windows.Forms.DialogResult.Cancel;
			this.btnClose.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
			this.btnClose.FlatAppearance.BorderSize = 2;
			this.btnClose.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnClose.Font = new System.Drawing.Font("Microsoft YaHei UI", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnClose.ForeColor = System.Drawing.Color.Red;
			this.btnClose.Image = global::_02_DVLD_Mine.Properties.Resources.close;
			this.btnClose.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btnClose.Location = new System.Drawing.Point(1191, 598);
			this.btnClose.Name = "btnClose";
			this.btnClose.Size = new System.Drawing.Size(119, 53);
			this.btnClose.TabIndex = 0;
			this.btnClose.Text = "Close";
			this.btnClose.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.btnClose.UseVisualStyleBackColor = false;
			this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
			// 
			// tsmiShowPersonDetails
			// 
			this.tsmiShowPersonDetails.Font = new System.Drawing.Font("Aldhabi", 17F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.tsmiShowPersonDetails.Image = global::_02_DVLD_Mine.Properties.Resources.wrap;
			this.tsmiShowPersonDetails.Name = "tsmiShowPersonDetails";
			this.tsmiShowPersonDetails.Size = new System.Drawing.Size(253, 40);
			this.tsmiShowPersonDetails.Text = "Show Person Details";
			this.tsmiShowPersonDetails.TextDirection = System.Windows.Forms.ToolStripTextDirection.Horizontal;
			this.tsmiShowPersonDetails.Click += new System.EventHandler(this.tsmiShowPersonDetails_Click);
			// 
			// frmManageDetainedL
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = System.Drawing.Color.CornflowerBlue;
			this.ClientSize = new System.Drawing.Size(1367, 661);
			this.Controls.Add(this.btnReleaseLicense);
			this.Controls.Add(this.btnDetainLicense);
			this.Controls.Add(this.btnClose);
			this.Controls.Add(this.lblFilterBy);
			this.Controls.Add(this.lblTotalDetainedL);
			this.Controls.Add(this.cbFilterBy);
			this.Controls.Add(this.dgvDetainLicenses);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.mtxbFilter);
			this.Controls.Add(this.cbStatus);
			this.Name = "frmManageDetainedL";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Manage Detained Licenses";
			((System.ComponentModel.ISupportInitialize)(this.dgvDetainLicenses)).EndInit();
			this.cmsDetainedL.ResumeLayout(false);
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.Button btnDetainLicense;
		private System.Windows.Forms.ComboBox cbStatus;
		private System.Windows.Forms.Button btnClose;
		private System.Windows.Forms.Label lblFilterBy;
		private System.Windows.Forms.MaskedTextBox mtxbFilter;
		private System.Windows.Forms.Label lblTotalDetainedL;
		private System.Windows.Forms.ComboBox cbFilterBy;
		private System.Windows.Forms.DataGridView dgvDetainLicenses;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.ContextMenuStrip cmsDetainedL;
		private System.Windows.Forms.ToolStripMenuItem tsmiShowPersonDetails;
		private System.Windows.Forms.ToolStripSeparator tsmiLine1;
		private System.Windows.Forms.ToolStripMenuItem tsmiShowLicense;
		private System.Windows.Forms.ToolStripMenuItem tsmiPersonDL_History;
		private System.Windows.Forms.ToolStripMenuItem tsmiReleaseDetainedL;
		private System.Windows.Forms.Button btnReleaseLicense;
	}
}