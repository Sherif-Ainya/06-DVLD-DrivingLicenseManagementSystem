﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Windows.Forms;
using _02_DVLD_Mine._src.Forms._02_People;
using _02_DVLD_Mine._src.Forms._09_Licenses;
using DVLD_Business;

namespace _02_DVLD_Mine._src.Forms._08_ManageDrivers
{
	public partial class frmManageDrivers : Form
	{
		public frmManageDrivers()
		{
			InitializeComponent();
			_PrepareThisForm();
		}


		private void dgvDrivers_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
		{
			dgvDrivers.ColumnHeadersHeight = 60;
			dgvDrivers.RowTemplate.Height = 30;

			dgvDrivers.Columns[0].Width = 160;
			dgvDrivers.Columns[1].Width = 160;
			dgvDrivers.Columns[3].Width = 170;
			dgvDrivers.Columns[5].Width = 160;

			dgvDrivers.Columns[0].HeaderText = "Driver ID";
			dgvDrivers.Columns[1].HeaderText = "Person ID";
			dgvDrivers.Columns[2].HeaderText = "National No";
			dgvDrivers.Columns[3].HeaderText = "Full Name";
			dgvDrivers.Columns[4].HeaderText = "Date";
			dgvDrivers.Columns[5].HeaderText = "Active Licenses";
		}
		private void _RefreshDrivers()
		{
			mtxbFilter.Text = "";
			mtxbFilter.Visible = false;

			dgvDrivers.SuspendLayout();
			dgvDrivers.DataSource = clsBusinessDrivers.GetAllDrivers();
			dgvDrivers.ResumeLayout();
			lblTotalDrivers.Text = "Total Drivers [" + dgvDrivers.RowCount.ToString() + "].";
		}
		private void _PrepareThisForm()
		{
			_RefreshDrivers();
			cbFilterBy.Items.AddRange(new string[] { "None", "Driver ID", "Person ID", "National No", "Number Of Active Licenses" });
		}



		Dictionary<string, string> columnMapping = new Dictionary<string, string>()
		{
			{"Driver ID", "DriverID" },
			{"Person ID", "PersonID" },
			{"National No", "NationalNo" },
			{"Full Name", "FullName" },
			{"Number Of Active Licenses", "NumberOfActiveLicenses" }
		};
		private void FilterData()
		{
			if (dgvDrivers.DataSource is DataTable dt)
			{
				string searchValue = mtxbFilter.Text.Replace("-", "").Trim();

				string displayName = cbFilterBy.SelectedItem.ToString();
				string actualColumnName = columnMapping[displayName];

				if (!string.IsNullOrEmpty(searchValue))
				{
					if (displayName.EndsWith("ID") || displayName.Contains("Of"))
					{
						string filterExpression = $"{actualColumnName} = {searchValue}";
						dt.DefaultView.RowFilter = filterExpression;
					}
					else
					{
						string filterExpression = $"{actualColumnName} LIKE '%{searchValue}%'";
						dt.DefaultView.RowFilter = filterExpression;
					}
				}
				else
				{
					dt.DefaultView.RowFilter = "";
				}
			}
		}
		private void cbFilterBy_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			mtxbFilter.Visible = false;

			if (cbFilterBy.SelectedItem.ToString() == "None")
			{
				if (dgvDrivers.DataSource is DataTable dt)
				{
					dt.DefaultView.RowFilter = "";
					lblTotalDrivers.Text = "Total Drivers [" + dgvDrivers.RowCount.ToString() + "].";
				}
				return;
			}


			if (cbFilterBy.SelectedItem.ToString().Contains("ID") || cbFilterBy.SelectedIndex == 4)
			{
				mtxbFilter.Mask = "000000";
			}
			else
			{
				mtxbFilter.Mask = "";
			}
			mtxbFilter.Visible = true;
			mtxbFilter.Text = string.Empty;
			mtxbFilter.Focus();
		}
		private void mtxbFilter_TextChanged(object sender, System.EventArgs e)
		{
			FilterData();
			lblTotalDrivers.Text = "# Records [" + dgvDrivers.RowCount.ToString() + "].";
		}


		private void tsmiShowDetails_Click(object sender, EventArgs e)
		{
			Form frm = new frmPersonDetailsN((int)dgvDrivers.CurrentRow.Cells[1].Value);
			frm.ShowDialog();
		}

		private void tsmiPersonDL_History_Click(object sender, EventArgs e)
		{
			int personID = (int)dgvDrivers.CurrentRow.Cells[0].Value;
			Form frm = new frmLicensesHistory(personID);
			frm.ShowDialog();
			_RefreshDrivers();
		}

		private void btnClose_Click(object sender, EventArgs e)
		{
			this.Close();
		}
	}
}
