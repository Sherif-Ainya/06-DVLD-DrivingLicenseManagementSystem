﻿namespace _02_DVLD_Mine._src.Forms._08_ManageDrivers
{
	partial class frmManageDrivers
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
			this.btnClose = new System.Windows.Forms.Button();
			this.lblFilterBy = new System.Windows.Forms.Label();
			this.mtxbFilter = new System.Windows.Forms.MaskedTextBox();
			this.lblTotalDrivers = new System.Windows.Forms.Label();
			this.cbFilterBy = new System.Windows.Forms.ComboBox();
			this.dgvDrivers = new System.Windows.Forms.DataGridView();
			this.cmsShowDetails = new System.Windows.Forms.ContextMenuStrip(this.components);
			this.tsmiShowDetails = new System.Windows.Forms.ToolStripMenuItem();
			this.lblManageDrivers = new System.Windows.Forms.Label();
			this.tsmiPersonDL_History = new System.Windows.Forms.ToolStripMenuItem();
			this.tsmiLine2 = new System.Windows.Forms.ToolStripSeparator();
			((System.ComponentModel.ISupportInitialize)(this.dgvDrivers)).BeginInit();
			this.cmsShowDetails.SuspendLayout();
			this.SuspendLayout();
			// 
			// btnClose
			// 
			this.btnClose.BackColor = System.Drawing.SystemColors.ScrollBar;
			this.btnClose.DialogResult = System.Windows.Forms.DialogResult.Cancel;
			this.btnClose.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
			this.btnClose.FlatAppearance.BorderSize = 2;
			this.btnClose.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnClose.Font = new System.Drawing.Font("Microsoft YaHei UI", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnClose.ForeColor = System.Drawing.Color.Red;
			this.btnClose.Image = global::_02_DVLD_Mine.Properties.Resources.close;
			this.btnClose.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btnClose.Location = new System.Drawing.Point(1094, 596);
			this.btnClose.Name = "btnClose";
			this.btnClose.Size = new System.Drawing.Size(119, 53);
			this.btnClose.TabIndex = 0;
			this.btnClose.Text = "Close";
			this.btnClose.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.btnClose.UseVisualStyleBackColor = false;
			this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
			// 
			// lblFilterBy
			// 
			this.lblFilterBy.AutoSize = true;
			this.lblFilterBy.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblFilterBy.Location = new System.Drawing.Point(23, 225);
			this.lblFilterBy.Name = "lblFilterBy";
			this.lblFilterBy.Size = new System.Drawing.Size(86, 22);
			this.lblFilterBy.TabIndex = 72;
			this.lblFilterBy.Text = "Filter By :";
			// 
			// mtxbFilter
			// 
			this.mtxbFilter.AsciiOnly = true;
			this.mtxbFilter.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.mtxbFilter.Location = new System.Drawing.Point(345, 223);
			this.mtxbFilter.Name = "mtxbFilter";
			this.mtxbFilter.Size = new System.Drawing.Size(211, 26);
			this.mtxbFilter.TabIndex = 1;
			this.mtxbFilter.Visible = false;
			this.mtxbFilter.TextChanged += new System.EventHandler(this.mtxbFilter_TextChanged);
			// 
			// lblTotalDrivers
			// 
			this.lblTotalDrivers.AutoSize = true;
			this.lblTotalDrivers.Font = new System.Drawing.Font("Mongolian Baiti", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblTotalDrivers.Location = new System.Drawing.Point(39, 608);
			this.lblTotalDrivers.Name = "lblTotalDrivers";
			this.lblTotalDrivers.Size = new System.Drawing.Size(153, 25);
			this.lblTotalDrivers.TabIndex = 70;
			this.lblTotalDrivers.Text = "Total Drivers";
			// 
			// cbFilterBy
			// 
			this.cbFilterBy.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.cbFilterBy.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.cbFilterBy.FormattingEnabled = true;
			this.cbFilterBy.ItemHeight = 18;
			this.cbFilterBy.Location = new System.Drawing.Point(115, 223);
			this.cbFilterBy.Name = "cbFilterBy";
			this.cbFilterBy.Size = new System.Drawing.Size(223, 26);
			this.cbFilterBy.TabIndex = 1;
			this.cbFilterBy.TabStop = false;
			this.cbFilterBy.SelectedIndexChanged += new System.EventHandler(this.cbFilterBy_SelectedIndexChanged);
			// 
			// dgvDrivers
			// 
			this.dgvDrivers.AllowUserToAddRows = false;
			this.dgvDrivers.AllowUserToDeleteRows = false;
			this.dgvDrivers.AllowUserToOrderColumns = true;
			this.dgvDrivers.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
			this.dgvDrivers.BackgroundColor = System.Drawing.SystemColors.GradientInactiveCaption;
			dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
			dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
			dataGridViewCellStyle1.Font = new System.Drawing.Font("Viner Hand ITC", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
			dataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.Aqua;
			dataGridViewCellStyle1.SelectionForeColor = System.Drawing.Color.Violet;
			dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
			this.dgvDrivers.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
			this.dgvDrivers.ColumnHeadersHeight = 50;
			this.dgvDrivers.ContextMenuStrip = this.cmsShowDetails;
			dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
			dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
			dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
			dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.MistyRose;
			dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.ControlText;
			dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
			this.dgvDrivers.DefaultCellStyle = dataGridViewCellStyle2;
			this.dgvDrivers.Location = new System.Drawing.Point(15, 265);
			this.dgvDrivers.Name = "dgvDrivers";
			this.dgvDrivers.ReadOnly = true;
			this.dgvDrivers.RowHeadersWidth = 35;
			this.dgvDrivers.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
			this.dgvDrivers.Size = new System.Drawing.Size(1226, 321);
			this.dgvDrivers.TabIndex = 0;
			this.dgvDrivers.TabStop = false;
			this.dgvDrivers.CellFormatting += new System.Windows.Forms.DataGridViewCellFormattingEventHandler(this.dgvDrivers_CellFormatting);
			// 
			// cmsShowDetails
			// 
			this.cmsShowDetails.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsmiShowDetails,
            this.tsmiLine2,
            this.tsmiPersonDL_History});
			this.cmsShowDetails.Name = "cmsPeople";
			this.cmsShowDetails.Size = new System.Drawing.Size(254, 112);
			// 
			// tsmiShowDetails
			// 
			this.tsmiShowDetails.Font = new System.Drawing.Font("Aldhabi", 17F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.tsmiShowDetails.Image = global::_02_DVLD_Mine.Properties.Resources.wrap;
			this.tsmiShowDetails.Name = "tsmiShowDetails";
			this.tsmiShowDetails.Size = new System.Drawing.Size(253, 40);
			this.tsmiShowDetails.Text = "Show Details";
			this.tsmiShowDetails.TextDirection = System.Windows.Forms.ToolStripTextDirection.Horizontal;
			this.tsmiShowDetails.Click += new System.EventHandler(this.tsmiShowDetails_Click);
			// 
			// lblManageDrivers
			// 
			this.lblManageDrivers.AutoSize = true;
			this.lblManageDrivers.Font = new System.Drawing.Font("Palatino Linotype", 48F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblManageDrivers.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
			this.lblManageDrivers.Location = new System.Drawing.Point(330, 47);
			this.lblManageDrivers.Name = "lblManageDrivers";
			this.lblManageDrivers.Size = new System.Drawing.Size(493, 85);
			this.lblManageDrivers.TabIndex = 67;
			this.lblManageDrivers.Text = "Manage Drivers";
			// 
			// tsmiPersonDL_History
			// 
			this.tsmiPersonDL_History.Font = new System.Drawing.Font("Aldhabi", 17F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.tsmiPersonDL_History.Name = "tsmiPersonDL_History";
			this.tsmiPersonDL_History.Size = new System.Drawing.Size(253, 40);
			this.tsmiPersonDL_History.Text = "Show Person License History";
			this.tsmiPersonDL_History.TextDirection = System.Windows.Forms.ToolStripTextDirection.Horizontal;
			this.tsmiPersonDL_History.Click += new System.EventHandler(this.tsmiPersonDL_History_Click);
			// 
			// tsmiLine2
			// 
			this.tsmiLine2.Name = "tsmiLine2";
			this.tsmiLine2.Size = new System.Drawing.Size(250, 6);
			// 
			// frmManageDrivers
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = System.Drawing.Color.SlateBlue;
			this.CancelButton = this.btnClose;
			this.ClientSize = new System.Drawing.Size(1254, 661);
			this.Controls.Add(this.btnClose);
			this.Controls.Add(this.lblFilterBy);
			this.Controls.Add(this.mtxbFilter);
			this.Controls.Add(this.lblTotalDrivers);
			this.Controls.Add(this.cbFilterBy);
			this.Controls.Add(this.dgvDrivers);
			this.Controls.Add(this.lblManageDrivers);
			this.Name = "frmManageDrivers";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Manage Drivers";
			((System.ComponentModel.ISupportInitialize)(this.dgvDrivers)).EndInit();
			this.cmsShowDetails.ResumeLayout(false);
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion
		private System.Windows.Forms.Button btnClose;
		private System.Windows.Forms.Label lblFilterBy;
		private System.Windows.Forms.MaskedTextBox mtxbFilter;
		private System.Windows.Forms.Label lblTotalDrivers;
		private System.Windows.Forms.ComboBox cbFilterBy;
		private System.Windows.Forms.DataGridView dgvDrivers;
		private System.Windows.Forms.Label lblManageDrivers;
		private System.Windows.Forms.ContextMenuStrip cmsShowDetails;
		private System.Windows.Forms.ToolStripMenuItem tsmiShowDetails;
		private System.Windows.Forms.ToolStripMenuItem tsmiPersonDL_History;
		private System.Windows.Forms.ToolStripSeparator tsmiLine2;
	}
}