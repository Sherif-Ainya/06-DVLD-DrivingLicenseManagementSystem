﻿namespace _02_DVLD_Mine._src.Forms._06_LicenseClasses
{
	partial class frmUpdateLicenseClass
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.txbLicenseClassDescription = new System.Windows.Forms.TextBox();
			this._lblLicenseClassDescription = new System.Windows.Forms.Label();
			this.txbLicenseClassFees = new System.Windows.Forms.TextBox();
			this.lblUpdateTestType = new System.Windows.Forms.Label();
			this.lblLicenseClassID = new System.Windows.Forms.Label();
			this._lblLicenseClassFees = new System.Windows.Forms.Label();
			this.txbLicenseClassTitle = new System.Windows.Forms.TextBox();
			this._lblLicenseClassTitle = new System.Windows.Forms.Label();
			this.btnClose = new System.Windows.Forms.Button();
			this.btnSave = new System.Windows.Forms.Button();
			this.txbMinimumAge = new System.Windows.Forms.TextBox();
			this._lblMinimumAge = new System.Windows.Forms.Label();
			this.txbDefaultValidity = new System.Windows.Forms.TextBox();
			this._lblDefaultValidity = new System.Windows.Forms.Label();
			this.SuspendLayout();
			// 
			// txbLicenseClassDescription
			// 
			this.txbLicenseClassDescription.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.txbLicenseClassDescription.Location = new System.Drawing.Point(247, 158);
			this.txbLicenseClassDescription.Multiline = true;
			this.txbLicenseClassDescription.Name = "txbLicenseClassDescription";
			this.txbLicenseClassDescription.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
			this.txbLicenseClassDescription.Size = new System.Drawing.Size(439, 98);
			this.txbLicenseClassDescription.TabIndex = 127;
			this.txbLicenseClassDescription.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			// 
			// _lblLicenseClassDescription
			// 
			this._lblLicenseClassDescription.AutoSize = true;
			this._lblLicenseClassDescription.Font = new System.Drawing.Font("Palatino Linotype", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this._lblLicenseClassDescription.Location = new System.Drawing.Point(86, 187);
			this._lblLicenseClassDescription.Name = "_lblLicenseClassDescription";
			this._lblLicenseClassDescription.Size = new System.Drawing.Size(149, 29);
			this._lblLicenseClassDescription.TabIndex = 134;
			this._lblLicenseClassDescription.Text = "Description  :";
			// 
			// txbLicenseClassFees
			// 
			this.txbLicenseClassFees.Font = new System.Drawing.Font("Microsoft Sans Serif", 17F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.txbLicenseClassFees.Location = new System.Drawing.Point(362, 358);
			this.txbLicenseClassFees.Name = "txbLicenseClassFees";
			this.txbLicenseClassFees.Size = new System.Drawing.Size(199, 33);
			this.txbLicenseClassFees.TabIndex = 128;
			this.txbLicenseClassFees.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			this.txbLicenseClassFees.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.mtxbClassFees_KeyPress);
			// 
			// lblUpdateTestType
			// 
			this.lblUpdateTestType.AutoSize = true;
			this.lblUpdateTestType.Font = new System.Drawing.Font("Palatino Linotype", 25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblUpdateTestType.ForeColor = System.Drawing.Color.Navy;
			this.lblUpdateTestType.Location = new System.Drawing.Point(239, 25);
			this.lblUpdateTestType.Name = "lblUpdateTestType";
			this.lblUpdateTestType.Size = new System.Drawing.Size(351, 46);
			this.lblUpdateTestType.TabIndex = 133;
			this.lblUpdateTestType.Text = "Update License Class";
			// 
			// lblLicenseClassID
			// 
			this.lblLicenseClassID.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
			this.lblLicenseClassID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.lblLicenseClassID.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblLicenseClassID.ForeColor = System.Drawing.Color.Red;
			this.lblLicenseClassID.Location = new System.Drawing.Point(423, 401);
			this.lblLicenseClassID.Name = "lblLicenseClassID";
			this.lblLicenseClassID.Size = new System.Drawing.Size(73, 41);
			this.lblLicenseClassID.TabIndex = 132;
			this.lblLicenseClassID.Text = "-1";
			this.lblLicenseClassID.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// _lblLicenseClassFees
			// 
			this._lblLicenseClassFees.AutoSize = true;
			this._lblLicenseClassFees.Font = new System.Drawing.Font("Palatino Linotype", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this._lblLicenseClassFees.Location = new System.Drawing.Point(116, 362);
			this._lblLicenseClassFees.Name = "_lblLicenseClassFees";
			this._lblLicenseClassFees.Size = new System.Drawing.Size(75, 29);
			this._lblLicenseClassFees.TabIndex = 131;
			this._lblLicenseClassFees.Text = "Fees  :";
			// 
			// txbLicenseClassTitle
			// 
			this.txbLicenseClassTitle.Enabled = false;
			this.txbLicenseClassTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.txbLicenseClassTitle.Location = new System.Drawing.Point(285, 114);
			this.txbLicenseClassTitle.Name = "txbLicenseClassTitle";
			this.txbLicenseClassTitle.Size = new System.Drawing.Size(372, 27);
			this.txbLicenseClassTitle.TabIndex = 126;
			this.txbLicenseClassTitle.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			// 
			// _lblLicenseClassTitle
			// 
			this._lblLicenseClassTitle.AutoSize = true;
			this._lblLicenseClassTitle.Font = new System.Drawing.Font("Palatino Linotype", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this._lblLicenseClassTitle.Location = new System.Drawing.Point(116, 114);
			this._lblLicenseClassTitle.Name = "_lblLicenseClassTitle";
			this._lblLicenseClassTitle.Size = new System.Drawing.Size(78, 29);
			this._lblLicenseClassTitle.TabIndex = 130;
			this._lblLicenseClassTitle.Text = "Title  :";
			// 
			// btnClose
			// 
			this.btnClose.BackColor = System.Drawing.Color.Pink;
			this.btnClose.FlatAppearance.BorderColor = System.Drawing.Color.Cyan;
			this.btnClose.FlatAppearance.BorderSize = 3;
			this.btnClose.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
			this.btnClose.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
			this.btnClose.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnClose.Font = new System.Drawing.Font("Microsoft YaHei UI", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnClose.ForeColor = System.Drawing.Color.Red;
			this.btnClose.Image = global::_02_DVLD_Mine.Properties.Resources.close1;
			this.btnClose.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btnClose.Location = new System.Drawing.Point(730, 396);
			this.btnClose.Name = "btnClose";
			this.btnClose.Size = new System.Drawing.Size(62, 52);
			this.btnClose.TabIndex = 125;
			this.btnClose.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.btnClose.UseVisualStyleBackColor = false;
			this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
			// 
			// btnSave
			// 
			this.btnSave.BackColor = System.Drawing.Color.Pink;
			this.btnSave.FlatAppearance.BorderColor = System.Drawing.Color.Cyan;
			this.btnSave.FlatAppearance.BorderSize = 3;
			this.btnSave.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
			this.btnSave.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
			this.btnSave.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnSave.Font = new System.Drawing.Font("Microsoft YaHei UI", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnSave.ForeColor = System.Drawing.Color.DarkOrchid;
			this.btnSave.Image = global::_02_DVLD_Mine.Properties.Resources.save_27_16;
			this.btnSave.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btnSave.Location = new System.Drawing.Point(628, 396);
			this.btnSave.Name = "btnSave";
			this.btnSave.Size = new System.Drawing.Size(100, 52);
			this.btnSave.TabIndex = 129;
			this.btnSave.Text = "SAVE";
			this.btnSave.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.btnSave.UseVisualStyleBackColor = false;
			this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
			// 
			// txbMinimumAge
			// 
			this.txbMinimumAge.Font = new System.Drawing.Font("Microsoft Sans Serif", 17F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.txbMinimumAge.Location = new System.Drawing.Point(338, 272);
			this.txbMinimumAge.Name = "txbMinimumAge";
			this.txbMinimumAge.Size = new System.Drawing.Size(252, 33);
			this.txbMinimumAge.TabIndex = 135;
			this.txbMinimumAge.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			this.txbMinimumAge.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txbMinimumAge_KeyPress);
			// 
			// _lblMinimumAge
			// 
			this._lblMinimumAge.AutoSize = true;
			this._lblMinimumAge.Font = new System.Drawing.Font("Palatino Linotype", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this._lblMinimumAge.Location = new System.Drawing.Point(27, 276);
			this._lblMinimumAge.Name = "_lblMinimumAge";
			this._lblMinimumAge.Size = new System.Drawing.Size(268, 29);
			this._lblMinimumAge.TabIndex = 136;
			this._lblMinimumAge.Text = "Minimum Allowed Age  :";
			// 
			// txbDefaultValidity
			// 
			this.txbDefaultValidity.Font = new System.Drawing.Font("Microsoft Sans Serif", 17F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.txbDefaultValidity.Location = new System.Drawing.Point(338, 312);
			this.txbDefaultValidity.Name = "txbDefaultValidity";
			this.txbDefaultValidity.Size = new System.Drawing.Size(252, 33);
			this.txbDefaultValidity.TabIndex = 137;
			this.txbDefaultValidity.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			this.txbDefaultValidity.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txbMinimumAge_KeyPress);
			// 
			// _lblDefaultValidity
			// 
			this._lblDefaultValidity.AutoSize = true;
			this._lblDefaultValidity.Font = new System.Drawing.Font("Palatino Linotype", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this._lblDefaultValidity.Location = new System.Drawing.Point(27, 320);
			this._lblDefaultValidity.Name = "_lblDefaultValidity";
			this._lblDefaultValidity.Size = new System.Drawing.Size(264, 29);
			this._lblDefaultValidity.TabIndex = 138;
			this._lblDefaultValidity.Text = "Default Validity Length :";
			// 
			// frmUpdateLicenseClass
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = System.Drawing.SystemColors.InactiveCaption;
			this.CancelButton = this.btnClose;
			this.ClientSize = new System.Drawing.Size(800, 450);
			this.Controls.Add(this.txbDefaultValidity);
			this.Controls.Add(this._lblDefaultValidity);
			this.Controls.Add(this.txbMinimumAge);
			this.Controls.Add(this._lblMinimumAge);
			this.Controls.Add(this.txbLicenseClassDescription);
			this.Controls.Add(this._lblLicenseClassDescription);
			this.Controls.Add(this.txbLicenseClassFees);
			this.Controls.Add(this.lblUpdateTestType);
			this.Controls.Add(this.lblLicenseClassID);
			this.Controls.Add(this._lblLicenseClassFees);
			this.Controls.Add(this.txbLicenseClassTitle);
			this.Controls.Add(this._lblLicenseClassTitle);
			this.Controls.Add(this.btnClose);
			this.Controls.Add(this.btnSave);
			this.Name = "frmUpdateLicenseClass";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Update License Class";
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.TextBox txbLicenseClassDescription;
		private System.Windows.Forms.Label _lblLicenseClassDescription;
		private System.Windows.Forms.TextBox txbLicenseClassFees;
		private System.Windows.Forms.Label lblUpdateTestType;
		private System.Windows.Forms.Label lblLicenseClassID;
		private System.Windows.Forms.Label _lblLicenseClassFees;
		private System.Windows.Forms.TextBox txbLicenseClassTitle;
		private System.Windows.Forms.Label _lblLicenseClassTitle;
		private System.Windows.Forms.Button btnClose;
		private System.Windows.Forms.Button btnSave;
		private System.Windows.Forms.TextBox txbMinimumAge;
		private System.Windows.Forms.Label _lblMinimumAge;
		private System.Windows.Forms.TextBox txbDefaultValidity;
		private System.Windows.Forms.Label _lblDefaultValidity;
	}
}