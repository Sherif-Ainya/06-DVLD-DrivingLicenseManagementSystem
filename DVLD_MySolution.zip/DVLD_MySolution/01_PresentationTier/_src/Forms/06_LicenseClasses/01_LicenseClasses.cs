﻿using System;
using System.Windows.Forms;
using DVLD_Business;

namespace _02_DVLD_Mine._src.Forms._06_LicenseClasses
{
	public partial class frmLicenseClasses : Form
	{
		public frmLicenseClasses()
		{
			InitializeComponent();
			_RefreshLicenseClasses();
		}


		private void dgvLicenseClasses_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
		{
			dgvLicenseClasses.ColumnHeadersHeight = 60;
			dgvLicenseClasses.RowTemplate.Height = 37;

			dgvLicenseClasses.Columns[0].Width = 190;

			dgvLicenseClasses.Columns[0].HeaderText = "Class ID";
			dgvLicenseClasses.Columns[1].HeaderText = "Class Name";
			dgvLicenseClasses.Columns[2].HeaderText = "Description";
			dgvLicenseClasses.Columns[2].Visible = false;
			dgvLicenseClasses.Columns[3].HeaderText = "Minimum Allowed Age";
			dgvLicenseClasses.Columns[4].HeaderText = "Default Validity Length";
			dgvLicenseClasses.Columns[5].HeaderText = "Class Fees";
		}
		private void _RefreshLicenseClasses()
		{
			dgvLicenseClasses.SuspendLayout();
			dgvLicenseClasses.DataSource = clsBusinessLicenseClasses.GetAllLicenseClasses();
			dgvLicenseClasses.ResumeLayout();
			lblTotalLicenseClasses.Text = "Total License Classes [" + dgvLicenseClasses.RowCount.ToString() + "].";
		}



		private void tsmiEdit_Click(object sender, EventArgs e)
		{
			int classID = (int)dgvLicenseClasses.CurrentRow.Cells[0].Value;
			Form update = new frmUpdateLicenseClass(classID);
			update.ShowDialog();
			_RefreshLicenseClasses();
		}
		private void btnClose_Click(object sender, EventArgs e)
		{
			this.Close();
		}
	}
}
