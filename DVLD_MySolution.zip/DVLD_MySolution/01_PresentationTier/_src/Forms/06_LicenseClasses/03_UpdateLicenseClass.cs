﻿using System;
using System.Windows.Forms;
using DVLD_Business;

namespace _02_DVLD_Mine._src.Forms._06_LicenseClasses
{
	public partial class frmUpdateLicenseClass : Form
	{
		private int _classID = -1;
		private clsBusinessLicenseClasses _currentClass;

		private void _LoadData()
		{
			_currentClass = clsBusinessLicenseClasses.Find(_classID);

			if (_currentClass == null)
				return;


			lblLicenseClassID.Text = _currentClass.LicenseClassID.ToString();
			txbLicenseClassTitle.Text = _currentClass.ClassName;
			txbLicenseClassDescription.Text = _currentClass.ClassDescription;
			txbMinimumAge.Text = _currentClass.MinimumAllowedAge.ToString();
			txbDefaultValidity.Text = _currentClass.DefaultValidittyLength.ToString();
			txbLicenseClassFees.Text = _currentClass.ClassFees.ToString();
		}


		public frmUpdateLicenseClass(int classID)
		{
			InitializeComponent();
			_classID = classID;
			_LoadData();
		}


		private void mtxbClassFees_KeyPress(object sender, KeyPressEventArgs e)
		{
			if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && e.KeyChar != ',' && e.KeyChar != '.')
			{
				e.Handled = true;
			}

			if ((e.KeyChar == ',' || e.KeyChar == '.') && (sender as TextBox).Text.IndexOfAny(new char[] { ',', '.' }) > -1)
			{
				e.Handled = true;
			}
		}
		private void txbMinimumAge_KeyPress(object sender, KeyPressEventArgs e)
		{
			// IsControl = backspace.

			if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && e.KeyChar != ',' && e.KeyChar != '.')
			{
				e.Handled = true;
			}
		}


		private bool _CheckAllInfoCompleted()
		{
			if (txbLicenseClassDescription.Text == "")
			{
				txbLicenseClassDescription.Focus();
				return false;
			}
			if (txbMinimumAge.Text == "")
			{
				txbMinimumAge.Focus();
				return false;
			}
			if (txbDefaultValidity.Text == "")
			{
				txbDefaultValidity.Focus();
				return false;
			}
			if (txbLicenseClassFees.Text == "")
			{
				txbLicenseClassFees.Focus();
				return false;
			}
			return true;
		}
		private void btnSave_Click(object sender, System.EventArgs e)
		{
			if (!_CheckAllInfoCompleted())
			{
				MessageBox.Show("Not All Information Completed!", "Warrning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
				return;
			}

			//_currentClass.ClassName = txbLicenseClassTitle.Text;
			_currentClass.ClassDescription = txbLicenseClassDescription.Text;
			_currentClass.MinimumAllowedAge = Convert.ToByte(txbMinimumAge.Text);
			_currentClass.DefaultValidittyLength = Convert.ToByte(txbDefaultValidity.Text);
			_currentClass.ClassFees = Convert.ToDecimal(txbLicenseClassFees.Text);

			if (_currentClass.Save())
				MessageBox.Show("Data Saved Successfully.");
			else
				MessageBox.Show("Error: Data Is not Saved Successfully.");

			btnSave.Enabled = false;
		}
		private void btnClose_Click(object sender, System.EventArgs e)
		{
			this.Close();
		}

	}
}
