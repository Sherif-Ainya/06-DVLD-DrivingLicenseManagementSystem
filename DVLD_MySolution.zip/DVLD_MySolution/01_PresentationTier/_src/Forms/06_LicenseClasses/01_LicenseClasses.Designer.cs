﻿namespace _02_DVLD_Mine._src.Forms._06_LicenseClasses
{
	partial class frmLicenseClasses
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
			this.lblTotalLicenseClasses = new System.Windows.Forms.Label();
			this.dgvLicenseClasses = new System.Windows.Forms.DataGridView();
			this.lblManageApplicationTypes = new System.Windows.Forms.Label();
			this.btnClose = new System.Windows.Forms.Button();
			this.cmsLicenseClasses = new System.Windows.Forms.ContextMenuStrip(this.components);
			this.tsmiEdit = new System.Windows.Forms.ToolStripMenuItem();
			((System.ComponentModel.ISupportInitialize)(this.dgvLicenseClasses)).BeginInit();
			this.cmsLicenseClasses.SuspendLayout();
			this.SuspendLayout();
			// 
			// lblTotalLicenseClasses
			// 
			this.lblTotalLicenseClasses.AutoSize = true;
			this.lblTotalLicenseClasses.Font = new System.Drawing.Font("Mongolian Baiti", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblTotalLicenseClasses.Location = new System.Drawing.Point(32, 680);
			this.lblTotalLicenseClasses.Name = "lblTotalLicenseClasses";
			this.lblTotalLicenseClasses.Size = new System.Drawing.Size(242, 25);
			this.lblTotalLicenseClasses.TabIndex = 65;
			this.lblTotalLicenseClasses.Text = "Total License Classes";
			// 
			// dgvLicenseClasses
			// 
			this.dgvLicenseClasses.AllowUserToAddRows = false;
			this.dgvLicenseClasses.AllowUserToDeleteRows = false;
			this.dgvLicenseClasses.AllowUserToOrderColumns = true;
			this.dgvLicenseClasses.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
			this.dgvLicenseClasses.BackgroundColor = System.Drawing.SystemColors.GradientInactiveCaption;
			dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
			dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
			dataGridViewCellStyle1.Font = new System.Drawing.Font("Viner Hand ITC", 15F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
			dataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.Aqua;
			dataGridViewCellStyle1.SelectionForeColor = System.Drawing.Color.Violet;
			dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
			this.dgvLicenseClasses.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
			this.dgvLicenseClasses.ColumnHeadersHeight = 50;
			this.dgvLicenseClasses.ContextMenuStrip = this.cmsLicenseClasses;
			dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
			dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
			dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
			dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.LightGray;
			dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.ControlText;
			dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
			this.dgvLicenseClasses.DefaultCellStyle = dataGridViewCellStyle2;
			this.dgvLicenseClasses.Location = new System.Drawing.Point(15, 264);
			this.dgvLicenseClasses.Name = "dgvLicenseClasses";
			this.dgvLicenseClasses.ReadOnly = true;
			dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
			dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control;
			dataGridViewCellStyle3.Font = new System.Drawing.Font("Lucida Fax", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText;
			dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
			dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
			dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
			this.dgvLicenseClasses.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
			this.dgvLicenseClasses.RowHeadersWidth = 35;
			this.dgvLicenseClasses.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
			this.dgvLicenseClasses.RowTemplate.Height = 30;
			this.dgvLicenseClasses.Size = new System.Drawing.Size(1132, 397);
			this.dgvLicenseClasses.TabIndex = 63;
			this.dgvLicenseClasses.TabStop = false;
			this.dgvLicenseClasses.CellFormatting += new System.Windows.Forms.DataGridViewCellFormattingEventHandler(this.dgvLicenseClasses_CellFormatting);
			this.dgvLicenseClasses.DoubleClick += new System.EventHandler(this.tsmiEdit_Click);
			// 
			// lblManageApplicationTypes
			// 
			this.lblManageApplicationTypes.Font = new System.Drawing.Font("Palatino Linotype", 48F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblManageApplicationTypes.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
			this.lblManageApplicationTypes.Location = new System.Drawing.Point(359, 25);
			this.lblManageApplicationTypes.Name = "lblManageApplicationTypes";
			this.lblManageApplicationTypes.Size = new System.Drawing.Size(476, 203);
			this.lblManageApplicationTypes.TabIndex = 64;
			this.lblManageApplicationTypes.Text = "Manage License Classes";
			this.lblManageApplicationTypes.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// btnClose
			// 
			this.btnClose.BackColor = System.Drawing.SystemColors.ScrollBar;
			this.btnClose.DialogResult = System.Windows.Forms.DialogResult.Cancel;
			this.btnClose.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
			this.btnClose.FlatAppearance.BorderSize = 2;
			this.btnClose.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnClose.Font = new System.Drawing.Font("Microsoft YaHei UI", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnClose.ForeColor = System.Drawing.Color.Red;
			this.btnClose.Image = global::_02_DVLD_Mine.Properties.Resources.close;
			this.btnClose.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btnClose.Location = new System.Drawing.Point(989, 667);
			this.btnClose.Name = "btnClose";
			this.btnClose.Size = new System.Drawing.Size(119, 53);
			this.btnClose.TabIndex = 62;
			this.btnClose.Text = "Close";
			this.btnClose.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.btnClose.UseVisualStyleBackColor = false;
			this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
			// 
			// cmsLicenseClasses
			// 
			this.cmsLicenseClasses.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsmiEdit});
			this.cmsLicenseClasses.Name = "cmsPeople";
			this.cmsLicenseClasses.Size = new System.Drawing.Size(108, 44);
			// 
			// tsmiEdit
			// 
			this.tsmiEdit.Font = new System.Drawing.Font("Aldhabi", 17F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.tsmiEdit.Image = global::_02_DVLD_Mine.Properties.Resources.highlighter_pen;
			this.tsmiEdit.Name = "tsmiEdit";
			this.tsmiEdit.Size = new System.Drawing.Size(107, 40);
			this.tsmiEdit.Text = "Edit";
			this.tsmiEdit.TextDirection = System.Windows.Forms.ToolStripTextDirection.Horizontal;
			this.tsmiEdit.Click += new System.EventHandler(this.tsmiEdit_Click);
			// 
			// frmLicenseClasses
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = System.Drawing.SystemColors.InactiveCaption;
			this.CancelButton = this.btnClose;
			this.ClientSize = new System.Drawing.Size(1156, 740);
			this.Controls.Add(this.btnClose);
			this.Controls.Add(this.lblTotalLicenseClasses);
			this.Controls.Add(this.dgvLicenseClasses);
			this.Controls.Add(this.lblManageApplicationTypes);
			this.Name = "frmLicenseClasses";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "License Classes";
			((System.ComponentModel.ISupportInitialize)(this.dgvLicenseClasses)).EndInit();
			this.cmsLicenseClasses.ResumeLayout(false);
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.Button btnClose;
		private System.Windows.Forms.Label lblTotalLicenseClasses;
		private System.Windows.Forms.DataGridView dgvLicenseClasses;
		private System.Windows.Forms.Label lblManageApplicationTypes;
		private System.Windows.Forms.ContextMenuStrip cmsLicenseClasses;
		private System.Windows.Forms.ToolStripMenuItem tsmiEdit;
	}
}