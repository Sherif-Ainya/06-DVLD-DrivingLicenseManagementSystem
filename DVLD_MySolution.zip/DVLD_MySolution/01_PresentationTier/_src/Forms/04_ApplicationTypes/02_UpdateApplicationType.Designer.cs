﻿namespace _02_DVLD_Mine._src.Forms._04_ApplicationTypes
{
	partial class frmUpdateApplicationType
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.lblAppTypeID = new System.Windows.Forms.Label();
			this.lblAppTypeFees = new System.Windows.Forms.Label();
			this.txbAppTypeTitle = new System.Windows.Forms.TextBox();
			this.lblAppTypeTitle = new System.Windows.Forms.Label();
			this.lblUpdateAppType = new System.Windows.Forms.Label();
			this.txbAppTypeFees = new System.Windows.Forms.TextBox();
			this.btnClose = new System.Windows.Forms.Button();
			this.btnSave = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// lblAppTypeID
			// 
			this.lblAppTypeID.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
			this.lblAppTypeID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.lblAppTypeID.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblAppTypeID.ForeColor = System.Drawing.Color.Red;
			this.lblAppTypeID.Location = new System.Drawing.Point(290, 246);
			this.lblAppTypeID.Name = "lblAppTypeID";
			this.lblAppTypeID.Size = new System.Drawing.Size(73, 41);
			this.lblAppTypeID.TabIndex = 113;
			this.lblAppTypeID.Text = "-1";
			this.lblAppTypeID.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// lblAppTypeFees
			// 
			this.lblAppTypeFees.AutoSize = true;
			this.lblAppTypeFees.Font = new System.Drawing.Font("Palatino Linotype", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblAppTypeFees.Location = new System.Drawing.Point(49, 203);
			this.lblAppTypeFees.Name = "lblAppTypeFees";
			this.lblAppTypeFees.Size = new System.Drawing.Size(75, 29);
			this.lblAppTypeFees.TabIndex = 111;
			this.lblAppTypeFees.Text = "Fees  :";
			// 
			// txbAppTypeTitle
			// 
			this.txbAppTypeTitle.Enabled = false;
			this.txbAppTypeTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.txbAppTypeTitle.Location = new System.Drawing.Point(148, 153);
			this.txbAppTypeTitle.Name = "txbAppTypeTitle";
			this.txbAppTypeTitle.Size = new System.Drawing.Size(372, 27);
			this.txbAppTypeTitle.TabIndex = 1;
			this.txbAppTypeTitle.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			// 
			// lblAppTypeTitle
			// 
			this.lblAppTypeTitle.AutoSize = true;
			this.lblAppTypeTitle.Font = new System.Drawing.Font("Palatino Linotype", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblAppTypeTitle.Location = new System.Drawing.Point(46, 153);
			this.lblAppTypeTitle.Name = "lblAppTypeTitle";
			this.lblAppTypeTitle.Size = new System.Drawing.Size(78, 29);
			this.lblAppTypeTitle.TabIndex = 107;
			this.lblAppTypeTitle.Text = "Title  :";
			// 
			// lblUpdateAppType
			// 
			this.lblUpdateAppType.AutoSize = true;
			this.lblUpdateAppType.Font = new System.Drawing.Font("Palatino Linotype", 25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblUpdateAppType.ForeColor = System.Drawing.Color.Navy;
			this.lblUpdateAppType.Location = new System.Drawing.Point(96, 42);
			this.lblUpdateAppType.Name = "lblUpdateAppType";
			this.lblUpdateAppType.Size = new System.Drawing.Size(414, 46);
			this.lblUpdateAppType.TabIndex = 114;
			this.lblUpdateAppType.Text = "Update Application Type";
			// 
			// txbAppTypeFees
			// 
			this.txbAppTypeFees.Font = new System.Drawing.Font("Microsoft Sans Serif", 17F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.txbAppTypeFees.Location = new System.Drawing.Point(222, 199);
			this.txbAppTypeFees.Name = "txbAppTypeFees";
			this.txbAppTypeFees.Size = new System.Drawing.Size(221, 33);
			this.txbAppTypeFees.TabIndex = 2;
			this.txbAppTypeFees.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			this.txbAppTypeFees.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.mtxbAppTypeFees_KeyPress);
			// 
			// btnClose
			// 
			this.btnClose.BackColor = System.Drawing.Color.Pink;
			this.btnClose.FlatAppearance.BorderColor = System.Drawing.Color.Cyan;
			this.btnClose.FlatAppearance.BorderSize = 3;
			this.btnClose.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
			this.btnClose.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
			this.btnClose.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnClose.Font = new System.Drawing.Font("Microsoft YaHei UI", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnClose.ForeColor = System.Drawing.Color.Red;
			this.btnClose.Image = global::_02_DVLD_Mine.Properties.Resources.close1;
			this.btnClose.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btnClose.Location = new System.Drawing.Point(512, 321);
			this.btnClose.Name = "btnClose";
			this.btnClose.Size = new System.Drawing.Size(62, 52);
			this.btnClose.TabIndex = 0;
			this.btnClose.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.btnClose.UseVisualStyleBackColor = false;
			this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
			// 
			// btnSave
			// 
			this.btnSave.BackColor = System.Drawing.Color.Pink;
			this.btnSave.FlatAppearance.BorderColor = System.Drawing.Color.Cyan;
			this.btnSave.FlatAppearance.BorderSize = 3;
			this.btnSave.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
			this.btnSave.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
			this.btnSave.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnSave.Font = new System.Drawing.Font("Microsoft YaHei UI", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnSave.ForeColor = System.Drawing.Color.DarkOrchid;
			this.btnSave.Image = global::_02_DVLD_Mine.Properties.Resources.save_27_16;
			this.btnSave.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btnSave.Location = new System.Drawing.Point(410, 321);
			this.btnSave.Name = "btnSave";
			this.btnSave.Size = new System.Drawing.Size(100, 52);
			this.btnSave.TabIndex = 3;
			this.btnSave.Text = "SAVE";
			this.btnSave.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.btnSave.UseVisualStyleBackColor = false;
			this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
			// 
			// frmUpdateApplicationType
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = System.Drawing.Color.MediumSpringGreen;
			this.CancelButton = this.btnClose;
			this.ClientSize = new System.Drawing.Size(593, 391);
			this.Controls.Add(this.txbAppTypeFees);
			this.Controls.Add(this.lblUpdateAppType);
			this.Controls.Add(this.lblAppTypeID);
			this.Controls.Add(this.lblAppTypeFees);
			this.Controls.Add(this.txbAppTypeTitle);
			this.Controls.Add(this.lblAppTypeTitle);
			this.Controls.Add(this.btnClose);
			this.Controls.Add(this.btnSave);
			this.Name = "frmUpdateApplicationType";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Update Application Type";
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.Label lblAppTypeID;
		private System.Windows.Forms.Label lblAppTypeFees;
		private System.Windows.Forms.TextBox txbAppTypeTitle;
		private System.Windows.Forms.Label lblAppTypeTitle;
		private System.Windows.Forms.Button btnClose;
		private System.Windows.Forms.Button btnSave;
		private System.Windows.Forms.Label lblUpdateAppType;
		private System.Windows.Forms.TextBox txbAppTypeFees;
	}
}