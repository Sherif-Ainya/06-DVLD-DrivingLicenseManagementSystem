﻿namespace _02_DVLD_Mine._src.Forms._04_ApplicationTypes
{
	partial class frmApplicationTypes
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
			this.lblTotalAppTypes = new System.Windows.Forms.Label();
			this.dgvAppTypes = new System.Windows.Forms.DataGridView();
			this.cmsAppTypes = new System.Windows.Forms.ContextMenuStrip(this.components);
			this.tsmiEdit = new System.Windows.Forms.ToolStripMenuItem();
			this.lblManageApplicationTypes = new System.Windows.Forms.Label();
			this.btnClose = new System.Windows.Forms.Button();
			((System.ComponentModel.ISupportInitialize)(this.dgvAppTypes)).BeginInit();
			this.cmsAppTypes.SuspendLayout();
			this.SuspendLayout();
			// 
			// lblTotalAppTypes
			// 
			this.lblTotalAppTypes.AutoSize = true;
			this.lblTotalAppTypes.Font = new System.Drawing.Font("Mongolian Baiti", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblTotalAppTypes.Location = new System.Drawing.Point(31, 680);
			this.lblTotalAppTypes.Name = "lblTotalAppTypes";
			this.lblTotalAppTypes.Size = new System.Drawing.Size(269, 25);
			this.lblTotalAppTypes.TabIndex = 61;
			this.lblTotalAppTypes.Text = "Total Application Types";
			// 
			// dgvAppTypes
			// 
			this.dgvAppTypes.AllowUserToAddRows = false;
			this.dgvAppTypes.AllowUserToDeleteRows = false;
			this.dgvAppTypes.AllowUserToOrderColumns = true;
			this.dgvAppTypes.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
			this.dgvAppTypes.BackgroundColor = System.Drawing.SystemColors.GradientInactiveCaption;
			dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
			dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
			dataGridViewCellStyle1.Font = new System.Drawing.Font("Viner Hand ITC", 15F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
			dataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.Aqua;
			dataGridViewCellStyle1.SelectionForeColor = System.Drawing.Color.Violet;
			dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
			this.dgvAppTypes.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
			this.dgvAppTypes.ColumnHeadersHeight = 50;
			this.dgvAppTypes.ContextMenuStrip = this.cmsAppTypes;
			dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
			dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
			dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
			dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.PaleGreen;
			dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.ControlText;
			dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
			this.dgvAppTypes.DefaultCellStyle = dataGridViewCellStyle2;
			this.dgvAppTypes.Location = new System.Drawing.Point(12, 264);
			this.dgvAppTypes.Name = "dgvAppTypes";
			this.dgvAppTypes.ReadOnly = true;
			dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
			dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control;
			dataGridViewCellStyle3.Font = new System.Drawing.Font("Lucida Fax", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText;
			dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
			dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
			dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
			this.dgvAppTypes.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
			this.dgvAppTypes.RowHeadersWidth = 35;
			this.dgvAppTypes.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
			this.dgvAppTypes.RowTemplate.Height = 30;
			this.dgvAppTypes.Size = new System.Drawing.Size(904, 397);
			this.dgvAppTypes.TabIndex = 1;
			this.dgvAppTypes.TabStop = false;
			this.dgvAppTypes.CellFormatting += new System.Windows.Forms.DataGridViewCellFormattingEventHandler(this.dgvAppTypes_CellFormatting);
			this.dgvAppTypes.DoubleClick += new System.EventHandler(this.tsmiEdit_Click);
			// 
			// cmsAppTypes
			// 
			this.cmsAppTypes.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsmiEdit});
			this.cmsAppTypes.Name = "cmsPeople";
			this.cmsAppTypes.Size = new System.Drawing.Size(108, 44);
			// 
			// tsmiEdit
			// 
			this.tsmiEdit.Font = new System.Drawing.Font("Aldhabi", 17F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.tsmiEdit.Image = global::_02_DVLD_Mine.Properties.Resources.highlighter_pen;
			this.tsmiEdit.Name = "tsmiEdit";
			this.tsmiEdit.Size = new System.Drawing.Size(107, 40);
			this.tsmiEdit.Text = "Edit";
			this.tsmiEdit.TextDirection = System.Windows.Forms.ToolStripTextDirection.Horizontal;
			this.tsmiEdit.Click += new System.EventHandler(this.tsmiEdit_Click);
			// 
			// lblManageApplicationTypes
			// 
			this.lblManageApplicationTypes.Font = new System.Drawing.Font("Palatino Linotype", 48F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblManageApplicationTypes.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
			this.lblManageApplicationTypes.Location = new System.Drawing.Point(156, 29);
			this.lblManageApplicationTypes.Name = "lblManageApplicationTypes";
			this.lblManageApplicationTypes.Size = new System.Drawing.Size(596, 203);
			this.lblManageApplicationTypes.TabIndex = 58;
			this.lblManageApplicationTypes.Text = "Manage Application Types";
			this.lblManageApplicationTypes.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// btnClose
			// 
			this.btnClose.BackColor = System.Drawing.SystemColors.ScrollBar;
			this.btnClose.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
			this.btnClose.FlatAppearance.BorderSize = 2;
			this.btnClose.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnClose.Font = new System.Drawing.Font("Microsoft YaHei UI", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnClose.ForeColor = System.Drawing.Color.Red;
			this.btnClose.Image = global::_02_DVLD_Mine.Properties.Resources.close;
			this.btnClose.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btnClose.Location = new System.Drawing.Point(782, 668);
			this.btnClose.Name = "btnClose";
			this.btnClose.Size = new System.Drawing.Size(119, 53);
			this.btnClose.TabIndex = 0;
			this.btnClose.Text = "Close";
			this.btnClose.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.btnClose.UseVisualStyleBackColor = false;
			this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
			// 
			// frmApplicationTypes
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = System.Drawing.Color.MediumSpringGreen;
			this.CancelButton = this.btnClose;
			this.ClientSize = new System.Drawing.Size(928, 740);
			this.Controls.Add(this.btnClose);
			this.Controls.Add(this.lblTotalAppTypes);
			this.Controls.Add(this.dgvAppTypes);
			this.Controls.Add(this.lblManageApplicationTypes);
			this.Name = "frmApplicationTypes";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Application Types";
			((System.ComponentModel.ISupportInitialize)(this.dgvAppTypes)).EndInit();
			this.cmsAppTypes.ResumeLayout(false);
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.Button btnClose;
		private System.Windows.Forms.Label lblTotalAppTypes;
		private System.Windows.Forms.DataGridView dgvAppTypes;
		private System.Windows.Forms.Label lblManageApplicationTypes;
		private System.Windows.Forms.ContextMenuStrip cmsAppTypes;
		private System.Windows.Forms.ToolStripMenuItem tsmiEdit;
	}
}