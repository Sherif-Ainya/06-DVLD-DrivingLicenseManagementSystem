﻿using System;
using System.Windows.Forms;
using DVLD_Business;

namespace _02_DVLD_Mine._src.Forms._04_ApplicationTypes
{
	public partial class frmUpdateApplicationType : Form
	{
		private int _applicationTypeID;
		private clsBusinessApplicationTypes _currentType;
		private void _LoadData()
		{
			_currentType = clsBusinessApplicationTypes.Find(_applicationTypeID);

			if (_currentType == null)
			{
				return;
			}

			lblAppTypeID.Text = _currentType.applicationTypeID.ToString();
			txbAppTypeTitle.Text = _currentType.applicationTypeTitle;
			txbAppTypeFees.Text = _currentType.applicationTypeFees.ToString();

			// This Was A Problem, I Solved It Using TabIndex, So this code here is almost nothing.
			txbAppTypeFees.Focus();
			txbAppTypeFees.SelectionStart = txbAppTypeFees.Text.Length;
		}


		public frmUpdateApplicationType(int applicationTypeID)
		{
			InitializeComponent();
			_applicationTypeID = applicationTypeID;
			_LoadData();
		}


		private void mtxbAppTypeFees_KeyPress(object sender, KeyPressEventArgs e)
		{
			if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && e.KeyChar != ',' && e.KeyChar != '.')
			{
				e.Handled = true;
			}

			if ((e.KeyChar == ',' || e.KeyChar == '.') && (sender as TextBox).Text.IndexOfAny(new char[] { ',', '.' }) > -1)
			{
				e.Handled = true;
			}
		}
		private bool _CheckAllInfoCompleted()
		{
			//if (txbAppTypeTitle.Text == "")
			//{
			//	txbAppTypeTitle.Focus();
			//	return false;
			//}
			if (txbAppTypeFees.Text == "")
			{
				txbAppTypeFees.Focus();
				return false;
			}
			return true;
		}
		private void btnSave_Click(object sender, System.EventArgs e)
		{
			if (!_CheckAllInfoCompleted())
			{
				MessageBox.Show("Not All Information Completed!", "Warrning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
				return;
			}

			//_currentType.applicationTypeTitle = txbAppTypeTitle.Text;
			_currentType.applicationTypeFees = Convert.ToDecimal(txbAppTypeFees.Text);

			if (_currentType.Save())
				MessageBox.Show("Data Saved Successfully.");
			else
				MessageBox.Show("Error: Data Is not Saved Successfully.");

			btnSave.Enabled = false;
		}
		private void btnClose_Click(object sender, System.EventArgs e)
		{
			this.Close();
		}
	}
}
