﻿using System;
using System.Windows.Forms;
using DVLD_Business;

namespace _02_DVLD_Mine._src.Forms._04_ApplicationTypes
{
	public partial class frmApplicationTypes : Form
	{
		private void dgvAppTypes_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
		{
			// Header Height.
			dgvAppTypes.ColumnHeadersHeight = 60;

			// Rows Height, Or [Properties > RowTemplate.Height], Or AutoSizeRowsMode.
			dgvAppTypes.RowTemplate.Height = 37;

			// Cell Width Firsth Put DataGridView AutoSizeColumnsMode = Fill. Then Make Changes To Some Of The Columns Like This.
			dgvAppTypes.Columns[0].Width = 190;
			dgvAppTypes.Columns[2].Width = 190;

			dgvAppTypes.Columns[0].HeaderText = "Type ID";
			dgvAppTypes.Columns[1].HeaderText = "Title";
			dgvAppTypes.Columns[2].HeaderText = "Fees";
		}
		private void _RefreshAppTypes()
		{
			dgvAppTypes.SuspendLayout();
			dgvAppTypes.DataSource = clsBusinessApplicationTypes.GetAllApplicationTypes();
			dgvAppTypes.ResumeLayout();
			lblTotalAppTypes.Text = "Total Application Types [" + dgvAppTypes.RowCount.ToString() + "].";
		}


		public frmApplicationTypes()
		{
			InitializeComponent();
			_RefreshAppTypes();
		}


		private void tsmiEdit_Click(object sender, EventArgs e)
		{
			int typeID = (int)dgvAppTypes.CurrentRow.Cells[0].Value;
			Form update = new frmUpdateApplicationType(typeID);
			update.ShowDialog();
			_RefreshAppTypes();
		}
		private void btnClose_Click(object sender, EventArgs e)
		{
			this.Close();
		}
	}
}
