﻿using System;
using System.Data;
using System.Windows.Forms;
using DVLD_Business;

namespace _02_DVLD_Mine._src.Forms._06_ManageLocalDL
{
	public partial class frmAddNewLDLA : Form
	{
		public frmAddNewLDLA()
		{
			InitializeComponent();
			btnNext.Enabled = false;
		}


		private clsBusinessApplications _currentApplication = new clsBusinessApplications();

		private bool _allowChangingTab = true;
		private byte _currentLicense_LDLA_Class = 0;
		clsBusiness_LDLA.stStatus_ApplicationID status_ApplicationID = new clsBusiness_LDLA.stStatus_ApplicationID();
		clsBusiness_LDLA _current_LDLA = new clsBusiness_LDLA();
		private void tabControl1_Selecting(object sender, TabControlCancelEventArgs e)
		{
			e.Cancel = _allowChangingTab;
		}
		private void _FillLicensesClass()
		{
			DataTable dtLicensesClasses = clsBusinessLicenseClasses.GetAllLicenseClasses();

			foreach (DataRow row in dtLicensesClasses.Rows)
			{
				cbLicensesClasses.Items.Add(row["ClassName"]);
			}
			cbLicensesClasses.SelectedIndex = 2;
		}


		private void findPerson_OnFound(int obj)
		{
			int personID = obj;
			_FillLicensesClass();

			_currentApplication.ApplicationPersonID = personID;
			_currentApplication.CreatedByUserID = clsGlobal.currentUser.userID;
			lblCreatedBy.Text = clsGlobal.currentUser.userName;
			lblApplicationDate.Text = DateTime.Now.ToString("d");
			_currentApplication.PaidFees = clsBusinessApplicationTypes.Find(1).applicationTypeFees;
			lblApplicationFees.Text = _currentApplication.PaidFees.ToString();

			btnNext.Enabled = true;
			_allowChangingTab = false;
		}


		private void btnNext_Click(object sender, EventArgs e)
		{
			tabControl1.SelectedIndex = 1;
		}
		private void btnBack_Click(object sender, EventArgs e)
		{
			tabControl1.SelectedIndex = 0;
		}


		private void btnSave_Click(object sender, EventArgs e)
		{
			status_ApplicationID = clsBusiness_LDLA.LastPerson_LDLA_Status(_currentApplication.ApplicationPersonID, _currentLicense_LDLA_Class);

			if (status_ApplicationID.status == 1)
			{
				MessageBox.Show("Sorry The Selected Person Already Have A New Active Application With ID [" + status_ApplicationID.applicationID + "], For The Selected Class.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
				return;
			}
			else if (status_ApplicationID.status == 2)
			{
				if (MessageBox.Show("The Selected Person Have A Cancelled Application With ID [" + status_ApplicationID.applicationID + "], Want To Complete And Create A New One?", "Information", MessageBoxButtons.OKCancel, MessageBoxIcon.Information, MessageBoxDefaultButton.Button2) == DialogResult.Cancel)
					return;
			}
			else if (status_ApplicationID.status == 3)
			{
				MessageBox.Show("Sorry The Selected Person Have A Completed Application With ID [" + status_ApplicationID.applicationID + "], For The Selected Class.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
				return;
			}

			_currentApplication.ApplicationDateTime = DateTime.Now;
			_currentApplication.ApplicationTypeID = 1;  // New Local Driving License Service.
			_currentApplication.ApplicationStatus = 1;  // New.
			_currentApplication.LastStatusDate = DateTime.Now;


			if (_currentApplication.Save())
			{
				_current_LDLA.ApplicationID = _currentApplication.ApplicationID;
				_current_LDLA.LicenseClassID = _currentLicense_LDLA_Class;
				if (_current_LDLA.Save())
					MessageBox.Show("Data Saved Successfully.");
			}
			else
				MessageBox.Show("Error: Data Is not Saved Successfully.");

			lblApplicationID.Text = _currentApplication.ApplicationID.ToString();
		}
		private void btnClose_Click(object sender, EventArgs e)
		{
			this.Close();
		}

		private void cbLicensesClasses_SelectedIndexChanged(object sender, EventArgs e)
		{
			_currentLicense_LDLA_Class = Convert.ToByte(cbLicensesClasses.SelectedIndex + 1);
		}
	}
}
