﻿namespace _02_DVLD_Mine._src.Forms._06_ManageLocalDL
{
	partial class frmAddNewLDLA
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.tpPersonalInfo = new System.Windows.Forms.TabPage();
			this.findPerson = new _02_DVLD_Mine._src.userControls._01_People.uc1N_FindPersonThenFillData();
			this.btnNext = new System.Windows.Forms.Button();
			this.tabControl1 = new System.Windows.Forms.TabControl();
			this.tpUserInfo = new System.Windows.Forms.TabPage();
			this.panel2 = new System.Windows.Forms.Panel();
			this.lblCreatedBy = new System.Windows.Forms.Label();
			this.lblApplicationDate = new System.Windows.Forms.Label();
			this.lblApplicationFees = new System.Windows.Forms.Label();
			this.cbLicensesClasses = new System.Windows.Forms.ComboBox();
			this._lblCreatedBy = new System.Windows.Forms.Label();
			this._lblApplicationFees = new System.Windows.Forms.Label();
			this._lblLicenseClasses = new System.Windows.Forms.Label();
			this._lblApplicationDate = new System.Windows.Forms.Label();
			this.lblApplicationID = new System.Windows.Forms.Label();
			this.btnBack = new System.Windows.Forms.Button();
			this.btnSave = new System.Windows.Forms.Button();
			this.panel1 = new System.Windows.Forms.Panel();
			this.btnClose = new System.Windows.Forms.Button();
			this.lblAdd_Update = new System.Windows.Forms.Label();
			this.tpPersonalInfo.SuspendLayout();
			this.tabControl1.SuspendLayout();
			this.tpUserInfo.SuspendLayout();
			this.panel2.SuspendLayout();
			this.panel1.SuspendLayout();
			this.SuspendLayout();
			// 
			// tpPersonalInfo
			// 
			this.tpPersonalInfo.BackColor = System.Drawing.Color.Aquamarine;
			this.tpPersonalInfo.Controls.Add(this.findPerson);
			this.tpPersonalInfo.Controls.Add(this.btnNext);
			this.tpPersonalInfo.Location = new System.Drawing.Point(4, 37);
			this.tpPersonalInfo.Name = "tpPersonalInfo";
			this.tpPersonalInfo.Padding = new System.Windows.Forms.Padding(3);
			this.tpPersonalInfo.Size = new System.Drawing.Size(1098, 652);
			this.tpPersonalInfo.TabIndex = 0;
			this.tpPersonalInfo.Text = "Personal Information";
			// 
			// findPerson
			// 
			this.findPerson.BackColor = System.Drawing.Color.DarkMagenta;
			this.findPerson.Location = new System.Drawing.Point(132, 0);
			this.findPerson.Name = "findPerson";
			this.findPerson.Size = new System.Drawing.Size(809, 653);
			this.findPerson.TabIndex = 115;
			this.findPerson.OnFound += new System.Action<int>(this.findPerson_OnFound);
			// 
			// btnNext
			// 
			this.btnNext.BackColor = System.Drawing.SystemColors.ScrollBar;
			this.btnNext.FlatAppearance.BorderColor = System.Drawing.Color.MediumTurquoise;
			this.btnNext.FlatAppearance.BorderSize = 4;
			this.btnNext.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnNext.Font = new System.Drawing.Font("Microsoft YaHei UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnNext.ForeColor = System.Drawing.Color.Red;
			this.btnNext.Image = global::_02_DVLD_Mine.Properties.Resources.redo;
			this.btnNext.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.btnNext.Location = new System.Drawing.Point(957, 573);
			this.btnNext.Name = "btnNext";
			this.btnNext.Size = new System.Drawing.Size(123, 61);
			this.btnNext.TabIndex = 1;
			this.btnNext.Text = "Next";
			this.btnNext.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btnNext.UseVisualStyleBackColor = false;
			this.btnNext.Click += new System.EventHandler(this.btnNext_Click);
			// 
			// tabControl1
			// 
			this.tabControl1.Controls.Add(this.tpPersonalInfo);
			this.tabControl1.Controls.Add(this.tpUserInfo);
			this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
			this.tabControl1.ItemSize = new System.Drawing.Size(58, 33);
			this.tabControl1.Location = new System.Drawing.Point(0, 0);
			this.tabControl1.Name = "tabControl1";
			this.tabControl1.SelectedIndex = 0;
			this.tabControl1.Size = new System.Drawing.Size(1106, 693);
			this.tabControl1.TabIndex = 3;
			this.tabControl1.Selecting += new System.Windows.Forms.TabControlCancelEventHandler(this.tabControl1_Selecting);
			// 
			// tpUserInfo
			// 
			this.tpUserInfo.BackColor = System.Drawing.Color.Aquamarine;
			this.tpUserInfo.Controls.Add(this.panel2);
			this.tpUserInfo.Controls.Add(this.btnBack);
			this.tpUserInfo.Controls.Add(this.btnSave);
			this.tpUserInfo.Location = new System.Drawing.Point(4, 37);
			this.tpUserInfo.Name = "tpUserInfo";
			this.tpUserInfo.Padding = new System.Windows.Forms.Padding(3);
			this.tpUserInfo.Size = new System.Drawing.Size(1098, 652);
			this.tpUserInfo.TabIndex = 1;
			this.tpUserInfo.Text = "DL Information";
			// 
			// panel2
			// 
			this.panel2.BackColor = System.Drawing.Color.LimeGreen;
			this.panel2.Controls.Add(this.lblCreatedBy);
			this.panel2.Controls.Add(this.lblApplicationDate);
			this.panel2.Controls.Add(this.lblApplicationFees);
			this.panel2.Controls.Add(this.cbLicensesClasses);
			this.panel2.Controls.Add(this._lblCreatedBy);
			this.panel2.Controls.Add(this._lblApplicationFees);
			this.panel2.Controls.Add(this._lblLicenseClasses);
			this.panel2.Controls.Add(this._lblApplicationDate);
			this.panel2.Controls.Add(this.lblApplicationID);
			this.panel2.Location = new System.Drawing.Point(168, 157);
			this.panel2.Name = "panel2";
			this.panel2.Size = new System.Drawing.Size(770, 273);
			this.panel2.TabIndex = 114;
			// 
			// lblCreatedBy
			// 
			this.lblCreatedBy.BackColor = System.Drawing.Color.DeepSkyBlue;
			this.lblCreatedBy.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblCreatedBy.Location = new System.Drawing.Point(373, 221);
			this.lblCreatedBy.Name = "lblCreatedBy";
			this.lblCreatedBy.Size = new System.Drawing.Size(122, 26);
			this.lblCreatedBy.TabIndex = 121;
			this.lblCreatedBy.Text = "????";
			this.lblCreatedBy.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// lblApplicationDate
			// 
			this.lblApplicationDate.BackColor = System.Drawing.Color.DeepSkyBlue;
			this.lblApplicationDate.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblApplicationDate.Location = new System.Drawing.Point(348, 183);
			this.lblApplicationDate.Name = "lblApplicationDate";
			this.lblApplicationDate.Size = new System.Drawing.Size(175, 26);
			this.lblApplicationDate.TabIndex = 120;
			this.lblApplicationDate.Text = "????";
			this.lblApplicationDate.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// lblApplicationFees
			// 
			this.lblApplicationFees.BackColor = System.Drawing.Color.DeepSkyBlue;
			this.lblApplicationFees.Font = new System.Drawing.Font("Palatino Linotype", 17F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblApplicationFees.Location = new System.Drawing.Point(370, 104);
			this.lblApplicationFees.Name = "lblApplicationFees";
			this.lblApplicationFees.Size = new System.Drawing.Size(125, 36);
			this.lblApplicationFees.TabIndex = 119;
			this.lblApplicationFees.Text = "0.00";
			this.lblApplicationFees.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// cbLicensesClasses
			// 
			this.cbLicensesClasses.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.cbLicensesClasses.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.cbLicensesClasses.FormattingEnabled = true;
			this.cbLicensesClasses.ItemHeight = 18;
			this.cbLicensesClasses.Location = new System.Drawing.Point(322, 47);
			this.cbLicensesClasses.Name = "cbLicensesClasses";
			this.cbLicensesClasses.Size = new System.Drawing.Size(223, 26);
			this.cbLicensesClasses.TabIndex = 5;
			this.cbLicensesClasses.TabStop = false;
			this.cbLicensesClasses.SelectedIndexChanged += new System.EventHandler(this.cbLicensesClasses_SelectedIndexChanged);
			// 
			// _lblCreatedBy
			// 
			this._lblCreatedBy.AutoSize = true;
			this._lblCreatedBy.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this._lblCreatedBy.Location = new System.Drawing.Point(162, 221);
			this._lblCreatedBy.Name = "_lblCreatedBy";
			this._lblCreatedBy.Size = new System.Drawing.Size(122, 26);
			this._lblCreatedBy.TabIndex = 117;
			this._lblCreatedBy.Text = "Created By :";
			// 
			// _lblApplicationFees
			// 
			this._lblApplicationFees.AutoSize = true;
			this._lblApplicationFees.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this._lblApplicationFees.Location = new System.Drawing.Point(138, 111);
			this._lblApplicationFees.Name = "_lblApplicationFees";
			this._lblApplicationFees.Size = new System.Drawing.Size(171, 26);
			this._lblApplicationFees.TabIndex = 116;
			this._lblApplicationFees.Text = "Application Fees :";
			// 
			// _lblLicenseClasses
			// 
			this._lblLicenseClasses.AutoSize = true;
			this._lblLicenseClasses.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this._lblLicenseClasses.Location = new System.Drawing.Point(145, 45);
			this._lblLicenseClasses.Name = "_lblLicenseClasses";
			this._lblLicenseClasses.Size = new System.Drawing.Size(157, 26);
			this._lblLicenseClasses.TabIndex = 115;
			this._lblLicenseClasses.Text = "License Classes :";
			// 
			// _lblApplicationDate
			// 
			this._lblApplicationDate.AutoSize = true;
			this._lblApplicationDate.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this._lblApplicationDate.Location = new System.Drawing.Point(138, 183);
			this._lblApplicationDate.Name = "_lblApplicationDate";
			this._lblApplicationDate.Size = new System.Drawing.Size(175, 26);
			this._lblApplicationDate.TabIndex = 107;
			this._lblApplicationDate.Text = "Application Date :";
			// 
			// lblApplicationID
			// 
			this.lblApplicationID.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
			this.lblApplicationID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.lblApplicationID.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblApplicationID.ForeColor = System.Drawing.Color.Red;
			this.lblApplicationID.Location = new System.Drawing.Point(677, 17);
			this.lblApplicationID.Name = "lblApplicationID";
			this.lblApplicationID.Size = new System.Drawing.Size(73, 41);
			this.lblApplicationID.TabIndex = 113;
			this.lblApplicationID.Text = "???";
			this.lblApplicationID.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// btnBack
			// 
			this.btnBack.BackColor = System.Drawing.SystemColors.ScrollBar;
			this.btnBack.FlatAppearance.BorderColor = System.Drawing.Color.MediumTurquoise;
			this.btnBack.FlatAppearance.BorderSize = 4;
			this.btnBack.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnBack.Font = new System.Drawing.Font("Microsoft YaHei UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnBack.ForeColor = System.Drawing.Color.Red;
			this.btnBack.Image = global::_02_DVLD_Mine.Properties.Resources.undo;
			this.btnBack.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btnBack.Location = new System.Drawing.Point(15, 575);
			this.btnBack.Name = "btnBack";
			this.btnBack.Size = new System.Drawing.Size(123, 61);
			this.btnBack.TabIndex = 2;
			this.btnBack.Text = "Back";
			this.btnBack.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.btnBack.UseVisualStyleBackColor = false;
			this.btnBack.Click += new System.EventHandler(this.btnBack_Click);
			// 
			// btnSave
			// 
			this.btnSave.BackColor = System.Drawing.Color.Pink;
			this.btnSave.FlatAppearance.BorderColor = System.Drawing.Color.MediumSpringGreen;
			this.btnSave.FlatAppearance.BorderSize = 4;
			this.btnSave.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
			this.btnSave.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
			this.btnSave.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnSave.Font = new System.Drawing.Font("Microsoft YaHei UI", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnSave.ForeColor = System.Drawing.Color.DarkOrchid;
			this.btnSave.Image = global::_02_DVLD_Mine.Properties.Resources.save_27_16;
			this.btnSave.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btnSave.Location = new System.Drawing.Point(995, 586);
			this.btnSave.Name = "btnSave";
			this.btnSave.Size = new System.Drawing.Size(100, 50);
			this.btnSave.TabIndex = 3;
			this.btnSave.Text = "SAVE";
			this.btnSave.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.btnSave.UseVisualStyleBackColor = false;
			this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
			// 
			// panel1
			// 
			this.panel1.Controls.Add(this.tabControl1);
			this.panel1.Dock = System.Windows.Forms.DockStyle.Bottom;
			this.panel1.Location = new System.Drawing.Point(0, 50);
			this.panel1.Name = "panel1";
			this.panel1.Size = new System.Drawing.Size(1106, 693);
			this.panel1.TabIndex = 119;
			// 
			// btnClose
			// 
			this.btnClose.BackColor = System.Drawing.SystemColors.ScrollBar;
			this.btnClose.FlatAppearance.BorderColor = System.Drawing.Color.Yellow;
			this.btnClose.FlatAppearance.BorderSize = 4;
			this.btnClose.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnClose.Font = new System.Drawing.Font("Microsoft YaHei UI", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnClose.ForeColor = System.Drawing.Color.Red;
			this.btnClose.Image = global::_02_DVLD_Mine.Properties.Resources.close;
			this.btnClose.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btnClose.Location = new System.Drawing.Point(1030, 8);
			this.btnClose.Name = "btnClose";
			this.btnClose.Size = new System.Drawing.Size(64, 52);
			this.btnClose.TabIndex = 0;
			this.btnClose.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.btnClose.UseVisualStyleBackColor = false;
			this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
			// 
			// lblAdd_Update
			// 
			this.lblAdd_Update.BackColor = System.Drawing.Color.Transparent;
			this.lblAdd_Update.Font = new System.Drawing.Font("Palatino Linotype", 38F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblAdd_Update.ForeColor = System.Drawing.Color.MediumVioletRed;
			this.lblAdd_Update.Location = new System.Drawing.Point(292, 8);
			this.lblAdd_Update.Name = "lblAdd_Update";
			this.lblAdd_Update.Size = new System.Drawing.Size(495, 76);
			this.lblAdd_Update.TabIndex = 118;
			this.lblAdd_Update.Text = "Add New Local DL";
			this.lblAdd_Update.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// frmAddNewLDLA
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = System.Drawing.Color.LightGreen;
			this.CancelButton = this.btnClose;
			this.ClientSize = new System.Drawing.Size(1106, 743);
			this.Controls.Add(this.btnClose);
			this.Controls.Add(this.lblAdd_Update);
			this.Controls.Add(this.panel1);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
			this.Name = "frmAddNewLDLA";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Add New Driving License Applicaiton";
			this.tpPersonalInfo.ResumeLayout(false);
			this.tabControl1.ResumeLayout(false);
			this.tpUserInfo.ResumeLayout(false);
			this.panel2.ResumeLayout(false);
			this.panel2.PerformLayout();
			this.panel1.ResumeLayout(false);
			this.ResumeLayout(false);

		}

		#endregion
		private System.Windows.Forms.Panel panel1;
		private System.Windows.Forms.TabControl tabControl1;
		private System.Windows.Forms.TabPage tpPersonalInfo;
		private userControls._01_People.uc1N_FindPersonThenFillData findPerson;
		private System.Windows.Forms.Button btnNext;
		private System.Windows.Forms.TabPage tpUserInfo;
		private System.Windows.Forms.Panel panel2;
		private System.Windows.Forms.Label _lblLicenseClasses;
		private System.Windows.Forms.Label _lblApplicationDate;
		private System.Windows.Forms.Label lblApplicationID;
		private System.Windows.Forms.Button btnBack;
		private System.Windows.Forms.Button btnSave;
		private System.Windows.Forms.Button btnClose;
		private System.Windows.Forms.Label lblAdd_Update;
		private System.Windows.Forms.Label _lblApplicationFees;
		private System.Windows.Forms.Label _lblCreatedBy;
		private System.Windows.Forms.ComboBox cbLicensesClasses;
		private System.Windows.Forms.Label lblApplicationFees;
		private System.Windows.Forms.Label lblApplicationDate;
		private System.Windows.Forms.Label lblCreatedBy;
	}
}