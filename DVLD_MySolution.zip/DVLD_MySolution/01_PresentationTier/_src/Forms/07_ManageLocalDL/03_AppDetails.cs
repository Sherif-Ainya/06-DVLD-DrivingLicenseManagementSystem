﻿using System.Windows.Forms;

namespace _02_DVLD_Mine._src.Forms._06_ManageLocalDL
{
	public partial class frmAppDetails : Form
	{
		private int _AppID;
		public frmAppDetails(int ApplicationID)
		{
			InitializeComponent();
			_AppID = ApplicationID;
		}


		private void frmAppDetails_Load(object sender, System.EventArgs e)
		{
			ucADL_BasicInfo1.LoadData(_AppID);
		}
		private void btnClose_Click(object sender, System.EventArgs e)
		{
			this.Close();
		}
	}
}
