﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Windows.Forms;
using _02_DVLD_Mine._src.Forms._07_Tests;
using _02_DVLD_Mine._src.Forms._09_Licenses;
using DVLD_Business;

namespace _02_DVLD_Mine._src.Forms._06_ManageLocalDL
{
	public partial class frmManageLDLA : Form
	{
		private void dgvLocalDL_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
		{
			dgvLocalDL.ColumnHeadersHeight = 60;
			dgvLocalDL.RowTemplate.Height = 30;

			dgvLocalDL.Columns[0].Width = 120;
			dgvLocalDL.Columns[2].Width = 120;
			dgvLocalDL.Columns[4].Width = 150;
			dgvLocalDL.Columns[5].Width = 120;
			dgvLocalDL.Columns[6].Width = 125;

			dgvLocalDL.Columns[0].HeaderText = "License ID";
			dgvLocalDL.Columns[1].HeaderText = "Type Name";
			dgvLocalDL.Columns[2].HeaderText = "National No";
			dgvLocalDL.Columns[3].HeaderText = "Full Name";
			dgvLocalDL.Columns[4].HeaderText = "Date";
			dgvLocalDL.Columns[5].HeaderText = "Passed Test Count";
			dgvLocalDL.Columns[6].HeaderText = "Status";
		}
		private void _RefreshLocalApps()
		{
			mtxbFilter.Text = "";
			mtxbFilter.Visible = false;

			dgvLocalDL.SuspendLayout();
			dgvLocalDL.DataSource = clsBusinessLocalDrivingLicenseapplications_View.GetAllLocalDLApplications_View();
			dgvLocalDL.ResumeLayout();
			lblTotalLocalDL.Text = "Total Local DL [" + dgvLocalDL.RowCount.ToString() + "].";
		}
		private void _PrepareThisForm()
		{
			_RefreshLocalApps();
			cbFilterBy.Items.AddRange(new string[] { "None", "DL ID", "NationalNo", "Full Name", "Status" });
		}


		public frmManageLDLA()
		{
			InitializeComponent();
			_PrepareThisForm();
		}


		Dictionary<string, string> columnMapping = new Dictionary<string, string>()
		{
			{"DL ID", "LocalDrivingLicenseApplicationID" },
			{"NationalNo", "NationalNo" },
			{"Full Name", "FullName" }
		};
		private void FilterData()
		{
			if (dgvLocalDL.DataSource is DataTable dt)
			{
				string searchValue = mtxbFilter.Text.Replace("-", "").Trim();

				string displayName = cbFilterBy.SelectedItem.ToString();
				string actualColumnName = columnMapping[displayName];

				if (!string.IsNullOrEmpty(searchValue))
				{
					if (displayName.Contains("ID"))
					{
						string filterExpression = $"{actualColumnName} = {searchValue}";
						dt.DefaultView.RowFilter = filterExpression;
					}
					else
					{
						string filterExpression = $"{actualColumnName} LIKE '%{searchValue}%'";
						dt.DefaultView.RowFilter = filterExpression;
					}
				}
				else
				{
					dt.DefaultView.RowFilter = "";
				}
			}
		}
		private void cbFilterBy_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			mtxbFilter.Visible = false;
			cbStatus.Visible = false;

			if (cbFilterBy.SelectedItem.ToString() == "None")
			{
				if (dgvLocalDL.DataSource is DataTable dt)
				{
					dt.DefaultView.RowFilter = "";
					lblTotalLocalDL.Text = "Total Local DL [" + dgvLocalDL.RowCount.ToString() + "].";
				}
				return;
			}

			if (cbFilterBy.SelectedItem.ToString() == "Status")
			{
				cbStatus.Visible = true;
				return;
			}

			if (cbFilterBy.SelectedItem.ToString().Contains("ID"))
			{
				mtxbFilter.Mask = "000000";
			}
			else
			{
				mtxbFilter.Mask = "";
			}
			mtxbFilter.Visible = true;
			mtxbFilter.Text = string.Empty;
			mtxbFilter.Focus();
		}
		//
		private void mtxbFilter_TextChanged(object sender, System.EventArgs e)
		{
			FilterData();
			lblTotalLocalDL.Text = "# Records [" + dgvLocalDL.RowCount.ToString() + "].";
		}
		private void cbStatus_DropDownClosed(object sender, EventArgs e)
		{
			if (dgvLocalDL.DataSource is DataTable dt)
			{
				string filterExpression = $"Status = '{cbStatus.SelectedItem}'";
				dt.DefaultView.RowFilter = filterExpression;
				lblTotalLocalDL.Text = "# Records [" + dgvLocalDL.RowCount.ToString() + "].";
			}
		}

		private void btnAddNewLocalDLA_Click(object sender, EventArgs e)
		{
			Form addNew = new frmAddNewLDLA();
			addNew.ShowDialog();
			_RefreshLocalApps();
		}
		private void btnClose_Click(object sender, EventArgs e)
		{
			this.Close();
		}


		//////////////////// Contest Menu Strip /////////////////////
		#region
		private void _New()
		{
			tsmiEdit.Enabled = true;
			tsmiCancel.Enabled = true;
			tsmiDelete.Enabled = true;
			tsmiSechduleTests.Enabled = true;
			tsmiIssueDL_FirstTime.Enabled = false;
			tsmiShowLicense.Enabled = false;

			int passedTests = (int)dgvLocalDL.CurrentRow.Cells[5].Value;
			switch (passedTests)
			{
				case 0:
					tsmi2_VisionTest.Enabled = true;
					tsmi2_WrittenTest.Enabled = false;
					tsmi2_PracticalTest.Enabled = false;
					break;
				case 1:
					tsmi2_VisionTest.Enabled = false;
					tsmi2_WrittenTest.Enabled = true;
					tsmi2_PracticalTest.Enabled = false;
					break;
				case 2:
					tsmi2_VisionTest.Enabled = false;
					tsmi2_WrittenTest.Enabled = false;
					tsmi2_PracticalTest.Enabled = true;
					break;
				case 3:
					tsmiSechduleTests.Enabled = false;
					tsmiIssueDL_FirstTime.Enabled = true;
					break;
			}
		}
		private void _Cancelled()
		{
			tsmiEdit.Enabled = false;
			tsmiCancel.Enabled = false;
			tsmiDelete.Enabled = true;
			tsmiSechduleTests.Enabled = false;
			tsmiIssueDL_FirstTime.Enabled = false;
			tsmiShowLicense.Enabled = false;
		}
		private void _Completed()
		{
			tsmiEdit.Enabled = false;
			tsmiCancel.Enabled = false;
			tsmiDelete.Enabled = false;
			tsmiSechduleTests.Enabled = false;
			tsmiIssueDL_FirstTime.Enabled = false;
			tsmiShowLicense.Enabled = true;
		}
		private void cmsApps_Opened(object sender, EventArgs e)
		{
			string status = dgvLocalDL.CurrentRow.Cells[6].Value.ToString();

			if (status == "New")
				_New();

			if (status == "Cancelled")
				_Cancelled();

			if (status == "Completed")
				_Completed();


			//if ( thisApplicationHasLicense)
			//if (firsttimemakethisPersonDriver)
		}
		//
		private void tsmiShowDetails_Click(object sender, EventArgs e)
		{
			Form frm = new frmAppDetails((int)dgvLocalDL.CurrentRow.Cells[0].Value);
			frm.ShowDialog();
		}
		private void tsmiEdit_Click(object sender, EventArgs e)
		{
			MessageBox.Show("Is Not Ready Yet!");
		}
		private void tsmiCancel_Click(object sender, EventArgs e)
		{
			if (MessageBox.Show("Are You Sure You Want To Cancel This Application?", "Warning", MessageBoxButtons.OKCancel, MessageBoxIcon.Question) == DialogResult.Cancel)
			{
				return;
			}

			int localAppID = (int)dgvLocalDL.CurrentRow.Cells[0].Value;
			if (!clsBusiness_LDLA.ChangeAppStatusByLDLA_ID(localAppID, clsBusiness_LDLA.enLA_Status.eCancelled))
			{
				MessageBox.Show("Application Is Not Cancelled Due To Data Connected To It.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
				return;
			}
			_RefreshLocalApps();
		}
		private void tsmiDelete_Click(object sender, EventArgs e)
		{
			if (MessageBox.Show("Are You Sure You Want To Delete This Application?", "Warning", MessageBoxButtons.OKCancel, MessageBoxIcon.Question) == DialogResult.Cancel)
			{
				return;
			}

			int appID = (int)dgvLocalDL.CurrentRow.Cells[0].Value;
			if (!clsBusiness_LDLA.DeleteLocalDLApplication(appID))
			{
				MessageBox.Show("Application Is Not Cancelled Due To Data Connected To It.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
				return;
			}
			_RefreshLocalApps();
		}

		private void tsmi2_VisionTest_Click(object sender, EventArgs e)
		{
			int LDLA_ID = (int)dgvLocalDL.CurrentRow.Cells[0].Value;
			Form frm = new frmTestApplication(LDLA_ID, frmTestApplication.enTestType.eVision);
			frm.ShowDialog();
			_RefreshLocalApps();
		}
		private void tsmi2_WrittenTest_Click(object sender, EventArgs e)
		{
			int LDLA_ID = (int)dgvLocalDL.CurrentRow.Cells[0].Value;
			Form frm = new frmTestApplication(LDLA_ID, frmTestApplication.enTestType.eWritten);
			frm.ShowDialog();
			_RefreshLocalApps();
		}
		private void tsmi2_PracticalTest_Click(object sender, EventArgs e)
		{
			int LDLA_ID = (int)dgvLocalDL.CurrentRow.Cells[0].Value;
			Form frm = new frmTestApplication(LDLA_ID, frmTestApplication.enTestType.ePractical);
			frm.ShowDialog();
			_RefreshLocalApps();
		}

		private void tsmiIssueDL_FirstTime_Click(object sender, EventArgs e)
		{
			int LDLA_ID = (int)dgvLocalDL.CurrentRow.Cells[0].Value;
			string personNationalNo = (string)dgvLocalDL.CurrentRow.Cells[2].Value;

			Form frm = new frmIssueLicenseFirstTime(LDLA_ID, personNationalNo);
			frm.ShowDialog();
			_RefreshLocalApps();
		}
		private void tsmiShowLicense_Click(object sender, EventArgs e)
		{
			Form frm = new frmLicenseDetails((int)dgvLocalDL.CurrentRow.Cells[0].Value, frmLicenseDetails.enFindBy.eLDLA_ID);
			frm.ShowDialog();
			_RefreshLocalApps();
		}
		private void tsmiPersonDL_History_Click(object sender, EventArgs e)
		{
			string personNationalNo = (string)dgvLocalDL.CurrentRow.Cells[2].Value;
			Form frm = new frmLicensesHistory(personNationalNo);
			frm.ShowDialog();
			_RefreshLocalApps();
		}
		#endregion
	}
}
