﻿namespace _02_DVLD_Mine._src.Forms._06_ManageLocalDL
{
	partial class frmAppDetails
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.btnClose = new System.Windows.Forms.Button();
			this.lblPersonDetails = new System.Windows.Forms.Label();
			this.ucADL_BasicInfo1 = new _02_DVLD_Mine._src.userControls._03_ucDLA.ucADL_BasicInfo();
			this.SuspendLayout();
			// 
			// btnClose
			// 
			this.btnClose.BackColor = System.Drawing.SystemColors.ScrollBar;
			this.btnClose.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
			this.btnClose.FlatAppearance.BorderSize = 2;
			this.btnClose.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnClose.Font = new System.Drawing.Font("Microsoft YaHei UI", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnClose.ForeColor = System.Drawing.Color.Red;
			this.btnClose.Image = global::_02_DVLD_Mine.Properties.Resources.close;
			this.btnClose.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btnClose.Location = new System.Drawing.Point(723, 570);
			this.btnClose.Name = "btnClose";
			this.btnClose.Size = new System.Drawing.Size(122, 53);
			this.btnClose.TabIndex = 0;
			this.btnClose.Text = "Close";
			this.btnClose.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.btnClose.UseVisualStyleBackColor = false;
			this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
			// 
			// lblPersonDetails
			// 
			this.lblPersonDetails.AutoSize = true;
			this.lblPersonDetails.Font = new System.Drawing.Font("Palatino Linotype", 39F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblPersonDetails.ForeColor = System.Drawing.Color.BlueViolet;
			this.lblPersonDetails.Location = new System.Drawing.Point(229, 21);
			this.lblPersonDetails.Name = "lblPersonDetails";
			this.lblPersonDetails.Size = new System.Drawing.Size(494, 71);
			this.lblPersonDetails.TabIndex = 13;
			this.lblPersonDetails.Text = "Application Details";
			// 
			// ucADL_BasicInfo1
			// 
			this.ucADL_BasicInfo1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
			this.ucADL_BasicInfo1.Location = new System.Drawing.Point(56, 118);
			this.ucADL_BasicInfo1.Name = "ucADL_BasicInfo1";
			this.ucADL_BasicInfo1.Size = new System.Drawing.Size(809, 443);
			this.ucADL_BasicInfo1.TabIndex = 14;
			// 
			// frmAppDetails
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = System.Drawing.Color.Plum;
			this.CancelButton = this.btnClose;
			this.ClientSize = new System.Drawing.Size(928, 633);
			this.Controls.Add(this.ucADL_BasicInfo1);
			this.Controls.Add(this.btnClose);
			this.Controls.Add(this.lblPersonDetails);
			this.Name = "frmAppDetails";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Application Details";
			this.Load += new System.EventHandler(this.frmAppDetails_Load);
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.Button btnClose;
		private System.Windows.Forms.Label lblPersonDetails;
		private userControls._03_ucDLA.ucADL_BasicInfo ucADL_BasicInfo1;
	}
}