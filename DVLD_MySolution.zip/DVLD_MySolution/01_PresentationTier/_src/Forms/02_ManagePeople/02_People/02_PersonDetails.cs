﻿using System.Windows.Forms;
using _02_DVLD_Mine._src.userControls.People;

namespace _02_DVLD_Mine._src.Main.People
{
	public partial class frmPersonDetails : Form
	{
		private int _personID;
		public frmPersonDetails(int PersonID)
		{
			InitializeComponent();
			_personID = PersonID;
		}


		private void _03_ShowDetails_Load(object sender, System.EventArgs e)
		{
			panShowDetails.SuspendLayout();
			panShowDetails.Controls.Clear();
			panShowDetails.Controls.Add(new uc1_PersonDetails(_personID));
			panShowDetails.ResumeLayout();
		}


		private void btnClose_Click(object sender, System.EventArgs e)
		{
			this.Close();
		}
	}
}
