﻿namespace _02_DVLD_Mine._src.Main
{
	partial class frmManagePeople
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
			this.label1 = new System.Windows.Forms.Label();
			this.dgvPeople = new System.Windows.Forms.DataGridView();
			this.cmsPeople = new System.Windows.Forms.ContextMenuStrip(this.components);
			this.tsmiReturnPersonID = new System.Windows.Forms.ToolStripMenuItem();
			this.tsmiLine0 = new System.Windows.Forms.ToolStripSeparator();
			this.tsmiShowDetails = new System.Windows.Forms.ToolStripMenuItem();
			this.tsmiLine1 = new System.Windows.Forms.ToolStripSeparator();
			this.tsmiAddNew = new System.Windows.Forms.ToolStripMenuItem();
			this.tsmiEdit = new System.Windows.Forms.ToolStripMenuItem();
			this.tsmiDelete = new System.Windows.Forms.ToolStripMenuItem();
			this.tsmiLine2 = new System.Windows.Forms.ToolStripSeparator();
			this.tsmiSendEmail = new System.Windows.Forms.ToolStripMenuItem();
			this.tsmiPhoneCall = new System.Windows.Forms.ToolStripMenuItem();
			this.cbFilterBy = new System.Windows.Forms.ComboBox();
			this.lblTotalPeople = new System.Windows.Forms.Label();
			this.mtxbFilter = new System.Windows.Forms.MaskedTextBox();
			this.lblFilterBy = new System.Windows.Forms.Label();
			this.btnClose = new System.Windows.Forms.Button();
			this.lblHintHowToReturn = new System.Windows.Forms.Label();
			this.cbCountries = new System.Windows.Forms.ComboBox();
			this.rbFemale = new System.Windows.Forms.RadioButton();
			this.rbMale = new System.Windows.Forms.RadioButton();
			this.gbGender = new System.Windows.Forms.GroupBox();
			this.btnAddNew = new System.Windows.Forms.Button();
			((System.ComponentModel.ISupportInitialize)(this.dgvPeople)).BeginInit();
			this.cmsPeople.SuspendLayout();
			this.gbGender.SuspendLayout();
			this.SuspendLayout();
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Font = new System.Drawing.Font("Palatino Linotype", 48F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
			this.label1.Location = new System.Drawing.Point(375, 43);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(471, 85);
			this.label1.TabIndex = 0;
			this.label1.Text = "Manage People";
			// 
			// dgvPeople
			// 
			this.dgvPeople.AllowUserToAddRows = false;
			this.dgvPeople.AllowUserToDeleteRows = false;
			this.dgvPeople.AllowUserToOrderColumns = true;
			this.dgvPeople.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.ColumnHeader;
			this.dgvPeople.BackgroundColor = System.Drawing.SystemColors.GradientInactiveCaption;
			dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
			dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
			dataGridViewCellStyle1.Font = new System.Drawing.Font("Viner Hand ITC", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
			dataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.Aqua;
			dataGridViewCellStyle1.SelectionForeColor = System.Drawing.Color.Violet;
			dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
			this.dgvPeople.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
			this.dgvPeople.ColumnHeadersHeight = 50;
			this.dgvPeople.ContextMenuStrip = this.cmsPeople;
			dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
			dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
			dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
			dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.SkyBlue;
			dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.ControlText;
			dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
			this.dgvPeople.DefaultCellStyle = dataGridViewCellStyle2;
			this.dgvPeople.Location = new System.Drawing.Point(16, 270);
			this.dgvPeople.Name = "dgvPeople";
			this.dgvPeople.ReadOnly = true;
			this.dgvPeople.RowHeadersWidth = 35;
			this.dgvPeople.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
			this.dgvPeople.Size = new System.Drawing.Size(1226, 321);
			this.dgvPeople.TabIndex = 0;
			this.dgvPeople.TabStop = false;
			this.dgvPeople.CellFormatting += new System.Windows.Forms.DataGridViewCellFormattingEventHandler(this.dgvPeople_CellFormatting);
			this.dgvPeople.DoubleClick += new System.EventHandler(this.showDetailsToolStripMenuItem_Click);
			// 
			// cmsPeople
			// 
			this.cmsPeople.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsmiReturnPersonID,
            this.tsmiLine0,
            this.tsmiShowDetails,
            this.tsmiLine1,
            this.tsmiAddNew,
            this.tsmiEdit,
            this.tsmiDelete,
            this.tsmiLine2,
            this.tsmiSendEmail,
            this.tsmiPhoneCall});
			this.cmsPeople.Name = "cmsPeople";
			this.cmsPeople.Size = new System.Drawing.Size(198, 302);
			// 
			// tsmiReturnPersonID
			// 
			this.tsmiReturnPersonID.Font = new System.Drawing.Font("Aldhabi", 17F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.tsmiReturnPersonID.Image = global::_02_DVLD_Mine.Properties.Resources.undo;
			this.tsmiReturnPersonID.Name = "tsmiReturnPersonID";
			this.tsmiReturnPersonID.Size = new System.Drawing.Size(197, 40);
			this.tsmiReturnPersonID.Text = "Return This Person";
			this.tsmiReturnPersonID.TextDirection = System.Windows.Forms.ToolStripTextDirection.Horizontal;
			this.tsmiReturnPersonID.Visible = false;
			this.tsmiReturnPersonID.Click += new System.EventHandler(this.tsmiReturnPersonID_Click);
			// 
			// tsmiLine0
			// 
			this.tsmiLine0.Name = "tsmiLine0";
			this.tsmiLine0.Size = new System.Drawing.Size(194, 6);
			this.tsmiLine0.Visible = false;
			// 
			// tsmiShowDetails
			// 
			this.tsmiShowDetails.Font = new System.Drawing.Font("Aldhabi", 17F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.tsmiShowDetails.Image = global::_02_DVLD_Mine.Properties.Resources.wrap;
			this.tsmiShowDetails.Name = "tsmiShowDetails";
			this.tsmiShowDetails.Size = new System.Drawing.Size(197, 40);
			this.tsmiShowDetails.Text = "Show Details";
			this.tsmiShowDetails.TextDirection = System.Windows.Forms.ToolStripTextDirection.Horizontal;
			this.tsmiShowDetails.Click += new System.EventHandler(this.showDetailsToolStripMenuItem_Click);
			// 
			// tsmiLine1
			// 
			this.tsmiLine1.Name = "tsmiLine1";
			this.tsmiLine1.Size = new System.Drawing.Size(194, 6);
			// 
			// tsmiAddNew
			// 
			this.tsmiAddNew.Font = new System.Drawing.Font("Aldhabi", 17F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.tsmiAddNew.Image = global::_02_DVLD_Mine.Properties.Resources.administrator;
			this.tsmiAddNew.Name = "tsmiAddNew";
			this.tsmiAddNew.Size = new System.Drawing.Size(197, 40);
			this.tsmiAddNew.Text = "Add New";
			this.tsmiAddNew.TextDirection = System.Windows.Forms.ToolStripTextDirection.Horizontal;
			this.tsmiAddNew.Visible = false;
			this.tsmiAddNew.Click += new System.EventHandler(this.btnAddNew_Click);
			// 
			// tsmiEdit
			// 
			this.tsmiEdit.Font = new System.Drawing.Font("Aldhabi", 17F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.tsmiEdit.Image = global::_02_DVLD_Mine.Properties.Resources.highlighter_pen;
			this.tsmiEdit.Name = "tsmiEdit";
			this.tsmiEdit.Size = new System.Drawing.Size(197, 40);
			this.tsmiEdit.Text = "Edit";
			this.tsmiEdit.TextDirection = System.Windows.Forms.ToolStripTextDirection.Horizontal;
			this.tsmiEdit.Click += new System.EventHandler(this.editToolStripMenuItem_Click);
			// 
			// tsmiDelete
			// 
			this.tsmiDelete.Font = new System.Drawing.Font("Aldhabi", 17F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.tsmiDelete.Image = global::_02_DVLD_Mine.Properties.Resources.delete;
			this.tsmiDelete.Name = "tsmiDelete";
			this.tsmiDelete.Size = new System.Drawing.Size(197, 40);
			this.tsmiDelete.Text = "Delete";
			this.tsmiDelete.TextDirection = System.Windows.Forms.ToolStripTextDirection.Horizontal;
			this.tsmiDelete.Click += new System.EventHandler(this.deleteToolStripMenuItem_Click);
			// 
			// tsmiLine2
			// 
			this.tsmiLine2.Name = "tsmiLine2";
			this.tsmiLine2.Size = new System.Drawing.Size(194, 6);
			// 
			// tsmiSendEmail
			// 
			this.tsmiSendEmail.Font = new System.Drawing.Font("Aldhabi", 17F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.tsmiSendEmail.Image = global::_02_DVLD_Mine.Properties.Resources.edit;
			this.tsmiSendEmail.Name = "tsmiSendEmail";
			this.tsmiSendEmail.Size = new System.Drawing.Size(197, 40);
			this.tsmiSendEmail.Text = "Send Email";
			this.tsmiSendEmail.TextDirection = System.Windows.Forms.ToolStripTextDirection.Horizontal;
			this.tsmiSendEmail.Click += new System.EventHandler(this.sendEmailToolStripMenuItem_Click);
			// 
			// tsmiPhoneCall
			// 
			this.tsmiPhoneCall.Font = new System.Drawing.Font("Aldhabi", 17F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.tsmiPhoneCall.Image = global::_02_DVLD_Mine.Properties.Resources.call;
			this.tsmiPhoneCall.Name = "tsmiPhoneCall";
			this.tsmiPhoneCall.Size = new System.Drawing.Size(197, 40);
			this.tsmiPhoneCall.Text = "Phone Call";
			this.tsmiPhoneCall.TextDirection = System.Windows.Forms.ToolStripTextDirection.Horizontal;
			this.tsmiPhoneCall.Click += new System.EventHandler(this.phoneCallToolStripMenuItem_Click);
			// 
			// cbFilterBy
			// 
			this.cbFilterBy.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.cbFilterBy.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.cbFilterBy.FormattingEnabled = true;
			this.cbFilterBy.ItemHeight = 18;
			this.cbFilterBy.Location = new System.Drawing.Point(116, 228);
			this.cbFilterBy.Name = "cbFilterBy";
			this.cbFilterBy.Size = new System.Drawing.Size(223, 26);
			this.cbFilterBy.TabIndex = 2;
			this.cbFilterBy.TabStop = false;
			this.cbFilterBy.SelectedIndexChanged += new System.EventHandler(this.cbFilterBy_SelectedIndexChanged);
			// 
			// lblTotalPeople
			// 
			this.lblTotalPeople.AutoSize = true;
			this.lblTotalPeople.Font = new System.Drawing.Font("Mongolian Baiti", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblTotalPeople.Location = new System.Drawing.Point(40, 613);
			this.lblTotalPeople.Name = "lblTotalPeople";
			this.lblTotalPeople.Size = new System.Drawing.Size(146, 25);
			this.lblTotalPeople.TabIndex = 4;
			this.lblTotalPeople.Text = "Total People";
			// 
			// mtxbFilter
			// 
			this.mtxbFilter.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.mtxbFilter.Location = new System.Drawing.Point(348, 228);
			this.mtxbFilter.Name = "mtxbFilter";
			this.mtxbFilter.Size = new System.Drawing.Size(223, 26);
			this.mtxbFilter.TabIndex = 6;
			this.mtxbFilter.Visible = false;
			this.mtxbFilter.TextChanged += new System.EventHandler(this.mtxbFilter_TextChanged);
			// 
			// lblFilterBy
			// 
			this.lblFilterBy.AutoSize = true;
			this.lblFilterBy.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblFilterBy.Location = new System.Drawing.Point(24, 230);
			this.lblFilterBy.Name = "lblFilterBy";
			this.lblFilterBy.Size = new System.Drawing.Size(86, 22);
			this.lblFilterBy.TabIndex = 6;
			this.lblFilterBy.Text = "Filter By :";
			// 
			// btnClose
			// 
			this.btnClose.BackColor = System.Drawing.SystemColors.ScrollBar;
			this.btnClose.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
			this.btnClose.FlatAppearance.BorderSize = 2;
			this.btnClose.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnClose.Font = new System.Drawing.Font("Microsoft YaHei UI", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnClose.ForeColor = System.Drawing.Color.Red;
			this.btnClose.Image = global::_02_DVLD_Mine.Properties.Resources.close;
			this.btnClose.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btnClose.Location = new System.Drawing.Point(1095, 601);
			this.btnClose.Name = "btnClose";
			this.btnClose.Size = new System.Drawing.Size(119, 53);
			this.btnClose.TabIndex = 0;
			this.btnClose.Text = "Close";
			this.btnClose.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.btnClose.UseVisualStyleBackColor = false;
			this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
			// 
			// lblHintHowToReturn
			// 
			this.lblHintHowToReturn.BackColor = System.Drawing.Color.PaleTurquoise;
			this.lblHintHowToReturn.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.lblHintHowToReturn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.lblHintHowToReturn.Font = new System.Drawing.Font("Microsoft Uighur", 15.75F, System.Drawing.FontStyle.Bold);
			this.lblHintHowToReturn.Location = new System.Drawing.Point(390, 601);
			this.lblHintHowToReturn.Name = "lblHintHowToReturn";
			this.lblHintHowToReturn.Size = new System.Drawing.Size(426, 53);
			this.lblHintHowToReturn.TabIndex = 35;
			this.lblHintHowToReturn.Text = "Select Person Then Right Click To Return It.";
			this.lblHintHowToReturn.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			this.lblHintHowToReturn.Visible = false;
			// 
			// cbCountries
			// 
			this.cbCountries.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.cbCountries.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.cbCountries.FormattingEnabled = true;
			this.cbCountries.ItemHeight = 18;
			this.cbCountries.Location = new System.Drawing.Point(348, 228);
			this.cbCountries.Name = "cbCountries";
			this.cbCountries.Size = new System.Drawing.Size(223, 26);
			this.cbCountries.TabIndex = 5;
			this.cbCountries.TabStop = false;
			this.cbCountries.Visible = false;
			this.cbCountries.DropDownClosed += new System.EventHandler(this.cbCountries_DropDownClosed);
			// 
			// rbFemale
			// 
			this.rbFemale.AutoSize = true;
			this.rbFemale.BackColor = System.Drawing.Color.LightSkyBlue;
			this.rbFemale.Font = new System.Drawing.Font("Malgun Gothic", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.rbFemale.Location = new System.Drawing.Point(93, 22);
			this.rbFemale.Name = "rbFemale";
			this.rbFemale.Size = new System.Drawing.Size(77, 24);
			this.rbFemale.TabIndex = 4;
			this.rbFemale.TabStop = true;
			this.rbFemale.Text = "Female";
			this.rbFemale.UseVisualStyleBackColor = false;
			this.rbFemale.CheckedChanged += new System.EventHandler(this.rbFemale_CheckedChanged);
			// 
			// rbMale
			// 
			this.rbMale.AutoSize = true;
			this.rbMale.BackColor = System.Drawing.Color.LightSkyBlue;
			this.rbMale.Font = new System.Drawing.Font("Malgun Gothic", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.rbMale.Location = new System.Drawing.Point(15, 22);
			this.rbMale.Name = "rbMale";
			this.rbMale.Size = new System.Drawing.Size(61, 24);
			this.rbMale.TabIndex = 3;
			this.rbMale.TabStop = true;
			this.rbMale.Text = "Male";
			this.rbMale.UseVisualStyleBackColor = false;
			this.rbMale.CheckedChanged += new System.EventHandler(this.rbMale_CheckedChanged);
			// 
			// gbGender
			// 
			this.gbGender.BackColor = System.Drawing.Color.LightBlue;
			this.gbGender.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
			this.gbGender.Controls.Add(this.rbFemale);
			this.gbGender.Controls.Add(this.rbMale);
			this.gbGender.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.gbGender.Font = new System.Drawing.Font("Microsoft Tai Le", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.gbGender.Location = new System.Drawing.Point(360, 206);
			this.gbGender.Name = "gbGender";
			this.gbGender.Size = new System.Drawing.Size(184, 59);
			this.gbGender.TabIndex = 55;
			this.gbGender.TabStop = false;
			this.gbGender.Text = "Gender :";
			this.gbGender.Visible = false;
			// 
			// btnAddNew
			// 
			this.btnAddNew.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
			this.btnAddNew.FlatAppearance.BorderColor = System.Drawing.Color.MediumSlateBlue;
			this.btnAddNew.FlatAppearance.BorderSize = 5;
			this.btnAddNew.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
			this.btnAddNew.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
			this.btnAddNew.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnAddNew.Font = new System.Drawing.Font("Microsoft YaHei UI", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnAddNew.ForeColor = System.Drawing.Color.Red;
			this.btnAddNew.Image = global::_02_DVLD_Mine.Properties.Resources.administrator;
			this.btnAddNew.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btnAddNew.Location = new System.Drawing.Point(1110, 193);
			this.btnAddNew.Name = "btnAddNew";
			this.btnAddNew.Size = new System.Drawing.Size(93, 71);
			this.btnAddNew.TabIndex = 1;
			this.btnAddNew.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.btnAddNew.UseVisualStyleBackColor = false;
			this.btnAddNew.Click += new System.EventHandler(this.btnAddNew_Click);
			// 
			// frmManagePeople
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = System.Drawing.Color.LightSkyBlue;
			this.CancelButton = this.btnClose;
			this.ClientSize = new System.Drawing.Size(1254, 661);
			this.Controls.Add(this.btnAddNew);
			this.Controls.Add(this.gbGender);
			this.Controls.Add(this.cbCountries);
			this.Controls.Add(this.lblHintHowToReturn);
			this.Controls.Add(this.btnClose);
			this.Controls.Add(this.lblFilterBy);
			this.Controls.Add(this.mtxbFilter);
			this.Controls.Add(this.lblTotalPeople);
			this.Controls.Add(this.cbFilterBy);
			this.Controls.Add(this.dgvPeople);
			this.Controls.Add(this.label1);
			this.Name = "frmManagePeople";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Manage People";
			((System.ComponentModel.ISupportInitialize)(this.dgvPeople)).EndInit();
			this.cmsPeople.ResumeLayout(false);
			this.gbGender.ResumeLayout(false);
			this.gbGender.PerformLayout();
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.DataGridView dgvPeople;
		private System.Windows.Forms.ComboBox cbFilterBy;
		private System.Windows.Forms.Label lblTotalPeople;
		private System.Windows.Forms.MaskedTextBox mtxbFilter;
		private System.Windows.Forms.Label lblFilterBy;
		private System.Windows.Forms.ContextMenuStrip cmsPeople;
		private System.Windows.Forms.ToolStripMenuItem tsmiShowDetails;
		private System.Windows.Forms.ToolStripSeparator tsmiLine1;
		private System.Windows.Forms.ToolStripMenuItem tsmiEdit;
		private System.Windows.Forms.ToolStripMenuItem tsmiDelete;
		private System.Windows.Forms.ToolStripSeparator tsmiLine2;
		private System.Windows.Forms.ToolStripMenuItem tsmiSendEmail;
		private System.Windows.Forms.ToolStripMenuItem tsmiPhoneCall;
		private System.Windows.Forms.Button btnClose;
		private System.Windows.Forms.ToolStripMenuItem tsmiReturnPersonID;
		private System.Windows.Forms.Label lblHintHowToReturn;
		private System.Windows.Forms.ComboBox cbCountries;
		private System.Windows.Forms.RadioButton rbFemale;
		private System.Windows.Forms.RadioButton rbMale;
		private System.Windows.Forms.GroupBox gbGender;
		private System.Windows.Forms.ToolStripSeparator tsmiLine0;
		private System.Windows.Forms.ToolStripMenuItem tsmiAddNew;
		private System.Windows.Forms.Button btnAddNew;
	}
}