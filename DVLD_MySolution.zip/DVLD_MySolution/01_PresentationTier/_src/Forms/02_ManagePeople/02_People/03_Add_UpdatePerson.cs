﻿using System;
using System.Windows.Forms;
using _02_DVLD_Mine._src.userControls.People;

namespace _02_DVLD_Mine._src.Main.People
{
	public partial class frmAdd_UpdatePerson : Form
	{
		public delegate void DataBackEventHandler(object sender, int personID);
		public event DataBackEventHandler ReturnPersonID;

		private int _personID;
		public frmAdd_UpdatePerson(int personID)
		{
			InitializeComponent();
			_personID = personID;
		}


		private void Add_UpdatePerson_Load(object sender, System.EventArgs e)
		{
			if (_personID == -1)
			{
				lblAdd_Update.Text = "Add New Person";
				lblAdd_Update.ForeColor = System.Drawing.Color.MediumVioletRed;
			}
			else
			{
				lblAdd_Update.Text = "Update Person";
				lblAdd_Update.ForeColor = System.Drawing.Color.DarkSlateBlue;
			}

			panShowDetails.SuspendLayout();
			panShowDetails.Controls.Clear();
			uc1_Add_UpdatePerson uc = new uc1_Add_UpdatePerson(_personID);
			panShowDetails.Controls.Add(uc);
			uc.ReturnPersonID += ucAdd_Update_SavedClicked;
			uc.CloseClicked += ucAdd_Update_CloseClicked;
			panShowDetails.ResumeLayout();
		}
		private void ucAdd_Update_SavedClicked(object sender, int personID)
		{
			_personID = personID;
			lblAdd_Update.Text = "Update Person";
			lblAdd_Update.ForeColor = System.Drawing.Color.DarkSlateBlue;
			lblPersonID.Visible = true;
			lblPersonID.Text = personID.ToString();
		}
		private void ucAdd_Update_CloseClicked(object sender, EventArgs eventArgs)
		{
			this.Close();
		}

		private void frmAdd_UpdatePerson_FormClosed(object sender, FormClosedEventArgs e)
		{
			ReturnPersonID?.Invoke(this, _personID);
		}

		private void btnClose_Click(object sender, EventArgs e)
		{
			this.Close();
		}
	}
}
