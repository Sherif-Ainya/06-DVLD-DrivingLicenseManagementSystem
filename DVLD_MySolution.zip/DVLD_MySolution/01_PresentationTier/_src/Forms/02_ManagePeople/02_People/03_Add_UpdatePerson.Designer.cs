﻿namespace _02_DVLD_Mine._src.Main.People
{
	partial class frmAdd_UpdatePerson
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.lblAdd_Update = new System.Windows.Forms.Label();
			this.panShowDetails = new System.Windows.Forms.Panel();
			this.lblPersonID = new System.Windows.Forms.Label();
			this.btnClose = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// lblAdd_Update
			// 
			this.lblAdd_Update.Font = new System.Drawing.Font("Palatino Linotype", 38F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblAdd_Update.ForeColor = System.Drawing.Color.MediumVioletRed;
			this.lblAdd_Update.Location = new System.Drawing.Point(333, 31);
			this.lblAdd_Update.Name = "lblAdd_Update";
			this.lblAdd_Update.Size = new System.Drawing.Size(436, 76);
			this.lblAdd_Update.TabIndex = 3;
			this.lblAdd_Update.Text = "Add New Person";
			this.lblAdd_Update.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// panShowDetails
			// 
			this.panShowDetails.BackColor = System.Drawing.Color.LightSteelBlue;
			this.panShowDetails.Location = new System.Drawing.Point(48, 154);
			this.panShowDetails.Name = "panShowDetails";
			this.panShowDetails.Size = new System.Drawing.Size(1009, 424);
			this.panShowDetails.TabIndex = 1;
			// 
			// lblPersonID
			// 
			this.lblPersonID.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
			this.lblPersonID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.lblPersonID.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblPersonID.ForeColor = System.Drawing.Color.Red;
			this.lblPersonID.Location = new System.Drawing.Point(72, 110);
			this.lblPersonID.Name = "lblPersonID";
			this.lblPersonID.Size = new System.Drawing.Size(73, 41);
			this.lblPersonID.TabIndex = 101;
			this.lblPersonID.Text = "-1";
			this.lblPersonID.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			this.lblPersonID.Visible = false;
			// 
			// btnClose
			// 
			this.btnClose.BackColor = System.Drawing.SystemColors.ScrollBar;
			this.btnClose.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
			this.btnClose.FlatAppearance.BorderSize = 2;
			this.btnClose.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnClose.Font = new System.Drawing.Font("Microsoft YaHei UI", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnClose.ForeColor = System.Drawing.Color.Red;
			this.btnClose.Image = global::_02_DVLD_Mine.Properties.Resources.close;
			this.btnClose.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btnClose.Location = new System.Drawing.Point(1043, 0);
			this.btnClose.Name = "btnClose";
			this.btnClose.Size = new System.Drawing.Size(62, 53);
			this.btnClose.TabIndex = 0;
			this.btnClose.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.btnClose.UseVisualStyleBackColor = false;
			this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
			// 
			// frmAdd_UpdatePerson
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = System.Drawing.Color.LightSkyBlue;
			this.CausesValidation = false;
			this.ClientSize = new System.Drawing.Size(1106, 601);
			this.Controls.Add(this.btnClose);
			this.Controls.Add(this.lblPersonID);
			this.Controls.Add(this.panShowDetails);
			this.Controls.Add(this.lblAdd_Update);
			this.Name = "frmAdd_UpdatePerson";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Add_Update Person";
			this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.frmAdd_UpdatePerson_FormClosed);
			this.Load += new System.EventHandler(this.Add_UpdatePerson_Load);
			this.ResumeLayout(false);

		}

		#endregion

		private System.Windows.Forms.Label lblAdd_Update;
		private System.Windows.Forms.Panel panShowDetails;
		private System.Windows.Forms.Label lblPersonID;
		private System.Windows.Forms.Button btnClose;
	}
}