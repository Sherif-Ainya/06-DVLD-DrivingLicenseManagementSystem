﻿using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Windows.Forms;
using _02_DVLD_Mine._src.Forms._02_People;
using _02_DVLD_Mine._src.Forms._09_Licenses;
using _03_DataAccessTier.src;
using DVLD_Business;

namespace _02_DVLD_Mine._src.Forms._02_PeopleN
{
	public partial class frmManagePeopleN : Form  /// NEW WAY.
	{
		public enum enReturnPerson { enReturnPerson, enReturnPerson_CheckUser }
		private enReturnPerson _returnMode = enReturnPerson.enReturnPerson;

		public delegate void DataBackEventHandler(object sender, int personID);
		public event DataBackEventHandler ReturnPersonID;
		private bool filterLoad = false;
		private void dgvPeople_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
		{
			dgvPeople.ColumnHeadersHeight = 60;
			dgvPeople.RowTemplate.Height = 30;

			dgvPeople.Columns["imagePath"].Visible = false;
			dgvPeople.Columns["Address"].Visible = false;

			dgvPeople.Columns["PersonID"].HeaderText = "ID";
			dgvPeople.Columns["NationalNo"].HeaderText = "National No";
			dgvPeople.Columns["FirstName"].HeaderText = "First Name";
			dgvPeople.Columns["SecondName"].HeaderText = "Second Name";
			dgvPeople.Columns["ThirdName"].HeaderText = "Third Name";
			dgvPeople.Columns["LastName"].HeaderText = "Last Name";
			dgvPeople.Columns["DateOfBirth"].HeaderText = "Date Of Birth";

			dgvPeople.Columns["Gendor"].HeaderText = "Gender";
			if (dgvPeople.Columns[e.ColumnIndex].Name == "Gendor")
			{
				if (e.Value != null)
				{
					if (e.Value.ToString() == "0")
					{
						e.Value = "Male";
					}
					else
					{
						e.Value = "Female";
					}
					e.FormattingApplied = true;
				}
			}

			dgvPeople.Columns["NationalityCountryID"].HeaderText = "Nationality";
			if (dgvPeople.Columns[e.ColumnIndex].Name == "NationalityCountryID")
			{
				if (e.Value != null)
				{
					e.Value = clsBusinessCountries.Find(Convert.ToInt32(e.Value)).countryName;
					e.FormattingApplied = true;
				}
			}
		}
		private void _RefreshPeople()
		{
			mtxbFilter.Text = "";
			mtxbFilter.Visible = false;

			dgvPeople.SuspendLayout();
			dgvPeople.DataSource = clsBusinessPeople.GetAllPeople();
			dgvPeople.ResumeLayout();
			lblTotalPeople.Text = "Total People [" + dgvPeople.RowCount.ToString() + "].";
		}
		private bool _DeleteImagePath(string path)
		{
			if (string.IsNullOrEmpty(path)) return true;

			if (!string.IsNullOrEmpty(path) && File.Exists(path))
			{
				File.Delete(path);
				return true;
			}
			return false;
		}
		private void _PrepareThisForm()
		{
			_RefreshPeople();
			cbFilterBy.Items.AddRange(new string[] { "None", "ID", "National No", "First Name", "Second Name", "Third Name", "Last Name", "Gender", "Address", "Phone", "Email", "Nationality" });
			cbFilterBy.SelectedIndex = 0;
			_FillCountriesInComoboBox();
		}
		private void _PrepareThisFormToReturnPersonID()
		{
			_PrepareThisForm();
			tsmiReturnPersonID.Visible = true;
			tsmiLine0.Visible = true;
			tsmiAddNew.Visible = true;
			tsmiDelete.Visible = false;
			tsmiSendEmail.Visible = false;
			tsmiPhoneCall.Visible = false;
			//
			lblHintHowToReturn.Visible = true;
		}
		private void _FillCountriesInComoboBox()
		{
			DataTable dtCountries = clsBusinessCountries.GetAllCountries();

			foreach (DataRow row in dtCountries.Rows)
			{
				cbCountries.Items.Add(row["CountryName"]);
			}
		}

		public frmManagePeopleN()
		{
			InitializeComponent();
			_PrepareThisForm();
		}
		public frmManagePeopleN(enReturnPerson returnMode)
		{
			InitializeComponent();
			_returnMode = returnMode;
			_PrepareThisFormToReturnPersonID();
		}


		Dictionary<string, string> columnMapping = new Dictionary<string, string>()
		{
			{"ID", "PersonID" },
			{"National No", "NationalNo" },
			{"First Name", "FirstName" },
			{"Second Name", "SecondName" },
			{"Third Name", "ThirdName" },
			{"Last Name", "LastName" },

			{"Address", "Address" },
			{"Phone", "Phone" },
			{"Email", "Email" }
		};
		private void FilterData()
		{
			if (dgvPeople.DataSource is DataTable dt)
			{
				string searchValue = mtxbFilter.Text.Replace("-", "").Trim();

				string displayName = cbFilterBy.SelectedItem.ToString();
				string actualColumnName = columnMapping[displayName];

				if (!string.IsNullOrEmpty(searchValue))
				{
					if (displayName.EndsWith("ID"))
					{
						string filterExpression = $"{actualColumnName} = {searchValue}";
						dt.DefaultView.RowFilter = filterExpression;
					}
					else
					{
						string filterExpression = $"{actualColumnName} LIKE '%{searchValue}%'";
						dt.DefaultView.RowFilter = filterExpression;
					}
				}
				else
				{
					dt.DefaultView.RowFilter = "";  // No Filter.
				}
			}
		}
		private void cbFilterBy_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			if (!filterLoad)
			{
				filterLoad = true;
				return;
			}

			mtxbFilter.Visible = false;
			gbGender.Visible = false;
			cbCountries.Visible = false;

			if (cbFilterBy.SelectedItem.ToString() == "None")
			{
				if (dgvPeople.DataSource is DataTable dt)
				{
					dt.DefaultView.RowFilter = "";
					lblTotalPeople.Text = "Total People [" + dgvPeople.RowCount.ToString() + "].";
				}
				return;
			}

			if (cbFilterBy.SelectedItem.ToString() == "Gender")
			{
				gbGender.Visible = true;
				rbMale.Checked = false;
				rbFemale.Checked = false;
				return;
			}

			if (cbFilterBy.SelectedItem.ToString() == "Nationality")
			{
				cbCountries.Visible = true;
				return;
			}

			if (cbFilterBy.SelectedItem.ToString() == "Person ID")
			{
				mtxbFilter.Mask = "000000";
			}
			else
			{
				mtxbFilter.Mask = "";
			}
			mtxbFilter.Visible = true;
			mtxbFilter.Text = string.Empty;
			mtxbFilter.Focus();
		}
		//
		private void mtxbFilter_TextChanged(object sender, System.EventArgs e)
		{
			FilterData();
			lblTotalPeople.Text = "# Records [" + dgvPeople.RowCount.ToString() + "].";
		}
		private void cbCountries_DropDownClosed(object sender, EventArgs e)
		{
			if (dgvPeople.DataSource is DataTable dt)
			{
				if (cbCountries.SelectedIndex != -1)
				{
					string filterExpression = $"NationalityCountryID = {clsBusinessCountries.Find(cbCountries.SelectedItem.ToString()).countryID}";
					dt.DefaultView.RowFilter = filterExpression;
					lblTotalPeople.Text = "# Records [" + dgvPeople.RowCount.ToString() + "].";
				}
			}
		}
		private void rbMale_CheckedChanged(object sender, EventArgs e)
		{
			if (rbMale.Checked)
			{
				if (dgvPeople.DataSource is DataTable dt)
				{
					string filterExpression = $"Gendor = 0";
					dt.DefaultView.RowFilter = filterExpression;
					lblTotalPeople.Text = "# Records [" + dgvPeople.RowCount.ToString() + "].";
				}
			}
		}
		private void rbFemale_CheckedChanged(object sender, EventArgs e)
		{
			if (rbFemale.Checked)
			{
				if (dgvPeople.DataSource is DataTable dt)
				{
					string filterExpression = $"Gendor = 1";
					dt.DefaultView.RowFilter = filterExpression;
					lblTotalPeople.Text = "# Records [" + dgvPeople.RowCount.ToString() + "].";
				}
			}
		}


		//
		// Context Menu Strip.
		private void showDetailsToolStripMenuItem_Click(object sender, EventArgs e)
		{
			int personID = (int)dgvPeople.CurrentRow.Cells[0].Value;
			Form showDetails = new frmPersonDetailsN(personID);
			showDetails.ShowDialog();
			_RefreshPeople();
		}
		private void editToolStripMenuItem_Click(object sender, EventArgs e)
		{
			int personID = (int)dgvPeople.CurrentRow.Cells[0].Value;
			Form update = new frmAdd_UpdatePersonN(personID);
			update.ShowDialog();
			_RefreshPeople();
		}
		private void deleteToolStripMenuItem_Click(object sender, EventArgs e)
		{
			if (MessageBox.Show("Are You Sure You Want To Delete This Person?", "Warning", MessageBoxButtons.OKCancel, MessageBoxIcon.Question) == DialogResult.Cancel)
			{
				return;
			}

			if (_DeleteImagePath(dgvPeople.CurrentRow.Cells["imagePath"].Value.ToString()))
			{
				int personID = (int)dgvPeople.CurrentRow.Cells[0].Value;
				if (!clsBusinessPeople.DeletePerson(personID))
				{
					MessageBox.Show("Person Is Not Deleted Due To Data Connected To It.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
					return;
				}
				_RefreshPeople();
			}
		}
		private void sendEmailToolStripMenuItem_Click(object sender, EventArgs e)
		{
			MessageBox.Show("Sending Email Is Not Implemented Yet!", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
		}
		private void phoneCallToolStripMenuItem_Click(object sender, EventArgs e)
		{
			MessageBox.Show("Phone Call Is Not Implemented Yet!", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
		}

		//
		// Return PersonID.
		private void tsmiReturnPersonID_Click(object sender, EventArgs e)
		{
			int personID = (int)dgvPeople.CurrentRow.Cells[0].Value;

			if (_returnMode == enReturnPerson.enReturnPerson)
			{
				ReturnPersonID?.Invoke(this, personID);
				this.Close();
				return;
			}
			else
			{
				if (clsBusinessPeople.IsThisPersonUser(personID))
				{
					MessageBox.Show("This Person Is Already A User!", "Warrning", MessageBoxButtons.OK, MessageBoxIcon.Information);
					return;
				}

				ReturnPersonID?.Invoke(this, personID);
				this.Close();
			}
		}
		//
		// Person History.
		private void tsmiPersonDL_History_Click(object sender, EventArgs e)
		{
			int personID = (int)dgvPeople.CurrentRow.Cells[0].Value;
			Form frm = new frmLicensesHistory(personID);
			frm.ShowDialog();
			_RefreshPeople();
		}


		//
		// Add New, Close.

		private void btnAddNew_Click(object sender, EventArgs e)
		{
			Form addNew = new frmAdd_UpdatePersonN();
			addNew.ShowDialog();
			_RefreshPeople();
		}
		private void btnClose_Click(object sender, EventArgs e)
		{
			this.Close();
		}

		private void tsmiLine2_Click(object sender, EventArgs e)
		{

		}
	}
}
