﻿namespace _02_DVLD_Mine._src.Forms._02_People
{
	partial class frmAdd_UpdatePersonN
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.lblPersonID = new System.Windows.Forms.Label();
			this.lblAdd_Update = new System.Windows.Forms.Label();
			this.ucAdd_UpdatePersonN1 = new _02_DVLD_Mine._src.userControls._01_PeopleNewWay.uc1N_Add_UpdatePersonN();
			this.SuspendLayout();
			// 
			// lblPersonID
			// 
			this.lblPersonID.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
			this.lblPersonID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.lblPersonID.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblPersonID.ForeColor = System.Drawing.Color.Red;
			this.lblPersonID.Location = new System.Drawing.Point(73, 106);
			this.lblPersonID.Name = "lblPersonID";
			this.lblPersonID.Size = new System.Drawing.Size(73, 41);
			this.lblPersonID.TabIndex = 104;
			this.lblPersonID.Text = "-1";
			this.lblPersonID.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			this.lblPersonID.Visible = false;
			// 
			// lblAdd_Update
			// 
			this.lblAdd_Update.Font = new System.Drawing.Font("Palatino Linotype", 38F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblAdd_Update.ForeColor = System.Drawing.Color.MediumVioletRed;
			this.lblAdd_Update.Location = new System.Drawing.Point(309, 28);
			this.lblAdd_Update.Name = "lblAdd_Update";
			this.lblAdd_Update.Size = new System.Drawing.Size(495, 76);
			this.lblAdd_Update.TabIndex = 102;
			this.lblAdd_Update.Text = "Add New Person N";
			this.lblAdd_Update.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// ucAdd_UpdatePersonN1
			// 
			this.ucAdd_UpdatePersonN1.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
			this.ucAdd_UpdatePersonN1.Location = new System.Drawing.Point(48, 154);
			this.ucAdd_UpdatePersonN1.Name = "ucAdd_UpdatePersonN1";
			this.ucAdd_UpdatePersonN1.Size = new System.Drawing.Size(1009, 424);
			this.ucAdd_UpdatePersonN1.TabIndex = 0;
			this.ucAdd_UpdatePersonN1.TabStop = false;
			this.ucAdd_UpdatePersonN1.OnSavedClicked += new System.Action<int>(this.ucAdd_UpdatePersonN1_OnSavedClicked);
			this.ucAdd_UpdatePersonN1.OnClosedClicked += new System.Action<bool>(this.ucAdd_UpdatePersonN1_OnClosedClicked);
			// 
			// frmAdd_UpdatePersonN
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = System.Drawing.Color.LightSkyBlue;
			this.ClientSize = new System.Drawing.Size(1106, 601);
			this.Controls.Add(this.ucAdd_UpdatePersonN1);
			this.Controls.Add(this.lblPersonID);
			this.Controls.Add(this.lblAdd_Update);
			this.Name = "frmAdd_UpdatePersonN";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Add_Update Person New";
			this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.frmAdd_UpdatePersonN_FormClosed);
			this.Load += new System.EventHandler(this.frmAdd_UpdatePersonN_Load);
			this.ResumeLayout(false);

		}

		#endregion

		private System.Windows.Forms.Label lblPersonID;
		private System.Windows.Forms.Label lblAdd_Update;
		private userControls._01_PeopleNewWay.uc1N_Add_UpdatePersonN ucAdd_UpdatePersonN1;
	}
}