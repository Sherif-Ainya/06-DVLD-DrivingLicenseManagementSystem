﻿using System.Windows.Forms;

namespace _02_DVLD_Mine._src.Forms._02_People
{
		public partial class frmPersonDetailsN : Form
		{
				private int _personID = -1;
				private string _nationalNo = string.Empty;
				public frmPersonDetailsN(int PersonID)
				{
						InitializeComponent();
						_personID = PersonID;
				}
				public frmPersonDetailsN(string nationalNo)
				{
						InitializeComponent();
						_nationalNo = nationalNo;
				}

				private void frmPersonDetailsN_Load(object sender, System.EventArgs e)
				{
						if (_personID != -1)
						{ ucPersonDetailsN1.LoadPersonData(_personID); return; }

						if (_nationalNo != string.Empty)
						{ ucPersonDetailsN1.LoadPersonData(_nationalNo); return; }
				}

				private void btnClose_Click(object sender, System.EventArgs e)
				{
						this.Close();
				}
		}
}
