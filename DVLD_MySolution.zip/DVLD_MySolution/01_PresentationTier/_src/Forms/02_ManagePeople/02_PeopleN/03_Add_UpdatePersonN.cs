﻿using System.Windows.Forms;

namespace _02_DVLD_Mine._src.Forms._02_People
{
	public partial class frmAdd_UpdatePersonN : Form
	{
		public delegate void DataBackEventHandler(object sender, int personID);
		public event DataBackEventHandler ReturnPersonID;

		private int _personID = -1;

		public frmAdd_UpdatePersonN()
		{
			InitializeComponent();
		}
		public frmAdd_UpdatePersonN(int personID)
		{
			InitializeComponent();
			_personID = personID;
		}


		private void frmAdd_UpdatePersonN_Load(object sender, System.EventArgs e)
		{
			if (_personID == -1)
			{
				lblAdd_Update.Text = "Add New Person";
				lblAdd_Update.ForeColor = System.Drawing.Color.MediumVioletRed;
				ucAdd_UpdatePersonN1.LoadPersonAddNew_Update(-1);
			}
			else
			{
				lblAdd_Update.Text = "Update Person";
				lblAdd_Update.ForeColor = System.Drawing.Color.DarkSlateBlue;
				ucAdd_UpdatePersonN1.LoadPersonAddNew_Update(_personID);
			}
		}


		private void ucAdd_UpdatePersonN1_OnSavedClicked(int obj)
		{
			_personID = obj;
			lblAdd_Update.Text = "Update Person";
			lblAdd_Update.ForeColor = System.Drawing.Color.DarkSlateBlue;
			lblPersonID.Visible = true;
			lblPersonID.Text = _personID.ToString();
		}
		private void ucAdd_UpdatePersonN1_OnClosedClicked(bool obj)
		{
			if (obj)
				this.Close();
		}


		private void frmAdd_UpdatePersonN_FormClosed(object sender, FormClosedEventArgs e)
		{
			ReturnPersonID?.Invoke(this, _personID);
		}
	}
}
