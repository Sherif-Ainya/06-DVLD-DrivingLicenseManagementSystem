﻿using System;
using System.Windows.Forms;
using _02_DVLD_Mine._src.Main.People;
using _02_DVLD_Mine._src.userControls.People;
using _02_DVLD_Mine._src.userControls.Users;
using DVLD_Business;

namespace _02_DVLD_Mine._src.Main.Users
{
	public partial class frmAdd_UpdateUser : Form
	{
		private int _UserID = -1, _PersonID;
		private void frmAdd_UpdateUser_Load(object sender, EventArgs e)
		{
			if (_UserID == -1)
			{
				lblAdd_Update.Text = "Add New User";
				lblAdd_Update.ForeColor = System.Drawing.Color.MediumVioletRed;
				cbPersonID_NationalNo.SelectedIndex = 0;
			}
			else
			{
				lblAdd_Update.Text = "Update User";
				lblAdd_Update.ForeColor = System.Drawing.Color.DarkSlateBlue;
				Update();
			}
		}


		public frmAdd_UpdateUser(int UserID, int PersonID = -1)
		{
			InitializeComponent();
			_UserID = UserID;
			_PersonID = PersonID;
		}


		private void btnFindPerson_Click(object sender, EventArgs e)
		{
			frmManagePeople returnvalue = new frmManagePeople("");
			returnvalue.ReturnPersonID += LoadPersonData;
			returnvalue.ShowDialog();
		}
		private void LoadPersonData(object sender, int personID)
		{
			_PersonID = personID;
			Update();
		}


		private void cbPersonID_NationalNo_SelectedIndexChanged(object sender, EventArgs e)
		{
			if (cbPersonID_NationalNo.SelectedIndex == 0)
			{
				mtxbFindPerson.Mask = "00000";
			}
			else
			{
				mtxbFindPerson.Mask = "";
			}
		}
		private void ClearFindPerson_Focus()
		{
			mtxbFindPerson.Text = "";
			mtxbFindPerson.Focus();
		}
		private void pbFind_Click(object sender, EventArgs e)
		{
			if (string.IsNullOrEmpty(mtxbFindPerson.Text))
			{
				mtxbFindPerson.Focus();
				return;
			}

			if (cbPersonID_NationalNo.SelectedIndex == 0)
			{
				int personID = Convert.ToInt32(mtxbFindPerson.Text);
				if (!clsBusinessPeople.IsPersonExist(personID))
				{
					MessageBox.Show("The Person With ID [" + mtxbFindPerson.Text + "] Is Not Found!", "Person Was Not Found!", MessageBoxButtons.OK, MessageBoxIcon.Information);
					ClearFindPerson_Focus();
					return;
				}
				if (clsBusinessPeople.IsThisPersonUser(personID))
				{
					MessageBox.Show("This Person Is Already A User!", "Error!", MessageBoxButtons.OK, MessageBoxIcon.Information);
					ClearFindPerson_Focus();
					return;
				}
				_PersonID = personID;
			}
			else
			{
				string nationalNo = mtxbFindPerson.Text.Trim();
				clsBusinessPeople person = clsBusinessPeople.Find(nationalNo);
				if (!clsBusinessPeople.IsPersonExist(person.personID))
				{
					MessageBox.Show("The Person With National No [" + mtxbFindPerson.Text + "] Is Not Found!", "Person Was Not Found!", MessageBoxButtons.OK, MessageBoxIcon.Information);
					ClearFindPerson_Focus();
					return;
				}
				if (clsBusinessPeople.IsThisPersonUser(person.personID))
				{
					MessageBox.Show("This Person Is Already A User!", "Error!", MessageBoxButtons.OK, MessageBoxIcon.Information);
					ClearFindPerson_Focus();
					return;
				}
				_PersonID = person.personID;
			}
			Update();
		}
		private void pbAddNewPerson_Click(object sender, EventArgs e)
		{
			frmAdd_UpdatePerson frm = new frmAdd_UpdatePerson(-1);
			frm.ReturnPersonID += AddedNewPerson;
			frm.ShowDialog();
		}
		private void AddedNewPerson(object sender, int personID)
		{
			_PersonID = personID;
			Update();
		}


		private void Update()
		{
			lblWhenYouChoose.Visible = false;

			panPerson.Controls.Clear();
			panPerson.Controls.Add(new uc1_PersonDetails(_PersonID));

			uc02_Add_UpdateUser ucUser = new uc02_Add_UpdateUser(_UserID, _PersonID);
			panUser.Controls.Add(ucUser);
			ucUser.ReturnUserID += ucAdd_UpdateUser_SavedClicked;
			ucUser.CloseClicked += ucAdd_Update_CloseClicked;
		}
		private void ucAdd_UpdateUser_SavedClicked(object sender, int userID)
		{
			lblAdd_Update.Text = "Update User";
			lblAdd_Update.ForeColor = System.Drawing.Color.DarkSlateBlue;
			_UserID = userID;
			uc02_Add_UpdateUser ucUser = new uc02_Add_UpdateUser(_UserID, _PersonID);
			panUser.Controls.Clear();
			panUser.Controls.Add(ucUser);
			ucUser.ReturnUserID += ucAdd_UpdateUser_SavedClicked;
			ucUser.CloseClicked += ucAdd_Update_CloseClicked;
		}


		private void ucAdd_Update_CloseClicked(object sender, EventArgs eventArgs)
		{
			this.Close();
		}
	}
}
