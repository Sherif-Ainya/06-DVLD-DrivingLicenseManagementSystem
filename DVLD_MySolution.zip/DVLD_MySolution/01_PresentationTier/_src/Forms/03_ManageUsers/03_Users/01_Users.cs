﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Windows.Forms;
using DVLD_Business;

namespace _02_DVLD_Mine._src.Main.Users
{
	public partial class frmManageUsers : Form
	{

		public delegate void DataBackEventHandler(object sender, int personID);
		public event DataBackEventHandler ReturnPersonID;
		private void dgvUsers_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
		{
			// Header Height.
			dgvUsers.ColumnHeadersHeight = 60;

			// Rows Height, Or [Properties > RowTemplate.Height], Or AutoSizeRowsMode.
			dgvUsers.RowTemplate.Height = 30;

			// Cell Width Firsth Put DataGridView AutoSizeColumnsMode = Fill. Then Make Changes To Some Of The Columns Like This.
			dgvUsers.Columns[0].Width = 190;
			dgvUsers.Columns[1].Width = 190;
			dgvUsers.Columns[3].Width = 190;
			dgvUsers.Columns[5].Width = 190;

			dgvUsers.Columns[0].HeaderText = "User ID";
			dgvUsers.Columns[1].HeaderText = "Person ID";
			dgvUsers.Columns[2].HeaderText = "Full Name";
			dgvUsers.Columns[3].HeaderText = "User Name";
			dgvUsers.Columns[4].Visible = false;
			dgvUsers.Columns[5].HeaderText = "Is Active";
		}
		private void _RefreshUsers()
		{
			mtxbFilter.Text = "";
			mtxbFilter.Visible = false;

			dgvUsers.SuspendLayout();
			dgvUsers.DataSource = clsBusinessUsers.GetAllUsers();
			dgvUsers.ResumeLayout();
			lblTotalUsers.Text = "Total Users [" + dgvUsers.RowCount.ToString() + "].";
		}
		private void _PrepareThisForm()
		{
			_RefreshUsers();
			cbFilterBy.Items.AddRange(new string[] { "None", "User ID", "Person ID", "Full Name", "User Name", "Is Active" });
		}


		public frmManageUsers()
		{
			InitializeComponent();
			_PrepareThisForm();
		}



		Dictionary<string, string> columnMapping = new Dictionary<string, string>()
		{
			{"User ID", "UserID" },
			{"Person ID", "PersonID" },
			{"Full Name", "FullName" },
			{"User Name", "UserName" }
		};
		private void FilterData()
		{
			if (dgvUsers.DataSource is DataTable dt)
			{
				string searchValue = mtxbFilter.Text.Replace("-", "").Trim();

				string displayName = cbFilterBy.SelectedItem.ToString();
				string actualColumnName = columnMapping[displayName];

				if (!string.IsNullOrEmpty(searchValue))
				{
					if (displayName.EndsWith("ID"))
					{
						string filterExpression = $"{actualColumnName} = {searchValue}";
						dt.DefaultView.RowFilter = filterExpression;
					}
					else
					{
						string filterExpression = $"{actualColumnName} LIKE '%{searchValue}%'";
						dt.DefaultView.RowFilter = filterExpression;
					}
				}
				else
				{
					dt.DefaultView.RowFilter = "";
				}
			}
		}
		private void cbFilterBy_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			mtxbFilter.Visible = false;
			gbActive.Visible = false;

			if (cbFilterBy.SelectedItem.ToString() == "None")
			{
				if (dgvUsers.DataSource is DataTable dt)
				{
					dt.DefaultView.RowFilter = "";
				}
				return;
			}

			if (cbFilterBy.SelectedItem.ToString() == "Is Active")
			{
				gbActive.Visible = true;
				rbActive.Checked = false;
				rbNotActive.Checked = false;
				return;
			}

			if (cbFilterBy.SelectedItem.ToString().Contains("ID"))
			{
				mtxbFilter.Mask = "000000";
			}
			else
			{
				mtxbFilter.Mask = "";
			}
			mtxbFilter.Visible = true;
			mtxbFilter.Text = string.Empty;
			mtxbFilter.Focus();
		}
		//
		private void mtxbFilter_TextChanged(object sender, System.EventArgs e)
		{
			FilterData();
		}
		private void rbActive_CheckedChanged(object sender, EventArgs e)
		{
			if (rbActive.Checked)
			{
				if (dgvUsers.DataSource is DataTable dt)
				{
					string filterExpression = $"IsActive = 1";
					dt.DefaultView.RowFilter = filterExpression;
				}
			}
		}
		private void rbNotActive_CheckedChanged(object sender, EventArgs e)
		{
			if (rbNotActive.Checked)
			{
				if (dgvUsers.DataSource is DataTable dt)
				{
					string filterExpression = $"IsActive = 0";
					dt.DefaultView.RowFilter = filterExpression;
				}
			}
		}


		//
		// Context Menu Strip.
		private void showDetailsToolStripMenuItem_Click(object sender, EventArgs e)
		{
			int userID = (int)dgvUsers.CurrentRow.Cells[0].Value;
			int personID = (int)dgvUsers.CurrentRow.Cells[1].Value;
			Form showDetails = new frmUserDetails(userID, personID);
			showDetails.ShowDialog();
			_RefreshUsers();
		}
		private void editToolStripMenuItem_Click(object sender, EventArgs e)
		{
			int userID = (int)dgvUsers.CurrentRow.Cells[0].Value;
			int personID = (int)dgvUsers.CurrentRow.Cells[1].Value;
			Form update = new frmAdd_UpdateUser(userID, personID);
			update.ShowDialog();
			_RefreshUsers();
		}
		private void deleteToolStripMenuItem_Click(object sender, EventArgs e)
		{
			if (MessageBox.Show("Are You Sure You Want To Delete This User?", "Warning", MessageBoxButtons.OKCancel, MessageBoxIcon.Question) == DialogResult.Cancel)
			{
				return;
			}

			int userID = (int)dgvUsers.CurrentRow.Cells[0].Value;
			if (!clsBusinessUsers.DeleteUser(userID))
			{
				MessageBox.Show("User Is Not Deleted Due To Data Connected To It.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
				return;
			}
			_RefreshUsers();
		}
		private void sendEmailToolStripMenuItem_Click(object sender, EventArgs e)
		{
			MessageBox.Show("Sending Email Is Not Implemented Yet!", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
		}
		private void phoneCallToolStripMenuItem_Click(object sender, EventArgs e)
		{
			MessageBox.Show("Phone Call Is Not Implemented Yet!", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
		}


		private void btnAddNew_Click(object sender, EventArgs e)
		{
			Form addNew = new frmAdd_UpdateUser(-1);
			addNew.ShowDialog();
			_RefreshUsers();
		}
		private void btnClose_Click(object sender, EventArgs e)
		{
			this.Close();
		}
	}
}
