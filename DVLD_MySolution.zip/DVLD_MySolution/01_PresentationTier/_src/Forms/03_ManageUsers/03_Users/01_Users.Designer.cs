﻿namespace _02_DVLD_Mine._src.Main.Users
{
	partial class frmManageUsers
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
			this.btnClose = new System.Windows.Forms.Button();
			this.lblFilterBy = new System.Windows.Forms.Label();
			this.mtxbFilter = new System.Windows.Forms.MaskedTextBox();
			this.lblTotalUsers = new System.Windows.Forms.Label();
			this.cbFilterBy = new System.Windows.Forms.ComboBox();
			this.dgvUsers = new System.Windows.Forms.DataGridView();
			this.cmsUsers = new System.Windows.Forms.ContextMenuStrip(this.components);
			this.tsmiShowDetails = new System.Windows.Forms.ToolStripMenuItem();
			this.tsmiLine1 = new System.Windows.Forms.ToolStripSeparator();
			this.tsmiEdit = new System.Windows.Forms.ToolStripMenuItem();
			this.tsmiDelete = new System.Windows.Forms.ToolStripMenuItem();
			this.tsmiLine2 = new System.Windows.Forms.ToolStripSeparator();
			this.tsmiSendEmail = new System.Windows.Forms.ToolStripMenuItem();
			this.tsmiPhoneCall = new System.Windows.Forms.ToolStripMenuItem();
			this.lblManageUsers = new System.Windows.Forms.Label();
			this.gbActive = new System.Windows.Forms.GroupBox();
			this.rbNotActive = new System.Windows.Forms.RadioButton();
			this.rbActive = new System.Windows.Forms.RadioButton();
			this.btnAddNew = new System.Windows.Forms.Button();
			((System.ComponentModel.ISupportInitialize)(this.dgvUsers)).BeginInit();
			this.cmsUsers.SuspendLayout();
			this.gbActive.SuspendLayout();
			this.SuspendLayout();
			// 
			// btnClose
			// 
			this.btnClose.BackColor = System.Drawing.SystemColors.ScrollBar;
			this.btnClose.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
			this.btnClose.FlatAppearance.BorderSize = 2;
			this.btnClose.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnClose.Font = new System.Drawing.Font("Microsoft YaHei UI", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnClose.ForeColor = System.Drawing.Color.Red;
			this.btnClose.Image = global::_02_DVLD_Mine.Properties.Resources.close;
			this.btnClose.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btnClose.Location = new System.Drawing.Point(1093, 601);
			this.btnClose.Name = "btnClose";
			this.btnClose.Size = new System.Drawing.Size(119, 53);
			this.btnClose.TabIndex = 0;
			this.btnClose.Text = "Close";
			this.btnClose.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.btnClose.UseVisualStyleBackColor = false;
			this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
			// 
			// lblFilterBy
			// 
			this.lblFilterBy.AutoSize = true;
			this.lblFilterBy.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblFilterBy.Location = new System.Drawing.Point(22, 230);
			this.lblFilterBy.Name = "lblFilterBy";
			this.lblFilterBy.Size = new System.Drawing.Size(86, 22);
			this.lblFilterBy.TabIndex = 41;
			this.lblFilterBy.Text = "Filter By :";
			// 
			// mtxbFilter
			// 
			this.mtxbFilter.AsciiOnly = true;
			this.mtxbFilter.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.mtxbFilter.Location = new System.Drawing.Point(344, 228);
			this.mtxbFilter.Name = "mtxbFilter";
			this.mtxbFilter.Size = new System.Drawing.Size(211, 26);
			this.mtxbFilter.TabIndex = 5;
			this.mtxbFilter.Visible = false;
			this.mtxbFilter.TextChanged += new System.EventHandler(this.mtxbFilter_TextChanged);
			// 
			// lblTotalUsers
			// 
			this.lblTotalUsers.AutoSize = true;
			this.lblTotalUsers.Font = new System.Drawing.Font("Mongolian Baiti", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblTotalUsers.Location = new System.Drawing.Point(38, 613);
			this.lblTotalUsers.Name = "lblTotalUsers";
			this.lblTotalUsers.Size = new System.Drawing.Size(134, 25);
			this.lblTotalUsers.TabIndex = 39;
			this.lblTotalUsers.Text = "Total Users";
			// 
			// cbFilterBy
			// 
			this.cbFilterBy.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.cbFilterBy.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.cbFilterBy.FormattingEnabled = true;
			this.cbFilterBy.ItemHeight = 18;
			this.cbFilterBy.Location = new System.Drawing.Point(114, 228);
			this.cbFilterBy.Name = "cbFilterBy";
			this.cbFilterBy.Size = new System.Drawing.Size(223, 26);
			this.cbFilterBy.TabIndex = 2;
			this.cbFilterBy.TabStop = false;
			this.cbFilterBy.SelectedIndexChanged += new System.EventHandler(this.cbFilterBy_SelectedIndexChanged);
			// 
			// dgvUsers
			// 
			this.dgvUsers.AllowUserToAddRows = false;
			this.dgvUsers.AllowUserToDeleteRows = false;
			this.dgvUsers.AllowUserToOrderColumns = true;
			this.dgvUsers.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
			this.dgvUsers.BackgroundColor = System.Drawing.SystemColors.GradientInactiveCaption;
			dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
			dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
			dataGridViewCellStyle1.Font = new System.Drawing.Font("Viner Hand ITC", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
			dataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.Aqua;
			dataGridViewCellStyle1.SelectionForeColor = System.Drawing.Color.Violet;
			dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
			this.dgvUsers.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
			this.dgvUsers.ColumnHeadersHeight = 50;
			this.dgvUsers.ContextMenuStrip = this.cmsUsers;
			dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
			dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
			dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
			dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.MistyRose;
			dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.ControlText;
			dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
			this.dgvUsers.DefaultCellStyle = dataGridViewCellStyle2;
			this.dgvUsers.Location = new System.Drawing.Point(14, 270);
			this.dgvUsers.Name = "dgvUsers";
			this.dgvUsers.ReadOnly = true;
			this.dgvUsers.RowHeadersWidth = 35;
			this.dgvUsers.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
			this.dgvUsers.Size = new System.Drawing.Size(1226, 321);
			this.dgvUsers.TabIndex = 0;
			this.dgvUsers.TabStop = false;
			this.dgvUsers.CellFormatting += new System.Windows.Forms.DataGridViewCellFormattingEventHandler(this.dgvUsers_CellFormatting);
			this.dgvUsers.DoubleClick += new System.EventHandler(this.showDetailsToolStripMenuItem_Click);
			// 
			// cmsUsers
			// 
			this.cmsUsers.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsmiShowDetails,
            this.tsmiLine1,
            this.tsmiEdit,
            this.tsmiDelete,
            this.tsmiLine2,
            this.tsmiSendEmail,
            this.tsmiPhoneCall});
			this.cmsUsers.Name = "cmsPeople";
			this.cmsUsers.Size = new System.Drawing.Size(160, 216);
			// 
			// tsmiShowDetails
			// 
			this.tsmiShowDetails.Font = new System.Drawing.Font("Aldhabi", 17F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.tsmiShowDetails.Image = global::_02_DVLD_Mine.Properties.Resources.wrap;
			this.tsmiShowDetails.Name = "tsmiShowDetails";
			this.tsmiShowDetails.Size = new System.Drawing.Size(159, 40);
			this.tsmiShowDetails.Text = "Show Details";
			this.tsmiShowDetails.TextDirection = System.Windows.Forms.ToolStripTextDirection.Horizontal;
			this.tsmiShowDetails.Click += new System.EventHandler(this.showDetailsToolStripMenuItem_Click);
			// 
			// tsmiLine1
			// 
			this.tsmiLine1.Name = "tsmiLine1";
			this.tsmiLine1.Size = new System.Drawing.Size(156, 6);
			// 
			// tsmiEdit
			// 
			this.tsmiEdit.Font = new System.Drawing.Font("Aldhabi", 17F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.tsmiEdit.Image = global::_02_DVLD_Mine.Properties.Resources.highlighter_pen;
			this.tsmiEdit.Name = "tsmiEdit";
			this.tsmiEdit.Size = new System.Drawing.Size(159, 40);
			this.tsmiEdit.Text = "Edit";
			this.tsmiEdit.TextDirection = System.Windows.Forms.ToolStripTextDirection.Horizontal;
			this.tsmiEdit.Click += new System.EventHandler(this.editToolStripMenuItem_Click);
			// 
			// tsmiDelete
			// 
			this.tsmiDelete.Font = new System.Drawing.Font("Aldhabi", 17F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.tsmiDelete.Image = global::_02_DVLD_Mine.Properties.Resources.delete;
			this.tsmiDelete.Name = "tsmiDelete";
			this.tsmiDelete.Size = new System.Drawing.Size(159, 40);
			this.tsmiDelete.Text = "Delete";
			this.tsmiDelete.TextDirection = System.Windows.Forms.ToolStripTextDirection.Horizontal;
			this.tsmiDelete.Click += new System.EventHandler(this.deleteToolStripMenuItem_Click);
			// 
			// tsmiLine2
			// 
			this.tsmiLine2.Name = "tsmiLine2";
			this.tsmiLine2.Size = new System.Drawing.Size(156, 6);
			// 
			// tsmiSendEmail
			// 
			this.tsmiSendEmail.Font = new System.Drawing.Font("Aldhabi", 17F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.tsmiSendEmail.Image = global::_02_DVLD_Mine.Properties.Resources.edit;
			this.tsmiSendEmail.Name = "tsmiSendEmail";
			this.tsmiSendEmail.Size = new System.Drawing.Size(159, 40);
			this.tsmiSendEmail.Text = "Send Email";
			this.tsmiSendEmail.TextDirection = System.Windows.Forms.ToolStripTextDirection.Horizontal;
			this.tsmiSendEmail.Click += new System.EventHandler(this.sendEmailToolStripMenuItem_Click);
			// 
			// tsmiPhoneCall
			// 
			this.tsmiPhoneCall.Font = new System.Drawing.Font("Aldhabi", 17F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.tsmiPhoneCall.Image = global::_02_DVLD_Mine.Properties.Resources.call;
			this.tsmiPhoneCall.Name = "tsmiPhoneCall";
			this.tsmiPhoneCall.Size = new System.Drawing.Size(159, 40);
			this.tsmiPhoneCall.Text = "Phone Call";
			this.tsmiPhoneCall.TextDirection = System.Windows.Forms.ToolStripTextDirection.Horizontal;
			this.tsmiPhoneCall.Click += new System.EventHandler(this.phoneCallToolStripMenuItem_Click);
			// 
			// lblManageUsers
			// 
			this.lblManageUsers.AutoSize = true;
			this.lblManageUsers.Font = new System.Drawing.Font("Palatino Linotype", 48F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblManageUsers.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
			this.lblManageUsers.Location = new System.Drawing.Point(375, 43);
			this.lblManageUsers.Name = "lblManageUsers";
			this.lblManageUsers.Size = new System.Drawing.Size(440, 85);
			this.lblManageUsers.TabIndex = 36;
			this.lblManageUsers.Text = "Manage Users";
			// 
			// gbActive
			// 
			this.gbActive.BackColor = System.Drawing.Color.LightBlue;
			this.gbActive.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
			this.gbActive.Controls.Add(this.rbNotActive);
			this.gbActive.Controls.Add(this.rbActive);
			this.gbActive.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.gbActive.Font = new System.Drawing.Font("Microsoft Tai Le", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.gbActive.Location = new System.Drawing.Point(358, 206);
			this.gbActive.Name = "gbActive";
			this.gbActive.Size = new System.Drawing.Size(197, 59);
			this.gbActive.TabIndex = 56;
			this.gbActive.TabStop = false;
			this.gbActive.Text = "Is Active :";
			this.gbActive.Visible = false;
			// 
			// rbNotActive
			// 
			this.rbNotActive.AutoSize = true;
			this.rbNotActive.BackColor = System.Drawing.Color.LightSkyBlue;
			this.rbNotActive.Font = new System.Drawing.Font("Malgun Gothic", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.rbNotActive.Location = new System.Drawing.Point(86, 22);
			this.rbNotActive.Name = "rbNotActive";
			this.rbNotActive.Size = new System.Drawing.Size(103, 24);
			this.rbNotActive.TabIndex = 4;
			this.rbNotActive.TabStop = true;
			this.rbNotActive.Text = "Not Active";
			this.rbNotActive.UseVisualStyleBackColor = false;
			this.rbNotActive.CheckedChanged += new System.EventHandler(this.rbNotActive_CheckedChanged);
			// 
			// rbActive
			// 
			this.rbActive.AutoSize = true;
			this.rbActive.BackColor = System.Drawing.Color.LightSkyBlue;
			this.rbActive.Font = new System.Drawing.Font("Malgun Gothic", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.rbActive.Location = new System.Drawing.Point(8, 22);
			this.rbActive.Name = "rbActive";
			this.rbActive.Size = new System.Drawing.Size(71, 24);
			this.rbActive.TabIndex = 3;
			this.rbActive.TabStop = true;
			this.rbActive.Text = "Active";
			this.rbActive.UseVisualStyleBackColor = false;
			this.rbActive.CheckedChanged += new System.EventHandler(this.rbActive_CheckedChanged);
			// 
			// btnAddNew
			// 
			this.btnAddNew.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
			this.btnAddNew.FlatAppearance.BorderColor = System.Drawing.Color.MediumTurquoise;
			this.btnAddNew.FlatAppearance.BorderSize = 5;
			this.btnAddNew.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
			this.btnAddNew.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
			this.btnAddNew.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnAddNew.Font = new System.Drawing.Font("Microsoft YaHei UI", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnAddNew.ForeColor = System.Drawing.Color.Red;
			this.btnAddNew.Image = global::_02_DVLD_Mine.Properties.Resources.administrator;
			this.btnAddNew.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btnAddNew.Location = new System.Drawing.Point(1109, 193);
			this.btnAddNew.Name = "btnAddNew";
			this.btnAddNew.Size = new System.Drawing.Size(93, 71);
			this.btnAddNew.TabIndex = 1;
			this.btnAddNew.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.btnAddNew.UseVisualStyleBackColor = false;
			this.btnAddNew.Click += new System.EventHandler(this.btnAddNew_Click);
			// 
			// frmManageUsers
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = System.Drawing.Color.LightPink;
			this.CancelButton = this.btnClose;
			this.ClientSize = new System.Drawing.Size(1254, 661);
			this.Controls.Add(this.btnAddNew);
			this.Controls.Add(this.gbActive);
			this.Controls.Add(this.btnClose);
			this.Controls.Add(this.lblFilterBy);
			this.Controls.Add(this.mtxbFilter);
			this.Controls.Add(this.lblTotalUsers);
			this.Controls.Add(this.cbFilterBy);
			this.Controls.Add(this.dgvUsers);
			this.Controls.Add(this.lblManageUsers);
			this.Name = "frmManageUsers";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Manage Users";
			((System.ComponentModel.ISupportInitialize)(this.dgvUsers)).EndInit();
			this.cmsUsers.ResumeLayout(false);
			this.gbActive.ResumeLayout(false);
			this.gbActive.PerformLayout();
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion
		private System.Windows.Forms.Button btnClose;
		private System.Windows.Forms.Label lblFilterBy;
		private System.Windows.Forms.MaskedTextBox mtxbFilter;
		private System.Windows.Forms.Label lblTotalUsers;
		private System.Windows.Forms.ComboBox cbFilterBy;
		private System.Windows.Forms.DataGridView dgvUsers;
		private System.Windows.Forms.Label lblManageUsers;
		private System.Windows.Forms.ContextMenuStrip cmsUsers;
		private System.Windows.Forms.ToolStripMenuItem tsmiShowDetails;
		private System.Windows.Forms.ToolStripSeparator tsmiLine1;
		private System.Windows.Forms.ToolStripMenuItem tsmiEdit;
		private System.Windows.Forms.ToolStripMenuItem tsmiDelete;
		private System.Windows.Forms.ToolStripSeparator tsmiLine2;
		private System.Windows.Forms.ToolStripMenuItem tsmiSendEmail;
		private System.Windows.Forms.ToolStripMenuItem tsmiPhoneCall;
		private System.Windows.Forms.GroupBox gbActive;
		private System.Windows.Forms.RadioButton rbNotActive;
		private System.Windows.Forms.RadioButton rbActive;
		private System.Windows.Forms.Button btnAddNew;
	}
}