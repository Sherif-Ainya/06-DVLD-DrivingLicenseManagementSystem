﻿namespace _02_DVLD_Mine._src.Main.Users
{
	partial class frmUserDetails
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.lblPersonDetails = new System.Windows.Forms.Label();
			this.panPersonDetails = new System.Windows.Forms.Panel();
			this.btnClose = new System.Windows.Forms.Button();
			this.panUserDetails = new System.Windows.Forms.Panel();
			this.SuspendLayout();
			// 
			// lblPersonDetails
			// 
			this.lblPersonDetails.AutoSize = true;
			this.lblPersonDetails.Font = new System.Drawing.Font("Palatino Linotype", 39F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblPersonDetails.ForeColor = System.Drawing.Color.BlueViolet;
			this.lblPersonDetails.Location = new System.Drawing.Point(300, 18);
			this.lblPersonDetails.Name = "lblPersonDetails";
			this.lblPersonDetails.Size = new System.Drawing.Size(321, 71);
			this.lblPersonDetails.TabIndex = 7;
			this.lblPersonDetails.Text = "User Details";
			// 
			// panPersonDetails
			// 
			this.panPersonDetails.BackColor = System.Drawing.Color.LightSteelBlue;
			this.panPersonDetails.Location = new System.Drawing.Point(59, 215);
			this.panPersonDetails.Name = "panPersonDetails";
			this.panPersonDetails.Size = new System.Drawing.Size(809, 465);
			this.panPersonDetails.TabIndex = 6;
			// 
			// btnClose
			// 
			this.btnClose.BackColor = System.Drawing.SystemColors.ScrollBar;
			this.btnClose.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
			this.btnClose.FlatAppearance.BorderSize = 2;
			this.btnClose.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnClose.Font = new System.Drawing.Font("Microsoft YaHei UI", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnClose.ForeColor = System.Drawing.Color.Red;
			this.btnClose.Image = global::_02_DVLD_Mine.Properties.Resources.close;
			this.btnClose.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btnClose.Location = new System.Drawing.Point(777, 684);
			this.btnClose.Name = "btnClose";
			this.btnClose.Size = new System.Drawing.Size(122, 53);
			this.btnClose.TabIndex = 3;
			this.btnClose.Text = "Close";
			this.btnClose.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.btnClose.UseVisualStyleBackColor = false;
			this.btnClose.Click += new System.EventHandler(this.btnClose_Click_1);
			// 
			// panUserDetails
			// 
			this.panUserDetails.BackColor = System.Drawing.Color.LightSteelBlue;
			this.panUserDetails.Location = new System.Drawing.Point(59, 114);
			this.panUserDetails.Name = "panUserDetails";
			this.panUserDetails.Size = new System.Drawing.Size(809, 100);
			this.panUserDetails.TabIndex = 7;
			// 
			// frmUserDetails
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = System.Drawing.Color.LightPink;
			this.ClientSize = new System.Drawing.Size(928, 740);
			this.Controls.Add(this.panUserDetails);
			this.Controls.Add(this.btnClose);
			this.Controls.Add(this.lblPersonDetails);
			this.Controls.Add(this.panPersonDetails);
			this.Name = "frmUserDetails";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "User Details";
			this.Load += new System.EventHandler(this.frmShowUserDetails_Load);
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.Button btnClose;
		private System.Windows.Forms.Label lblPersonDetails;
		private System.Windows.Forms.Panel panPersonDetails;
		private System.Windows.Forms.Panel panUserDetails;
	}
}