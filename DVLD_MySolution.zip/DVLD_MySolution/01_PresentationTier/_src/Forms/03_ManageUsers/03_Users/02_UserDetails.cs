﻿using System.Windows.Forms;
using _02_DVLD_Mine._src.userControls.People;
using _02_DVLD_Mine._src.userControls.Users;

namespace _02_DVLD_Mine._src.Main.Users
{
	public partial class frmUserDetails : Form
	{
		private int _UserID, _PersonID;
		public frmUserDetails(int UserID, int PersonID)
		{
			InitializeComponent();
			_UserID = UserID;
			_PersonID = PersonID;
		}


		private void frmShowUserDetails_Load(object sender, System.EventArgs e)
		{
			panPersonDetails.Controls.Add(new uc1_PersonDetails(_PersonID));
			panUserDetails.Controls.Add(new uc02_UserShortDetails(_UserID));
		}

		private void btnClose_Click_1(object sender, System.EventArgs e)
		{
			this.Close();
		}
	}
}
