﻿namespace _02_DVLD_Mine._src.Main.Users
{
	partial class frmAdd_UpdateUser
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.lblAdd_Update = new System.Windows.Forms.Label();
			this.panPerson = new System.Windows.Forms.Panel();
			this.pbAddNewPerson = new System.Windows.Forms.PictureBox();
			this.mtxbFindPerson = new System.Windows.Forms.MaskedTextBox();
			this.lblFiindBy = new System.Windows.Forms.Label();
			this.pbFind = new System.Windows.Forms.PictureBox();
			this.cbPersonID_NationalNo = new System.Windows.Forms.ComboBox();
			this.btnFindPerson = new System.Windows.Forms.Button();
			this.panUser = new System.Windows.Forms.Panel();
			this.lblWhenYouChoose = new System.Windows.Forms.Label();
			this.panPerson.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.pbAddNewPerson)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.pbFind)).BeginInit();
			this.panUser.SuspendLayout();
			this.SuspendLayout();
			// 
			// lblAdd_Update
			// 
			this.lblAdd_Update.Font = new System.Drawing.Font("Palatino Linotype", 38F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblAdd_Update.ForeColor = System.Drawing.Color.MediumVioletRed;
			this.lblAdd_Update.Location = new System.Drawing.Point(331, 7);
			this.lblAdd_Update.Name = "lblAdd_Update";
			this.lblAdd_Update.Size = new System.Drawing.Size(436, 76);
			this.lblAdd_Update.TabIndex = 5;
			this.lblAdd_Update.Text = "Add New User";
			this.lblAdd_Update.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// panPerson
			// 
			this.panPerson.BackColor = System.Drawing.Color.LightSteelBlue;
			this.panPerson.Controls.Add(this.pbAddNewPerson);
			this.panPerson.Controls.Add(this.mtxbFindPerson);
			this.panPerson.Controls.Add(this.lblFiindBy);
			this.panPerson.Controls.Add(this.pbFind);
			this.panPerson.Controls.Add(this.cbPersonID_NationalNo);
			this.panPerson.Controls.Add(this.btnFindPerson);
			this.panPerson.Location = new System.Drawing.Point(147, 275);
			this.panPerson.Name = "panPerson";
			this.panPerson.Size = new System.Drawing.Size(809, 465);
			this.panPerson.TabIndex = 7;
			// 
			// pbAddNewPerson
			// 
			this.pbAddNewPerson.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
			this.pbAddNewPerson.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
			this.pbAddNewPerson.Image = global::_02_DVLD_Mine.Properties.Resources.administrator;
			this.pbAddNewPerson.Location = new System.Drawing.Point(562, 129);
			this.pbAddNewPerson.Name = "pbAddNewPerson";
			this.pbAddNewPerson.Size = new System.Drawing.Size(74, 71);
			this.pbAddNewPerson.TabIndex = 42;
			this.pbAddNewPerson.TabStop = false;
			this.pbAddNewPerson.Click += new System.EventHandler(this.pbAddNewPerson_Click);
			// 
			// mtxbFindPerson
			// 
			this.mtxbFindPerson.AsciiOnly = true;
			this.mtxbFindPerson.Font = new System.Drawing.Font("Microsoft Sans Serif", 17F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.mtxbFindPerson.Location = new System.Drawing.Point(295, 148);
			this.mtxbFindPerson.Name = "mtxbFindPerson";
			this.mtxbFindPerson.Size = new System.Drawing.Size(211, 33);
			this.mtxbFindPerson.TabIndex = 41;
			this.mtxbFindPerson.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			// 
			// lblFiindBy
			// 
			this.lblFiindBy.AutoSize = true;
			this.lblFiindBy.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblFiindBy.Location = new System.Drawing.Point(240, 79);
			this.lblFiindBy.Name = "lblFiindBy";
			this.lblFiindBy.Size = new System.Drawing.Size(81, 22);
			this.lblFiindBy.TabIndex = 39;
			this.lblFiindBy.Text = "Find By :";
			// 
			// pbFind
			// 
			this.pbFind.BackColor = System.Drawing.Color.HotPink;
			this.pbFind.Image = global::_02_DVLD_Mine.Properties.Resources.find;
			this.pbFind.Location = new System.Drawing.Point(510, 148);
			this.pbFind.Name = "pbFind";
			this.pbFind.Size = new System.Drawing.Size(46, 33);
			this.pbFind.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
			this.pbFind.TabIndex = 38;
			this.pbFind.TabStop = false;
			this.pbFind.Click += new System.EventHandler(this.pbFind_Click);
			// 
			// cbPersonID_NationalNo
			// 
			this.cbPersonID_NationalNo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.cbPersonID_NationalNo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.cbPersonID_NationalNo.FormattingEnabled = true;
			this.cbPersonID_NationalNo.ItemHeight = 20;
			this.cbPersonID_NationalNo.Items.AddRange(new object[] {
            "PersonID",
            "NationalNo"});
			this.cbPersonID_NationalNo.Location = new System.Drawing.Point(219, 104);
			this.cbPersonID_NationalNo.Name = "cbPersonID_NationalNo";
			this.cbPersonID_NationalNo.Size = new System.Drawing.Size(223, 28);
			this.cbPersonID_NationalNo.TabIndex = 37;
			this.cbPersonID_NationalNo.SelectedIndexChanged += new System.EventHandler(this.cbPersonID_NationalNo_SelectedIndexChanged);
			// 
			// btnFindPerson
			// 
			this.btnFindPerson.BackColor = System.Drawing.Color.LightSkyBlue;
			this.btnFindPerson.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
			this.btnFindPerson.FlatAppearance.BorderSize = 7;
			this.btnFindPerson.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnFindPerson.Font = new System.Drawing.Font("Microsoft Tai Le", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnFindPerson.Location = new System.Drawing.Point(263, 283);
			this.btnFindPerson.Name = "btnFindPerson";
			this.btnFindPerson.Size = new System.Drawing.Size(259, 99);
			this.btnFindPerson.TabIndex = 0;
			this.btnFindPerson.Text = "Find A Person From People Managment";
			this.btnFindPerson.UseVisualStyleBackColor = false;
			this.btnFindPerson.Click += new System.EventHandler(this.btnFindPerson_Click);
			// 
			// panUser
			// 
			this.panUser.BackColor = System.Drawing.Color.LightSteelBlue;
			this.panUser.Controls.Add(this.lblWhenYouChoose);
			this.panUser.Location = new System.Drawing.Point(147, 101);
			this.panUser.Name = "panUser";
			this.panUser.Size = new System.Drawing.Size(809, 173);
			this.panUser.TabIndex = 8;
			// 
			// lblWhenYouChoose
			// 
			this.lblWhenYouChoose.BackColor = System.Drawing.Color.Plum;
			this.lblWhenYouChoose.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.lblWhenYouChoose.Dock = System.Windows.Forms.DockStyle.Bottom;
			this.lblWhenYouChoose.Font = new System.Drawing.Font("Perpetua Titling MT", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblWhenYouChoose.Location = new System.Drawing.Point(0, 108);
			this.lblWhenYouChoose.Name = "lblWhenYouChoose";
			this.lblWhenYouChoose.Size = new System.Drawing.Size(809, 65);
			this.lblWhenYouChoose.TabIndex = 0;
			this.lblWhenYouChoose.Text = "Adding New User Will Be Ready When You Choose A Person";
			this.lblWhenYouChoose.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// frmAdd_UpdateUser
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = System.Drawing.Color.LightPink;
			this.ClientSize = new System.Drawing.Size(1106, 743);
			this.Controls.Add(this.panUser);
			this.Controls.Add(this.panPerson);
			this.Controls.Add(this.lblAdd_Update);
			this.Name = "frmAdd_UpdateUser";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Add_Update User";
			this.Load += new System.EventHandler(this.frmAdd_UpdateUser_Load);
			this.panPerson.ResumeLayout(false);
			this.panPerson.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.pbAddNewPerson)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.pbFind)).EndInit();
			this.panUser.ResumeLayout(false);
			this.ResumeLayout(false);

		}

		#endregion
		private System.Windows.Forms.Label lblAdd_Update;
		private System.Windows.Forms.Panel panPerson;
		private System.Windows.Forms.Panel panUser;
		private System.Windows.Forms.Button btnFindPerson;
		private System.Windows.Forms.Label lblWhenYouChoose;
		private System.Windows.Forms.ComboBox cbPersonID_NationalNo;
		private System.Windows.Forms.PictureBox pbFind;
		private System.Windows.Forms.Label lblFiindBy;
		private System.Windows.Forms.MaskedTextBox mtxbFindPerson;
		private System.Windows.Forms.PictureBox pbAddNewPerson;
	}
}