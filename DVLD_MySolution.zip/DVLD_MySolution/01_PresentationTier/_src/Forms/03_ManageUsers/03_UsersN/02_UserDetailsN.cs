﻿using System.Windows.Forms;

namespace _02_DVLD_Mine._src.Forms._03_Users
{
	public partial class frmUserDetailsN : Form
	{
		private int _UserID;


		public frmUserDetailsN(int UserID)
		{
			InitializeComponent();
			_UserID = UserID;
		}


		private void frmUserDetailsN_Load(object sender, System.EventArgs e)
		{
			FullUserDetails.LoadUserData(_UserID);
		}
		private void btnClose_Click(object sender, System.EventArgs e)
		{
			this.Close();
		}
	}
}
