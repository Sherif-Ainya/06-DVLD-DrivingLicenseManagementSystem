﻿namespace _02_DVLD_Mine._src.Forms._03_Users
{
	partial class frmAdd_UpdateUserN
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			this.lblAdd_Update = new System.Windows.Forms.Label();
			this.btnNext = new System.Windows.Forms.Button();
			this.panel2 = new System.Windows.Forms.Panel();
			this.lblCurrentPassword = new System.Windows.Forms.Label();
			this.txbCurrentPassword = new System.Windows.Forms.TextBox();
			this.lblUserName = new System.Windows.Forms.Label();
			this.lblUserID = new System.Windows.Forms.Label();
			this.txbUserName = new System.Windows.Forms.TextBox();
			this.cbIsActive = new System.Windows.Forms.CheckBox();
			this.lblPassword = new System.Windows.Forms.Label();
			this.lblIsActive = new System.Windows.Forms.Label();
			this.txbPassword = new System.Windows.Forms.TextBox();
			this.txbConfim = new System.Windows.Forms.TextBox();
			this.lblConfirm = new System.Windows.Forms.Label();
			this.btnBack = new System.Windows.Forms.Button();
			this.btnSave = new System.Windows.Forms.Button();
			this.btnClose = new System.Windows.Forms.Button();
			this.panel1 = new System.Windows.Forms.Panel();
			this.tabControl1 = new System.Windows.Forms.TabControl();
			this.tpPersonalInfo = new System.Windows.Forms.TabPage();
			this.personDetails = new _02_DVLD_Mine._src.userControls._01_PeopleNewWay.uc1N_PersonDetailsN();
			this.findPerson = new _02_DVLD_Mine._src.userControls._01_People.uc1N_FindPersonThenFillData();
			this.tpUserInfo = new System.Windows.Forms.TabPage();
			this.errorProvider1 = new System.Windows.Forms.ErrorProvider(this.components);
			this.panel2.SuspendLayout();
			this.panel1.SuspendLayout();
			this.tabControl1.SuspendLayout();
			this.tpPersonalInfo.SuspendLayout();
			this.tpUserInfo.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).BeginInit();
			this.SuspendLayout();
			// 
			// lblAdd_Update
			// 
			this.lblAdd_Update.BackColor = System.Drawing.Color.Transparent;
			this.lblAdd_Update.Font = new System.Drawing.Font("Palatino Linotype", 38F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblAdd_Update.ForeColor = System.Drawing.Color.MediumVioletRed;
			this.lblAdd_Update.Location = new System.Drawing.Point(324, 9);
			this.lblAdd_Update.Name = "lblAdd_Update";
			this.lblAdd_Update.Size = new System.Drawing.Size(436, 76);
			this.lblAdd_Update.TabIndex = 9;
			this.lblAdd_Update.Text = "Add New User";
			this.lblAdd_Update.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// btnNext
			// 
			this.btnNext.BackColor = System.Drawing.SystemColors.ScrollBar;
			this.btnNext.FlatAppearance.BorderColor = System.Drawing.Color.MediumTurquoise;
			this.btnNext.FlatAppearance.BorderSize = 4;
			this.btnNext.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnNext.Font = new System.Drawing.Font("Microsoft YaHei UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnNext.ForeColor = System.Drawing.Color.Red;
			this.btnNext.Image = global::_02_DVLD_Mine.Properties.Resources.redo;
			this.btnNext.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.btnNext.Location = new System.Drawing.Point(970, 572);
			this.btnNext.Name = "btnNext";
			this.btnNext.Size = new System.Drawing.Size(123, 61);
			this.btnNext.TabIndex = 1;
			this.btnNext.Text = "Next";
			this.btnNext.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btnNext.UseVisualStyleBackColor = false;
			this.btnNext.Click += new System.EventHandler(this.btnNext_Click);
			// 
			// panel2
			// 
			this.panel2.BackColor = System.Drawing.Color.BlanchedAlmond;
			this.panel2.Controls.Add(this.lblCurrentPassword);
			this.panel2.Controls.Add(this.txbCurrentPassword);
			this.panel2.Controls.Add(this.lblUserName);
			this.panel2.Controls.Add(this.lblUserID);
			this.panel2.Controls.Add(this.txbUserName);
			this.panel2.Controls.Add(this.cbIsActive);
			this.panel2.Controls.Add(this.lblPassword);
			this.panel2.Controls.Add(this.lblIsActive);
			this.panel2.Controls.Add(this.txbPassword);
			this.panel2.Controls.Add(this.txbConfim);
			this.panel2.Controls.Add(this.lblConfirm);
			this.panel2.Location = new System.Drawing.Point(168, 157);
			this.panel2.Name = "panel2";
			this.panel2.Size = new System.Drawing.Size(770, 273);
			this.panel2.TabIndex = 114;
			// 
			// lblCurrentPassword
			// 
			this.lblCurrentPassword.AutoSize = true;
			this.lblCurrentPassword.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblCurrentPassword.Location = new System.Drawing.Point(16, 86);
			this.lblCurrentPassword.Name = "lblCurrentPassword";
			this.lblCurrentPassword.Size = new System.Drawing.Size(182, 26);
			this.lblCurrentPassword.TabIndex = 115;
			this.lblCurrentPassword.Text = "Current Password :";
			// 
			// txbCurrentPassword
			// 
			this.txbCurrentPassword.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.txbCurrentPassword.Location = new System.Drawing.Point(213, 84);
			this.txbCurrentPassword.Name = "txbCurrentPassword";
			this.txbCurrentPassword.PasswordChar = '*';
			this.txbCurrentPassword.Size = new System.Drawing.Size(224, 29);
			this.txbCurrentPassword.TabIndex = 3;
			this.txbCurrentPassword.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			this.txbCurrentPassword.Validating += new System.ComponentModel.CancelEventHandler(this.txbCurrentPassword_Validating);
			// 
			// lblUserName
			// 
			this.lblUserName.AutoSize = true;
			this.lblUserName.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblUserName.Location = new System.Drawing.Point(47, 45);
			this.lblUserName.Name = "lblUserName";
			this.lblUserName.Size = new System.Drawing.Size(122, 26);
			this.lblUserName.TabIndex = 107;
			this.lblUserName.Text = "User Name :";
			// 
			// lblUserID
			// 
			this.lblUserID.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
			this.lblUserID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.lblUserID.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblUserID.ForeColor = System.Drawing.Color.Red;
			this.lblUserID.Location = new System.Drawing.Point(677, 17);
			this.lblUserID.Name = "lblUserID";
			this.lblUserID.Size = new System.Drawing.Size(73, 41);
			this.lblUserID.TabIndex = 113;
			this.lblUserID.Text = "???";
			this.lblUserID.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// txbUserName
			// 
			this.txbUserName.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.txbUserName.Location = new System.Drawing.Point(214, 42);
			this.txbUserName.Name = "txbUserName";
			this.txbUserName.Size = new System.Drawing.Size(224, 29);
			this.txbUserName.TabIndex = 2;
			this.txbUserName.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			// 
			// cbIsActive
			// 
			this.cbIsActive.Font = new System.Drawing.Font("Modern No. 20", 19F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.cbIsActive.ForeColor = System.Drawing.Color.DarkBlue;
			this.cbIsActive.Location = new System.Drawing.Point(543, 149);
			this.cbIsActive.Name = "cbIsActive";
			this.cbIsActive.Size = new System.Drawing.Size(150, 31);
			this.cbIsActive.TabIndex = 99;
			this.cbIsActive.TabStop = false;
			this.cbIsActive.Text = "Not Active";
			this.cbIsActive.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			this.cbIsActive.UseVisualStyleBackColor = true;
			this.cbIsActive.CheckedChanged += new System.EventHandler(this.cbIsActive_CheckedChanged);
			// 
			// lblPassword
			// 
			this.lblPassword.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblPassword.Location = new System.Drawing.Point(29, 150);
			this.lblPassword.Name = "lblPassword";
			this.lblPassword.Size = new System.Drawing.Size(159, 26);
			this.lblPassword.TabIndex = 108;
			this.lblPassword.Text = "New Password :";
			this.lblPassword.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// lblIsActive
			// 
			this.lblIsActive.AutoSize = true;
			this.lblIsActive.Font = new System.Drawing.Font("Palatino Linotype", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblIsActive.ForeColor = System.Drawing.Color.DarkRed;
			this.lblIsActive.Location = new System.Drawing.Point(551, 99);
			this.lblIsActive.Name = "lblIsActive";
			this.lblIsActive.Size = new System.Drawing.Size(120, 32);
			this.lblIsActive.TabIndex = 110;
			this.lblIsActive.Text = "Is Active?";
			// 
			// txbPassword
			// 
			this.txbPassword.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.txbPassword.Location = new System.Drawing.Point(212, 149);
			this.txbPassword.Name = "txbPassword";
			this.txbPassword.PasswordChar = '*';
			this.txbPassword.Size = new System.Drawing.Size(224, 29);
			this.txbPassword.TabIndex = 4;
			this.txbPassword.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			// 
			// txbConfim
			// 
			this.txbConfim.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.txbConfim.Location = new System.Drawing.Point(212, 190);
			this.txbConfim.Name = "txbConfim";
			this.txbConfim.PasswordChar = '*';
			this.txbConfim.Size = new System.Drawing.Size(224, 29);
			this.txbConfim.TabIndex = 5;
			this.txbConfim.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			this.txbConfim.Validating += new System.ComponentModel.CancelEventHandler(this.txbConfim_Validating);
			// 
			// lblConfirm
			// 
			this.lblConfirm.AutoSize = true;
			this.lblConfirm.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblConfirm.Location = new System.Drawing.Point(62, 190);
			this.lblConfirm.Name = "lblConfirm";
			this.lblConfirm.Size = new System.Drawing.Size(90, 26);
			this.lblConfirm.TabIndex = 109;
			this.lblConfirm.Text = "Confirm :";
			// 
			// btnBack
			// 
			this.btnBack.BackColor = System.Drawing.SystemColors.ScrollBar;
			this.btnBack.FlatAppearance.BorderColor = System.Drawing.Color.MediumTurquoise;
			this.btnBack.FlatAppearance.BorderSize = 4;
			this.btnBack.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnBack.Font = new System.Drawing.Font("Microsoft YaHei UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnBack.ForeColor = System.Drawing.Color.Red;
			this.btnBack.Image = global::_02_DVLD_Mine.Properties.Resources.undo;
			this.btnBack.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btnBack.Location = new System.Drawing.Point(15, 575);
			this.btnBack.Name = "btnBack";
			this.btnBack.Size = new System.Drawing.Size(123, 61);
			this.btnBack.TabIndex = 6;
			this.btnBack.Text = "Back";
			this.btnBack.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.btnBack.UseVisualStyleBackColor = false;
			this.btnBack.Click += new System.EventHandler(this.btnBack_Click);
			// 
			// btnSave
			// 
			this.btnSave.BackColor = System.Drawing.Color.Pink;
			this.btnSave.FlatAppearance.BorderColor = System.Drawing.Color.MediumSpringGreen;
			this.btnSave.FlatAppearance.BorderSize = 4;
			this.btnSave.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
			this.btnSave.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
			this.btnSave.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnSave.Font = new System.Drawing.Font("Microsoft YaHei UI", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnSave.ForeColor = System.Drawing.Color.DarkOrchid;
			this.btnSave.Image = global::_02_DVLD_Mine.Properties.Resources.save_27_16;
			this.btnSave.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btnSave.Location = new System.Drawing.Point(995, 586);
			this.btnSave.Name = "btnSave";
			this.btnSave.Size = new System.Drawing.Size(100, 50);
			this.btnSave.TabIndex = 7;
			this.btnSave.Text = "SAVE";
			this.btnSave.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.btnSave.UseVisualStyleBackColor = false;
			this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
			// 
			// btnClose
			// 
			this.btnClose.BackColor = System.Drawing.SystemColors.ScrollBar;
			this.btnClose.FlatAppearance.BorderColor = System.Drawing.Color.Yellow;
			this.btnClose.FlatAppearance.BorderSize = 4;
			this.btnClose.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnClose.Font = new System.Drawing.Font("Microsoft YaHei UI", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnClose.ForeColor = System.Drawing.Color.Red;
			this.btnClose.Image = global::_02_DVLD_Mine.Properties.Resources.close;
			this.btnClose.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btnClose.Location = new System.Drawing.Point(1045, 9);
			this.btnClose.Name = "btnClose";
			this.btnClose.Size = new System.Drawing.Size(64, 52);
			this.btnClose.TabIndex = 0;
			this.btnClose.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.btnClose.UseVisualStyleBackColor = false;
			this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
			// 
			// panel1
			// 
			this.panel1.Controls.Add(this.tabControl1);
			this.panel1.Dock = System.Windows.Forms.DockStyle.Bottom;
			this.panel1.Location = new System.Drawing.Point(0, 89);
			this.panel1.Name = "panel1";
			this.panel1.Size = new System.Drawing.Size(1122, 693);
			this.panel1.TabIndex = 116;
			// 
			// tabControl1
			// 
			this.tabControl1.Controls.Add(this.tpPersonalInfo);
			this.tabControl1.Controls.Add(this.tpUserInfo);
			this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
			this.tabControl1.ItemSize = new System.Drawing.Size(58, 33);
			this.tabControl1.Location = new System.Drawing.Point(0, 0);
			this.tabControl1.Name = "tabControl1";
			this.tabControl1.SelectedIndex = 0;
			this.tabControl1.Size = new System.Drawing.Size(1122, 693);
			this.tabControl1.TabIndex = 3;
			this.tabControl1.Selecting += new System.Windows.Forms.TabControlCancelEventHandler(this.tabControl1_Selecting);
			// 
			// tpPersonalInfo
			// 
			this.tpPersonalInfo.BackColor = System.Drawing.Color.PeachPuff;
			this.tpPersonalInfo.Controls.Add(this.personDetails);
			this.tpPersonalInfo.Controls.Add(this.findPerson);
			this.tpPersonalInfo.Controls.Add(this.btnNext);
			this.tpPersonalInfo.Location = new System.Drawing.Point(4, 37);
			this.tpPersonalInfo.Name = "tpPersonalInfo";
			this.tpPersonalInfo.Padding = new System.Windows.Forms.Padding(3);
			this.tpPersonalInfo.Size = new System.Drawing.Size(1114, 652);
			this.tpPersonalInfo.TabIndex = 0;
			this.tpPersonalInfo.Text = "Personal Information";
			// 
			// personDetails
			// 
			this.personDetails.Location = new System.Drawing.Point(132, 89);
			this.personDetails.Name = "personDetails";
			this.personDetails.Size = new System.Drawing.Size(810, 465);
			this.personDetails.TabIndex = 116;
			// 
			// findPerson
			// 
			this.findPerson.BackColor = System.Drawing.Color.DarkMagenta;
			this.findPerson.Location = new System.Drawing.Point(132, 0);
			this.findPerson.Name = "findPerson";
			this.findPerson.Size = new System.Drawing.Size(809, 653);
			this.findPerson.TabIndex = 115;
			this.findPerson.OnFound += new System.Action<int>(this.findPerson_OnFound);
			// 
			// tpUserInfo
			// 
			this.tpUserInfo.BackColor = System.Drawing.Color.PeachPuff;
			this.tpUserInfo.Controls.Add(this.panel2);
			this.tpUserInfo.Controls.Add(this.btnBack);
			this.tpUserInfo.Controls.Add(this.btnSave);
			this.tpUserInfo.Location = new System.Drawing.Point(4, 37);
			this.tpUserInfo.Name = "tpUserInfo";
			this.tpUserInfo.Padding = new System.Windows.Forms.Padding(3);
			this.tpUserInfo.Size = new System.Drawing.Size(1114, 652);
			this.tpUserInfo.TabIndex = 1;
			this.tpUserInfo.Text = "User Information";
			// 
			// errorProvider1
			// 
			this.errorProvider1.ContainerControl = this;
			// 
			// frmAdd_UpdateUserN
			// 
			this.AcceptButton = this.btnNext;
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = System.Drawing.Color.LightPink;
			this.CancelButton = this.btnClose;
			this.ClientSize = new System.Drawing.Size(1122, 782);
			this.Controls.Add(this.lblAdd_Update);
			this.Controls.Add(this.panel1);
			this.Controls.Add(this.btnClose);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
			this.Name = "frmAdd_UpdateUserN";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Add_Update UserN";
			this.Load += new System.EventHandler(this.frmAdd_UpdateUserN_Load);
			this.panel2.ResumeLayout(false);
			this.panel2.PerformLayout();
			this.panel1.ResumeLayout(false);
			this.tabControl1.ResumeLayout(false);
			this.tpPersonalInfo.ResumeLayout(false);
			this.tpUserInfo.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).EndInit();
			this.ResumeLayout(false);

		}

		#endregion
		private System.Windows.Forms.Label lblAdd_Update;
		private System.Windows.Forms.Button btnSave;
		private System.Windows.Forms.Button btnClose;
		private System.Windows.Forms.Button btnBack;
		private System.Windows.Forms.Button btnNext;
		private System.Windows.Forms.Panel panel2;
		private System.Windows.Forms.Label lblUserID;
		private System.Windows.Forms.CheckBox cbIsActive;
		private System.Windows.Forms.Label lblIsActive;
		private System.Windows.Forms.TextBox txbConfim;
		private System.Windows.Forms.Label lblConfirm;
		private System.Windows.Forms.TextBox txbPassword;
		private System.Windows.Forms.Label lblPassword;
		private System.Windows.Forms.TextBox txbUserName;
		private System.Windows.Forms.Label lblUserName;
		private userControls._01_People.uc1N_FindPersonThenFillData findPerson;
		private System.Windows.Forms.Panel panel1;
		private System.Windows.Forms.TabControl tabControl1;
		private System.Windows.Forms.TabPage tpPersonalInfo;
		private System.Windows.Forms.TabPage tpUserInfo;
		private userControls._01_PeopleNewWay.uc1N_PersonDetailsN personDetails;
		private System.Windows.Forms.ErrorProvider errorProvider1;
		private System.Windows.Forms.Label lblCurrentPassword;
		private System.Windows.Forms.TextBox txbCurrentPassword;
	}
}