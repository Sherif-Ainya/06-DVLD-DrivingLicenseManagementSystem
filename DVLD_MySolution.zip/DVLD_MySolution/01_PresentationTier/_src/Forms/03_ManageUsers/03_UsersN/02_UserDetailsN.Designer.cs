﻿namespace _02_DVLD_Mine._src.Forms._03_Users
{
	partial class frmUserDetailsN
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.btnClose = new System.Windows.Forms.Button();
			this.lblPersonDetails = new System.Windows.Forms.Label();
			this.FullUserDetails = new _02_DVLD_Mine._src.userControls._02_UsersN.uc02N_ucUserDetailsN();
			this.SuspendLayout();
			// 
			// btnClose
			// 
			this.btnClose.BackColor = System.Drawing.SystemColors.ScrollBar;
			this.btnClose.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
			this.btnClose.FlatAppearance.BorderSize = 2;
			this.btnClose.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnClose.Font = new System.Drawing.Font("Microsoft YaHei UI", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnClose.ForeColor = System.Drawing.Color.Red;
			this.btnClose.Image = global::_02_DVLD_Mine.Properties.Resources.close;
			this.btnClose.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btnClose.Location = new System.Drawing.Point(762, 677);
			this.btnClose.Name = "btnClose";
			this.btnClose.Size = new System.Drawing.Size(122, 53);
			this.btnClose.TabIndex = 0;
			this.btnClose.Text = "Close";
			this.btnClose.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.btnClose.UseVisualStyleBackColor = false;
			this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
			// 
			// lblPersonDetails
			// 
			this.lblPersonDetails.AutoSize = true;
			this.lblPersonDetails.Font = new System.Drawing.Font("Palatino Linotype", 39F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblPersonDetails.ForeColor = System.Drawing.Color.BlueViolet;
			this.lblPersonDetails.Location = new System.Drawing.Point(285, 11);
			this.lblPersonDetails.Name = "lblPersonDetails";
			this.lblPersonDetails.Size = new System.Drawing.Size(321, 71);
			this.lblPersonDetails.TabIndex = 11;
			this.lblPersonDetails.Text = "User Details";
			// 
			// FullUserDetails
			// 
			this.FullUserDetails.BackColor = System.Drawing.Color.SlateBlue;
			this.FullUserDetails.Location = new System.Drawing.Point(59, 96);
			this.FullUserDetails.Name = "FullUserDetails";
			this.FullUserDetails.Size = new System.Drawing.Size(809, 575);
			this.FullUserDetails.TabIndex = 1;
			this.FullUserDetails.TabStop = false;
			// 
			// frmUserDetailsN
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = System.Drawing.Color.LightPink;
			this.ClientSize = new System.Drawing.Size(928, 740);
			this.Controls.Add(this.FullUserDetails);
			this.Controls.Add(this.btnClose);
			this.Controls.Add(this.lblPersonDetails);
			this.Name = "frmUserDetailsN";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "User Details New";
			this.Load += new System.EventHandler(this.frmUserDetailsN_Load);
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion
		private System.Windows.Forms.Button btnClose;
		private System.Windows.Forms.Label lblPersonDetails;
		private userControls._02_UsersN.uc02N_ucUserDetailsN FullUserDetails;
	}
}