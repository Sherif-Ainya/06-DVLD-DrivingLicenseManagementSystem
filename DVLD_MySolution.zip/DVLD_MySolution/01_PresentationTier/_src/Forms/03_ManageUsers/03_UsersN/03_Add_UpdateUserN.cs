﻿using System;
using System.Windows.Forms;
using _02_DVLD_Mine._src.Forms._02_PeopleN;
using DVLD_Business;

namespace _02_DVLD_Mine._src.Forms._03_Users
{
	public partial class frmAdd_UpdateUserN : Form
	{
		public frmAdd_UpdateUserN(int UserID)
		{
			InitializeComponent();
			_userID = UserID;
		}


		private int _userID = -1;
		private clsBusinessUsers _currentUser = new clsBusinessUsers();
		private string _currentPassword = "";

		private bool _allowChangingTab = true;
		private void tabControl1_Selecting(object sender, TabControlCancelEventArgs e)
		{
			e.Cancel = _allowChangingTab;
		}
		private void _UpdateMode()
		{
			lblAdd_Update.Text = "Update User";
			lblAdd_Update.ForeColor = System.Drawing.Color.DarkSlateBlue;
			_currentUser = clsBusinessUsers.Find(_userID);

			if (_currentUser == null)
				return;

			personDetails.LoadPersonData(_currentUser.personID);
			_allowChangingTab = false;
			tabControl1.SelectedIndex = 1;
			findPerson.Visible = false;
			_currentPassword = _currentUser.password;

			txbUserName.Text = _currentUser.userName;
			cbIsActive.Checked = _currentUser.active;
			txbPassword.Text = _currentUser.password;
			txbConfim.Text = _currentUser.password;
			lblUserID.Text = _currentUser.userID.ToString();
		}
		private void _AddNewMode()
		{
			personDetails.Visible = false;
			btnNext.Enabled = false;
			lblCurrentPassword.Visible = false;
			txbCurrentPassword.Visible = false;

			lblUserName.Location = new System.Drawing.Point(46, 84);
			txbUserName.Location = new System.Drawing.Point(213, 84);

			lblPassword.Text = "Password :";

			findPerson.FindPersonFor(frmManagePeopleN.enReturnPerson.enReturnPerson_CheckUser);
		}


		private void frmAdd_UpdateUserN_Load(object sender, EventArgs e)
		{
			if (_userID != -1)
				_UpdateMode();
			else
				_AddNewMode();
		}
		private void findPerson_OnFound(int obj)
		{
			int personID = obj;
			_currentUser.personID = personID;

			btnNext.Enabled = true;
			_allowChangingTab = false;
		}


		private void btnNext_Click(object sender, EventArgs e)
		{
			tabControl1.SelectedIndex = 1;
		}
		private void btnBack_Click(object sender, EventArgs e)
		{
			tabControl1.SelectedIndex = 0;
		}


		private void cbIsActive_CheckedChanged(object sender, EventArgs e)
		{
			if (cbIsActive.Checked)
				cbIsActive.Text = "Active";
			else
				cbIsActive.Text = "Not Active";
		}
		private bool _CheckAllInfoCompleted()
		{
			if (txbUserName.Text == "")
			{
				txbUserName.Focus();
				return false;
			}
			if (txbPassword.Text == "")
			{
				txbPassword.Focus();
				return false;
			}
			if (txbConfim.Text == "")
			{
				txbConfim.Focus();
				return false;
			}
			if (txbCurrentPassword.Text == "" && _currentPassword != "")
			{
				txbCurrentPassword.Focus();
				return false;
			}
			return true;
		}
		private void btnSave_Click(object sender, EventArgs e)
		{
			if (!_CheckAllInfoCompleted())
			{
				MessageBox.Show("Not All Information Completed!", "Warrning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
				return;
			}

			_currentUser.userName = txbUserName.Text;
			_currentUser.password = txbPassword.Text;
			_currentUser.active = cbIsActive.Checked;

			if (_currentUser.Save())
				MessageBox.Show("Data Saved Successfully.");
			else
				MessageBox.Show("Error: Data Is not Saved Successfully.");

			lblUserID.Text = _currentUser.userID.ToString();
		}
		private void btnClose_Click(object sender, EventArgs e)
		{
			this.Close();
		}


		private void txbConfim_Validating(object sender, System.ComponentModel.CancelEventArgs e)
		{
			if (!string.IsNullOrEmpty(txbConfim.Text) && txbConfim.Text != txbPassword.Text)
			{
				e.Cancel = true;
				txbConfim.Text = "";
				txbConfim.Focus();
				errorProvider1.SetError(txbConfim, "Password Dosen't Match The Confirm Value!");
			}
			else
			{
				e.Cancel = false;
				errorProvider1.SetError(txbConfim, "");
			}
		}
		private void txbCurrentPassword_Validating(object sender, System.ComponentModel.CancelEventArgs e)
		{
			if (!string.IsNullOrEmpty(txbConfim.Text) && txbCurrentPassword.Text != _currentPassword)
			{
				e.Cancel = true;
				txbCurrentPassword.Text = "";
				txbCurrentPassword.Focus();
				errorProvider1.SetError(txbCurrentPassword, "Not Correct Password Try Again!");
			}
			else
			{
				e.Cancel = false;
				errorProvider1.SetError(txbCurrentPassword, "");
			}
		}
	}
}
