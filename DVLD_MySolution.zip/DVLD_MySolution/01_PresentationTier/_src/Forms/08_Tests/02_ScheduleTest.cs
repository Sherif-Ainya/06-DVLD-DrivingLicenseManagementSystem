﻿using System;
using System.Windows.Forms;
using DVLD_Business;
using static _02_DVLD_Mine._src.Forms._07_Tests.frmTestApplication;

namespace _02_DVLD_Mine._src.Forms._07_Tests
{
	public partial class frmScheduleTest : Form
	{
		private clsBusinessTestAppointments _appointment = new clsBusinessTestAppointments();

		public enum enNewTest_Retake { eNewTest, eRetake, eEdit };
		private enNewTest_Retake _NewTest_Retake = enNewTest_Retake.eNewTest;
		private decimal _Fees = 0.0m;
		private decimal _RetakeTestFees = 0.0m;

		private void _PrepareForm()
		{
			switch (_appointment.TestTypeID)
			{
				case 1:
					lblScheduleTestTitle.Text = "Schedule Vision Test Appointment";
					break;
				case 2:
					lblScheduleTestTitle.Text = "Schedule Written Test Appointment";
					break;
				case 3:
					lblScheduleTestTitle.Text = "Schedule Practical Test Appointment";
					break;
			}

			dtpDate.MinDate = DateTime.Today.AddDays(1);
			dtpDate.Value = dtpDate.MinDate;
			_Fees = clsBusinessTestTypes.Find(_appointment.TestTypeID).TestTypeFees;
			lblFees.Text = _Fees.ToString();

			if (_NewTest_Retake == enNewTest_Retake.eRetake)
			{
				lblRetakeTest.Visible = true;
				_lblRetakeTestFees.Visible = true;
				lblRetakeFees.Visible = true;
				_RetakeTestFees = clsBusinessApplicationTypes.Find(2).applicationTypeFees;
				lblRetakeFees.Text = _RetakeTestFees.ToString();
			}
		}


		public frmScheduleTest(int LDLA_ID, enTestType testType, enNewTest_Retake newTest_Retake)
		{
			InitializeComponent();
			_appointment.LDLA_ID = LDLA_ID;
			_appointment.TestTypeID = (int)testType;
			_appointment.CreatedByUserID = clsGlobal.currentUser.userID;
			_appointment.IsLocked = false;

			_NewTest_Retake = newTest_Retake;
			_PrepareForm();
		}
		public frmScheduleTest(int TestAppointmentID, enNewTest_Retake newTest_Retake = enNewTest_Retake.eEdit)
		{
			InitializeComponent();
			dtpDate.MinDate = DateTime.Today.AddDays(1);
			dtpDate.Value = dtpDate.MinDate;

			_appointment = clsBusinessTestAppointments.GetTestAppointment(TestAppointmentID);
			dtpDate.Value = _appointment.AppointmentDate;
			lblAppointmentID.Text = _appointment.TestAppointmentID.ToString();
			lblFees.Text = _appointment.PaidFees.ToString();

			_NewTest_Retake = newTest_Retake;
		}


		private void btnSave_Click_1(object sender, System.EventArgs e)
		{
			_appointment.AppointmentDate = dtpDate.Value;

			if (_NewTest_Retake == enNewTest_Retake.eEdit)
			{
				if (_appointment.Save())
					MessageBox.Show("Data Saved Successfully.");
				else
					MessageBox.Show("Error: Data Is not Saved Successfully.");
				return;
			}


			_appointment.PaidFees = _Fees + _RetakeTestFees;

			if (_appointment.Save())
				MessageBox.Show("Data Saved Successfully.");
			else
				MessageBox.Show("Error: Data Is not Saved Successfully.");

			lblAppointmentID.Text = _appointment.TestAppointmentID.ToString();
		}
		private void btnClose_Click(object sender, System.EventArgs e)
		{
			this.Close();
		}
	}
}
