﻿using System.Windows.Forms;
using _02_DVLD_Mine._src.Forms._07_Tests;
using DVLD_Business;

namespace _02_DVLD_Mine._src.Forms._06_ManageLocalDL
{
	public partial class frmTakeTest : Form
	{
		private clsBusinessTests _test = new clsBusinessTests();
		private clsBusinessTestAppointments _relatedAppointment;

		public frmTakeTest(int testAppointmentID, frmTestApplication.enTestType testType)
		{
			InitializeComponent();

			switch ((int)testType)
			{
				case 1:
					lbTakeTestTitle.Text = "Taking Vision Test Results...";
					break;
				case 2:
					lbTakeTestTitle.Text = "Taking Written Test Results...";
					break;
				case 3:
					lbTakeTestTitle.Text = "Taking Practical Test Results...";
					break;
			}

			if (testAppointmentID != -1)
			{
				_test.TestAppointmentID = testAppointmentID;
				_relatedAppointment = clsBusinessTestAppointments.GetTestAppointment(testAppointmentID);
			}

			if (_relatedAppointment.IsLocked)
			{
				rbPass.Enabled = false;
				rbFaild.Enabled = false;
				txbNotes.Enabled = false;
				btnSave.Enabled = false;
			}
		}



		private void btnSave_Click(object sender, System.EventArgs e)
		{
			if (rbPass.Checked == rbFaild.Checked)
			{ MessageBox.Show("Not All Info Completed!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error); return; }

			_test.CreatedByUserID = clsGlobal.currentUser.userID;

			_test.TestResult = rbPass.Checked;
			_test.Notes = txbNotes.Text;
			_relatedAppointment.IsLocked = true;

			if (_test.Save() && _relatedAppointment.Save())
			{
				MessageBox.Show("Data Saved Successfully.");
			}
			else
				MessageBox.Show("Error: Data Is not Saved Successfully.");


			lblTestID.Text = _test.TestID.ToString();
		}
		private void btnClose_Click(object sender, System.EventArgs e)
		{
			this.Close();
		}
	}
}
