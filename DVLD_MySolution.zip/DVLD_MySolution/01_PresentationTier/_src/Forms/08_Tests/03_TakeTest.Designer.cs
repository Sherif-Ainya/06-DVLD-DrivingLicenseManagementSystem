﻿namespace _02_DVLD_Mine._src.Forms._06_ManageLocalDL
{
	partial class frmTakeTest
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.btnSave = new System.Windows.Forms.Button();
			this.btnClose = new System.Windows.Forms.Button();
			this.lbTakeTestTitle = new System.Windows.Forms.Label();
			this._lblTestID = new System.Windows.Forms.Label();
			this.lblTestID = new System.Windows.Forms.Label();
			this._lblResult = new System.Windows.Forms.Label();
			this._lblNotes = new System.Windows.Forms.Label();
			this.txbNotes = new System.Windows.Forms.TextBox();
			this.rbPass = new System.Windows.Forms.RadioButton();
			this.rbFaild = new System.Windows.Forms.RadioButton();
			this.SuspendLayout();
			// 
			// btnSave
			// 
			this.btnSave.BackColor = System.Drawing.Color.Pink;
			this.btnSave.FlatAppearance.BorderColor = System.Drawing.Color.MediumSpringGreen;
			this.btnSave.FlatAppearance.BorderSize = 4;
			this.btnSave.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
			this.btnSave.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
			this.btnSave.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnSave.Font = new System.Drawing.Font("Microsoft YaHei UI", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnSave.ForeColor = System.Drawing.Color.DarkOrchid;
			this.btnSave.Image = global::_02_DVLD_Mine.Properties.Resources.save_27_16;
			this.btnSave.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btnSave.Location = new System.Drawing.Point(516, 470);
			this.btnSave.Name = "btnSave";
			this.btnSave.Size = new System.Drawing.Size(100, 50);
			this.btnSave.TabIndex = 5;
			this.btnSave.Text = "SAVE";
			this.btnSave.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.btnSave.UseVisualStyleBackColor = false;
			this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
			// 
			// btnClose
			// 
			this.btnClose.BackColor = System.Drawing.SystemColors.ScrollBar;
			this.btnClose.DialogResult = System.Windows.Forms.DialogResult.Cancel;
			this.btnClose.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
			this.btnClose.FlatAppearance.BorderSize = 2;
			this.btnClose.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnClose.Font = new System.Drawing.Font("Microsoft YaHei UI", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnClose.ForeColor = System.Drawing.Color.Red;
			this.btnClose.Image = global::_02_DVLD_Mine.Properties.Resources.close;
			this.btnClose.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btnClose.Location = new System.Drawing.Point(554, 0);
			this.btnClose.Name = "btnClose";
			this.btnClose.Size = new System.Drawing.Size(62, 47);
			this.btnClose.TabIndex = 1;
			this.btnClose.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.btnClose.UseVisualStyleBackColor = false;
			this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
			// 
			// lbTakeTestTitle
			// 
			this.lbTakeTestTitle.Font = new System.Drawing.Font("Palatino Linotype", 32F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lbTakeTestTitle.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
			this.lbTakeTestTitle.Location = new System.Drawing.Point(65, 50);
			this.lbTakeTestTitle.Name = "lbTakeTestTitle";
			this.lbTakeTestTitle.Size = new System.Drawing.Size(491, 65);
			this.lbTakeTestTitle.TabIndex = 82;
			this.lbTakeTestTitle.Text = "Take Test";
			this.lbTakeTestTitle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// _lblTestID
			// 
			this._lblTestID.AutoSize = true;
			this._lblTestID.BackColor = System.Drawing.Color.LavenderBlush;
			this._lblTestID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this._lblTestID.Font = new System.Drawing.Font("Palatino Linotype", 19F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this._lblTestID.Location = new System.Drawing.Point(186, 168);
			this._lblTestID.Name = "_lblTestID";
			this._lblTestID.Size = new System.Drawing.Size(111, 37);
			this._lblTestID.TabIndex = 89;
			this._lblTestID.Text = "Test ID :";
			// 
			// lblTestID
			// 
			this.lblTestID.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
			this.lblTestID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.lblTestID.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblTestID.ForeColor = System.Drawing.Color.Red;
			this.lblTestID.Location = new System.Drawing.Point(348, 168);
			this.lblTestID.Name = "lblTestID";
			this.lblTestID.Size = new System.Drawing.Size(65, 37);
			this.lblTestID.TabIndex = 88;
			this.lblTestID.Text = "????";
			this.lblTestID.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// _lblResult
			// 
			this._lblResult.AutoSize = true;
			this._lblResult.BackColor = System.Drawing.Color.LavenderBlush;
			this._lblResult.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this._lblResult.Font = new System.Drawing.Font("Palatino Linotype", 19F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this._lblResult.Location = new System.Drawing.Point(108, 246);
			this._lblResult.Name = "_lblResult";
			this._lblResult.Size = new System.Drawing.Size(100, 37);
			this._lblResult.TabIndex = 90;
			this._lblResult.Text = "Result :";
			// 
			// _lblNotes
			// 
			this._lblNotes.AutoSize = true;
			this._lblNotes.BackColor = System.Drawing.Color.LavenderBlush;
			this._lblNotes.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this._lblNotes.Font = new System.Drawing.Font("Palatino Linotype", 19F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this._lblNotes.Location = new System.Drawing.Point(38, 362);
			this._lblNotes.Name = "_lblNotes";
			this._lblNotes.Size = new System.Drawing.Size(98, 37);
			this._lblNotes.TabIndex = 91;
			this._lblNotes.Text = "Notes :";
			// 
			// txbNotes
			// 
			this.txbNotes.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.txbNotes.Location = new System.Drawing.Point(142, 327);
			this.txbNotes.Multiline = true;
			this.txbNotes.Name = "txbNotes";
			this.txbNotes.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
			this.txbNotes.Size = new System.Drawing.Size(414, 122);
			this.txbNotes.TabIndex = 4;
			// 
			// rbPass
			// 
			this.rbPass.AutoSize = true;
			this.rbPass.Font = new System.Drawing.Font("Modern No. 20", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.rbPass.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
			this.rbPass.Location = new System.Drawing.Point(242, 251);
			this.rbPass.Name = "rbPass";
			this.rbPass.Size = new System.Drawing.Size(70, 28);
			this.rbPass.TabIndex = 2;
			this.rbPass.TabStop = true;
			this.rbPass.Text = "Pass";
			this.rbPass.UseVisualStyleBackColor = true;
			// 
			// rbFaild
			// 
			this.rbFaild.AutoSize = true;
			this.rbFaild.Font = new System.Drawing.Font("Modern No. 20", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.rbFaild.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
			this.rbFaild.Location = new System.Drawing.Point(333, 251);
			this.rbFaild.Name = "rbFaild";
			this.rbFaild.Size = new System.Drawing.Size(80, 28);
			this.rbFaild.TabIndex = 3;
			this.rbFaild.TabStop = true;
			this.rbFaild.Text = "Faild";
			this.rbFaild.UseVisualStyleBackColor = true;
			// 
			// frmTakeTest
			// 
			this.AcceptButton = this.btnSave;
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = System.Drawing.Color.Coral;
			this.CancelButton = this.btnClose;
			this.ClientSize = new System.Drawing.Size(615, 520);
			this.Controls.Add(this.rbFaild);
			this.Controls.Add(this.rbPass);
			this.Controls.Add(this.txbNotes);
			this.Controls.Add(this._lblNotes);
			this.Controls.Add(this._lblResult);
			this.Controls.Add(this._lblTestID);
			this.Controls.Add(this.lblTestID);
			this.Controls.Add(this.btnSave);
			this.Controls.Add(this.btnClose);
			this.Controls.Add(this.lbTakeTestTitle);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
			this.Name = "frmTakeTest";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "_03_TakeTest";
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.Button btnSave;
		private System.Windows.Forms.Button btnClose;
		private System.Windows.Forms.Label lbTakeTestTitle;
		private System.Windows.Forms.Label _lblTestID;
		private System.Windows.Forms.Label lblTestID;
		private System.Windows.Forms.Label _lblResult;
		private System.Windows.Forms.Label _lblNotes;
		private System.Windows.Forms.TextBox txbNotes;
		private System.Windows.Forms.RadioButton rbPass;
		private System.Windows.Forms.RadioButton rbFaild;
	}
}