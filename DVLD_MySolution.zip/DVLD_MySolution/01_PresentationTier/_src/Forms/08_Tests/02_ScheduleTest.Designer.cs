﻿namespace _02_DVLD_Mine._src.Forms._07_Tests
{
	partial class frmScheduleTest
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.lblScheduleTestTitle = new System.Windows.Forms.Label();
			this.lblRetakeTest = new System.Windows.Forms.Label();
			this.btnClose = new System.Windows.Forms.Button();
			this.btnSave = new System.Windows.Forms.Button();
			this.dtpDate = new System.Windows.Forms.DateTimePicker();
			this._lblDateOfBirth = new System.Windows.Forms.Label();
			this._lblFees = new System.Windows.Forms.Label();
			this.lblAppointmentID = new System.Windows.Forms.Label();
			this._lblAppointmentID = new System.Windows.Forms.Label();
			this._lblRetakeTestFees = new System.Windows.Forms.Label();
			this.lblFees = new System.Windows.Forms.Label();
			this.lblRetakeFees = new System.Windows.Forms.Label();
			this.SuspendLayout();
			// 
			// lblScheduleTestTitle
			// 
			this.lblScheduleTestTitle.Font = new System.Drawing.Font("Palatino Linotype", 23F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblScheduleTestTitle.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
			this.lblScheduleTestTitle.Location = new System.Drawing.Point(86, 64);
			this.lblScheduleTestTitle.Name = "lblScheduleTestTitle";
			this.lblScheduleTestTitle.Size = new System.Drawing.Size(491, 42);
			this.lblScheduleTestTitle.TabIndex = 69;
			this.lblScheduleTestTitle.Text = "Edit Test Appointment";
			this.lblScheduleTestTitle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// lblRetakeTest
			// 
			this.lblRetakeTest.AutoSize = true;
			this.lblRetakeTest.BackColor = System.Drawing.Color.Gainsboro;
			this.lblRetakeTest.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.lblRetakeTest.Font = new System.Drawing.Font("Palatino Linotype", 20F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblRetakeTest.ForeColor = System.Drawing.Color.Red;
			this.lblRetakeTest.Location = new System.Drawing.Point(233, 132);
			this.lblRetakeTest.Name = "lblRetakeTest";
			this.lblRetakeTest.Size = new System.Drawing.Size(159, 37);
			this.lblRetakeTest.TabIndex = 70;
			this.lblRetakeTest.Text = "Retake Test";
			this.lblRetakeTest.Visible = false;
			// 
			// btnClose
			// 
			this.btnClose.BackColor = System.Drawing.SystemColors.ScrollBar;
			this.btnClose.DialogResult = System.Windows.Forms.DialogResult.Cancel;
			this.btnClose.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
			this.btnClose.FlatAppearance.BorderSize = 2;
			this.btnClose.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnClose.Font = new System.Drawing.Font("Microsoft YaHei UI", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnClose.ForeColor = System.Drawing.Color.Red;
			this.btnClose.Image = global::_02_DVLD_Mine.Properties.Resources.close;
			this.btnClose.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btnClose.Location = new System.Drawing.Point(583, 0);
			this.btnClose.Name = "btnClose";
			this.btnClose.Size = new System.Drawing.Size(62, 47);
			this.btnClose.TabIndex = 0;
			this.btnClose.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.btnClose.UseVisualStyleBackColor = false;
			this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
			// 
			// btnSave
			// 
			this.btnSave.BackColor = System.Drawing.Color.Pink;
			this.btnSave.FlatAppearance.BorderColor = System.Drawing.Color.MediumSpringGreen;
			this.btnSave.FlatAppearance.BorderSize = 4;
			this.btnSave.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
			this.btnSave.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
			this.btnSave.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnSave.Font = new System.Drawing.Font("Microsoft YaHei UI", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnSave.ForeColor = System.Drawing.Color.DarkOrchid;
			this.btnSave.Image = global::_02_DVLD_Mine.Properties.Resources.save_27_16;
			this.btnSave.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btnSave.Location = new System.Drawing.Point(545, 462);
			this.btnSave.Name = "btnSave";
			this.btnSave.Size = new System.Drawing.Size(100, 50);
			this.btnSave.TabIndex = 1;
			this.btnSave.Text = "SAVE";
			this.btnSave.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.btnSave.UseVisualStyleBackColor = false;
			this.btnSave.Click += new System.EventHandler(this.btnSave_Click_1);
			// 
			// dtpDate
			// 
			this.dtpDate.CalendarFont = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.dtpDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.dtpDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
			this.dtpDate.Location = new System.Drawing.Point(365, 260);
			this.dtpDate.MaximumSize = new System.Drawing.Size(167, 29);
			this.dtpDate.MinimumSize = new System.Drawing.Size(167, 29);
			this.dtpDate.Name = "dtpDate";
			this.dtpDate.Size = new System.Drawing.Size(167, 29);
			this.dtpDate.TabIndex = 2;
			this.dtpDate.TabStop = false;
			// 
			// _lblDateOfBirth
			// 
			this._lblDateOfBirth.AutoSize = true;
			this._lblDateOfBirth.BackColor = System.Drawing.SystemColors.ActiveCaption;
			this._lblDateOfBirth.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this._lblDateOfBirth.Font = new System.Drawing.Font("Palatino Linotype", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this._lblDateOfBirth.Location = new System.Drawing.Point(152, 261);
			this._lblDateOfBirth.Name = "_lblDateOfBirth";
			this._lblDateOfBirth.Size = new System.Drawing.Size(74, 31);
			this._lblDateOfBirth.TabIndex = 84;
			this._lblDateOfBirth.Text = "Date :";
			// 
			// _lblFees
			// 
			this._lblFees.AutoSize = true;
			this._lblFees.BackColor = System.Drawing.SystemColors.ActiveCaption;
			this._lblFees.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this._lblFees.Font = new System.Drawing.Font("Palatino Linotype", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this._lblFees.Location = new System.Drawing.Point(154, 317);
			this._lblFees.Name = "_lblFees";
			this._lblFees.Size = new System.Drawing.Size(71, 31);
			this._lblFees.TabIndex = 85;
			this._lblFees.Text = "Fees :";
			// 
			// lblAppointmentID
			// 
			this.lblAppointmentID.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
			this.lblAppointmentID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.lblAppointmentID.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblAppointmentID.ForeColor = System.Drawing.Color.Red;
			this.lblAppointmentID.Location = new System.Drawing.Point(413, 201);
			this.lblAppointmentID.Name = "lblAppointmentID";
			this.lblAppointmentID.Size = new System.Drawing.Size(65, 35);
			this.lblAppointmentID.TabIndex = 86;
			this.lblAppointmentID.Text = "????";
			this.lblAppointmentID.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// _lblAppointmentID
			// 
			this._lblAppointmentID.AutoSize = true;
			this._lblAppointmentID.BackColor = System.Drawing.SystemColors.ActiveCaption;
			this._lblAppointmentID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this._lblAppointmentID.Font = new System.Drawing.Font("Palatino Linotype", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this._lblAppointmentID.Location = new System.Drawing.Point(93, 205);
			this._lblAppointmentID.Name = "_lblAppointmentID";
			this._lblAppointmentID.Size = new System.Drawing.Size(192, 31);
			this._lblAppointmentID.TabIndex = 87;
			this._lblAppointmentID.Text = "Appointment ID :";
			// 
			// _lblRetakeTestFees
			// 
			this._lblRetakeTestFees.AutoSize = true;
			this._lblRetakeTestFees.BackColor = System.Drawing.SystemColors.ActiveCaption;
			this._lblRetakeTestFees.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this._lblRetakeTestFees.Font = new System.Drawing.Font("Palatino Linotype", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this._lblRetakeTestFees.Location = new System.Drawing.Point(93, 367);
			this._lblRetakeTestFees.Name = "_lblRetakeTestFees";
			this._lblRetakeTestFees.Size = new System.Drawing.Size(192, 31);
			this._lblRetakeTestFees.TabIndex = 88;
			this._lblRetakeTestFees.Text = "Retake Test Fees :";
			this._lblRetakeTestFees.Visible = false;
			// 
			// lblFees
			// 
			this.lblFees.BackColor = System.Drawing.Color.LightGray;
			this.lblFees.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.lblFees.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblFees.ForeColor = System.Drawing.Color.Black;
			this.lblFees.Location = new System.Drawing.Point(399, 317);
			this.lblFees.Name = "lblFees";
			this.lblFees.Size = new System.Drawing.Size(95, 35);
			this.lblFees.TabIndex = 89;
			this.lblFees.Text = "???";
			this.lblFees.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// lblRetakeFees
			// 
			this.lblRetakeFees.BackColor = System.Drawing.Color.LightGray;
			this.lblRetakeFees.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.lblRetakeFees.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblRetakeFees.ForeColor = System.Drawing.Color.Black;
			this.lblRetakeFees.Location = new System.Drawing.Point(399, 367);
			this.lblRetakeFees.Name = "lblRetakeFees";
			this.lblRetakeFees.Size = new System.Drawing.Size(95, 35);
			this.lblRetakeFees.TabIndex = 90;
			this.lblRetakeFees.Text = "???";
			this.lblRetakeFees.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			this.lblRetakeFees.Visible = false;
			// 
			// frmScheduleTest
			// 
			this.AcceptButton = this.btnSave;
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = System.Drawing.Color.LightCoral;
			this.CancelButton = this.btnClose;
			this.ClientSize = new System.Drawing.Size(645, 512);
			this.Controls.Add(this.lblRetakeFees);
			this.Controls.Add(this.lblFees);
			this.Controls.Add(this._lblRetakeTestFees);
			this.Controls.Add(this._lblAppointmentID);
			this.Controls.Add(this.lblAppointmentID);
			this.Controls.Add(this._lblFees);
			this.Controls.Add(this._lblDateOfBirth);
			this.Controls.Add(this.dtpDate);
			this.Controls.Add(this.btnSave);
			this.Controls.Add(this.btnClose);
			this.Controls.Add(this.lblRetakeTest);
			this.Controls.Add(this.lblScheduleTestTitle);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
			this.Name = "frmScheduleTest";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Schedule Test";
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.Label lblScheduleTestTitle;
		private System.Windows.Forms.Label lblRetakeTest;
		private System.Windows.Forms.Button btnClose;
		private System.Windows.Forms.Button btnSave;
		private System.Windows.Forms.DateTimePicker dtpDate;
		private System.Windows.Forms.Label _lblDateOfBirth;
		private System.Windows.Forms.Label _lblFees;
		private System.Windows.Forms.Label lblAppointmentID;
		private System.Windows.Forms.Label _lblAppointmentID;
		private System.Windows.Forms.Label _lblRetakeTestFees;
		private System.Windows.Forms.Label lblFees;
		private System.Windows.Forms.Label lblRetakeFees;
	}
}