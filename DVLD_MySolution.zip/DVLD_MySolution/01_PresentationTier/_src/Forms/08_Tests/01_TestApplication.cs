﻿using System;
using System.Windows.Forms;
using _02_DVLD_Mine._src.Forms._06_ManageLocalDL;
using DVLD_Business;

namespace _02_DVLD_Mine._src.Forms._07_Tests
{
	public partial class frmTestApplication : Form
	{
		public enum enTestType { eVision = 1, eWritten = 2, ePractical = 3 };
		private enTestType _TestType = enTestType.eVision;
		private int _LDLA_ID = 0;

		public frmTestApplication(int LDLA_ID, enTestType testType)
		{
			InitializeComponent();
			_LDLA_ID = LDLA_ID;
			_TestType = testType;
			ucADL_BasicInfo1.LoadData(LDLA_ID);
			_RefreshTests();
		}


		private void dgvVisionTests_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
		{
			// Header Height.
			dgvTests.ColumnHeadersHeight = 60;

			// Rows Height, Or [Properties > RowTemplate.Height], Or AutoSizeRowsMode.
			dgvTests.RowTemplate.Height = 32;

			// Cell Width Firsth Put DataGridView AutoSizeColumnsMode = Fill. Then Make Changes To Some Of The Columns Like This.
			dgvTests.Columns[0].Width = 190;

			dgvTests.Columns[1].Visible = false;
			dgvTests.Columns[2].Visible = false;
			dgvTests.Columns[5].Visible = false;

			dgvTests.Columns[0].HeaderText = "Test Appointment ID";
			dgvTests.Columns[3].HeaderText = "Appointment Date";
			dgvTests.Columns[4].HeaderText = "Paid Fees";
			dgvTests.Columns[6].HeaderText = "Is Locked?";
		}
		private void _RefreshTests()
		{
			switch (_TestType)
			{
				case enTestType.eVision:
					lblTitleTestAppointment.Text = "Vision Test Appointments";
					break;
				case enTestType.eWritten:
					lblTitleTestAppointment.Text = "Written Test Appointments";
					break;
				case enTestType.ePractical:
					lblTitleTestAppointment.Text = "Practical Test Appointments";
					break;
			}

			dgvTests.SuspendLayout();
			dgvTests.DataSource = clsBusinessTestAppointments.GetAllAppointmentsOfLocalApp_TestType(_LDLA_ID, (int)_TestType);
			dgvTests.ResumeLayout();
			lblTotalTestsAppointments.Text = "Total Appointments [" + dgvTests.RowCount.ToString() + "].";
		}



		private void cmsTests_Opened(object sender, EventArgs e)
		{
			bool isLocked = !(bool)dgvTests.CurrentRow.Cells["IsLocked"].Value;

			tsmiEdit.Enabled = isLocked;
			tsmiTake.Enabled = isLocked;
		}
		private void tsmiEdit_Click(object sender, EventArgs e)
		{
			int appointmentID = (int)dgvTests.CurrentRow.Cells[0].Value;
			Form addNew = new frmScheduleTest(appointmentID);
			addNew.ShowDialog();
			_RefreshTests();
		}
		private void tsmiTake_Click(object sender, EventArgs e)
		{
			int appointmentID = (int)dgvTests.CurrentRow.Cells[0].Value;
			Form addNew = new frmTakeTest(appointmentID, _TestType);
			addNew.ShowDialog();
			_RefreshTests();
			ucADL_BasicInfo1.LoadData(_LDLA_ID);
		}


		private void btnAddNewVisionTest_Click(object sender, EventArgs e)
		{
			if (clsBusinessTestAppointments.HasActiveAppointment(_LDLA_ID, (int)_TestType))
			{
				MessageBox.Show("This Person Already Have An Active Appointment For This Test!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
				return;
			}

			if (clsBusinessTestAppointments.PassedThisTest(_LDLA_ID, (int)_TestType))
			{
				MessageBox.Show("This Person Have Passed This Test Before!", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
				return;
			}

			if (dgvTests.RowCount == 0)
			{
				Form addNew = new frmScheduleTest(_LDLA_ID, _TestType, frmScheduleTest.enNewTest_Retake.eNewTest);
				addNew.ShowDialog();
			}
			else
			{
				Form addNew = new frmScheduleTest(_LDLA_ID, _TestType, frmScheduleTest.enNewTest_Retake.eRetake);
				addNew.ShowDialog();
			}
			_RefreshTests();
		}
		private void btnClose_Click(object sender, EventArgs e)
		{
			this.Close();
		}
	}
}
