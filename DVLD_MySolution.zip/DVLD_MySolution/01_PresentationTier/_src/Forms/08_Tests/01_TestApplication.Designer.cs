﻿namespace _02_DVLD_Mine._src.Forms._07_Tests
{
	partial class frmTestApplication
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
			this.lblTitleTestAppointment = new System.Windows.Forms.Label();
			this.btnAddNewVisionTest = new System.Windows.Forms.Button();
			this.btnClose = new System.Windows.Forms.Button();
			this.dgvTests = new System.Windows.Forms.DataGridView();
			this.cmsTests = new System.Windows.Forms.ContextMenuStrip(this.components);
			this.tsmiEdit = new System.Windows.Forms.ToolStripMenuItem();
			this.tsmiTake = new System.Windows.Forms.ToolStripMenuItem();
			this.lblTotalTestsAppointments = new System.Windows.Forms.Label();
			this.ucADL_BasicInfo1 = new _02_DVLD_Mine._src.userControls._03_ucDLA.ucADL_BasicInfo();
			((System.ComponentModel.ISupportInitialize)(this.dgvTests)).BeginInit();
			this.cmsTests.SuspendLayout();
			this.SuspendLayout();
			// 
			// lblTitleTestAppointment
			// 
			this.lblTitleTestAppointment.AutoSize = true;
			this.lblTitleTestAppointment.Font = new System.Drawing.Font("Palatino Linotype", 35F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblTitleTestAppointment.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
			this.lblTitleTestAppointment.Location = new System.Drawing.Point(188, 18);
			this.lblTitleTestAppointment.Name = "lblTitleTestAppointment";
			this.lblTitleTestAppointment.Size = new System.Drawing.Size(567, 62);
			this.lblTitleTestAppointment.TabIndex = 68;
			this.lblTitleTestAppointment.Text = "Vision Test Appointments";
			// 
			// btnAddNewVisionTest
			// 
			this.btnAddNewVisionTest.BackColor = System.Drawing.Color.MediumSlateBlue;
			this.btnAddNewVisionTest.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
			this.btnAddNewVisionTest.FlatAppearance.BorderSize = 3;
			this.btnAddNewVisionTest.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnAddNewVisionTest.Font = new System.Drawing.Font("Modern No. 20", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnAddNewVisionTest.Location = new System.Drawing.Point(724, 770);
			this.btnAddNewVisionTest.Name = "btnAddNewVisionTest";
			this.btnAddNewVisionTest.Size = new System.Drawing.Size(119, 53);
			this.btnAddNewVisionTest.TabIndex = 1;
			this.btnAddNewVisionTest.Text = "ADD NEW";
			this.btnAddNewVisionTest.UseVisualStyleBackColor = false;
			this.btnAddNewVisionTest.Click += new System.EventHandler(this.btnAddNewVisionTest_Click);
			// 
			// btnClose
			// 
			this.btnClose.BackColor = System.Drawing.SystemColors.ScrollBar;
			this.btnClose.DialogResult = System.Windows.Forms.DialogResult.Cancel;
			this.btnClose.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
			this.btnClose.FlatAppearance.BorderSize = 2;
			this.btnClose.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnClose.Font = new System.Drawing.Font("Microsoft YaHei UI", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnClose.ForeColor = System.Drawing.Color.Red;
			this.btnClose.Image = global::_02_DVLD_Mine.Properties.Resources.close;
			this.btnClose.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btnClose.Location = new System.Drawing.Point(873, 0);
			this.btnClose.Name = "btnClose";
			this.btnClose.Size = new System.Drawing.Size(63, 53);
			this.btnClose.TabIndex = 0;
			this.btnClose.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.btnClose.UseVisualStyleBackColor = false;
			this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
			// 
			// dgvTests
			// 
			this.dgvTests.AllowUserToAddRows = false;
			this.dgvTests.AllowUserToDeleteRows = false;
			this.dgvTests.AllowUserToOrderColumns = true;
			this.dgvTests.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
			this.dgvTests.BackgroundColor = System.Drawing.SystemColors.GradientInactiveCaption;
			dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
			dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
			dataGridViewCellStyle1.Font = new System.Drawing.Font("Viner Hand ITC", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
			dataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.Aqua;
			dataGridViewCellStyle1.SelectionForeColor = System.Drawing.Color.Violet;
			dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
			this.dgvTests.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
			this.dgvTests.ColumnHeadersHeight = 50;
			this.dgvTests.ContextMenuStrip = this.cmsTests;
			dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
			dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
			dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
			dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.SkyBlue;
			dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.ControlText;
			dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
			this.dgvTests.DefaultCellStyle = dataGridViewCellStyle2;
			this.dgvTests.Location = new System.Drawing.Point(63, 551);
			this.dgvTests.Name = "dgvTests";
			this.dgvTests.ReadOnly = true;
			this.dgvTests.RowHeadersWidth = 35;
			this.dgvTests.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
			this.dgvTests.Size = new System.Drawing.Size(809, 213);
			this.dgvTests.TabIndex = 99;
			this.dgvTests.TabStop = false;
			this.dgvTests.CellFormatting += new System.Windows.Forms.DataGridViewCellFormattingEventHandler(this.dgvVisionTests_CellFormatting);
			// 
			// cmsTests
			// 
			this.cmsTests.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsmiEdit,
            this.tsmiTake});
			this.cmsTests.Name = "cmsPeople";
			this.cmsTests.Size = new System.Drawing.Size(139, 84);
			this.cmsTests.Opened += new System.EventHandler(this.cmsTests_Opened);
			// 
			// tsmiEdit
			// 
			this.tsmiEdit.Font = new System.Drawing.Font("Aldhabi", 17F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.tsmiEdit.Image = global::_02_DVLD_Mine.Properties.Resources.highlighter_pen;
			this.tsmiEdit.Name = "tsmiEdit";
			this.tsmiEdit.Size = new System.Drawing.Size(138, 40);
			this.tsmiEdit.Text = "Edit Test";
			this.tsmiEdit.TextDirection = System.Windows.Forms.ToolStripTextDirection.Horizontal;
			this.tsmiEdit.Click += new System.EventHandler(this.tsmiEdit_Click);
			// 
			// tsmiTake
			// 
			this.tsmiTake.Font = new System.Drawing.Font("Aldhabi", 17F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.tsmiTake.Image = global::_02_DVLD_Mine.Properties.Resources.redo;
			this.tsmiTake.Name = "tsmiTake";
			this.tsmiTake.Size = new System.Drawing.Size(138, 40);
			this.tsmiTake.Text = "Take Test";
			this.tsmiTake.TextDirection = System.Windows.Forms.ToolStripTextDirection.Horizontal;
			this.tsmiTake.Click += new System.EventHandler(this.tsmiTake_Click);
			// 
			// lblTotalTestsAppointments
			// 
			this.lblTotalTestsAppointments.AutoSize = true;
			this.lblTotalTestsAppointments.Font = new System.Drawing.Font("Mongolian Baiti", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblTotalTestsAppointments.Location = new System.Drawing.Point(58, 782);
			this.lblTotalTestsAppointments.Name = "lblTotalTestsAppointments";
			this.lblTotalTestsAppointments.Size = new System.Drawing.Size(281, 25);
			this.lblTotalTestsAppointments.TabIndex = 81;
			this.lblTotalTestsAppointments.Text = "Total Appointments [ 0 ].";
			// 
			// ucADL_BasicInfo1
			// 
			this.ucADL_BasicInfo1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
			this.ucADL_BasicInfo1.Location = new System.Drawing.Point(63, 96);
			this.ucADL_BasicInfo1.Name = "ucADL_BasicInfo1";
			this.ucADL_BasicInfo1.Size = new System.Drawing.Size(809, 443);
			this.ucADL_BasicInfo1.TabIndex = 0;
			// 
			// frmTestApplication
			// 
			this.AcceptButton = this.btnAddNewVisionTest;
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = System.Drawing.Color.RosyBrown;
			this.CancelButton = this.btnClose;
			this.ClientSize = new System.Drawing.Size(936, 832);
			this.Controls.Add(this.lblTotalTestsAppointments);
			this.Controls.Add(this.btnAddNewVisionTest);
			this.Controls.Add(this.btnClose);
			this.Controls.Add(this.dgvTests);
			this.Controls.Add(this.lblTitleTestAppointment);
			this.Controls.Add(this.ucADL_BasicInfo1);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
			this.Name = "frmTestApplication";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Test Appointments";
			((System.ComponentModel.ISupportInitialize)(this.dgvTests)).EndInit();
			this.cmsTests.ResumeLayout(false);
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private userControls._03_ucDLA.ucADL_BasicInfo ucADL_BasicInfo1;
		private System.Windows.Forms.Label lblTitleTestAppointment;
		private System.Windows.Forms.Button btnAddNewVisionTest;
		private System.Windows.Forms.Button btnClose;
		private System.Windows.Forms.DataGridView dgvTests;
		private System.Windows.Forms.Label lblTotalTestsAppointments;
		private System.Windows.Forms.ContextMenuStrip cmsTests;
		private System.Windows.Forms.ToolStripMenuItem tsmiEdit;
		private System.Windows.Forms.ToolStripMenuItem tsmiTake;
	}
}