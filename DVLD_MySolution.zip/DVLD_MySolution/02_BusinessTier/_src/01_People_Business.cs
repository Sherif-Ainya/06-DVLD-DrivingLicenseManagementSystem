﻿using System;
using System.Data;
using DVLD_DataAccess;

namespace DVLD_Business
{
	public class clsBusinessPeople
	{
		private enum enPersonMode { enAddNew, enUpdate };
		private enPersonMode _Mode;

		public int personID { get; set; }
		public string nationalNo { get; set; }
		public string firstName { get; set; }
		public string secondName { get; set; }
		public string thirdName { get; set; }
		public string lastName { get; set; }
		public string FullName
		{
			get { return firstName + ' ' + lastName; }
		}
		public DateTime dateOfBirth { get; set; }
		public short gender { get; set; }
		public string address { get; set; }
		public string phone { get; set; }
		public string email { get; set; }
		public int nationalityCountryID { get; set; }
		public string imagePath { get; set; }
		private bool _AddNewPerson()
		{
			this.personID = clsDataAccessPeople.AddNewPerson(this.nationalNo, this.firstName, this.secondName, this.thirdName, this.lastName,
				this.dateOfBirth, this.gender, this.address, this.phone, this.email, this.nationalityCountryID, this.imagePath);

			return (personID != -1);
		}
		private bool _UpdatePerson()
		{
			return clsDataAccessPeople.UpdatePerson(this.personID, this.nationalNo, this.firstName, this.secondName, this.thirdName, this.lastName,
				this.dateOfBirth, this.gender, this.address, this.phone, this.email, this.nationalityCountryID, this.imagePath);
		}


		public clsBusinessPeople()
		{
			personID = -1;
			nationalNo = string.Empty;
			firstName = string.Empty;
			secondName = string.Empty;
			thirdName = string.Empty;
			lastName = string.Empty;
			dateOfBirth = DateTime.MinValue;
			gender = -1;
			address = string.Empty;
			phone = string.Empty;
			email = string.Empty;
			nationalityCountryID = -1;
			imagePath = string.Empty;
		}
		public clsBusinessPeople(int personID, string nationalNo, string firstName, string secondName, string thirdName, string lastName,
			DateTime dateOfBirth, short gender, string address, string phone, string email, int countryID, string imagePath)
		{
			this.personID = personID;
			this.nationalNo = nationalNo;
			this.firstName = firstName;
			this.secondName = secondName;
			this.thirdName = thirdName;
			this.lastName = lastName;
			this.dateOfBirth = dateOfBirth;
			this.gender = gender;
			this.address = address;
			this.phone = phone;
			this.email = email;
			this.nationalityCountryID = countryID;
			this.imagePath = imagePath;

			_Mode = enPersonMode.enUpdate;
		}


		public static clsBusinessPeople Find(int personID)
		{
			string nationalNo = "", firstName = "", secondName = "", thirdName = "", lastName = "",
				address = "", phone = "", email = "", imagePath = "";
			DateTime dateOfBirth = DateTime.MinValue;
			int countryID = -1;
			short gender = -1;

			if (clsDataAccessPeople.GetPerson(personID, ref nationalNo, ref firstName, ref secondName, ref thirdName, ref lastName,
				 ref dateOfBirth, ref gender, ref address, ref phone, ref email, ref countryID, ref imagePath))
			{
				return new clsBusinessPeople(personID, nationalNo, firstName, secondName, thirdName, lastName, dateOfBirth, gender, address, phone, email, countryID, imagePath);
			}
			return null;
		}
		public static clsBusinessPeople Find(string nationalNo)
		{
			int personID = -1, countryID = -1;
			short gender = -1;
			string firstName = "", secondName = "", thirdName = "", lastName = "",
				address = "", phone = "", email = "", imagePath = "";
			DateTime dateOfBirth = DateTime.MinValue;

			if (clsDataAccessPeople.GetPerson(ref personID, nationalNo, ref firstName, ref secondName, ref thirdName, ref lastName,
				 ref dateOfBirth, ref gender, ref address, ref phone, ref email, ref countryID, ref imagePath))
			{
				return new clsBusinessPeople(personID, nationalNo, firstName, secondName, thirdName, lastName, dateOfBirth, gender, address, phone, email, countryID, imagePath);
			}
			return null;
		}
		public bool Save()
		{
			switch (_Mode)
			{
				case enPersonMode.enAddNew:
				{
					if (_AddNewPerson())
					{
						_Mode = enPersonMode.enUpdate;
						return true;
					}
					else
					{
						return false;
					}
				}
				case enPersonMode.enUpdate:
				{
					return _UpdatePerson();
				}
			}
			return false;
		}
		public static bool DeletePerson(int PersonID)
		{
			return clsDataAccessPeople.DeletePerson(PersonID);
		}
		public static bool IsPersonExist(int PersonID)
		{
			return clsDataAccessPeople.IsPersonExist(PersonID);
		}
		public static bool IsPersonExist(string nationalNo)
		{
			return clsDataAccessPeople.IsPersonExist(nationalNo);
		}
		public static bool IsThisPersonUser(int PersonID)
		{
			return clsDataAccessPeople.IsThisPersonUser(PersonID);
		}
		public static DataTable GetAllPeople()
		{
			return clsDataAccessPeople.GetAllPeople();
		}
	}
}
