﻿using System;
using System.Data;
using DVLD_DataAccess;

namespace DVLD_Business
{
	public class clsBusinessDetainedLicenses
	{
		private enum enMode { enAddNew, enUpdate };
		private enMode _Mode;
		public int DetainID { get; set; }
		public int LicenseID { get; set; }
		public DateTime DetainDate { get; set; }
		public decimal FineFees { get; set; }
		public int CreatedByUserID { get; set; }
		public bool IsReleased { get; set; }
		public DateTime ReleaseDate { get; set; }
		public int ReleasedByUserID { get; set; }
		public int ReleaseApplicaitonID { get; set; }

		private bool _AddNewDetainLicenseRecord()
		{
			this.DetainID = clsDataAccessDetainedLicenses.AddNewDetainedLicense(this.LicenseID, this.DetainDate, this.FineFees, this.CreatedByUserID);

			return (this.DetainID != -1);
		}
		private bool _UpdateDetainLicenseRecord()
		{
			return clsDataAccessDetainedLicenses.UpdateLicense(this.DetainID, this.IsReleased, this.ReleaseDate, this.ReleasedByUserID, this.ReleaseApplicaitonID);
		}


		public clsBusinessDetainedLicenses()
		{
			DetainID = -1;
			LicenseID = -1;
			DetainDate = DateTime.Now;
			FineFees = 0;
			CreatedByUserID = -1;
			IsReleased = false;
			ReleaseDate = DateTime.MinValue;
			ReleasedByUserID = -1;
			ReleaseApplicaitonID = -1;

			_Mode = enMode.enAddNew;
		}
		private clsBusinessDetainedLicenses(int DetainID, int LicenseID, DateTime DetainDate, decimal FineFees, int CreatedByUserID,
			bool IsReleased, DateTime ReleaseDate, int ReleasedByUserID, int ReleaseApplicaitonID)
		{
			this.DetainID = DetainID;
			this.LicenseID = LicenseID;
			this.DetainDate = DetainDate;
			this.FineFees = FineFees;
			this.CreatedByUserID = CreatedByUserID;
			this.IsReleased = IsReleased;
			this.ReleaseDate = ReleaseDate;
			this.ReleasedByUserID = ReleasedByUserID;
			this.ReleaseApplicaitonID = ReleaseApplicaitonID;

			_Mode = enMode.enUpdate;
		}


		public static bool IsThisLicenseDetained(int licenseID)
		{
			return clsDataAccessDetainedLicenses.IsThisLicenseDetained(licenseID);
		}


		public static clsBusinessDetainedLicenses FindBy(int licenseID)
		{
			int detainID = -1, createdByUserID = -1, releasedByUserID = -1, releaseApplicaitonID = -1;
			DateTime detainDate = DateTime.MinValue, releaseDate = DateTime.MinValue;
			decimal fineFees = 0;
			bool isReleased = false;

			if (clsDataAccessDetainedLicenses.GetDetainedLicenseByLicenseID(ref detainID, licenseID,
				ref detainDate, ref fineFees, ref createdByUserID, ref isReleased, ref releaseDate, ref releasedByUserID, ref releaseApplicaitonID))
			{
				return new clsBusinessDetainedLicenses(detainID, licenseID,
				detainDate, fineFees, createdByUserID, isReleased, releaseDate, releasedByUserID, releaseApplicaitonID);
			}
			return null;
		}
		public static clsBusinessDetainedLicenses FindBy_(int detainID)
		{
			int licenseID = -1, createdByUserID = -1, releasedByUserID = -1, releaseApplicaitonID = -1;
			DateTime detainDate = DateTime.MinValue, releaseDate = DateTime.MinValue;
			decimal fineFees = 0;
			bool isReleased = false;

			if (clsDataAccessDetainedLicenses.GetDetainedLicenseByDetainID(detainID, ref licenseID,
				ref detainDate, ref fineFees, ref createdByUserID, ref isReleased, ref releaseDate, ref releasedByUserID, ref releaseApplicaitonID))
			{
				return new clsBusinessDetainedLicenses(detainID, licenseID,
				detainDate, fineFees, createdByUserID, isReleased, releaseDate, releasedByUserID, releaseApplicaitonID);
			}
			return null;
		}
		public bool Save()
		{
			switch (_Mode)
			{
				case enMode.enAddNew:
				{
					if (_AddNewDetainLicenseRecord())
					{
						_Mode = enMode.enUpdate;
						return true;
					}
					else
					{
						return false;
					}
				}
				case enMode.enUpdate:
				{
					return _UpdateDetainLicenseRecord();
				}
			}
			return false;
		}
		public static DataTable GetAllDetainedLicenses()
		{
			return clsDataAccessDetainedLicenses.GetAllDetainedLicenses();
		}
	}
}
