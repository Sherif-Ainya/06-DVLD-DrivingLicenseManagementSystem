﻿using DVLD_DataAccess;

namespace DVLD_Business
{
	public class clsBusinessTests
	{
		private enum enMode { enAddNew, enUpdate };
		private enMode _Mode;
		public int TestID { get; set; }
		public int TestAppointmentID { get; set; }
		public bool TestResult { get; set; }
		public string Notes { get; set; }
		public int CreatedByUserID { get; set; }
		private bool _AddNewTest()
		{
			this.TestID = clsDataAccessTests.AddNewTest(this.TestAppointmentID, this.TestResult, this.Notes, this.CreatedByUserID);

			return (this.TestID != -1);
		}
		private bool _UpdateTest()
		{
			return clsDataAccessTests.UpdateTest(this.TestID, this.TestAppointmentID, this.TestResult, this.Notes, this.CreatedByUserID);
		}


		public clsBusinessTests()
		{
			TestID = -1;
			TestAppointmentID = -1;
			TestResult = false;
			Notes = string.Empty;
			CreatedByUserID = -1;

			_Mode = enMode.enAddNew;
		}
		private clsBusinessTests(int TestID, int TestAppointmentID, bool TestResult, string Notes, int CreatedByUserID)
		{
			this.TestID = TestID;
			this.TestAppointmentID = TestAppointmentID;
			this.TestResult = TestResult;
			this.Notes = Notes;
			this.CreatedByUserID = CreatedByUserID;

			_Mode = enMode.enUpdate;
		}


		public static clsBusinessTests GetTest(int TestID)
		{
			int TestAppointmentID = -1, CreatedByUserID = -1;
			string Notes = string.Empty;
			bool TestResult = false;

			if (clsDataAccessTests.GetTest(TestID, ref TestAppointmentID, ref TestResult, ref Notes, ref CreatedByUserID))
			{
				return new clsBusinessTests(TestID, TestAppointmentID, TestResult, Notes, CreatedByUserID);
			}
			return null;
		}
		public bool Save()
		{
			switch (_Mode)
			{
				case enMode.enAddNew:
				{
					if (_AddNewTest())
					{
						_Mode = enMode.enUpdate;
						return true;
					}
					else
					{
						return false;
					}
				}
				case enMode.enUpdate:
				{
					return _UpdateTest();
				}
			}
			return false;
		}
	}
}
