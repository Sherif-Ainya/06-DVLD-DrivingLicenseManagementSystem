﻿using System;
using DVLD_DataAccess;

namespace DVLD_Business
{
	public class clsBusinessApplications
	{
		private enum enMode { enAddNew, enUpdate };
		private enMode _Mode;
		public int ApplicationID { get; set; }
		public int ApplicationPersonID { get; set; }
		public DateTime ApplicationDateTime { get; set; }
		public int ApplicationTypeID { get; set; }
		public byte ApplicationStatus { get; set; }
		public DateTime LastStatusDate { get; set; }
		public decimal PaidFees { get; set; }
		public int CreatedByUserID { get; set; }
		private bool _AddNewApplication()
		{
			this.ApplicationID = clsDataAccessApplications.AddNewApplication(this.ApplicationPersonID, this.ApplicationDateTime, this.ApplicationTypeID,
				this.ApplicationStatus, this.LastStatusDate, this.PaidFees, this.CreatedByUserID);

			return (this.ApplicationID != -1);
		}
		private bool _UpdateApplication()
		{
			return clsDataAccessApplications.UpdateApplication(this.ApplicationID, this.ApplicationPersonID, this.ApplicationDateTime, this.ApplicationTypeID,
				this.ApplicationStatus, this.LastStatusDate, this.PaidFees, this.CreatedByUserID);
		}


		public clsBusinessApplications()
		{
			ApplicationID = -1;
			ApplicationPersonID = -1;
			ApplicationDateTime = DateTime.Now;
			ApplicationTypeID = -1;
			ApplicationStatus = 0;
			LastStatusDate = DateTime.Now;
			PaidFees = 0;
			CreatedByUserID = -1;

			_Mode = enMode.enAddNew;
		}
		private clsBusinessApplications(int ApplicationID, int ApplicationPersonID, DateTime ApplicationDateTime, int ApplicationTypeID,
			byte ApplicationStatus, DateTime LastStatusDate, decimal PaidFees, int CreatedByUserID)
		{
			this.ApplicationID = ApplicationID;
			this.ApplicationPersonID = ApplicationPersonID;
			this.ApplicationDateTime = ApplicationDateTime;
			this.ApplicationTypeID = ApplicationTypeID;
			this.ApplicationStatus = ApplicationStatus;
			this.LastStatusDate = LastStatusDate;
			this.PaidFees = PaidFees;
			this.CreatedByUserID = CreatedByUserID;

			_Mode = enMode.enUpdate;
		}


		public static clsBusinessApplications Find(int ApplicationID)
		{
			int ApplicationPersonID = -1, ApplicationTypeID = -1, CreatedByUserID = -1;
			DateTime ApplicationDateTime = DateTime.Now, LastStatusDate = DateTime.Now;
			byte ApplicationStatus = 0;
			decimal PaidFees = 0;

			if (clsDataAccessApplications.GetApplication(ApplicationID, ref ApplicationPersonID, ref ApplicationDateTime, ref ApplicationTypeID,
				ref ApplicationStatus, ref LastStatusDate, ref PaidFees, ref CreatedByUserID))
			{
				return new clsBusinessApplications(ApplicationID, ApplicationPersonID, ApplicationDateTime, ApplicationTypeID,
					ApplicationStatus, LastStatusDate, PaidFees, CreatedByUserID);
			}
			return null;
		}
		public bool Save()
		{
			switch (_Mode)
			{
				case enMode.enAddNew:
				{
					if (_AddNewApplication())
					{
						_Mode = enMode.enUpdate;
						return true;
					}
					else
					{
						return false;
					}
				}
				case enMode.enUpdate:
				{
					return _UpdateApplication();
				}
			}
			return false;
		}
	}
}
