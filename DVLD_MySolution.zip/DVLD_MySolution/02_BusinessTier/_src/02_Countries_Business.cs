﻿using System.Data;

namespace _03_DataAccessTier.src
{
	public class clsBusinessCountries
	{
		public int countryID { get; set; }
		public string countryName { get; set; }


		private clsBusinessCountries(int countryID, string countryName)
		{
			this.countryID = countryID;
			this.countryName = countryName;
		}


		public static clsBusinessCountries Find(int countryID)
		{
			string countryName = "";

			if (clsDataAccessCountries.GetCountryInfoByID(countryID, ref countryName))
			{
				return new clsBusinessCountries(countryID, countryName);
			}
			else
			{
				return null;
			}
		}
		public static clsBusinessCountries Find(string countryName)
		{
			int countryID = -1;

			if (clsDataAccessCountries.GetCountryInfoByName(ref countryID, countryName))
			{
				return new clsBusinessCountries(countryID, countryName);
			}
			else
			{
				return null;
			}
		}
		public static DataTable GetAllCountries()
		{
			return clsDataAccessCountries.GetAllCountries();
		}
	}
}
