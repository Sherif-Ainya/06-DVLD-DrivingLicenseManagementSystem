﻿using System.Data;
using DVLD_DataAccess;

namespace DVLD_Business
{
	public class clsBusinessUsers
	{
		/*
		public enum enPermissions
		{
			pAll = -1, pManageClients = 1, pClientsTransactions = 2, pManageUsers = 4, pCurrencyExchange = 8
		};
		public bool HasAccess(enPermissions per)
		{
			if (this.Permissions == (int)enPermissions.pAll)
				return true;

			if (((int)per & this.Permissions) == (int)per) // 1 & 49 == 1 ,true, cuz 49 = 1 + 16 + 32.
			{
				return true;
			}
			else
				return false;
		}
		public int permissions { get; set; }
		*/

		private enum enUserMode { enAddNew, enUpdate };
		private enUserMode _Mode;
		public int userID { get; set; }
		public int personID { get; set; }
		public string userName { get; set; }
		public string password { get; set; }
		public bool active { get; set; }
		private bool _AddNewUser()
		{
			this.userID = clsDataAccessUsers.AddNewUser(this.personID, this.userName, this.password, this.active);

			return (userID != -1);
		}
		private bool _UpdateUser()
		{
			return clsDataAccessUsers.UpdateUser(this.userID, this.userName, this.password, this.active);
		}


		public clsBusinessUsers()
		{
			userID = -1;
			userName = string.Empty;
			password = string.Empty;
			active = false;

			_Mode = enUserMode.enAddNew;
		}
		private clsBusinessUsers(int userID, int personID, string userName, string password, bool active)
		{
			this.userID = userID;
			this.personID = personID;
			this.userName = userName;
			this.password = password;
			this.active = active;

			_Mode = enUserMode.enUpdate;
		}


		public static clsBusinessUsers Find(int userID)
		{
			int personID = -1;
			string userName = "", password = "";
			bool active = false;

			if (clsDataAccessUsers.GetUser(userID, ref personID, ref userName, ref password, ref active))
			{
				return new clsBusinessUsers(userID, personID, userName, password, active);
			}
			return null;
		}
		public static clsBusinessUsers Find(string userName, string password)
		{
			int userID = -1, personID = -1;
			bool active = false;

			if (clsDataAccessUsers.GetUser(ref userID, ref personID, userName, password, ref active))
			{
				return new clsBusinessUsers(userID, personID, userName, password, active);
			}
			return null;
		}
		public bool Save()
		{
			switch (_Mode)
			{
				case enUserMode.enAddNew:
				{
					if (_AddNewUser())
					{
						_Mode = enUserMode.enUpdate;
						return true;
					}
					else
					{
						return false;
					}
				}
				case enUserMode.enUpdate:
				{
					return _UpdateUser();
				}
			}
			return false;
		}
		public static bool DeleteUser(int User_ID)
		{
			return clsDataAccessUsers.DeleteUser(User_ID);
		}
		public static DataTable GetAllUsers()
		{
			return clsDataAccessUsers.GetAllUsers();
		}
	}
}
