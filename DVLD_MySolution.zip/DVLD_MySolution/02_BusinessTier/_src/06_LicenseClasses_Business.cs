﻿using System.Data;
using DVLD_DataAccess;

namespace DVLD_Business
{
	public class clsBusinessLicenseClasses
	{
		private enum enUserMode { enAddNew, enUpdate };
		private enUserMode _Mode;
		public int LicenseClassID { get; set; }
		public string ClassName { get; set; }
		public string ClassDescription { get; set; }
		public byte MinimumAllowedAge { get; set; }
		public byte DefaultValidittyLength { get; set; }
		public decimal ClassFees { get; set; }

		private bool _AddNewLicenseClass()
		{
			return false;
		}
		private bool _UpdateLicenseClass()
		{
			return clsDataAccessLicenseClasses.UpdateLicenseClass(this.LicenseClassID, this.ClassName, this.ClassDescription, this.MinimumAllowedAge, this.DefaultValidittyLength, this.ClassFees);
		}


		public clsBusinessLicenseClasses()
		{
			LicenseClassID = -1;
			ClassName = string.Empty;
			ClassDescription = string.Empty;
			MinimumAllowedAge = 0;
			DefaultValidittyLength = 0;
			ClassFees = -1;

			_Mode = enUserMode.enAddNew;
		}
		private clsBusinessLicenseClasses(int LicenseClassID, string ClassName, string ClassDescription, byte MinimumAllowedAge, byte DefaultValidittyLength, decimal ClassFees)
		{
			this.LicenseClassID = LicenseClassID;
			this.ClassName = ClassName;
			this.ClassDescription = ClassDescription;
			this.MinimumAllowedAge = MinimumAllowedAge;
			this.DefaultValidittyLength = DefaultValidittyLength;
			this.ClassFees = ClassFees;

			_Mode = enUserMode.enUpdate;
		}


		public static clsBusinessLicenseClasses Find(int LicenseClassID)
		{
			string ClassName = "";
			string ClassDescription = "";
			byte MinimumAllowedAge = 0;
			byte DefaultValidittyLength = 0;
			decimal ClassFees = -1;

			if (clsDataAccessLicenseClasses.GetLicenseClass(LicenseClassID, ref ClassName, ref ClassDescription, ref MinimumAllowedAge, ref DefaultValidittyLength, ref ClassFees))
			{
				return new clsBusinessLicenseClasses(LicenseClassID, ClassName, ClassDescription, MinimumAllowedAge, DefaultValidittyLength, ClassFees);
			}
			return null;
		}
		public bool Save()
		{
			switch (_Mode)
			{
				case enUserMode.enAddNew:
				{
					if (_AddNewLicenseClass())
					{
						_Mode = enUserMode.enUpdate;
						return true;
					}
					else
					{
						return false;
					}
				}
				case enUserMode.enUpdate:
				{
					return _UpdateLicenseClass();
				}
			}
			return false;
		}
		public static DataTable GetAllLicenseClasses()
		{
			return clsDataAccessLicenseClasses.GetAllLicenseClasses();
		}
	}
}
