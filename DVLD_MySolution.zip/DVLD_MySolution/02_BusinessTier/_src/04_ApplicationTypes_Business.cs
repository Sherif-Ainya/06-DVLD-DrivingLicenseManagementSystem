﻿using System.Data;
using DVLD_DataAccess;

namespace DVLD_Business
{
	public class clsBusinessApplicationTypes
	{
		private enum enUserMode { enAddNew, enUpdate };
		private enUserMode _Mode;
		public int applicationTypeID { get; set; }
		public string applicationTypeTitle { get; set; }
		public decimal applicationTypeFees { get; set; }

		private bool _AddNewApplicationType()
		{
			return false;
		}
		private bool _UpdateApplicationType()
		{
			return clsDataAccessApplicationTypes.UpdateApplicationType(this.applicationTypeID, this.applicationTypeTitle, this.applicationTypeFees);
		}


		public clsBusinessApplicationTypes()
		{
			applicationTypeID = -1;
			applicationTypeTitle = string.Empty;
			applicationTypeFees = -1;

			_Mode = enUserMode.enAddNew;
		}
		private clsBusinessApplicationTypes(int applicationTypeID, string applicationTypeTitle, decimal applicationTypeFees)
		{
			this.applicationTypeID = applicationTypeID;
			this.applicationTypeTitle = applicationTypeTitle;
			this.applicationTypeFees = applicationTypeFees;

			_Mode = enUserMode.enUpdate;
		}


		public static clsBusinessApplicationTypes Find(int applicationTypeID)
		{
			string applicationTypeTitle = "";
			decimal applicationTypeFees = -1;

			if (clsDataAccessApplicationTypes.GetApplicationType(applicationTypeID, ref applicationTypeTitle, ref applicationTypeFees))
			{
				return new clsBusinessApplicationTypes(applicationTypeID, applicationTypeTitle, applicationTypeFees);
			}
			return null;
		}
		public bool Save()
		{
			switch (_Mode)
			{
				case enUserMode.enAddNew:
				{
					if (_AddNewApplicationType())
					{
						_Mode = enUserMode.enUpdate;
						return true;
					}
					else
					{
						return false;
					}
				}
				case enUserMode.enUpdate:
				{
					return _UpdateApplicationType();
				}
			}
			return false;
		}
		public static DataTable GetAllApplicationTypes()
		{
			return clsDataAccessApplicationTypes.GetAllApplicationTypes();
		}
	}
}
