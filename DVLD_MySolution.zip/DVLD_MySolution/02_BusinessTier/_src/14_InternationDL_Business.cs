﻿using System;
using System.Data;
using DVLD_DataAccess;

namespace DVLD_Business
{
	public class clsBusinessInternationDL
	{
		private enum enMode { enAddNew, enUpdate };
		private enMode _Mode;
		public int InternationalLicenseID { get; set; }
		public int ApplicationID { get; set; }
		public int DriverID { get; set; }
		public int IssuedUsingLocalLicenseID { get; set; }
		public DateTime IssueDate { get; set; }
		public DateTime ExpirationDate { get; set; }
		public bool IsActive { get; set; }
		public int CreatedByUserID { get; set; }

		private bool _AddNewIntLicense()
		{
			this.InternationalLicenseID = clsDataAccessInternationDL.AddNewIntL(this.ApplicationID, this.DriverID, this.IssuedUsingLocalLicenseID,
				this.IssueDate, this.ExpirationDate, this.IsActive, this.CreatedByUserID);

			return (this.InternationalLicenseID != -1);
		}
		private bool _UpdateIntLicense()
		{
			return clsDataAccessInternationDL.UpdateIntL(this.InternationalLicenseID, this.IsActive);
		}


		public clsBusinessInternationDL()
		{
			InternationalLicenseID = -1;
			ApplicationID = -1;
			DriverID = -1;
			IssuedUsingLocalLicenseID = -1;
			IssueDate = DateTime.MinValue;
			ExpirationDate = DateTime.MinValue;
			IsActive = false;
			CreatedByUserID = -1;

			_Mode = enMode.enAddNew;
		}
		private clsBusinessInternationDL(int InternationalLicenseID, int ApplicationID, int DriverID, int IssuedUsingLocalLicenseID,
			DateTime IssueDate, DateTime ExpirationDate, bool IsActive, int CreatedByUserID)
		{
			this.InternationalLicenseID = InternationalLicenseID;
			this.ApplicationID = ApplicationID;
			this.DriverID = DriverID;
			this.IssuedUsingLocalLicenseID = IssuedUsingLocalLicenseID;
			this.IssueDate = IssueDate;
			this.ExpirationDate = ExpirationDate;
			this.IsActive = IsActive;
			this.CreatedByUserID = CreatedByUserID;

			_Mode = enMode.enUpdate;
		}


		public static int IsThisLocalDLHasInternationalDL(int LocalDL_ID)
		{
			return clsDataAccessInternationDL.IsThisLocalDLHasInternationalDL(LocalDL_ID);
		}
		public static clsBusinessInternationDL Find(int IntL_ID)
		{
			int ApplicationID = -1, DriverID = -1, IssuedUsing = -1, CreatedByUserID = -1;
			DateTime IssueDate = DateTime.MinValue, ExpirationDate = DateTime.MinValue;
			bool IsActive = false;

			if (clsDataAccessInternationDL.GetIntL_ID(IntL_ID, ref ApplicationID, ref DriverID, ref IssuedUsing,
				ref IssueDate, ref ExpirationDate, ref IsActive, ref CreatedByUserID))
			{
				return new clsBusinessInternationDL(IntL_ID, ApplicationID, DriverID, IssuedUsing, IssueDate, ExpirationDate, IsActive, CreatedByUserID);
			}
			return null;
		}
		public bool Save()
		{
			switch (_Mode)
			{
				case enMode.enAddNew:
				{
					if (_AddNewIntLicense())
					{
						_Mode = enMode.enUpdate;
						return true;
					}
					else
					{
						return false;
					}
				}
				case enMode.enUpdate:
				{
					return _UpdateIntLicense();
				}
			}
			return false;
		}
		public static DataTable GetAll_InDL()
		{
			return clsDataAccessInternationDL.GetAll_InDL();
		}
		public static DataTable GetAll_IntLicensesForPerson(int personID)
		{
			return clsDataAccessInternationDL.GetAll_IntLicensesForPerson(personID);
		}
		public static DataTable GetAll_IntLicensesForPerson(string nationalNo)
		{
			return clsDataAccessInternationDL.GetAll_IntLicensesForPerson(nationalNo);
		}
	}
}
