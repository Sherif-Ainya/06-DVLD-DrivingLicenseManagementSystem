﻿using System.Data;
using DVLD_DataAccess;

namespace DVLD_Business
{
	public class clsBusinessTestTypes
	{
		private enum enUserMode { enAddNew, enUpdate };
		private enUserMode _Mode;
		public int TestTypeID { get; set; }
		public string TestTypeTitle { get; set; }
		public string TestTypeDescription { get; set; }
		public decimal TestTypeFees { get; set; }

		private bool _AddNewTestType()
		{
			return false;
		}
		private bool _UpdateTestType()
		{
			return clsDataAccessTestTypes.UpdateTestType(this.TestTypeID, this.TestTypeTitle, this.TestTypeDescription, this.TestTypeFees);
		}


		public clsBusinessTestTypes()
		{
			TestTypeID = -1;
			TestTypeTitle = string.Empty;
			TestTypeDescription = string.Empty;
			TestTypeFees = -1;

			_Mode = enUserMode.enAddNew;
		}
		private clsBusinessTestTypes(int TestTypeID, string TestTypeTitle, string TestTypeDescription, decimal TestTypeFees)
		{
			this.TestTypeID = TestTypeID;
			this.TestTypeTitle = TestTypeTitle;
			this.TestTypeDescription = TestTypeDescription;
			this.TestTypeFees = TestTypeFees;

			_Mode = enUserMode.enUpdate;
		}


		public static clsBusinessTestTypes Find(int TestTypeID)
		{
			string TestTypeTitle = "";
			string TestTypeDescription = "";
			decimal TestTypeFees = -1;

			if (clsDataAccessTestTypes.GetTestType(TestTypeID, ref TestTypeTitle, ref TestTypeDescription, ref TestTypeFees))
			{
				return new clsBusinessTestTypes(TestTypeID, TestTypeTitle, TestTypeDescription, TestTypeFees);
			}
			return null;
		}
		public bool Save()
		{
			switch (_Mode)
			{
				case enUserMode.enAddNew:
				{
					if (_AddNewTestType())
					{
						_Mode = enUserMode.enUpdate;
						return true;
					}
					else
					{
						return false;
					}
				}
				case enUserMode.enUpdate:
				{
					return _UpdateTestType();
				}
			}
			return false;
		}
		public static DataTable GetAllTestTypes()
		{
			return clsDataAccessTestTypes.GetAllTestTypes();
		}
	}
}
