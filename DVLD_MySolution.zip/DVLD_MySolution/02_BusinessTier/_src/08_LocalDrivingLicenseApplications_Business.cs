﻿using DVLD_DataAccess;

namespace DVLD_Business
{
	public class clsBusiness_LDLA
	{
		private enum enMode { enAddNew, enUpdate };
		private enMode _Mode;
		public enum enLA_Status { eNew = 1, eCancelled = 2, eCompleted = 3 };

		public int LocalDrivingLicenseApplicationID { get; set; }
		public int ApplicationID { get; set; }
		public int LicenseClassID { get; set; }
		public struct stStatus_ApplicationID
		{
			public bool Found { get; set; }
			public byte status { get; set; }
			public int applicationID { get; set; }
		}

		private bool _AddNewLocalApplication()
		{
			this.LocalDrivingLicenseApplicationID =
				clsDataAccess_LDLA.AddNew_LDLA(this.ApplicationID, this.LicenseClassID);

			return (this.LocalDrivingLicenseApplicationID != -1);
		}
		private bool _UpdateLocalApplication()
		{
			return clsDataAccess_LDLA.Update_LDLA(this.LocalDrivingLicenseApplicationID, this.ApplicationID, this.LicenseClassID);
		}


		public clsBusiness_LDLA()
		{
			LocalDrivingLicenseApplicationID = -1;
			ApplicationID = -1;
			LicenseClassID = -1;

			_Mode = enMode.enAddNew;
		}
		private clsBusiness_LDLA(int LocalDrivingLicenseApplicationID, int ApplicationID, int LicenseClassID)
		{
			this.LocalDrivingLicenseApplicationID = LocalDrivingLicenseApplicationID;
			this.ApplicationID = ApplicationID;
			this.LicenseClassID = LicenseClassID;

			_Mode = enMode.enUpdate;
		}



		public static stStatus_ApplicationID LastPerson_LDLA_Status(int personID, int LicenseClassID)
		{
			stStatus_ApplicationID status_ApplicationID = new stStatus_ApplicationID();
			clsDataAccess_LDLA.stStatus_ApplicationID status_ApplicationID_Data = clsDataAccess_LDLA.LastPerson_LDLA_Status_ApplicationID(personID, LicenseClassID);

			status_ApplicationID.Found = status_ApplicationID_Data.Found;
			status_ApplicationID.applicationID = status_ApplicationID_Data.applicationID;
			status_ApplicationID.status = status_ApplicationID_Data.status;

			return status_ApplicationID;
		}

		public static bool ChangeAppStatusByLDLA_ID(int LDLA_ID, enLA_Status newStatus)
		{
			return clsDataAccess_LDLA.ChangeAppStatusByLDLA_ID(LDLA_ID, (int)newStatus);
		}
		public static bool DeleteLocalDLApplication(int LDLA_ID)
		{
			return clsDataAccess_LDLA.Delete_LDLA(LDLA_ID);
		}

		public static clsBusiness_LDLA Find(int LocalDrivingLicenseApplicationID)
		{
			int ApplicationID = -1, LicenseClassID = -1;

			if (clsDataAccess_LDLA.Get_LDLA(LocalDrivingLicenseApplicationID, ref ApplicationID, ref LicenseClassID))
			{
				return new clsBusiness_LDLA(LocalDrivingLicenseApplicationID, ApplicationID, LicenseClassID);
			}
			return null;
		}
		public bool Save()
		{
			switch (_Mode)
			{
				case enMode.enAddNew:
				{
					if (_AddNewLocalApplication())
					{
						_Mode = enMode.enUpdate;
						return true;
					}
					else
					{
						return false;
					}
				}
				case enMode.enUpdate:
				{
					return _UpdateLocalApplication();
				}
			}
			return false;
		}
	}
}
