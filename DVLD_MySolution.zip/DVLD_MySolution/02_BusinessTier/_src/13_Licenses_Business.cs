﻿using System;
using System.Data;
using DVLD_DataAccess;

namespace DVLD_Business
{
	public class clsBusinessLicenses
	{
		private enum enMode { enAddNew, enUpdate };
		private enMode _Mode;
		public int LicenseID { get; set; }
		public int ApplicationID { get; set; }
		public int DriverID { get; set; }
		public int LicenseClass { get; set; }
		public DateTime IssueDate { get; set; }
		public DateTime ExpirationDate { get; set; }
		public string Notes { get; set; }
		public decimal PaidFees { get; set; }
		public bool IsActive { get; set; }
		public byte IssueReason { get; set; }
		public int CreatedByUserID { get; set; }

		private bool _AddNewLicense()
		{
			this.LicenseID = clsDataAccessLicenses.AddNewLicense(this.ApplicationID, this.DriverID, this.LicenseClass,
				this.IssueDate, this.ExpirationDate, this.Notes, this.PaidFees, this.IsActive, this.IssueReason, this.CreatedByUserID);

			return (this.LicenseID != -1);
		}
		private bool _UpdateLicense()
		{
			return clsDataAccessLicenses.UpdateLicense(this.LicenseID, this.IsActive);
		}


		public clsBusinessLicenses()
		{
			LicenseID = -1;
			ApplicationID = -1;
			DriverID = -1;
			LicenseClass = -1;
			IssueDate = DateTime.MinValue;
			ExpirationDate = DateTime.MinValue;
			Notes = string.Empty;
			PaidFees = 0;
			IsActive = false;
			IssueReason = 0;
			CreatedByUserID = -1;

			_Mode = enMode.enAddNew;
		}
		private clsBusinessLicenses(int LicenseID, int ApplicationID, int DriverID, int LicenseClass,
			DateTime IssueDate, DateTime ExpirationDate, string Notes, decimal PaidFees, bool IsActive, byte IssueReason, int CreatedByUserID)
		{
			this.LicenseID = LicenseID;
			this.ApplicationID = ApplicationID;
			this.DriverID = DriverID;
			this.LicenseClass = LicenseClass;
			this.IssueDate = IssueDate;
			this.ExpirationDate = ExpirationDate;
			this.Notes = Notes;
			this.PaidFees = PaidFees;
			this.IsActive = IsActive;
			this.IssueReason = IssueReason;
			this.CreatedByUserID = CreatedByUserID;

			_Mode = enMode.enUpdate;
		}



		public static clsBusinessLicenses FindByLDLA_ID(int LDLA_ID)
		{
			int LicenseID = -1, ApplicationID = -1, DriverID = -1, LicenseClass = -1, CreatedByUserID = -1;
			DateTime IssueDate = DateTime.MinValue, ExpirationDate = DateTime.MinValue;
			string Notes = string.Empty;
			decimal PaidFees = 0;
			bool IsActive = false;
			byte IssueReason = 0;

			if (clsDataAccessLicenses.GetLicenseByLDLA_ID(LDLA_ID, ref LicenseID, ref ApplicationID, ref DriverID, ref LicenseClass,
				ref IssueDate, ref ExpirationDate, ref Notes, ref PaidFees, ref IsActive, ref IssueReason, ref CreatedByUserID))
			{
				return new clsBusinessLicenses(LicenseID, ApplicationID, DriverID, LicenseClass, IssueDate, ExpirationDate, Notes, PaidFees, IsActive, IssueReason, CreatedByUserID);
			}
			return null;
		}
		public static clsBusinessLicenses FindByLicenseID(int licenseID)
		{
			int ApplicationID = -1, DriverID = -1, LicenseClass = -1, CreatedByUserID = -1;
			DateTime IssueDate = DateTime.MinValue, ExpirationDate = DateTime.MinValue;
			string Notes = string.Empty;
			decimal PaidFees = 0;
			bool IsActive = false;
			byte IssueReason = 0;

			if (clsDataAccessLicenses.GetLicenseByLicenseID(licenseID, ref ApplicationID, ref DriverID, ref LicenseClass,
				ref IssueDate, ref ExpirationDate, ref Notes, ref PaidFees, ref IsActive, ref IssueReason, ref CreatedByUserID))
			{
				return new clsBusinessLicenses(licenseID, ApplicationID, DriverID, LicenseClass, IssueDate, ExpirationDate, Notes, PaidFees, IsActive, IssueReason, CreatedByUserID);
			}
			return null;
		}
		public bool Save()
		{
			switch (_Mode)
			{
				case enMode.enAddNew:
				{
					if (_AddNewLicense())
					{
						_Mode = enMode.enUpdate;
						return true;
					}
					else
					{
						return false;
					}
				}
				case enMode.enUpdate:
				{
					return _UpdateLicense();
				}
			}
			return false;
		}
		public static DataTable GetAllLocalLicensesForPerson(int personID)
		{
			return clsDataAccessLicenses.GetAllLocalLicensesForPerson(personID);
		}
		public static DataTable GetAllLocalLicensesForPerson(string nationalNo)
		{
			return clsDataAccessLicenses.GetAllLocalLicensesForPerson(nationalNo);
		}
	}
}
