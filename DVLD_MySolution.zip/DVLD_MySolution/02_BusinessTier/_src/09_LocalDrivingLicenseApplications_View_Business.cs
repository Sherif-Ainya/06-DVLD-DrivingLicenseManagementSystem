﻿using System.Data;
using DVLD_DataAccess;

namespace DVLD_Business
{
	public class clsBusinessLocalDrivingLicenseapplications_View
	{
		public static bool GetLDLA_ShortInfo(int LDLA_ID, ref string className, ref int passedTestCount)
		{
			return clsDataAccessLocalDrivingLicenseapplications_View.GetLDLA_ShortInfo(LDLA_ID, ref className, ref passedTestCount);
		}

		public static DataTable GetAllLocalDLApplications_View()
		{
			return clsDataAccessLocalDrivingLicenseapplications_View.GetAllLocalDLApplications_View();
		}
	}
}
