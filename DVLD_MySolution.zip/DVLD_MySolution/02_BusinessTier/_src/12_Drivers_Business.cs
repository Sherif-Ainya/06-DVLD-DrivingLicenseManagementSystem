﻿using System;
using System.Data;
using DVLD_DataAccess;

namespace DVLD_Business
{
	public class clsBusinessDrivers
	{
		private enum enMode { enAddNew, enUpdate };
		private enMode _Mode;
		public int DriverID { get; set; }
		public int PersonID { get; set; }
		public int CreatedByUser { get; set; }
		public DateTime CreatedDate { get; set; }


		private clsBusinessDrivers(int DriverID, int PersonID, int CreatedByUser, DateTime CreatedDate)
		{
			this.DriverID = DriverID;
			this.PersonID = PersonID;
			this.CreatedByUser = CreatedByUser;
			this.CreatedDate = CreatedDate;

			_Mode = enMode.enUpdate;
		}


		public static int IsPersonDriver(int PersonID)
		{
			return clsDataAccessDrivers.IsPersonDriver(PersonID);
		}
		public static int IsPersonDriver(string NationalNo)
		{
			return clsDataAccessDrivers.IsPersonDriver(NationalNo);
		}

		public static int AddNewDriver(int personID, int createdByUser)
		{
			return clsDataAccessDrivers.AddNewDriver(personID, createdByUser, DateTime.Now);
		}

		//

		public static clsBusinessDrivers Find(int DriverID)
		{
			int personID = -1, createdByUser = -1;
			DateTime createdDate = DateTime.MinValue;

			if (clsDataAccessDrivers.GetDriver(DriverID, ref personID, ref createdByUser, ref createdDate))
			{
				return new clsBusinessDrivers(DriverID, personID, createdByUser, createdDate);
			}
			return null;
		}
		public static DataTable GetAllDrivers()
		{
			return clsDataAccessDrivers.GetAllDrivers();
		}
	}
}
