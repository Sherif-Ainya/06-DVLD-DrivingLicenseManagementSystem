﻿using System;
using System.Data;
using DVLD_DataAccess;

namespace DVLD_Business
{
	public class clsBusinessTestAppointments
	{
		private enum enMode { enAddNew, enUpdate };
		private enMode _Mode;
		public int TestAppointmentID { get; set; }
		public int TestTypeID { get; set; }
		public int LDLA_ID { get; set; }
		public DateTime AppointmentDate { get; set; }
		public decimal PaidFees { get; set; }
		public int CreatedByUserID { get; set; }
		public bool IsLocked { get; set; }
		private bool _AddNewAppointment()
		{
			this.TestAppointmentID = clsDataAccessTestAppointments.AddNewAppointment(this.TestTypeID, this.LDLA_ID, this.AppointmentDate,
				this.PaidFees, this.CreatedByUserID, this.IsLocked);

			return (this.TestAppointmentID != -1);
		}
		private bool _UpdateAppointment()
		{
			return clsDataAccessTestAppointments.UpdateAppointment(this.TestAppointmentID, this.TestTypeID, this.LDLA_ID, this.AppointmentDate,
				this.PaidFees, this.CreatedByUserID, this.IsLocked);
		}


		public clsBusinessTestAppointments()
		{
			TestAppointmentID = -1;
			TestTypeID = -1;
			LDLA_ID = -1;
			AppointmentDate = DateTime.Now;
			PaidFees = 0;
			CreatedByUserID = -1;
			IsLocked = false;

			_Mode = enMode.enAddNew;
		}
		private clsBusinessTestAppointments(int TestAppointmentID, int TestTypeID, int LDLA_ID, DateTime AppointmentDate,
			decimal PaidFees, int CreatedByUserID, bool IsLocked)
		{
			this.TestAppointmentID = TestAppointmentID;
			this.TestTypeID = TestTypeID;
			this.LDLA_ID = LDLA_ID;
			this.AppointmentDate = AppointmentDate;
			this.PaidFees = PaidFees;
			this.CreatedByUserID = CreatedByUserID;
			this.IsLocked = IsLocked;

			_Mode = enMode.enUpdate;
		}


		public static bool HasActiveAppointment(int LDLA_ID, int TestTypeID)
		{
			return clsDataAccessTestAppointments.HasOpenAppointment(LDLA_ID, TestTypeID);
		}
		public static bool PassedThisTest(int LDLA_ID, int TestTypeID)
		{
			return clsDataAccessTestAppointments.PassedThisTest(LDLA_ID, TestTypeID);
		}

		public static clsBusinessTestAppointments GetTestAppointment(int TestAppointmentID)
		{
			int LDLA_ID = -1, TestTypeID = -1, CreatedByUserID = -1;
			DateTime AppointmentDate = DateTime.Now;
			decimal PaidFees = 0;
			bool IsLocked = false;

			if (clsDataAccessTestAppointments.GetTestAppointment(TestAppointmentID, ref TestTypeID, ref LDLA_ID,
					ref AppointmentDate, ref PaidFees, ref CreatedByUserID, ref IsLocked))
			{
				return new clsBusinessTestAppointments(TestAppointmentID, TestTypeID, LDLA_ID,
					AppointmentDate, PaidFees, CreatedByUserID, IsLocked);
			}
			return null;
		}
		public bool Save()
		{
			switch (_Mode)
			{
				case enMode.enAddNew:
				{
					if (_AddNewAppointment())
					{
						_Mode = enMode.enUpdate;
						return true;
					}
					else
					{
						return false;
					}
				}
				case enMode.enUpdate:
				{
					return _UpdateAppointment();
				}
			}
			return false;
		}
		public static DataTable GetAllAppointmentsOfLocalApp_TestType(int LDLA_ID, int TestTypeID)
		{
			return clsDataAccessTestAppointments.GetAllAppointmentsOfLocalApp_TestType(LDLA_ID, TestTypeID);
		}
	}
}
