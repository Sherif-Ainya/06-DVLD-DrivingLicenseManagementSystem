//! Full Real Project In C#.
// DVLD - Driving License Management.
// Database File - DVLD.

/*
  * Try to make Relational Schema Based on the 'DVLD_Requirements.pdf'.
  &
  * Then open SQL server new query and type:
"
  Restore Database DVLD
  From Disk = 'C:\Path\to\DVLD.bak';
"
*/
