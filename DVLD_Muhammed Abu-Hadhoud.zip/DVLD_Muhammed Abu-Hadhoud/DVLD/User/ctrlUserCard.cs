﻿using System.Windows.Forms;
using DVLD_Buisness;

namespace DVLD.Controls
{
		public partial class ctrlUserCard : UserControl
		{
				private clsUser _User;
				private int _UserID = -1;
				public int UserID
				{
						get { return _UserID; }
				}

				private void _ResetPersonInfo()
				{
						ctrlPersonCard1.ResetPersonInfo();
						lblUserID.Text = "[???]";
						lblUserName.Text = "[???]";
						lblIsActive.Text = "[???]";
				}
				private void _FillUserInfo()
				{
						ctrlPersonCard1.LoadPersonInfo(_User.PersonID);
						lblUserID.Text = _User.UserID.ToString();
						lblUserName.Text = _User.UserName.ToString();

						lblIsActive.Text = (_User.IsActive) ? "Yes." : "No";

						//if (_User.IsActive)
						//		lblIsActive.Text = "Yes";
						//else
						//		lblIsActive.Text = "No";
				}


				public ctrlUserCard()
				{
						InitializeComponent();
				}


				public void LoadUserInfo(int UserID)
				{
						_UserID = UserID;
						_User = clsUser.FindByUserID(UserID);

						if (_User == null)
						{
								_ResetPersonInfo();
								MessageBox.Show("No User with UserID = " + UserID.ToString(), "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
								return;
						}

						_FillUserInfo();
				}
		}
}
