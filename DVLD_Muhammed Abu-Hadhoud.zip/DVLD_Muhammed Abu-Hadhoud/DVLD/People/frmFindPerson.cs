﻿using System;
using System.Windows.Forms;
using DVLD_Buisness;

namespace DVLD.People
{
		public partial class frmFindPerson : Form
		{
				// Declare a delegate
				public delegate void DataBackEventHandler(object sender, int PersonID);
				public delegate void DataBackEventHandler2(object sender, clsPerson person);

				// Declare an event using the delegate
				public event DataBackEventHandler DataBack_ID;
				public event DataBackEventHandler2 DataBack_All;


				public frmFindPerson()
				{
						InitializeComponent();
				}

				private void btnClose_Click(object sender, EventArgs e)
				{
						this.Close();

						// Trigger the event to send data back to the caller form.
						DataBack_ID?.Invoke(this, ctrlPersonCardWithFilter1.PersonID);
						DataBack_All?.Invoke(this, ctrlPersonCardWithFilter1.SelectedPersonInfo);
				}
		}
}
