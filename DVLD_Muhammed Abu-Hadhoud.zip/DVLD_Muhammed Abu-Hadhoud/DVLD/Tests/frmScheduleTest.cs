﻿using System;
using System.Windows.Forms;
using DVLD_Buisness;

namespace DVLD.Tests
{
		public partial class frmScheduleTest : Form
		{
				private int _LocalDrivingLicenseApplicationID = -1;
				private clsTestType.enTestType _TestTypeID = clsTestType.enTestType.VisionTest;
				private int _AppointmentID = -1;


				public frmScheduleTest(int LocalDrivingLicenseApplicationID, clsTestType.enTestType TestTypeID, int AppointmentID = -1)
				{
						InitializeComponent();

						_LocalDrivingLicenseApplicationID = LocalDrivingLicenseApplicationID;
						_TestTypeID = TestTypeID;
						_AppointmentID = AppointmentID;
				}



				private void frmScheduleTest_Load(object sender, EventArgs e)
				{
						ctrlScheduleTest1.TestTypeID = _TestTypeID;
						ctrlScheduleTest1.LoadInfo(_LocalDrivingLicenseApplicationID, _AppointmentID);
				}

				//

				private void btnClose_Click(object sender, EventArgs e)
				{
						this.Close();
				}
		}
}
