﻿using System.Windows.Forms;
using DVLD.Classes;
using DVLD.People;
using DVLD_Buisness;

namespace DVLD.Controls.ApplicationControls
{
		public partial class ctrlApplicationBasicInfo : UserControl
		{
				private clsApplication _Application;
				private int _ApplicationID = -1;
				public int ApplicationID
				{
						get { return _ApplicationID; }
				}

				private void _FillApplicationInfo()
				{
						_ApplicationID = _Application.ApplicationID;
						lblApplicationID.Text = _Application.ApplicationID.ToString();
						lblStatus.Text = _Application.StatusText;
						lblType.Text = _Application.ApplicationTypeInfo.Title;
						lblFees.Text = _Application.PaidFees.ToString();
						lblApplicant.Text = _Application.ApplicantFullName;
						lblDate.Text = clsFormat.DateToShort(_Application.ApplicationDate);
						lblStatusDate.Text = clsFormat.DateToShort(_Application.LastStatusDate);
						lblCreatedByUser.Text = _Application.CreatedByUserInfo.UserName;
				}


				public ctrlApplicationBasicInfo()
				{
						InitializeComponent();
				}



				public void ResetApplicationInfo()
				{
						_ApplicationID = -1;

						lblApplicationID.Text = "[????]";
						lblStatus.Text = "[????]";
						lblType.Text = "[????]";
						lblFees.Text = "[????]";
						lblApplicant.Text = "[????]";
						lblDate.Text = "[????]";
						lblStatusDate.Text = "[????]";
						lblCreatedByUser.Text = "[????]";
				}

				//

				public void LoadApplicationInfo(int ApplicationID)
				{
						_Application = clsApplication.FindBaseApplication(ApplicationID);
						if (_Application == null)
						{
								ResetApplicationInfo();
								MessageBox.Show("No Application with ApplicationID = " + ApplicationID.ToString(), "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
						}
						else
								_FillApplicationInfo();
				}

				//

				private void llViewPersonInfo_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
				{
						frmShowPersonInfo frm = new frmShowPersonInfo(_Application.ApplicantPersonID);
						frm.ShowDialog();

						//Refresh
						LoadApplicationInfo(_ApplicationID);
				}
		}
}
