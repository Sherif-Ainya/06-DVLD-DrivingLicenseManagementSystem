﻿using System;
using System.Windows.Forms;
using DVLD_Buisness;

namespace DVLD.Applications
{
		public partial class frmListApplicationTypes : Form
		{
				//private DataTable _dtAllApplicationTypes;
				public frmListApplicationTypes()
				{
						InitializeComponent();
				}


				private void frmListApplicationTypes_Load(object sender, EventArgs e)
				{
						//_dtAllApplicationTypes = clsApplicationType.GetAllApplicationTypes();

						dgvApplicationTypes.DataSource = clsApplicationType.GetAllApplicationTypes();
						lblRecordsCount.Text = dgvApplicationTypes.Rows.Count.ToString();

						if (dgvApplicationTypes.Rows.Count > 0)
						{
								dgvApplicationTypes.Columns[0].HeaderText = "ID";
								dgvApplicationTypes.Columns[0].Width = 110;

								dgvApplicationTypes.Columns[1].HeaderText = "Title";
								dgvApplicationTypes.Columns[1].Width = 400;

								dgvApplicationTypes.Columns[2].HeaderText = "Fees";
								dgvApplicationTypes.Columns[2].Width = 100;
						}
				}

				private void editToolStripMenuItem_Click(object sender, EventArgs e)
				{
						frmEditApplicationType frm = new frmEditApplicationType((int)dgvApplicationTypes.CurrentRow.Cells[0].Value);
						frm.ShowDialog();
						frmListApplicationTypes_Load(null, null);
				}

				//

				private void btnClose_Click(object sender, EventArgs e)
				{
						this.Close();
				}
		}
}
